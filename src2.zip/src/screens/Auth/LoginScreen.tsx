import {
  View,
  Text,
  SafeAreaView,
  ImageBackground,
  TouchableOpacity,
  Image,
  Keyboard,
  TextInput,
  Pressable,
} from "react-native";
import React, { useState } from "react";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { colors, images } from "../../config";
import { heightPercentageToDP as hp } from "react-native-responsive-screen";
import AuthBody from "./CommonComponent/AuthBody";
import Button from "../../components/Button/Button";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { loginAction } from "../../actions";
import { Controller, FormProvider, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { schema, LoginSchema } from "./schema";
import { FormFieldError } from "../../components/Error/form-field-error";
import Loader from "../../components/Loader/Loader";

const LoginScreen = ({ navigation }: any) => {
  const form = useForm<LoginSchema>({
    resolver: zodResolver(schema),
    reValidateMode: "onChange",
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const {
    control,
    getValues,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = form;
  
  const [showPassword, setshowPassword] = useState(true);
  const [isChecked, setIsChecked] = useState(false);
  const [isloading, setIsLoading] = useState(false);

  const onSubmit = async (data: LoginSchema) => {
    try {
      setIsLoading(true);
      const response = await loginAction(data);
      await AsyncStorage.setItem("authToken", response.user.data.token);
      await AsyncStorage.setItem("user", JSON.stringify(response.user.data.user));
      await AsyncStorage.setItem(
        "refreshToken",
        response.user.data.refreshToken
      );
      setIsLoading(false);
      navigation.navigate("HomeDashboardScreen");
    } catch (error) {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaProvider>
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.white }}>
        <ImageBackground
          source={images.loginHeader}
          resizeMode="cover"
          style={{ flex: 0.175, padding: hp(2) }}
        >
          <View
            style={{
              borderColor: "red",
              borderWidth: 0,
              width: "100%",
              padding: hp(1),
            }}
          >
            <TouchableOpacity
              onPress={() => {
                navigation.pop();
              }}
              style={{
                marginTop: hp(4),
                backgroundColor: colors.headerBackColor,
                borderRadius: 8,
                padding: hp(1.25),
                alignSelf: "flex-start",
              }}
            >
              <Image
                source={images.acnBackArrow}
                style={{ width: hp(1.125), height: hp(1.75) }}
              />
            </TouchableOpacity>
          </View>
        </ImageBackground>
        <View
          style={{
            borderColor: "red",
            borderWidth: 0,
            flex: 1,
            marginTop: hp(-2.5),
            padding: hp(3),
            borderTopLeftRadius: 25,
            borderTopRightRadius: 25,
            backgroundColor: colors.white,
          }}
        >
          <AuthBody
            title={"Welcome back!"}
            discription={"Enter username and password below"}
          >
            <FormProvider {...form}>
              <View
                style={{
                  marginBottom: hp(0),
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "flex-start",
                  flexDirection: "row",
                  width: "100%",
                  borderColor: colors.inputBorder,
                  borderWidth: 1,
                  backgroundColor: colors.inputBgColor,
                  borderRadius: 8,
                  marginVertical: hp(3),
                  paddingHorizontal: hp(1),
                  padding: hp(0.5),
                  paddingBottom: 0,
                }}
              >
                <Controller
                  control={control}
                  name="email"
                  render={({ field: { onChange, value } }) => (
                    <TextInput
                      style={{
                        fontSize: hp(1.75),
                        width: "90%",
                        color: colors.black,
                        marginLeft: hp(1),
                      }}
                      onSubmitEditing={() => {
                        Keyboard.dismiss();
                      }}
                      onChangeText={onChange}
                      value={value}
                      placeholderTextColor={colors.inputPlaceHolderColor}
                      placeholder={"Enter your email"}
                      keyboardType="default"
                    />
                  )}
                />
              </View>
              <FormFieldError name="email" />
            </FormProvider>
            <FormProvider {...form}>
              <View
                style={{
                  marginTop: hp(2),
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "flex-start",
                  flexDirection: "row",
                  width: "100%",
                  borderColor: colors.inputBorder,
                  borderWidth: 1,
                  backgroundColor: colors.inputBgColor,
                  borderRadius: 8,
                  paddingHorizontal: hp(1),
                  padding: hp(0.5),
                }}
              >
                <Controller
                  control={control}
                  name="password"
                  render={({ field: { onChange, value } }) => (
                    <TextInput
                      style={{
                        fontSize: hp(1.75),
                        width: "90%",
                        color: colors.textMuted,
                        marginLeft: hp(1),
                      }}
                      onSubmitEditing={() => {
                        Keyboard.dismiss();
                      }}
                      onChangeText={onChange}
                      value={value}
                      placeholderTextColor={colors.inputPlaceHolderColor}
                      placeholder={"Enter your password"}
                      keyboardType="default"
                      secureTextEntry={showPassword}
                    />
                  )}
                />
                <Pressable
                  onPress={() => {
                    setshowPassword(!showPassword);
                  }}
                >
                  <Image
                    source={images.showPassword}
                    style={{
                      width: hp(2.5),
                      height: hp(2),
                      marginLeft: hp(-1.5),
                    }}
                  />
                </Pressable>
              </View>
              <FormFieldError name="password" />
            </FormProvider>
            {/* Remember me and forgot password */}
            <View
              style={{
                marginBottom: hp(2),
                marginTop: hp(2),
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                borderColor: "green",
                borderWidth: 0,
              }}
            >
              <View
                style={{
                  width: "60%",
                  borderColor: "red",
                  borderWidth: 0,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "flex-start",
                  flexDirection: "row",
                }}
              >
                <TouchableOpacity
                  style={{
                    width: 20,
                    height: 20,
                    borderWidth: 2,
                    borderRadius: 4,
                    alignItems: "center",
                    justifyContent: "center",
                    marginHorizontal: hp(1),
                    borderColor: isChecked ? colors.primary : "gray",
                  }}
                  onPress={() => setIsChecked(!isChecked)}
                >
                  {isChecked && (
                    <View
                      style={{
                        width: 14,
                        height: 14,
                        backgroundColor: colors.primary,
                      }}
                    />
                  )}
                </TouchableOpacity>
                <Text
                  style={{
                    textAlign: "left",
                    color: colors.textGray,
                    fontWeight: "600",
                  }}
                >
                  Remember me
                </Text>
              </View>
              <TouchableOpacity
                onPress={() => {
                  navigation.navigate("ForgotPassword");
                }}
              >
                <Text
                  style={{
                    color: colors.forgotPasswordColor,
                    fontWeight: "600",
                  }}
                >
                  Forgot password?
                </Text>
              </TouchableOpacity>
            </View>
            {/* LoginButton */}
            <View
              style={{
                width: "100%",
                borderColor: "red",
                borderWidth: 0,
                marginTop: hp(2),
                padding: hp(2),
                height: hp(11),
              }}
            >
              <Button
              disable={false}
                type={0}
                text={"Log In"}
                handlePress={handleSubmit(onSubmit)}
              />
            </View>
            {isloading && <Loader />}
          </AuthBody>
        </View>
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

export default LoginScreen;
