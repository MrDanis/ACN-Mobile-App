import { z } from "zod";
const signupschema = z
  .object({
    firstName: z.string().min(1, "First name is required"),
    lastName: z.string().min(1, "Last name is required"),
    email: z.string().trim().min(1, "Email is required").email(),
    phoneNo: z.string().min(1, "Phone no is required"),
    password: z.string().min(1, "Password is required"),
    confirmPassword: z.string().min(1, "Confirm password is required"),
    treatyNo: z
      .string()
      .length(9, "Treaty number must be exactly 9 characters long"),
    drivingLicenseNo: z
      .string()
      .length(15, "Driving License must be exactly 15 characters long")
      .regex(
        /^[a-zA-Z0-9]+$/,
        "Driving License must contain only letters and numbers"
      ),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });
export type SignUpSchema = z.infer<typeof signupschema>;
export { signupschema };
