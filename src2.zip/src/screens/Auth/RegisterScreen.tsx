import {
  View,
  Text,
  SafeAreaView,
  ImageBackground,
  TouchableOpacity,
  Image,
  Keyboard,
  TextInput,
  Pressable,
  Alert,
  KeyboardAvoidingView,
  ScrollView,
  Platform,
  StyleSheet,
} from "react-native";
import React, { useState } from "react";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { colors, images } from "../../config";
import { heightPercentageToDP as hp } from "react-native-responsive-screen";
import AuthBody from "./CommonComponent/AuthBody";
import Button from "../../components/Button/Button";
import { any } from "zod";
import { signupschema, SignUpSchema } from "./signupschema";
import { Controller, FormProvider, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { FormFieldError } from "../../components/Error/form-field-error";
import { signupAction } from "../../actions";
import Loader from "../../components/Loader/Loader";
import AsyncStorage from "@react-native-async-storage/async-storage";
const RegisterScreen = ({ navigation }: any) => {
  const form = useForm<SignUpSchema>({
    resolver: zodResolver(signupschema),
    reValidateMode: "onChange",
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phoneNo: "",
      password: "",
      confirmPassword: "",
      treatyNo: "",
      drivingLicenseNo: "",
    },
  });

  const {
    control,
    getValues,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = form;

  const [showPassword, setshowPassword] = useState(true);
  const [showConfirmPassword, setshowConfirmPassword] = useState(true);
  const [isloading, setIsLoading] = useState(false);

  const onSubmit = async (data: SignUpSchema) => {
    try {
      console.log(data);
      await AsyncStorage.clear();
      setIsLoading(true);
      const response = await signupAction(data);
      console.log(response, "signup api response");
      setIsLoading(false);
      navigation.navigate("LoginScreen")
    } catch (error) {
      setIsLoading(false);
      console.log(error);
    }
  };
  return (
    <SafeAreaProvider>
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.white }}>
        <ImageBackground
          source={images.loginHeader}
          resizeMode="cover"
          style={{ flex: 0.175, padding: hp(2) }}
        >
          <View
            style={{
              borderColor: "red",
              borderWidth: 0,
              width: "100%",
              padding: hp(1),
            }}
          >
            <TouchableOpacity
              onPress={() => {
                navigation.pop();
              }}
              style={{
                marginTop: hp(4),
                backgroundColor: colors.headerBackColor,
                borderRadius: 8,
                padding: hp(1.25),
                alignSelf: "flex-start",
              }}
            >
              <Image
                source={images.acnBackArrow}
                style={{ width: hp(1.125), height: hp(1.75) }}
              />
            </TouchableOpacity>
          </View>
        </ImageBackground>
        <View
          style={{
            borderColor: "red",
            borderWidth: 0,
            flex: 1,
            marginTop: hp(-2.5),
            padding: hp(3),
            borderTopLeftRadius: 25,
            borderTopRightRadius: 25,
            backgroundColor: colors.white,
          }}
        >
          <AuthBody
            title={"Hi!"}
            discription={"Enter details below to register"}
          >
            <KeyboardAvoidingView
              behavior={Platform.OS === "ios" ? "padding" : undefined}
            >
              <ScrollView contentContainerStyle={styles.scrollContainer}>
                <FormProvider {...form}>
                  <View
                    style={{
                      marginTop: hp(3),
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "flex-start",
                      flexDirection: "row",
                      width: "100%",
                      borderColor: colors.inputBorder,
                      borderWidth: 1,
                      backgroundColor: colors.inputBgColor,
                      borderRadius: 8,
                      paddingHorizontal: hp(1),
                      padding: hp(0.5),
                    }}
                  >
                    <Controller
                      control={control}
                      name="firstName"
                      render={({ field: { onChange, value } }) => (
                        <TextInput
                          style={{
                            fontSize: hp(1.75),
                            width: "90%",
                            color: colors.black,
                            marginLeft: hp(1),
                          }}
                          onSubmitEditing={() => {
                            Keyboard.dismiss();
                          }}
                          onChangeText={onChange}
                          value={value}
                          placeholderTextColor={colors.inputPlaceHolderColor}
                          placeholder={"Enter your first name"}
                          keyboardType="default"
                        />
                      )}
                    />
                  </View>
                  <FormFieldError name="firstname" />
                </FormProvider>

                <FormProvider {...form}>
                  <View
                    style={{
                      marginTop: hp(3),
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "flex-start",
                      flexDirection: "row",
                      width: "100%",
                      borderColor: colors.inputBorder,
                      borderWidth: 1,
                      backgroundColor: colors.inputBgColor,
                      borderRadius: 8,
                      paddingHorizontal: hp(1),
                      padding: hp(0.5),
                    }}
                  >
                    <Controller
                      control={control}
                      name="lastName"
                      render={({ field: { onChange, value } }) => (
                        <TextInput
                          style={{
                            fontSize: hp(1.75),
                            width: "90%",
                            color: colors.black,
                            marginLeft: hp(1),
                          }}
                          onSubmitEditing={() => {
                            Keyboard.dismiss();
                          }}
                          onChangeText={onChange}
                          value={value}
                          placeholderTextColor={colors.inputPlaceHolderColor}
                          placeholder={"Enter your last name"}
                          keyboardType="default"
                        />
                      )}
                    />
                  </View>
                  <FormFieldError name="lastname" />
                </FormProvider>

                <FormProvider {...form}>
                  <View
                    style={{
                      marginTop: hp(2),
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "flex-start",
                      flexDirection: "row",
                      width: "100%",
                      borderColor: colors.inputBorder,
                      borderWidth: 1,
                      backgroundColor: colors.inputBgColor,
                      borderRadius: 8,
                      paddingHorizontal: hp(1),
                      padding: hp(0.5),
                    }}
                  >
                    <Controller
                      control={control}
                      name="email"
                      render={({ field: { onChange, value } }) => (
                        <TextInput
                          style={{
                            fontSize: hp(1.75),
                            width: "90%",
                            color: colors.black,
                            marginLeft: hp(1),
                          }}
                          onSubmitEditing={() => {
                            Keyboard.dismiss();
                          }}
                          onChangeText={onChange}
                          value={value}
                          placeholderTextColor={colors.inputPlaceHolderColor}
                          placeholder={"Enter your email"}
                          keyboardType="default"
                        />
                      )}
                    />
                  </View>
                  <FormFieldError name="email" />
                </FormProvider>

                <FormProvider {...form}>
                  <View
                    style={{
                      marginTop: hp(2),
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "flex-start",
                      flexDirection: "row",
                      width: "100%",
                      borderColor: colors.inputBorder,
                      borderWidth: 1,
                      backgroundColor: colors.inputBgColor,
                      borderRadius: 8,
                      paddingHorizontal: hp(1),
                      padding: hp(0.5),
                    }}
                  >
                    <Controller
                      control={control}
                      name="phoneNo"
                      render={({ field: { onChange, value } }) => (
                        <TextInput
                          style={{
                            fontSize: hp(1.75),
                            width: "90%",
                            color: colors.black,
                            marginLeft: hp(1),
                          }}
                          onSubmitEditing={() => {
                            Keyboard.dismiss();
                          }}
                          onChangeText={onChange}
                          value={value}
                          placeholderTextColor={colors.inputPlaceHolderColor}
                          placeholder={"Enter your phoneNo"}
                          keyboardType="default"
                        />
                      )}
                    />
                  </View>
                  <FormFieldError name="phoneNo" />
                </FormProvider>

                <FormProvider {...form}>
                  <View
                    style={{
                      marginTop: hp(2),
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "flex-start",
                      flexDirection: "row",
                      width: "100%",
                      borderColor: colors.inputBorder,
                      borderWidth: 1,
                      backgroundColor: colors.inputBgColor,
                      borderRadius: 8,
                      paddingHorizontal: hp(1),
                      padding: hp(0.5),
                    }}
                  >
                    <Controller
                      control={control}
                      name="treatyNo"
                      render={({ field: { onChange, value } }) => (
                        <TextInput
                          style={{
                            fontSize: hp(1.75),
                            width: "90%",
                            color: colors.black,
                            marginLeft: hp(1),
                          }}
                          onSubmitEditing={() => {
                            Keyboard.dismiss();
                          }}
                          onChangeText={onChange}
                          value={value}
                          placeholderTextColor={colors.inputPlaceHolderColor}
                          placeholder={"Enter your treatyNo"}
                          keyboardType="default"
                        />
                      )}
                    />
                  </View>
                  <FormFieldError name="treatyNo" />
                </FormProvider>

                <FormProvider {...form}>
                  <View
                    style={{
                      marginTop: hp(2),
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "flex-start",
                      flexDirection: "row",
                      width: "100%",
                      borderColor: colors.inputBorder,
                      borderWidth: 1,
                      backgroundColor: colors.inputBgColor,
                      borderRadius: 8,
                      paddingHorizontal: hp(1),
                      padding: hp(0.5),
                    }}
                  >
                    <Controller
                      control={control}
                      name="drivingLicenseNo"
                      render={({ field: { onChange, value } }) => (
                        <TextInput
                          style={{
                            fontSize: hp(1.75),
                            width: "90%",
                            color: colors.black,
                            marginLeft: hp(1),
                          }}
                          onSubmitEditing={() => {
                            Keyboard.dismiss();
                          }}
                          onChangeText={onChange}
                          value={value}
                          placeholderTextColor={colors.inputPlaceHolderColor}
                          placeholder={"Enter your drivingLicenseNo"}
                          keyboardType="default"
                        />
                      )}
                    />
                  </View>
                  <FormFieldError name="drivingLicenseNo" />
                </FormProvider>

                <FormProvider {...form}>
                  <View
                    style={{
                      marginTop: hp(2),
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "flex-start",
                      flexDirection: "row",
                      width: "100%",
                      borderColor: colors.inputBorder,
                      borderWidth: 1,
                      backgroundColor: colors.inputBgColor,
                      borderRadius: 8,
                      paddingHorizontal: hp(1),
                      padding: hp(0.5),
                    }}
                  >
                    <Controller
                      control={control}
                      name="password"
                      render={({ field: { onChange, value } }) => (
                        <TextInput
                          style={{
                            fontSize: hp(1.75),
                            width: "90%",
                            color: colors.black,
                            marginLeft: hp(1),
                          }}
                          onSubmitEditing={() => {
                            Keyboard.dismiss();
                          }}
                          onChangeText={onChange}
                          value={value}
                          placeholder={"Enter your password"}
                          keyboardType="default"
                          secureTextEntry={showPassword}
                        />
                      )}
                    />
                    <Pressable
                      onPress={() => {
                        setshowPassword(!showPassword);
                      }}
                    >
                      <Image
                        source={images.showPassword}
                        style={{
                          width: hp(2.5),
                          height: hp(2),
                          marginLeft: hp(-1.5),
                        }}
                      />
                    </Pressable>
                  </View>
                  <FormFieldError name="password" />
                </FormProvider>

                <FormProvider {...form}>
                  <View
                    style={{
                      marginTop: hp(2),
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "flex-start",
                      flexDirection: "row",
                      width: "100%",
                      borderColor: colors.inputBorder,
                      borderWidth: 1,
                      backgroundColor: colors.inputBgColor,
                      borderRadius: 8,
                      paddingHorizontal: hp(1),
                      padding: hp(0.5),
                    }}
                  >
                    <Controller
                      control={control}
                      name="confirmPassword"
                      render={({ field: { onChange, value } }) => (
                        <TextInput
                          style={{
                            fontSize: hp(1.75),
                            width: "90%",
                            color: colors.black,
                            marginLeft: hp(1),
                          }}
                          onSubmitEditing={() => {
                            Keyboard.dismiss();
                          }}
                          onChangeText={onChange}
                          value={value}
                          placeholderTextColor={colors.inputPlaceHolderColor}
                          placeholder={"Enter confirm password"}
                          keyboardType="default"
                          secureTextEntry={showConfirmPassword}
                        />
                      )}
                    />
                    <Pressable
                      onPress={() => {
                        setshowConfirmPassword(!showConfirmPassword);
                      }}
                    >
                      <Image
                        source={images.showPassword}
                        style={{
                          width: hp(2.5),
                          height: hp(2),
                          marginLeft: hp(-1.5),
                        }}
                      />
                    </Pressable>
                  </View>
                  <FormFieldError name="confirmPassword" />
                </FormProvider>
                {/* LoginButton */}
                <View
                  style={{
                    width: "100%",
                    borderColor: "red",
                    borderWidth: 0,
                    marginTop: hp(2),
                    padding: hp(2),
                    height: hp(11),
                  }}
                >
                  <Button
                    type={0}
                    text={"Register"}
                    handlePress={handleSubmit(onSubmit)}
                  />
                </View>
              </ScrollView>
            </KeyboardAvoidingView>
          </AuthBody>
        </View>
        {isloading && <Loader />}
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

export default RegisterScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    paddingBottom: 100,
  },
});
