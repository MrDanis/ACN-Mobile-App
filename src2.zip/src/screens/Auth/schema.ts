import { z } from "zod";

const schema = z.object({
  email: z.string().trim().min(1, "Email is required").email(),
  password: z.string().trim().min(1, "Password is required"),
});
export type LoginSchema = z.infer<typeof schema>;

export { schema };
