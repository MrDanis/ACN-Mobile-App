import {useNavigation} from '@react-navigation/native';
import React, {useEffect, useState} from 'react';
import {
  View,
  StyleSheet,
  Text,
  ActivityIndicator,
  PermissionsAndroid,
  Platform,
  Alert,
  BackHandler
} from 'react-native';
import {WebView} from 'react-native-webview';

const WebViewScreen = ({navigation,route}:any) => {
  const {url} = route.params; // Get the URL from navigation params
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Request permissions when the component is mounted
    const requestPermissions = async () => {
      if (Platform.OS === 'android') {
        try {
          const granted = await PermissionsAndroid.requestMultiple([
            PermissionsAndroid.PERMISSIONS.CAMERA,
            PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
          ]);

          const cameraGranted =
            granted[PermissionsAndroid.PERMISSIONS.CAMERA] ===
            PermissionsAndroid.RESULTS.GRANTED;
          const micGranted =
            granted[PermissionsAndroid.PERMISSIONS.RECORD_AUDIO] ===
            PermissionsAndroid.RESULTS.GRANTED;

          if (!cameraGranted || !micGranted) {
            Alert.alert(
              'Permissions Required',
              'Both Camera and Microphone permissions are required for the video call to work. Please enable them in your settings.',
              [{text: 'OK'}],
            );
          }
        
        } catch (err) {
          console.warn(err);
        }
      }
    };

    requestPermissions();
  }, []);

  const handleLoadStart = () => setLoading(true);
  const handleLoadEnd = () => {
    setLoading(false);
    // navigation.pop(2);

};

  return (
    <View style={{flex: 1, marginTop: (Platform.OS === 'ios' && 50) || 0}}>
      {loading && (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#0000ff" />
          <Text>Loading...</Text>
        </View>
      )}
      {/* WebView component that will load the URL */}
      <WebView
        source={{uri: url}}
        style={{flex: 1}}
        onLoadStart={handleLoadStart}
        onLoadEnd={handleLoadEnd}
        javaScriptEnabled={true}
        domStorageEnabled={true}
        mediaPlaybackRequiresUserAction={false}
        allowsInlineMediaPlayback={true}
        onError={() => {Alert.alert('Failed to load web page.')}}
        onHttpError={syntheticEvent => {
          const {nativeEvent} = syntheticEvent;
          Alert.alert(`HTTP Error: ${nativeEvent.statusCode}`);
        }}
      />
    </View>
  );
};

export default WebViewScreen;

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
