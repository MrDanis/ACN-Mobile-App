import {
    View,
    Modal,
    StyleSheet,
    Dimensions,
    Text,
    TouchableOpacity,
    Alert
  } from 'react-native';
  import React,{useState,useEffect, useCallback} from 'react';
  import { joinIncommingCall } from '../../actions/chatAction';
import { useFocusEffect } from '@react-navigation/native';
  const CommingCallModal = ({navigation,route}:any) => {
    const [show,setshow] = useState(true);
    const [name,setname] =  useState('');
    const [incomingCallURL,setincomingCallURL] = useState('');
    const onCancel = () =>{
        setshow(false);
        navigation.pop();
    }
    const onConfirm = ()=>{
        if (incomingCallURL) {
            setshow(false); // Close modal if open
            navigation.navigate('WebViewScreen', {url: incomingCallURL}); // Navigate to the WebView screen with the URL
          } else {
            console.error('No URL found in the response');
            Alert.alert('Something went wrong. No URL found in the response.');
          }
    }
    const handleCall = async (data:any) => {
        console.log('Incoming call data:', data);
    
        const payload = {
          userId: data?.id,
          roomId: data?.roomId,
          type: data?.type,
        };
    
        console.log('Sending Payload:', payload);
        const incommingCall = await joinIncommingCall(payload);  
        let incommingCallUrl = incommingCall?.incommingCallStatus?.url
        if(incommingCallUrl)
        {
            setname(data?.sender);
            setincomingCallURL(incommingCallUrl)
            setshow(true);
        }
      };
      useEffect(()=>{
        handleCall(route?.params?.data);
      },[]);
      useFocusEffect(
        useCallback(() => {
          if (!show) {
            // This will run when user comes back and modal was closed
            navigation.pop(); // or pop(2) if needed
          }
        }, [show])
      );
    return (
      <Modal visible={show} transparent>
        <View style={styles.modalView}>
          <View style={styles.mainView}>
            <Text style={styles.title}>Incoming Call</Text>
            <View style={styles.separator} />
            <Text style={styles.message}>
              {name} {'\n'} is calling you
            </Text>
  
            <View style={styles.buttonContainer}>
              <TouchableOpacity style={styles.confirmButton} onPress={onConfirm}>
                <Text style={styles.buttonText}>Accept</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.cancelButton} onPress={onCancel}>
                <Text style={{...styles.buttonText, color: 'black'}}>Reject</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    );
  };
  
  export default CommingCallModal;
  
  const styles = StyleSheet.create({
    modalView: {
      height: Dimensions.get('window').height,
      width: Dimensions.get('window').width,
      backgroundColor: 'rgba(0,0,0,0.6)',
      justifyContent: 'center',
      alignItems: 'center',
    },
    mainView: {
      height: 250,
      width: '80%',
      borderRadius: 10,
      backgroundColor: '#fff',
      padding: 15,
    },
    title: {
      fontSize: 20,
      //   marginLeft: 10,
      marginTop: 10,
      fontWeight: 'bold',
      textAlign: 'center',
    },
    separator: {
      height: 1,
      backgroundColor: '#ccc',
      marginVertical: 10,
    },
    message: {
      fontSize: 16,
      marginHorizontal: 10,
      textAlign: 'center',
    },
    note: {
      fontSize: 14,
      marginHorizontal: 10,
      textAlign: 'center',
      color: 'red',
    },
    buttonContainer: {
      flexDirection: 'row',
      width: '80%',
      marginTop: 20,
      justifyContent: 'space-between',
      alignSelf: 'center',
    },
    confirmButton: {
      backgroundColor: '#6b21a8',
      height: 40,
      width: 100,
      borderRadius: 5,
      alignItems: 'center',
      justifyContent: 'center',
    },
    cancelButton: {
      backgroundColor: '#d91f07',
      height: 40,
      width: 100,
      borderRadius: 5,
      alignItems: 'center',
      justifyContent: 'center',
      borderWidth: 1,
    },
    buttonText: {
      textAlign: 'center',
      color: 'white',
      fontWeight: 'bold',
      fontSize: 16,
    },
  });
  