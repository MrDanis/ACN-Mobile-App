import {
  View,
  Text,
  Image,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Linking,
} from "react-native";
import React, { useEffect, useState } from "react";
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from "react-native-responsive-screen";
import MainLayout from "../../layout/MainLayout";
import Icon from "react-native-vector-icons/FontAwesome";
import moment from "moment";
import { NEXT_PUBLIC_BUCKET_URL } from "@env";
import Loader from "../../components/Loader/Loader";
import RenderHTML from "react-native-render-html";

export default function NewsDetailScreen({ route, navigation }: any) {
  const [article, setArticle] = useState<any>();
  const [isLoading, setIsLoading] = useState(false);
  useEffect(() => {
    setIsLoading(true);
    const data = route.params;
    setArticle(data.article);
    setIsLoading(false);
  }, []);

  const handlePress = (URL: any) => {
    // Open the URL in the default browser
    Linking.openURL(URL).catch((err) =>
      console.error("Failed to open URL:", err)
    );
  };
  return (
    <MainLayout navigation={navigation} activeTabIndex={3}>
      <ScrollView style={styles.scrollView}>
        {article?.attachments?.length > 0 && (
          <Image
            source={{
              uri: `${NEXT_PUBLIC_BUCKET_URL}/${article.attachments[0].file.path}`,
            }}
            style={styles.mainImage}
          />
        )}

        <View style={styles.categoryContainer}>
          <Image
            source={require("../../assets/Images/News/Frame.png")}
            style={styles.categoryIcon}
          />
          <Text style={styles.categoryText}>
            Author:{" "}
            {`${article?.author?.firstName} ${article?.author?.lastName}`}
          </Text>
        </View>
        <Text style={styles.title}>{article?.title}</Text>
        <Text style={styles.author}>{article?.category?.title || "News"}</Text>
        <Text style={styles.metaInfo}>
          {moment(article?.createdAt).format("MMMM D, YYYY · h:mm A")}
        </Text>
        <View style={styles.socialIconsContainer}>
          <TouchableOpacity
            onPress={() => {
              handlePress("https://www.linkedin.com/company/nomadstrategies/");
            }}
          >
            <Icon name="twitter" size={20} color="#888888" />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              handlePress("https://www.facebook.com/nomadcreativestrategies/");
            }}
          >
            <Icon name="facebook" size={20} color="#888888" />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              handlePress("https://www.instagram.com/nomad_strategies/?hl=en");
            }}
          >
            <Icon name="instagram" size={20} color="#888888" />
          </TouchableOpacity>
        </View>
        <Text style={styles.contentText}>
          <RenderHTML
            source={{
              html: article?.body
                ? article?.body
                    .replace(/^"|"$/g, "")
                    .replace(/\n+/g, " ")
                    .replace(/<p>\s*<\/p>/g, "")
                    .trim()
                : "...",
            }}
            baseStyle={{
              color: "#4A4A4A",
              fontSize: 15,
              marginTop: 0,
              marginBottom: 0,
              paddingTop: 0,
              paddingBottom: 0,
              lineHeight: 18,
            }}
            tagsStyles={{
              p: {
                margin: 0,
                paddingVertical: 5,
              },
            }}
          />
        </Text>
      </ScrollView>
      {isLoading && <Loader />}
    </MainLayout>
  );
}

const styles = StyleSheet.create({
  scrollView: {
    paddingBottom: hp(14),
    backgroundColor: "#fff",
  },
  mainImage: {
    width: "100%",
    height: hp(25),
    resizeMode: "cover",
  },
  categoryContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: hp(2),
    marginHorizontal: wp(4),
  },
  categoryIcon: {
    width: wp(4.5),
    height: wp(4.5),
    resizeMode: "contain",
    marginRight: wp(2),
  },
  categoryText: {
    color: "#8E5C2A",
    fontWeight: "bold",
    fontSize: hp(2),
  },
  title: {
    fontSize: hp(2.4),
    fontWeight: "bold",
    marginTop: hp(1),
    marginHorizontal: wp(4),
  },
  author: {
    marginHorizontal: wp(4),
    marginTop: hp(1),
    fontSize: hp(1.8),
    color: "#000",
  },
  metaInfo: {
    marginTop: hp(1),
    marginHorizontal: wp(4),
    fontSize: hp(1.6),
    color: "#888",
  },
  socialIconsContainer: {
    flexDirection: "row",
    marginTop: hp(1),
    marginHorizontal: wp(4),
    width: "25%",
    marginBottom: hp(2),
    justifyContent: "space-between",
  },
  contentText: {
    fontSize: hp(1.9),
    color: "#333",
    lineHeight: hp(3.1),
    marginHorizontal: wp(4),
    marginBottom: hp(3),
  },
  underlinedText: {
    textDecorationLine: "underline",
  },
});
