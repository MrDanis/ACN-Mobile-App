import React from "react";
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  SafeAreaView,
} from "react-native";
import Icon from "react-native-vector-icons/Feather";
import { heightPercentageToDP as hp } from "react-native-responsive-screen";
import MainLayout from "../../layout/MainLayout";
import { colors } from "../../config";

const recentNews = [
  {
    id: 1,
    image: "https://picsum.photos/id/1/200/300",
    source: "Microsoft",
    readTime: "5 min read",
    title: "Meet Microsoft Office’s new default font: Aptos",
    date: "April 14, 2025",
  },
  {
    id: 2,
    image: "https://picsum.photos/id/1015/200/300",
    source: "The Verge",
    readTime: "3 min read",
    title: "Nothing Phone 2 review: the vibes abide",
    date: "April 13, 2025",
  },
];

const recommendedNews = [
  {
    id: 1,
    image: "https://picsum.photos/id/1025/200/300",
    source: "Film",
    readTime: "7 min read",
    title: "Christopher Nolan wants Oppenheimer to be a cautionary tale",
    date: "April 13, 2025",
  },
  {
    id: 2,
    image: "https://picsum.photos/id/1040/200/300",
    source: "SpaceX",
    readTime: "7 min read",
    title: "SpaceX Starship launch: test flight explosive ending!",
    date: "April 13, 2025",
  },
];

export default function NewsAllCategories({ navigation }: any) {
  const renderCard = (item: any) => (
    <TouchableOpacity key={item.id} style={styles.card}>
      <Image source={{ uri: item.image }} style={styles.cardImage} />
      <Text style={styles.source}>
        {item.source} • {item.readTime}
      </Text>
      <Text style={styles.title} numberOfLines={2}>
        {item.title}
      </Text>
      <View style={styles.footer}>
        <Text style={styles.date}>{item.date}</Text>
        <Icon name="bookmark" size={18} color="#797979" />
      </View>
    </TouchableOpacity>
  );

  return (
    <MainLayout navigation={navigation} activeTabIndex={5}>
      <SafeAreaView style={{ flex: 1 }}>
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{
            paddingBottom: hp(5),
            backgroundColor: "#fff",
          }}
        >
          {/* recent news */}
          <View style={styles.header}>
            <Text style={styles.headerTitle}>Recent News</Text>
            <TouchableOpacity disabled={true}>
              <Text style={styles.headerLink}>View more</Text>
            </TouchableOpacity>
          </View>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={{ paddingHorizontal: hp(2) }}
          >
            {recentNews.map(renderCard)}
          </ScrollView>
          {/* recommended */}
          <View style={styles.header}>
            <Text style={styles.headerTitle}>Recommended</Text>
            <TouchableOpacity disabled={true}>
              <Text style={styles.headerLink}>View more</Text>
            </TouchableOpacity>
          </View>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={{ paddingHorizontal: hp(2) }}
          >
            {recommendedNews.map(renderCard)}
          </ScrollView>
        </ScrollView>
      </SafeAreaView>
    </MainLayout>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: hp(2),
    marginTop: hp(2),
    marginBottom: hp(1),
    alignItems:'center'
  },
  headerTitle: {
    color: colors.primary,
    fontSize: hp(2.4),
    fontWeight: "bold",
  },
  headerLink: {
    color: '#888888',
    fontSize: hp(1.5),
  },
  card: {
    backgroundColor: "#E2E2E2",
    borderRadius: 12,
    padding: hp(1.5),
    marginRight: hp(2),
    width: hp(22),
  },
  cardImage: {
    height: hp(14),
    width: "100%",
    borderRadius: 8,
    resizeMode: "cover",
    marginBottom: hp(1),
  },
  source: {
    color: "#797979",
    fontSize: hp(1.6),
    marginBottom: hp(0.5),
  },
  title: {
    fontSize: hp(2),
    fontWeight: "bold",
    color: "#000",
  },
  footer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: hp(1),
    alignItems: "center",
  },
  date: {
    color: "#797979",
    fontSize: hp(1.6),
  },
});
