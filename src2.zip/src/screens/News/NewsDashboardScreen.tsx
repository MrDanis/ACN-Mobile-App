import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  Image,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import { heightPercentageToDP as hp } from "react-native-responsive-screen";
import MainLayout from "../../layout/MainLayout";
import { colors, images } from "../../config";
import Icon from "react-native-vector-icons/Feather";
import Loader from "../../components/Loader/Loader";
import apiClient from "../../utils/api";
import { NEXT_PUBLIC_BUCKET_URL } from "@env";
import moment from "moment";
import { getCategories, getNews } from "../../actions/newsAction";

const NewsDashboardScreen = ({ navigation }: any) => {
  const [isLoading, setIsLoading] = useState(false);
  const [mainCategoryID, setMainCategoryID] = useState("");
  const [articles, setArticles] = useState<any[]>([]);

  const fetchNews = async () => {
    try {
      setIsLoading(true);
      const newsData = await getCategories();
      if (newsData.categories.success) {
        const newsCategory = newsData.categories.data?.find(
          (item: any) => item.title.toLowerCase().includes("news")
        );
        const newsId = newsCategory ? newsCategory._id : null;
        setMainCategoryID(newsId);
        if (newsId) {
          const newsResponse = await getNews(newsId);
          if (newsResponse.news.success) {
            setArticles(newsResponse.news.data.documents);
          }
        }
      }
    } catch (error) {
      console.error("Error fetching news:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchNews();
  }, []);

  const renderArticle = (item: any) => {
    const defaultImage = images.loginHeader;
    return (
      <TouchableOpacity
        key={item._id}
        style={styles.card}
        onPress={() =>
          navigation.navigate("NewsDetailScreen", { article: item })
        }
      >
        <View style={styles.cardContent}>
          <Image
            source={
              item.attachments?.length > 0
                ? {
                    uri: `${NEXT_PUBLIC_BUCKET_URL}/${item.attachments[0].file.path}`,
                  }
                : defaultImage
            }
            style={styles.cardImage}
            resizeMode="cover"
            defaultSource={defaultImage}
          />
          <View style={styles.cardText}>
            <Text style={styles.source}>{item.category?.title || "News"}</Text>
            <Text style={styles.title} numberOfLines={2}>
              {item.title}
            </Text>
          </View>
        </View>
        <View style={styles.footer}>
          <Text style={styles.date}>
            {moment(item.createdAt).format("MMMM D, YYYY · h:mm A")}
          </Text>
          <View style={styles.iconRow}>
            <Icon
              name="bookmark"
              size={18}
              color="#8C8C8C"
              style={{ marginTop: hp(0.5), marginRight: hp(1) }}
            />
            <Text style={styles.icon}>⋮</Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <MainLayout navigation={navigation} activeTabIndex={5}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Top Stories</Text>
        {/* <TouchableOpacity
          onPress={() => navigation.navigate("NewsAllCategories")}
        >
          <Text style={styles.headerLink}>See all</Text>
        </TouchableOpacity> */}
      </View>
      {isLoading ? (
        <Loader />
      ) : articles.length > 0 ? (
        <ScrollView
          contentContainerStyle={styles.scrollContainer}
          showsVerticalScrollIndicator={false}
        >
          {articles.map((item) => renderArticle(item))}
        </ScrollView>
      ) : (
        <View style={styles.emptyContainer}>
          <Text>No articles found</Text>
        </View>
      )}
    </MainLayout>
  );
};

export default NewsDashboardScreen;

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: hp(2),
    marginTop: hp(2),
    alignItems: "center",
  },
  headerTitle: {
    color: colors.primary,
    fontSize: hp(2.4),
    fontWeight: "bold",
  },
  headerLink: {
    color: colors.black,
    fontSize: hp(1.5),
  },
  scrollContainer: {
    padding: hp(2),
    paddingBottom: hp(4),
  },
  card: {
    backgroundColor: "#F4F4F4",
    borderRadius: 12,
    padding: hp(1.5),
    marginBottom: hp(2),
    elevation: 10,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: -4,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  cardContent: {
    flexDirection: "row",
  },
  cardImage: {
    width: hp(8),
    height: hp(8),
    borderRadius: 8,
    marginRight: hp(1.5),
  },
  cardText: {
    flex: 1,
    justifyContent: "center",
  },
  source: {
    color: "grey",
    fontSize: hp(1.7),
    marginBottom: hp(0.5),
  },
  title: {
    fontWeight: "600",
    fontSize: hp(2),
    color: "black",
  },
  footer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: hp(1.5),
    alignItems: "center",
  },
  date: {
    color: "grey",
    fontSize: hp(1.6),
  },
  iconRow: {
    flexDirection: "row",
    gap: hp(1),
    alignItems: "center",
  },
  icon: {
    fontSize: hp(2),
    color: "grey",
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: hp(5),
  },
});
