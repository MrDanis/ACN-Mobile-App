import {
  View,
  Text,
  ScrollView,
  Image,
  TextInput,
  Alert,
  TouchableOpacity,
  Keyboard,
  StyleSheet,
  Platform,
  KeyboardAvoidingView,
} from "react-native";
import React, { useEffect, useState } from "react";
import MainLayout from "../../layout/MainLayout";
import { heightPercentageToDP as hp } from "react-native-responsive-screen";
import { colors, images } from "../../config";
import Button from "../../components/Button/Button";
import { DateTimePickerAndroid } from "@react-native-community/datetimepicker";
import Icon from "react-native-vector-icons/Octicons";
import DropDownPicker from "react-native-dropdown-picker";
import DateTimePickerModal from "react-native-modal-datetime-picker";
import apiClient from "../../utils/api";
import moment from "moment";
import DocumentPicker from "react-native-document-picker";
import Loader from "../../components/Loader/Loader";
import {
  getDepartmentData,
  getEventsTypes,
  getLocations,
  getUsersData,
} from "../../actions/eventDropDownActions";
import { EventApiPayload, EventFormSchema, eventSchema } from "./eventSchema";
import { Controller, FormProvider, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { FormFieldError } from "../../components/Error/form-field-error";
import RNFS from "react-native-fs";
import { uploadFile } from "../../actions/upload-file";
import { createEvent } from "../../actions/create-event";
import { showMessage } from "react-native-flash-message";
const CreateEventScreen = ({ navigation }: any) => {
  const form = useForm<EventFormSchema>({
    resolver: zodResolver(eventSchema),
    mode: "onSubmit",
    defaultValues: {
      name: "",
      description: "",
      startDateTime: "",
      endDateTime: "",
      type: "",
      category: "",
      organizers: [],
      guestType: "",
      participants: [],
      departmentIds: [],
    },
  });

  const {
    control,
    getValues,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = form;

  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        const data = await AsyncStorage.getItem("user");
        if (data) {
          const parseData: any = JSON.parse(data);
          form.setValue("organizers", [parseData._id], {
            shouldValidate: true,
          });
        }
      } catch (error) {
        console.error("Failed to fetch current user", error);
      }
    };

    fetchCurrentUser();
  }, [form]);

  const [eventName, setEventName] = useState("");
  const [endTime, setendTime] = useState(new Date());
  const [startDateTime, setStartDateTime] = useState(new Date());
  const [endDateTime, setEndDateTime] = useState(new Date());
  const [open, setOpen] = useState(false);
  const [openLocation, setOpenLocation] = useState(false);
  const [value, setValue] = useState("Select Type");
  const [locationValue, setlocationValue] = useState(null);
  const [openGuest, setopenGuest] = useState(false);
  const [guestValue, setguestValue] = useState("");
  const [openMember, setopenMember] = useState(false);
  const [memberValue, setmemberValue] = useState([]);
  const [openDepartment, setopenDepartment] = useState(false);
  const [departmentValue, setdepartmentValue] = useState([]);
  const [openOrganizer, setopenOrganizer] = useState(false);
  const [organizerValue, setorganizerValue] = useState<any>([]);
  const [types, setEventTypes] = useState([]);
  const [organizers, setOrganizers] = useState([]);
  const [invitees, setInvitees] = useState([]);
  const [isloading, setIsLoading] = useState(false);
  const [bannerImage, setBannerImage] = useState<any>(null);
  const [attachment, setAttachment] = useState<any>(null);
  const [description, setDescription] = useState<any>(null);
  const [eventOpen, setEventOpen] = useState(false);
  const [eventcategory, setSelectedEventCategory] = useState("Please Select");
  const [locations, setLocations] = useState<any>("");
  const [showDropdown, setShowDropdown] = useState(false);
  const [data, setData] = useState([]);
  const [onlineEventTypeId, setOnlineEventTypeId] = useState();
  const showStartDatePicker = () => setStartDatePickerVisibility(true);
  const hideStartDatePicker = () => setStartDatePickerVisibility(false);
  const showEndDatePicker = () => setEndDatePickerVisibility(true);
  const hideEndDatePicker = () => setEndDatePickerVisibility(false);
  const [isStartDatePickerVisible, setStartDatePickerVisibility] =
    useState(false);
  const [isEndDatePickerVisible, setEndDatePickerVisibility] = useState(false);
  const Categories = [
    { label: "Select Category", value: "Please Select" },
    { label: "Paid", value: "paid" },
    { label: "Unpaid", value: "unpaid" },
    { label: "Invitaion_only", value: "invitation_only" },
  ];

  const guestTypes = [
    { label: "Select Guest", value: "Please Select" },
    { label: "Member", value: "member" },
    { label: "Department", value: "department" },
  ];

  const handleStartConfirm = (date: any) => {
    setStartDateTime(date);
    const formattedStartDate = moment(startDateTime)
      .utc()
      .format("YYYY-MM-DDTHH:mm");
    form.setValue("startDateTime", formattedStartDate, {
      shouldValidate: true,
    });
    hideStartDatePicker();
  };

  const handleEndConfirm = (date: any) => {
    setEndDateTime(date);
    const formattedEndDate = moment(endDateTime)
      .utc()
      .format("YYYY-MM-DDTHH:mm");
    form.setValue("endDateTime", formattedEndDate, {
      shouldValidate: true,
    });
    setEndDatePickerVisibility(false);
  };

  const fetchLocations = async (query: any) => {
    try {
      const response = await getLocations(locations);
      setData(response.locations.data.documents);
    } catch (error) {
      console.error("Error fetching locations:", error);
    }
  };

  useEffect(() => {
    fetchEventsTypes();
    fetchUsersData();
    fetchDepartmentData();
  }, []);

  const handleInputChange = (text: any) => {
    setLocations(text);
    if (text.length > 0) {
      setShowDropdown(true);
      fetchLocations(text);
    } else {
      setShowDropdown(false);
      setData([]);
    }
  };

  const fetchEventsTypes = async () => {
    try {
      const response = await getEventsTypes();
      if (response) {
        const formattedData = response?.eventType.data.map(
          (invitation: any) => ({
            label: invitation.type,
            value: invitation._id,
          })
        );
        formattedData.unshift({
          label: "Select Type",
          value: "Select Type",
        });
        setEventTypes(formattedData);
        const onlineEvent = response?.eventType.data.find(
          (invitation: any) => invitation.type === "online"
        );
        if (onlineEvent) {
          setOnlineEventTypeId(onlineEvent._id);
        }
      }
    } catch (error) {
      console.error("Error fetching eventtype:", error);
    }
  };

  const fetchUsersData = async () => {
    try {
      const response = await getUsersData();
      if (response) {
        const formattedData = response.users.data.map((invitation: any) => ({
          label: invitation.firstName + " " + invitation.lastName,
          value: invitation._id,
        }));
        setOrganizers(formattedData);
      }
    } catch (error) {
      console.error("Error fetching eventtype:", error);
    }
  };

  const fetchDepartmentData = async () => {
    try {
      const response = await getDepartmentData();

      if (response) {
        const formattedData = response.invitees.data.documents.map(
          (invitation: any) => ({
            label: invitation.title,
            value: invitation._id,
          })
        );
        setInvitees(formattedData);
      }
    } catch (error) {
      console.error("Error fetching eventtype:", error);
    }
  };

  const onSubmit = async (data: EventFormSchema) => {
    try {
      const payload: EventApiPayload = {
        name: data.name,
        startDateTime: data.startDateTime,
        endDateTime: data.endDateTime,
        organizer: data.organizers,
        type: data.type,
        category: data.category,
        participantAccess: data.guestType,
        description: data.description,
        participants: data.participants,
        departmentIds: data.departmentIds,
        location: data.location?.display_name || "",
        attachment: data.attachments,
        bannerImage: data.bannerImage,
        noOfParticipants: data.participants?.length || 0,
      };
      const res = await createEvent(payload);
      if (res.state === "success") {
        showMessage({
          message: "Confirmation",
          description: `Event created successfully`,
          type: "success",
        });
        navigation.navigate("EventDashboardScreen");
      } else {
        showMessage({
          message: "Error",
          description: `${res.error?.message}`,
          type: "danger",
        });
      }
    } catch (error) {
      console.error("Error creating event:", error);
    }
  };

  const pickImage = async () => {
    try {
      const result: any = await DocumentPicker.pick({
        type: [DocumentPicker.types.images],
      });
      const file: any = result[0];
      setBannerImage(result);
      const fileBase64 = await RNFS.readFile(file.uri, "base64");
      const res = await uploadFile({ file, fileBase64 });
      const returnFile = res.data.data.files[0];
      form.setValue("bannerImage", returnFile, {
        shouldValidate: true,
      });
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
        console.log("User cancelled document picker");
      } else {
        console.error("Unknown error: ", err);
      }
    }
  };

  const pickDocument = async () => {
    try {
      const result = await DocumentPicker.pick({
        type: [DocumentPicker.types.allFiles],
      });
      console.log(result);
      const file: any = result[0];
      setAttachment(file);
      const fileBase64 = await RNFS.readFile(file.uri, "base64");
      const res = await uploadFile({ file, fileBase64 });
      const returnFile = res.data.data.files;
      form.setValue("attachments", returnFile, {
        shouldValidate: true,
      });
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
        console.log("User cancelled document picker");
      } else {
        console.log("Document picker error:", err);
      }
    }
  };

  const handleSelect = (item: any) => {
    setLocations({ _id: item._id, name: item.country + " " + item.city });
    form.setValue(
      "location",
      { id: item._id, display_name: item.country + " " + item.city },
      {
        shouldValidate: true,
      }
    );
    setShowDropdown(false);
  };

  const clearAllFields = () => {
    form.reset({
      name: "",
      startDateTime: "",
      endDateTime: "",
      type: "",
      description: "",
      category: "",
      organizers: [],
      guestType: "4",
      participants: [],
      departmentIds: [],
    });
    setEventName("");
    setStartDateTime(new Date());
    setEndDateTime(new Date());
    setValue("Select Type");
    setlocationValue(null);
    setguestValue("");
    setmemberValue([]);
    setdepartmentValue([]);
    setorganizerValue([]);
    setBannerImage(null);
    setAttachment(null);
    setDescription(null);
    setSelectedEventCategory("Please Select");
    setLocations("");
    setShowDropdown(false);
    setData([]);
    setDescription("");
    setEventName("");
  };

  return (
    <MainLayout navigation={navigation} activeTabIndex={0}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={Platform.OS === "ios" ? 130 : 0}
      >
        <ScrollView
          style={{
            flex: 1,
            borderColor: "black",
            borderWidth: 0,
            backgroundColor: colors.white,
          }}
        >
          <View
            style={{
              display: "flex",
              flexDirection: "column",
              padding: hp(2),
              width: "100%",
              borderColor: "red",
              borderWidth: 0,
            }}
          >
            <Text
              style={{
                textAlign: "center",
                fontSize: hp(2),
                fontWeight: "600",
                color: colors.black,
                marginTop: hp(1),
              }}
            >
              Add New Event
            </Text>
            <View
              style={{
                width: "100%",
                borderColor: "red",
                borderWidth: 0,
                marginTop: hp(1),
                display: "flex",
                flexDirection: "column",
              }}
            >
              <FormProvider {...form}>
                <View
                  style={{
                    width: "100%",
                    marginTop: hp(2),
                    borderColor: "#D4D4D4",
                    borderWidth: 1,
                    borderRadius: 8,
                    backgroundColor: colors.white,
                    display: "flex",
                    flexDirection: "row",
                    alignItems: "center",
                    paddingHorizontal: hp(1),
                  }}
                >
                  <Controller
                    control={control}
                    name="name"
                    render={({ field: { onChange, value } }) => (
                      <TextInput
                        style={{
                          flex: 1,
                          borderColor: "red",
                          borderWidth: 0,
                          fontSize: hp(1.5),
                        }}
                        onSubmitEditing={() => {
                          Keyboard.dismiss();
                        }}
                        onChangeText={onChange}
                        value={value}
                        placeholderTextColor={colors.inputPlaceHolderColor}
                        placeholder={"Event name*"}
                        keyboardType="default"
                      />
                    )}
                  />
                </View>
                <FormFieldError name="name" />
              </FormProvider>

              <View
                style={{
                  width: "100%",
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "space-between",
                  borderColor: "red",
                  borderWidth: 0,
                  marginTop: hp(2),
                }}
              >
                <FormProvider {...form}>
                  <View
                    style={{
                      width: "100%",
                      borderColor: "#D4D4D4",
                      borderWidth: 1,
                      borderRadius: 8,
                      backgroundColor: colors.white,
                      display: "flex",
                      flexDirection: "row",
                      alignItems: "center",
                      paddingHorizontal: hp(1),
                    }}
                  >
                    <Controller
                      control={control}
                      name="startDateTime"
                      render={({ field: { onChange, value } }) => (
                        <View
                          style={{
                            width: "100%",
                            justifyContent: "space-between",
                            flexDirection: "row",
                            alignItems: "center",
                          }}
                        >
                          <TouchableOpacity
                            onPress={showStartDatePicker}
                            activeOpacity={0.7}
                          >
                            <TextInput
                              style={styles.textInput}
                              placeholder="Select Start Date & Time"
                              placeholderTextColor="#A0A0A0"
                              value={startDateTime.toLocaleString()}
                              editable={false}
                              pointerEvents="none"
                            />
                          </TouchableOpacity>

                          <DateTimePickerModal
                            isVisible={isStartDatePickerVisible}
                            mode="datetime"
                            onConfirm={handleStartConfirm}
                            onCancel={hideStartDatePicker}
                            minimumDate={new Date()}
                            display={
                              Platform.OS === "ios" ? "inline" : "default"
                            }
                            modalStyleIOS={styles.iosPickerStyle}
                          />
                          <TouchableOpacity onPress={showStartDatePicker}>
                            <Image
                              source={images.timeIcon}
                              style={{ width: hp(3), height: hp(3) }}
                            />
                          </TouchableOpacity>
                        </View>
                      )}
                    />
                  </View>
                  <FormFieldError name="startDateTime" />
                </FormProvider>

                <FormProvider {...form}>
                  <View
                    style={{
                      width: "100%",
                      borderColor: "#D4D4D4",
                      borderWidth: 1,
                      borderRadius: 8,
                      backgroundColor: colors.white,
                      display: "flex",
                      flexDirection: "row",
                      alignItems: "center",
                      paddingHorizontal: hp(1),
                      marginTop: hp(2),
                    }}
                  >
                    <Controller
                      control={control}
                      name="endDateTime"
                      render={({ field: { onChange, value } }) => (
                        <View
                          style={{
                            width: "100%",
                            justifyContent: "space-between",
                            flexDirection: "row",
                            alignItems: "center",
                          }}
                        >
                          <TouchableOpacity
                            onPress={() => setEndDatePickerVisibility(true)}
                            activeOpacity={0.7}
                          >
                            <TextInput
                              style={styles.textInput}
                              placeholder="Select End Date & Time"
                              placeholderTextColor="#A0A0A0"
                              value={endDateTime.toLocaleString()}
                              editable={false}
                              pointerEvents="none"
                            />
                          </TouchableOpacity>

                          <DateTimePickerModal
                            isVisible={isEndDatePickerVisible}
                            mode="datetime"
                            onConfirm={(date) => {
                              handleEndConfirm(date);
                            }}
                            onCancel={() => setEndDatePickerVisibility(false)}
                            minimumDate={startDateTime}
                            display={
                              Platform.OS === "ios" ? "inline" : "default"
                            }
                            modalStyleIOS={styles.iosPickerStyle}
                          />
                          <TouchableOpacity
                            onPress={() => setEndDatePickerVisibility(true)}
                          >
                            <Image
                              source={images.timeIcon}
                              style={{ width: hp(3), height: hp(3) }}
                            />
                          </TouchableOpacity>
                        </View>
                      )}
                    />
                  </View>
                  <FormFieldError name="endDateTime" />
                </FormProvider>
              </View>
              <View
                style={{
                  width: "100%",
                  height: hp(7),
                  borderColor: "red",
                  borderWidth: 0,
                  marginTop: hp(2),
                }}
              >
                <TouchableOpacity
                  onPress={() => {
                    pickImage();
                  }}
                  style={{
                    width: "100%",
                    height: hp(5),
                    borderWidth: 1,
                    borderColor: "#D0D3D9",
                    borderRadius: 8,
                    alignItems: "center",
                    justifyContent: "space-between",
                    flexDirection: "row",
                    paddingHorizontal: hp(2),
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      width: "70%",
                    }}
                  >
                    <Icon name="image" size={27} color="#858d9d" />
                    <Text style={{ marginLeft: hp(2), flexWrap: "wrap" }}>
                      {bannerImage ? bannerImage[0].name : "Upload Banner"}
                    </Text>
                  </View>
                  <Icon name="upload" size={27} color="#858d9d" />
                </TouchableOpacity>
              </View>

              <View
                style={{
                  overflow: "visible",
                  borderWidth: 0,
                  width: "100%",
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                {/* Event Category Dropdown */}
                <FormProvider {...form}>
                  <Controller
                    control={control}
                    name="category"
                    render={({ field: { onChange } }) => (
                      <View>
                        <DropDownPicker
                          style={{
                            borderColor: "#D0D3D9",
                            marginBottom: hp(2.25),
                          }}
                          dropDownContainerStyle={{
                            maxHeight: 200,
                          }}
                          open={eventOpen}
                          value={eventcategory}
                          items={Categories}
                          setOpen={setEventOpen}
                          setValue={(callback) => {
                            const newValue = callback(value);
                            onChange(newValue);
                            setSelectedEventCategory(newValue);
                          }}
                          onChangeValue={(val) => {
                            onChange(val);
                          }}
                          zIndex={6000}
                          zIndexInverse={1000}
                          listMode="SCROLLVIEW"
                          maxHeight={200}
                        />
                      </View>
                    )}
                  />
                </FormProvider>

                {/* Payment Options */}
                {eventcategory === "paid" && (
                  <View
                    style={{
                      flexDirection: "row",
                      width: "50%",
                      marginBottom: hp(2.25),
                    }}
                  >
                    <View>
                      <Image
                        style={{ height: 40, width: 80 }}
                        resizeMode="center"
                        source={require("../../assets/Images/Events/visacard.png")}
                      />
                      <Text style={{ textAlign: "center", color: "black" }}>
                        Master
                      </Text>
                    </View>
                    <View>
                      <Image
                        style={{ height: 40, width: 80 }}
                        resizeMode="center"
                        source={require("../../assets/Images/Events/download.png")}
                      />
                      <Text style={{ textAlign: "center", color: "black" }}>
                        Visa
                      </Text>
                    </View>
                  </View>
                )}
                {/* Event Type Dropdown */}
                <FormProvider {...form}>
                  <Controller
                    control={control}
                    name="type"
                    render={({ field: { onChange, value: formValue } }) => (
                      <DropDownPicker
                        zIndex={5000}
                        zIndexInverse={2000}
                        open={open}
                        value={formValue}
                        items={types}
                        setOpen={setOpen}
                        setValue={(callback) => {
                          const newValue = callback(formValue);
                          onChange(newValue);
                          setValue(newValue);
                        }}
                        onChangeValue={(value) => {
                          onChange(value);
                        }}
                        placeholder="Select Type"
                        style={{ borderColor: "#D0D3D9" }}
                        dropDownContainerStyle={{ borderColor: "#D0D3D9" }}
                        listMode="SCROLLVIEW"
                      />
                    )}
                  />
                  {form.formState.isSubmitted && errors && (
                    <FormFieldError name="type" />
                  )}
                </FormProvider>

                {/* Location Input & Dropdown */}
                {value !== "Select Type" && value !== onlineEventTypeId && (
                  <>
                    <TextInput
                      placeholder="Locations"
                      onChangeText={handleInputChange}
                      placeholderTextColor={colors.inputPlaceHolderColor}
                      value={locations?.name}
                      style={{
                        width: "100%",
                        borderColor: "#D4D4D4",
                        borderWidth: 1,
                        marginTop: hp(2.25),
                        borderRadius: 8,
                        backgroundColor: colors.white,
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center",
                        paddingHorizontal: hp(1),
                        borderBottomWidth: showDropdown ? 0 : 1,
                        borderBottomLeftRadius: showDropdown ? 0 : 8,
                        borderBottomRightRadius: showDropdown ? 0 : 8,
                      }}
                    />
                    {showDropdown && (
                      <View
                        style={{
                          borderColor: "#ccc",
                          borderWidth: 1,
                          borderRadius: 5,
                          borderTopLeftRadius: 0,
                          borderTopRightRadius: 0,
                          backgroundColor: "#fff",
                          maxHeight: 150,
                        }}
                      >
                        <ScrollView nestedScrollEnabled={true}>
                          {data.map((item: any, index) => (
                            <TouchableOpacity
                              key={index}
                              style={{
                                padding: 10,
                                borderBottomWidth: 1,
                                borderBottomColor: "#eee",
                                maxHeight: 150,
                              }}
                              onPress={() => handleSelect(item)}
                            >
                              <Text>
                                {item.country} {item.city}
                              </Text>
                            </TouchableOpacity>
                          ))}
                        </ScrollView>
                      </View>
                    )}
                  </>
                )}

                {/* Guest Type Dropdown */}
                <FormProvider {...form}>
                  <Controller
                    control={control}
                    name="guestType"
                    render={({ field: { onChange } }) => (
                      <View style={{ marginVertical: hp(2.25) }}>
                        <DropDownPicker
                          zIndex={4000}
                          zIndexInverse={6000}
                          open={openGuest}
                          value={guestValue}
                          items={guestTypes}
                          setOpen={setopenGuest}
                          setValue={(callback) => {
                            const newValue = callback(value);
                            onChange(newValue);
                            setguestValue(newValue);
                          }}
                          onChangeValue={(val) => {
                            onChange(val);
                          }}
                          placeholder="Select Guest"
                          style={{
                            borderColor: "#D0D3D9",
                          }}
                          dropDownContainerStyle={{ borderColor: "#D0D3D9" }}
                          listMode="SCROLLVIEW"
                        />
                      </View>
                    )}
                  />
                </FormProvider>

                {/* Participant Dropdown - Only for Guest Type 2 */}
                {guestValue === "member" && (
                  <FormProvider {...form}>
                    <Controller
                      control={control}
                      name="participants"
                      render={({ field: { onChange, value } }) => (
                        <View style={{ marginBottom: hp(2.25) }}>
                          <DropDownPicker
                            zIndex={3500}
                            zIndexInverse={5000}
                            multiple={true}
                            open={openMember}
                            value={memberValue}
                            items={organizers}
                            setOpen={setopenMember}
                            setValue={setmemberValue}
                            onChangeValue={(newValue) => {
                              onChange(newValue);
                              form.setValue("participants", memberValue, {
                                shouldValidate: true,
                              });
                            }}
                            placeholder="Select Participants"
                            style={{
                              borderColor: "#D0D3D9",
                            }}
                            dropDownContainerStyle={{ borderColor: "#D0D3D9" }}
                            listMode="SCROLLVIEW"
                            mode="BADGE"
                            badgeDotColors={colors.primary}
                          />
                        </View>
                      )}
                    />
                  </FormProvider>
                )}

                {/* Department Dropdown - Only for Guest Type 3 */}
                {guestValue === "department" && (
                  <FormProvider {...form}>
                    <Controller
                      control={control}
                      name="departmentIds"
                      render={({ field: { onChange, value } }) => (
                        <DropDownPicker
                          zIndex={3400}
                          zIndexInverse={5000}
                          multiple={true}
                          open={openDepartment}
                          value={departmentValue}
                          items={invitees}
                          setOpen={setopenDepartment}
                          setValue={setdepartmentValue}
                          onChangeValue={(newValue: any) => {
                            onChange(newValue);
                            form.setValue("departmentIds", newValue, {
                              shouldValidate: true,
                            });
                          }}
                          placeholder="Select Invitee"
                          style={{
                            borderColor: "#D0D3D9",
                            marginBottom: hp(2.25),
                          }}
                          dropDownContainerStyle={{ borderColor: "#D0D3D9" }}
                          listMode="SCROLLVIEW"
                          mode="BADGE"
                          badgeDotColors={colors.primary}
                        />
                      )}
                    />
                  </FormProvider>
                )}

                {/* Organizer Dropdown */}
                <FormProvider {...form}>
                  <Controller
                    control={control}
                    name="organizers"
                    render={({ field: { onChange, value } }) => (
                      <DropDownPicker
                        zIndex={3000}
                        zIndexInverse={6000}
                        multiple={true}
                        open={openOrganizer}
                        value={organizerValue}
                        items={organizers}
                        setOpen={setopenOrganizer}
                        setValue={setorganizerValue}
                        onChangeValue={(newValue: any) => {
                          onChange(newValue);
                          form.setValue("organizers", newValue, {
                            shouldValidate: true,
                          });
                        }}
                        placeholder="Select Organizer"
                        style={{ borderColor: "#D0D3D9" }}
                        dropDownContainerStyle={{
                          borderColor: "#D0D3D9",
                          maxHeight: 200,
                        }}
                        listMode="SCROLLVIEW"
                        maxHeight={200}
                        mode="BADGE"
                        badgeDotColors={colors.primary}
                      />
                    )}
                  />
                  {form.formState.isSubmitted && errors && (
                    <FormFieldError name="organizers" />
                  )}
                </FormProvider>
              </View>

              {/* This is the upload file */}
              <View style={{ marginVertical: hp(2) }}>
                <TouchableOpacity
                  onPress={() => {
                    pickDocument();
                  }}
                  style={{
                    width: "100%",
                    height: hp(5),
                    borderWidth: 1,
                    borderColor: "#D0D3D9",
                    borderRadius: 8,
                    alignItems: "center",
                    justifyContent: "space-between",
                    flexDirection: "row",
                    paddingHorizontal: hp(2),
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      width: "70%",
                    }}
                  >
                    <Icon name="file" size={27} color="#858d9d" />
                    <Text style={{ marginLeft: hp(2), flexWrap: "wrap" }}>
                      {attachment ? attachment.name : "Upload Attachment"}
                    </Text>
                  </View>
                  <Icon name="upload" size={27} color="#858d9d" />
                </TouchableOpacity>
              </View>

              <FormProvider {...form}>
                <View
                  style={{
                    width: "100%",
                    marginBottom: hp(2),
                    borderColor: "#D4D4D4",
                    borderWidth: 1,
                    borderRadius: 8,
                    backgroundColor: colors.white,
                    display: "flex",
                    flexDirection: "row",
                    alignItems: "center",
                    paddingHorizontal: hp(1),
                  }}
                >
                  <Controller
                    control={control}
                    name="description"
                    render={({ field: { onChange, value } }) => (
                      <TextInput
                        placeholder={"Description"}
                        style={{
                          flex: 1,
                          borderColor: "red",
                          borderWidth: 0,
                          fontSize: hp(1.5),
                        }}
                        onSubmitEditing={() => {
                          Keyboard.dismiss();
                        }}
                        onChangeText={onChange}
                        value={value}
                        multiline
                        numberOfLines={5}
                        placeholderTextColor={colors.inputPlaceHolderColor}
                        keyboardType="default"
                      />
                    )}
                  />
                </View>
              </FormProvider>
            </View>
            <View
              style={{
                width: "100%",
                display: "flex",
                flexDirection: "row",
                borderColor: "green",
                borderWidth: 0,
              }}
            >
              <View
                style={{
                  flex: 1,
                  borderColor: "blue",
                  borderWidth: 0,
                  height: hp(6),
                  paddingRight: hp(1),
                }}
              >
                <Button
                  type={1}
                  text={"Clear"}
                  handlePress={() => {
                    clearAllFields();
                  }}
                  disable={false}
                />
              </View>
              <View
                style={{
                  flex: 1,
                  borderColor: "blue",
                  borderWidth: 0,
                  height: hp(6),
                  paddingLeft: hp(1),
                }}
              >
                <Button
                  type={0}
                  text={"Save"}
                  handlePress={handleSubmit(onSubmit)}
                  disable={false}
                />
              </View>
            </View>
            {isloading && <Loader />}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </MainLayout>
  );
};

export default CreateEventScreen;

const styles = StyleSheet.create({
  card: {
    justifyContent: "center",
    width: "90%",
    backgroundColor: "#fff",
    borderColor: "#c2c2c2",
    paddingBottom: 20,
    // flex:1
  },
  textInput: {
    width: "100%",
    alignSelf: "center",
    borderColor: "#a0a0a0",
    borderRadius: 5,
    color: "#000",
    paddingHorizontal: 10,
  },
  label: {
    marginBottom: 5,
    color: "#000",
    fontSize: 16,
    marginTop: 10,
    fontWeight: "bold",
  },
  picker: {
    height: 50,
    width: "100%",
    alignSelf: "center",
    marginBottom: 10,
    backgroundColor: "#a0a0a0",
  },
  touchables: {
    height: 35,
    borderRadius: 5,
    width: 100,
    backgroundColor: "#A362A7",
    alignItems: "center",
    justifyContent: "center",
    alignSelf: "flex-end",
    margin: 10,
    // marginRight: '5%',
  },
  touchablestext: {
    color: "white",
    fontSize: 17,
    fontWeight: "bold",
  },
  separator: {
    borderRightColor: "#c2c2c2",
    borderBottomWidth: 0.3,
    alignSelf: "center",
    height: 1,
    width: "100%",
    marginBottom: 9,
  },
  dropdown: {
    marginTop: 8,
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 5,
    // maxHeight: 200,
    backgroundColor: "#fff",
    maxHeight: 150, // Limit dropdown height
  },
  dropdownItem: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#eee",
    maxHeight: 150, // Ensure scrolling
  },
  iosPickerStyle: {
    margin: 0,
    justifyContent: "flex-end",
  },
});
