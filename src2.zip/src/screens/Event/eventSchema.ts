import { z } from "zod";
import moment from "moment";

export const eventSchema = z.object({
  name: z.string().trim().min(1, "Event name is required"),
  startDateTime: z.string().min(1, "Start date and time is required"),
  endDateTime: z.string().min(1, "End date and time is required"),
  type: z.string().trim().min(1, "Event type is required"),
  category: z.string().optional(),
  guestType: z.string().optional(),
  location: z.object({
    id: z.string().optional(),
    display_name: z.string().optional(),
  }).optional(),
  bannerImage: z.string().optional(),
  description: z.string().optional(),
  participants: z.array(z.string()).optional(),
  departmentIds: z.array(z.string()).optional(),
  organizers: z.array(z.string()).min(1, "At least one organizer is required"),
  attachments: z.array(z.string()).optional(),
}).refine((data) => {
  if (data.startDateTime && data.endDateTime) {
    const startDate = moment(data.startDateTime);
    const endDate = moment(data.endDateTime);
    const hoursDifference = endDate.diff(startDate, 'hours');
    
    return hoursDifference <= 24;
  }
  return true;
}, {
  message: "Event duration cannot exceed 24 hours",
  path: ["endDateTime"],
});

export type EventFormSchema = z.infer<typeof eventSchema>;

export interface EventApiPayload {
  name: string;
  startDateTime: string;
  endDateTime: string;
  type: string;
  category?: string;
  location?: string; 
  guestType?: string;
  bannerImage?: string;
  noOfParticipants?: number;
  organizer: string[];
  attachment?: string[];
  description?: string;
  participants?: string[];
  departmentIds?: string[];
  participantAccess?: string;
}

