import {
  View,
  Text,
  ScrollView,
  Image,
  Alert,
  TouchableOpacity,
  Linking,
  StyleSheet,
} from "react-native";
import React, { useEffect, useState } from "react";
import MainLayout from "../../layout/MainLayout";
import { heightPercentageToDP as hp } from "react-native-responsive-screen";
import { colors, images } from "../../config";
import Button from "../../components/Button/Button";
import { NEXT_PUBLIC_BUCKET_URL } from "@env";
import Icon from "react-native-vector-icons/MaterialIcons";
import { getEventDetails } from "../../actions/get-event-details";
import moment from "moment";
import Loader from "../../components/Loader/Loader";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { showMessage } from "react-native-flash-message";
import { cancelEvent } from "../../actions/cancel-event";
import { startEvent } from "../../actions/start-event";
import { joinEvent } from "../../actions/join-event";
const EventDetailsScreen = ({ route, navigation }: any) => {
  const [data, setData] = useState<any>();
  const [isloading, setIsLoading] = useState(false);
  const [id, setId] = useState();
  const [organizer, setOrganizer] = useState(false);
  const [btn, setBtn] = useState<any>({});

  useEffect(() => {
    const routeData = route.params;
    if (routeData?.id) {
      getEventDetail(routeData.id);
    }
    const fetchCurrentUser = async () => {
      try {
        const data = await AsyncStorage.getItem("user");
        if (data) {
          const parseData = JSON.parse(data);
          setId(parseData._id);
        }
      } catch (error) {
        console.error("Failed to fetch current user", error);
      }
    };

    fetchCurrentUser();
  }, [route.params]);

  useEffect(() => {
    setBtnText();
  }, [data]);

  const getEventDetail = async (id: any) => {
    try {
      setIsLoading(true);
      const response = await getEventDetails({ id });
      setData(response.data.data[0]);
      console.log(JSON.stringify(response.data.data[0]));
      setIsLoading(false);
    } catch (error) {
      console.error("Failed to fetch event details:", error);
      setIsLoading(false);
    }
  };

  const openDocument = async (uri: any) => {
    try {
      await Linking.openURL(`${NEXT_PUBLIC_BUCKET_URL}/${uri}`);
    } catch (error) {
      console.log("Error opening document:", error);
    }
  };

  const setBtnText = async () => {
    if (data && data.status) {
      const isOrganizer = await data.organizer.some(
        (organizer: any) => organizer._id === id
      );
      setOrganizer(isOrganizer);

      switch (data.status) {
        case "started":
          if (isOrganizer) {
            setBtn({
              disabled: false,
              text: "Start Event",
              onPress: start_Event,
            });
          } else {
            setBtn({ disabled: true, text: "Event not yet started" });
          }
          break;
        case "in progress":
          setBtn({ disabled: false, text: "Join Event", onPress: join_Event });
          break;
        case "ended":
          setBtn({ disabled: true, text: "Event Ended" });
          break;
        case "cancelled":
          setBtn({ disabled: true, text: "Event cancelled" });
          break;
        default:
          setBtn({ disabled: true, text: "Event not yet started" });
          break;
      }
    }
  };

  const start_Event = async () => {
    try {
      const rdata = await startEvent({ eventId: data._id });
      if (rdata?.data?.data?.url) {
        navigation.navigate("WebViewScreen", { url: rdata.data.data.url });
      } else {
        showMessage({
          message: "Error",
          description: `No URL found in the response`,
          type: "danger",
        });
      }
    } catch (error) {
      console.log("Error sending video call request:", error);
    }
  };

  const join_Event = async () => {
    try {
      const rdata = await joinEvent({
        eventId: data._id,
        participantId: id,
      });
      if (rdata?.data?.data?.url) {
        const url = rdata.data.data.url;
        navigation.navigate("WebViewScreen", { url });
      } else {
        showMessage({
          message: "Error",
          description: `User Room not found`,
          type: "danger",
        });
      }
    } catch (error) {}
  };

  const CancleEvent = async () => {
    try {
      const rdata = await cancelEvent({ eventId: data._id });
      console.log(rdata);
      if (rdata.data.success) {
        getEventDetail(data._id);
      } else {
        showMessage({
          message: "Error",
          description: `You are not able to cancel this event!`,
          type: "danger",
        });
      }
    } catch (error) {
      console.log("Error in cancel event:", error);
    }
  };

  return (
    <MainLayout navigation={navigation} activeTabIndex={0}>
      <ScrollView
        style={{
          flex: 1,
          borderColor: "red",
          borderWidth: 0,
          padding: hp(3),
          backgroundColor: colors.white,
        }}
      >
        <View
          style={{
            width: "100%",
            display: "flex",
            flexDirection: "column",
            gap: hp(2),
            padding: hp(2),
            backgroundColor: colors.eventcardBg,
            borderRadius: 10,
          }}
        >
          {data?.bannerImage?.path && (
            <Image
              source={{
                uri: `${NEXT_PUBLIC_BUCKET_URL}/${data?.bannerImage?.path}`,
              }}
              resizeMode="stretch"
              style={{ height: hp(20), width: "100%" }}
            />
          )}

          <Text
            style={{
              width: "100%",
              flexWrap: "wrap",
              fontSize: hp(3),
              color: colors.black,
              fontWeight: "600",
            }}
          >
            {data?.name}
          </Text>
          <View
            style={{
              width: "100%",
              borderWidth: 0.5,
              borderColor: colors.black,
            }}
          />
          <Text
            style={{
              color: colors.primary,
              fontSize: hp(2),
              gap: hp(1),
              fontWeight: "500",
            }}
          >
            When:
            <Text
              style={{
                color: colors.textMuted,
                fontSize: hp(2),
                gap: hp(1),
                fontWeight: "400",
              }}
            >
               {moment(data?.startDateTime).format("MMMM DD, YYYY, hh:mm A")} -
               {moment(data?.endDateTime).format("MMMM DD, YYYY, hh:mm A")}
            </Text>
          </Text>

          {data?.description && (
            <View
              style={{
                width: "100%",
                display: "flex",
                flexDirection: "column",
              }}
            >
              <Text
                style={{
                  color: colors.primary,
                  fontSize: hp(2),
                  gap: hp(1),
                  fontWeight: "500",
                }}
              >
                Details:
              </Text>
              <Text
                style={{
                  color: colors.black,
                  fontSize: hp(2),
                  gap: hp(1),
                  fontWeight: "400",
                }}
              >
                {data?.description}
              </Text>
            </View>
          )}
          <View
            style={{
              width: "100%",
              borderWidth: 0.5,
              borderColor: colors.black,
            }}
          />
          <View
            style={{
              width: "100%",
              display: "flex",
              flexDirection: "column",
            }}
          >
            <Text
              style={{
                color: colors.primary,
                fontSize: hp(2),
                gap: hp(1),
                fontWeight: "500",
              }}
            >
              Participants:
            </Text>
            <ScrollView
              nestedScrollEnabled={true}
              style={styles.participantsContainer}
            >
              {data?.participants &&
                data?.participants.length > 0 &&
                data?.participants.map((participant: any, index: any) => (
                  <View key={index} style={styles.participantItem}>
                    <Text style={styles.participantName}>
                      {participant.recipient && participant.recipient.firstName
                        ? participant.recipient.firstName
                        : ""}{" "}
                      {participant.recipient && participant.recipient.lastName
                        ? participant.recipient.lastName
                        : ""}
                    </Text>
                    {participant.status && (
                      <Text
                        style={{
                          ...styles.crossButtonText,
                          color: "#CACACA",
                          padding: 3,
                          borderRadius: 5,
                        }}
                      >
                        {participant.status}
                      </Text>
                    )}
                  </View>
                ))}
            </ScrollView>
            <Text
              style={{
                color: colors.primary,
                fontSize: hp(2),
                gap: hp(1),
                fontWeight: "500",
                marginTop:hp(1)
              }}
            >
              Organizers:
            </Text>
            <ScrollView
              nestedScrollEnabled={true}
              style={styles.participantsContainer}
            >
              {data?.organizer &&
                data?.organizer.length > 0 &&
                data?.organizer.map((organizer: any, index: any) => (
                  <View
                    key={index}
                    style={{
                      ...styles.participantItem,
                      flexDirection: "column",
                      alignItems: "flex-start",
                    }}
                  >
                    <Text style={styles.participantName}>
                      {organizer && organizer.firstName
                        ? organizer.firstName
                        : ""}{" "}
                      {organizer && organizer.lastName
                        ? organizer.lastName
                        : ""}
                    </Text>
                  </View>
                ))}
            </ScrollView>
          </View>
          <View
            style={{
              width: "100%",
              borderWidth: 0.5,
              borderColor: colors.black,
            }}
          />
          <View
            style={{
              width: "100%",
              display: "flex",
              flexDirection: "column",
            }}
          >
            <Text
              style={{
                color: colors.primary,
                fontSize: hp(2),
                gap: hp(1),
                fontWeight: "500",
              }}
            >
              Attachment:
            </Text>
            {data?.attachment[0]?.path && (
              <View
                style={{
                  width: "100%",
                  height: hp(7),
                  borderColor: "red",
                  borderWidth: 0,
                  marginTop: hp(1),
                }}
              >
                <TouchableOpacity
                  onPress={() => {
                    openDocument(data?.attachment[0]?.path);
                  }}
                  style={{
                    width: "100%",
                    height: hp(7),
                    borderWidth: 1,
                    borderColor: "#D0D3D9",
                    borderRadius: hp(2),
                    alignItems: "center",
                    justifyContent: "space-between",
                    flexDirection: "row",
                    paddingHorizontal: hp(2),
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      width: "70%",
                    }}
                  >
                    <Icon name="file-present" size={27} color="#E1251B" />
                    <Text style={{ marginLeft: hp(2), flexWrap: "wrap" }}>
                      {data?.attachment[0].name}
                    </Text>
                  </View>
                  <Icon name="file-download" size={27} color="black" />
                </TouchableOpacity>
              </View>
            )}
          </View>

          <View
            style={{
              width: "100%",
              borderWidth: 0.5,
              borderColor: colors.black,
            }}
          />
          <View
            style={{
              width: "90%",
              display: "flex",
              flexDirection: "row",
              gap: hp(1),
              borderColor: "red",
              borderWidth: 0,
              alignSelf: "center",
              justifyContent: "space-between",
              marginBottom: hp(2),
            }}
          >
            <View
              style={{
                borderColor: "red",
                borderWidth: 0,
                backgroundColor: "#9E7C4D33",
                padding: hp(1.5),
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                gap: hp(1),
                borderRadius: 10,
              }}
            >
              <View
                style={{
                  width: hp(1.25),
                  height: hp(1.25),
                  borderRadius: 50,
                  backgroundColor: colors.primary,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <View
                  style={{
                    width: "50%",
                    height: "50%",
                    backgroundColor: colors.eventcardBg,
                    borderRadius: 50,
                  }}
                />
              </View>
              <Text style={{ fontSize: hp(1.5), fontWeight: "500" }}>
                {data?.category}
              </Text>
            </View>
            <View
              style={{
                borderColor: "red",
                borderWidth: 0,
                backgroundColor: "#9E7C4D33",
                padding: hp(1.5),
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                gap: hp(1),
                borderRadius: 10,
              }}
            >
              <View
                style={{
                  width: hp(1.25),
                  height: hp(1.25),
                  borderRadius: 50,
                  backgroundColor: colors.primary,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <View
                  style={{
                    width: "50%",
                    height: "50%",
                    backgroundColor: colors.eventcardBg,
                    borderRadius: 50,
                  }}
                />
              </View>
              <Text style={{ fontSize: hp(1.5), fontWeight: "500" }}>
                {data?.type?.type}
              </Text>
            </View>
            <View
              style={{
                borderColor: "red",
                borderWidth: 0,
                backgroundColor: "#9E7C4D33",
                padding: hp(1.5),
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                gap: hp(1),
                borderRadius: 10,
              }}
            >
              <View
                style={{
                  width: hp(1.25),
                  height: hp(1.25),
                  borderRadius: 50,
                  backgroundColor: colors.primary,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <View
                  style={{
                    width: "50%",
                    height: "50%",
                    backgroundColor: colors.eventcardBg,
                    borderRadius: 50,
                  }}
                />
              </View>
              <Text style={{ fontSize: hp(1.5), fontWeight: "500" }}>
                {data?.status}
              </Text>
            </View>
          </View>
        </View>
        {organizer &&
          btn?.text !== "Event cancelled" &&
          btn?.text !== "Event Ended" && (
            <View
              style={{ width: "100%", height: hp(6), marginVertical: hp(1) }}
            >
              <Button
                disable={false}
                text={"Cancle Event"}
                type={0}
                handlePress={() => {
                  CancleEvent();
                }}
              />
            </View>
          )}
        {btn.text &&
          (btn.text === "Start Event" ||
            btn.text === "Join Event" ||
            btn.text === "Event not yet started" ||
            btn.text === "Event cancelled" ||
            btn.text === "Event Ended") && (
            <View
              style={{ width: "100%", height: hp(6), marginVertical: hp(1) }}
            >
              <Button
                disable={btn.disabled}
                text={btn.text}
                type={0}
                handlePress={btn.onPress}
              />
            </View>
          )}
        <View style={{ marginTop: hp(2) }} />
        {isloading && <Loader />}
      </ScrollView>
    </MainLayout>
  );
};

export default EventDetailsScreen;

const styles = StyleSheet.create({
  participantsContainer: {
    maxHeight: 100,
  },
  participantItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
    backgroundColor: "#fff",
    paddingVertical: hp(1),
    paddingHorizontal: hp(2),
    marginTop:hp(1)
  },
  participantName: {
    fontSize: 16,
    fontWeight: "500",
  },
  crossButtonText: {
    color: "#721c24",
    fontWeight: "bold",
  },
});
