import {
  View,
  Text,
  SafeAreaView,
  ScrollView,
  Linking,
  Image,
  TouchableOpacity,
  Alert,
} from "react-native";
import React, { useEffect, useState } from "react";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { colors, images } from "../../config";
import Footer from "../../components/Footer/Footer";
import { heightPercentageToDP as hp } from "react-native-responsive-screen";
import Button from "../../components/Button/Button";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import Loader from "../../components/Loader/Loader";
import { Job } from "./jobInterface";
import Icon from "react-native-vector-icons/MaterialIcons";
import { NEXT_PUBLIC_BUCKET_URL } from "@env";
const JobDetails = ({ route, navigation }: any) => {
  const [job, setJob] = useState<Job | null>(null);
  const [isloading, setIsLoading] = useState(false);
  const [companyDetail, setCompanyDetail] = useState(true);
  const [jobDetail, setJobDetail] = useState(false);
  useEffect(() => {
    setIsLoading(true);
    if (route.params?.data) {
      setJob(route.params.data);
    }
    setIsLoading(false);
  }, [route.params]);

  const openDocument = async (uri: any) => {
    try {
      await Linking.openURL(`${NEXT_PUBLIC_BUCKET_URL}/${uri}`);
    } catch (error) {
      console.log("Error opening document:", error);
    }
  };

  return (
    <SafeAreaProvider>
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.white }}>
        <View
          style={{
            flex: 0.08,
            borderColor: "red",
            borderWidth: 0,
            display: "flex",
            flexDirection: "row",
            gap: hp(1.5),
            alignItems: "center",
            paddingHorizontal: hp(2),
            justifyContent: "flex-start",
          }}
        >
          <TouchableOpacity
            onPress={() => {
              navigation.pop();
            }}
          >
            <Image
              source={images.backButton}
              style={{ width: hp(3), height: hp(3) }}
            />
          </TouchableOpacity>
          <Text
            style={{ color: colors.black, fontSize: hp(2), fontWeight: "600" }}
          >
            Job Details
          </Text>
        </View>
        <ScrollView style={{ flex: 0.84, borderColor: "red", borderWidth: 0 }}>
          <View
            style={{
              width: "100%",
              height: hp(35),
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexDirection: "column",
              gap: hp(1),
              backgroundColor: "#DADADA",
              borderBottomLeftRadius: hp(2),
              borderBottomRightRadius: hp(2),
            }}
          >
            <View
              style={{
                padding: hp(1),
                backgroundColor: colors.white,
                borderRadius: 10,
              }}
            >
              <View
                style={{
                  borderRadius: 8,
                  backgroundColor: colors.primary,
                  width: hp(5),
                  height: hp(5),
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Text
                  style={{ color: "white", fontSize: 20, fontWeight: "bold" }}
                >
                  {job ? job.title[0] : "N"}
                </Text>
              </View>
            </View>
            <View style={{ display: "flex", flexDirection: "column" }}>
              <Text
                style={{
                  fontSize: hp(3),
                  textAlign: "center",
                  color: colors.black,
                  fontWeight: "600",
                }}
              >
                {job ? job.title : ""}
              </Text>
              <Text
                style={{
                  fontSize: hp(2),
                  textAlign: "center",
                  color: colors.black,
                  fontWeight: "600",
                  marginBottom: hp(2),
                }}
              >
                {job?.company?.name || ""}
              </Text>
            </View>
            <View style={{ display: "flex", flexDirection: "row", gap: hp(2) }}>
              <View
                style={{
                  paddingHorizontal: hp(1.5),
                  padding: hp(0.75),
                  backgroundColor: colors.primary,
                  borderRadius: 5,
                  elevation: 10,
                }}
              >
                <Text
                  style={{
                    color: colors.white,
                    fontWeight: "500",
                    fontSize: hp(1.75),
                  }}
                >
                  {job?.type.type}
                </Text>
              </View>
              {/* <View
                style={{
                  paddingHorizontal: hp(1.5),
                  padding: hp(0.75),
                  backgroundColor: colors.primary,
                  borderRadius: 5,
                  elevation: 10,
                }}
              >
                <Text
                  style={{
                    color: colors.white,
                    fontWeight: "500",
                    fontSize: hp(1.75),
                  }}
                >
                  On Site
                </Text>
              </View> */}
            </View>
          </View>
          <View
            style={{
              width: "100%",
              padding: hp(2),
              borderColor: "red",
              borderWidth: 0,
              marginTop: hp(2),
            }}
          >
            <View
              style={{
                width: "100%",
                display: "flex",
                flexDirection: "row",
                gap: hp(1),
              }}
            >
              <TouchableOpacity
                onPress={() => {
                  setCompanyDetail(true);
                  setJobDetail(false);
                }}
                style={{
                  backgroundColor: companyDetail
                    ? "#9E7C4D33"
                    : colors.inputBgColor,
                  flex: 1,
                  padding: hp(1.5),
                  borderRadius: 10,
                }}
              >
                <Text
                  style={{
                    color: companyDetail ? colors.primary : colors.textMuted,
                    fontWeight: "600",
                    fontSize: hp(2),
                    textAlign: "center",
                  }}
                >
                  About Company
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  setCompanyDetail(false);
                  setJobDetail(true);
                }}
                style={{
                  backgroundColor: jobDetail
                    ? "#9E7C4D33"
                    : colors.inputBgColor,
                  flex: 1,
                  padding: hp(1.5),
                  borderRadius: 10,
                }}
              >
                <Text
                  style={{
                    color: jobDetail ? colors.primary : colors.textMuted,
                    fontWeight: "600",
                    fontSize: hp(2),
                    textAlign: "center",
                  }}
                >
                  Details
                </Text>
              </TouchableOpacity>
            </View>
            {companyDetail && (
              <View
                style={{
                  width: "100%",
                  borderColor: "red",
                  borderWidth: 0,
                  marginTop: hp(3),
                }}
              >
                <Text
                  style={{
                    width: "100%",
                    fontSize: hp(2),
                    lineHeight: hp(3),
                    color: colors.black,
                  }}
                >
                  {job?.company?.description}
                </Text>
              </View>
            )}

            {jobDetail && (
              <View
                style={{
                  width: "100%",
                  borderColor: "red",
                  borderWidth: 0,
                  marginTop: hp(3),
                }}
              >
                {job?.jobDescription && (
                  <Text
                    style={{
                      width: "100%",
                      fontSize: hp(2),
                      lineHeight: hp(3),
                      color: colors.black,
                      fontWeight: "bold",
                    }}
                  >
                    Requirements
                  </Text>
                )}
                <Text
                  style={{
                    width: "100%",
                    fontSize: hp(2),
                    lineHeight: hp(3),
                    color: colors.black,
                    marginBottom: hp(2),
                  }}
                >
                  {job?.jobDescription}
                </Text>
                {job?.keyResponsibilities && (
                  <Text
                    style={{
                      width: "100%",
                      fontSize: hp(2),
                      lineHeight: hp(3),
                      color: colors.black,
                      fontWeight: "bold",
                    }}
                  >
                    Key Responsibilities
                  </Text>
                )}
                <Text
                  style={{
                    width: "100%",
                    fontSize: hp(2),
                    lineHeight: hp(3),
                    color: colors.black,
                    marginBottom: hp(1),
                  }}
                >
                  {job?.keyResponsibilities}
                </Text>
              </View>
            )}

            {job?.attachments[0]?.path && (
              <View
                style={{
                  width: "100%",
                  height: hp(7),
                  borderColor: "red",
                  borderWidth: 0,
                  marginTop: hp(2),
                }}
              >
                <TouchableOpacity
                  onPress={() => {
                    openDocument(job?.attachments[0]?.path);
                  }}
                  style={{
                    width: "80%",
                    height: hp(7),
                    borderWidth: 1,
                    borderColor: "#D0D3D9",
                    borderRadius: hp(2),
                    alignItems: "center",
                    justifyContent: "space-between",
                    flexDirection: "row",
                    paddingHorizontal: hp(2),
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      width: "70%",
                    }}
                  >
                    <Icon name="file-present" size={27} color="#E1251B" />
                    <Text style={{ marginLeft: hp(2), flexWrap: "wrap" }}>
                      {job?.attachments[0].name}
                    </Text>
                  </View>
                  <Icon name="file-download" size={27} color="black" />
                </TouchableOpacity>
              </View>
            )}
            <View
              style={{
                width: "100%",
                height: hp(7),
                borderColor: "red",
                borderWidth: 0,
                marginTop: hp(2),
              }}
            >
              <Button
                disable={false}
                type={0}
                text={"Apply"}
                handlePress={() => {
                  const mailtoUrl = `mailto:${job?.company?.email}`;
                  Linking.openURL(mailtoUrl).catch((err) =>
                    console.error("Failed to open email app:", err)
                  );
                }}
              />
            </View>
          </View>
        </ScrollView>
        <View
          style={{
            flex: 0.08,
            borderColor: "red",
            borderWidth: 0,
            backgroundColor: colors.white,
            elevation: 7,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: hp(1.25),
          }}
        >
          <Footer navigation={navigation} activeTab={3} />
        </View>
        {isloading && <Loader />}
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

export default JobDetails;
