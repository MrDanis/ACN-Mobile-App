import {
  View,
  Text,
  ScrollView,
  Image,
  TextInput,
  TouchableOpacity,
  FlatList,
} from "react-native";
import React, { useEffect, useState } from "react";
import MainLayout from "../../layout/MainLayout";
import { images, colors } from "../../config";
import { heightPercentageToDP as hp } from "react-native-responsive-screen";
import Loader from "../../components/Loader/Loader";
import apiClient from "../../utils/api";
import {Job} from "./jobInterface";
import { jobAction } from "../../actions/jobAction";

const JobDashboardScreen = ({ navigation }: any) => {
 

  const [isloading, setIsLoading] = useState(false);
  const [jobsData, setJobsData] = useState<Job[]>([]);
  const [searchText, setSearchText] = useState("");

  const filteredJobs = jobsData.filter((job) =>
    job.title.toLowerCase().includes(searchText.toLowerCase())
  );

  const fetchJobs = async () => {
    try {
      setIsLoading(true);
      const response = await jobAction();
      console.log(response)
      setJobsData(response.user.data.documents);
    } catch (err) {
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchJobs();
  }, []);
  const formatDate = (dateString: any) => {
    const months = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];

    const date = new Date(dateString);
    const day = date.getDate();
    const month = months[date.getMonth()];
    const year = date.getFullYear();

    return `${day} ${month} ${year}`;
  };

  const renderJobItem = ({ item }: { item: any }) => (
    <TouchableOpacity
      onPress={() => {
        navigation.navigate("JobDetailsScreen", { data: item });
      }}
      style={{
        borderColor: "#E6E6E6",
        borderWidth: 1,
        borderRadius: 10,
        padding: hp(2),
        marginBottom: hp(2),
      }}
    >
      <View
        style={{
          borderColor: "green",
          borderWidth: 0,
          width: "100%",
          display: "flex",
          flexDirection: "row",
          alignItems: "center",
          gap: hp(1),
        }}
      >
        <View
          style={{
            borderColor: "green",
            borderWidth: 0,
            width: "85%",
            display: "flex",
            flexDirection: "row",
            gap: hp(1),
          }}
        >
          <View
            style={{
              padding: hp(1),
              borderRadius: 8,
              backgroundColor: colors.primary,
              width: hp(5),
              height: hp(5),
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Text style={{ color: "white", fontSize: 20, fontWeight: "bold" }}>
              {item.title[0]}
            </Text>
          </View>
          <View style={{ flex: 1, display: "flex", flexDirection: "column" }}>
            <Text
              style={{
                width: "100%",
                flexWrap: "wrap",
                fontSize: hp(2),
                color: colors.black,
              }}
            >
              {item.title}
            </Text>
            <Text
              style={{
                fontSize: hp(1.5),
                fontWeight: "600",
                color: colors.black,
              }}
            >
              {item.company?.name || ""}
            </Text>
          </View>
        </View>
        <Image
          source={images.jobBookMark}
          resizeMode="cover"
          style={{ width: hp(3), height: hp(3) }}
        />
      </View>
      <Text
        style={{
          fontSize: hp(1.75),
          color: colors.textMuted,
          marginTop: hp(0.5),
          marginBottom: hp(2),
        }}
      >
        {item.location?.name || "Location"}
      </Text>
      <View
        style={{
          width: "100%",
          borderColor: "red",
          flexWrap: "wrap",
          borderWidth: 0,
          display: "flex",
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <View
          style={{
            borderColor: "green",
            borderWidth: 0,
            display: "flex",
            flexDirection: "row",
            gap: hp(1),
          }}
        >
          <View
            style={{
              paddingHorizontal: hp(1),
              padding: hp(0.5),
              backgroundColor: "#3583F91A",
            }}
          >
            <Text
              style={{
                color: colors.primary,
                fontWeight: "500",
                fontSize: hp(1.5),
              }}
            >
              {item.type.type}
            </Text>
          </View>
          {/* <View
            style={{
              paddingHorizontal: hp(1.5),
              padding: hp(0.5),
              backgroundColor: "#3583F91A",
              borderRadius: 5,
            }}
          >
            <Text
              style={{
                color: colors.primary,
                fontWeight: "500",
                fontSize: hp(1.5),
              }}
            >
              On Site
            </Text>
          </View> */}
        </View>
        <Text style={{ color: colors.textMuted, fontSize: hp(1.5) }}>
          {formatDate(item.createdAt)}
        </Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <MainLayout navigation={navigation} activeTabIndex={3}>
      <ScrollView
        style={{
          flex: 1,
          borderColor: "red",
          borderWidth: 0,
          padding: hp(2),
          backgroundColor: colors.white,
        }}
      >
        <View
          style={{
            width: "100%",
            display: "flex",
            flexDirection: "column",
            gap: hp(1),
            borderColor: "red",
            borderWidth: 0,
          }}
        >
          <View
            style={{
              width: "100%",
              borderColor: "green",
              borderWidth: 0,
              display: "flex",
              flexDirection: "row",
              alignItems: "center",
              gap: hp(3),
            }}
          >
            <View
              style={{
                width: "85%",
                marginVertical: hp(1),
                borderColor: "#D4D4D4",
                borderWidth: 1,
                borderRadius: 8,
                backgroundColor: colors.inputBgColor,
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                paddingHorizontal: hp(1),
              }}
            >
              <Image
                source={images.searchIcon}
                style={{ width: hp(2), height: hp(2) }}
              />
              <TextInput
                placeholderTextColor={colors.inputPlaceHolderColor}
                placeholder={"Search"}
                style={{
                  flex: 1,
                  borderColor: "red",
                  borderWidth: 0,
                  fontSize: hp(1.5),
                }}
                value={searchText}
                onChangeText={setSearchText}
              />
            </View>
            <Image
              source={images.filterIcon}
              style={{ width: hp(3), height: hp(3) }}
            />
          </View>
          <View
            style={{
              width: "100%",
              borderColor: "black",
              borderWidth: 0,
              marginTop: hp(1.5),
              display: "flex",
              flexDirection: "column",
              gap: hp(2),
            }}
          >
            <Text
              style={{
                color: colors.black,
                fontWeight: "600",
                fontSize: hp(2.5),
                marginBottom: hp(1),
              }}
            >
              Recently Update
            </Text>

            <FlatList
              data={filteredJobs}
              renderItem={renderJobItem}
              keyExtractor={(item) => item.id}
              scrollEnabled={false} // Since it's inside a ScrollView
              contentContainerStyle={{ paddingBottom: hp(2) }}
            />
          </View>
        </View>
        {isloading && <Loader />}
      </ScrollView>
    </MainLayout>
  );
};

export default JobDashboardScreen;
