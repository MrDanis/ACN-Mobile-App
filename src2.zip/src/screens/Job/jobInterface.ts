export interface Job {
  id: string;
  title: string;
  company?: {
    name: string;
    description: string;
    email: string;
  };
  location?: {
    name: string;
  };
  type: {
    type: string;
  };
  keyResponsibilities: string;
  jobDescription: string;
  Bonus: string;
  createdAt: string;
  attachments:{
    path:string;
    name:string
  }[];
}
