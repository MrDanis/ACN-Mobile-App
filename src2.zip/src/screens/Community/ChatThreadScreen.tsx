import { View, Text,SafeAreaView, ScrollView,Image, TouchableOpacity, Alert, TextInput,StyleSheet,KeyboardAvoidingView,Platform } from 'react-native'
import React,{useEffect,useState,useRef} from 'react'
import {SafeAreaProvider} from 'react-native-safe-area-context';
import { colors,images } from '../../config';
import Footer from '../../components/Footer/Footer';
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';
import Button from '../../components/Button/Button';
import { SpecificChatUsersConversationAction,sendMessageChat,chatCalll } from '../../actions/chatAction';
import Loader from '../../components/Loader/Loader';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { useChat } from '../../../ChatProvider,';
import moment from 'moment';
import CallModal from './CommunityComponents/CallModal';
const ChatThreadScreen = ({navigation,route}:any) => {
  const [calModal, setCalModal] = useState(false);
  const [callType, setCallType] = useState('');
  const [messageText, setMessageText] = useState('');
  const {masseges, setMesseges} = useChat();
  const scrollViewRef = useRef<KeyboardAwareScrollView>(null);
  const [isHistoryFetching,setisHistoryFetching] = useState(false);
  const [chatuserData,setchatuserData] = useState<any>([])
  const handleFetchChatData=async(id:String) =>{
    setisHistoryFetching(true);
   let messages = await SpecificChatUsersConversationAction(id);
   setchatuserData(messages?.specificConversations?.messages);
   setMesseges(messages?.specificConversations?.messages);
   setisHistoryFetching(false);
  }
  const sendMessage = async()=>{
     let dataPayload = {
      message: `${messageText}`,
      senderId: `${route?.params?.loginUserId}`,
      receiverId: (route?.params?.loginUserId===route?.params?.data?.lastMessage?.sender._id)?route?.params?.data?.lastMessage?.receiver._id:route?.params?.data?.lastMessage?.sender._id,
      conversationId: `${route?.params?.data?._id}`
     };
     let conversationType =  0
    let messageRes = await sendMessageChat(dataPayload,conversationType);
     let newMessage = {
      attachments:messageRes?.message?.message?.attachments,
      conversation:messageRes?.message?.message?.conversation,
      createdAt:messageRes?.message?.message?.createdAt,
      forwardedMessage:messageRes?.message?.message?.forwardedMessage,
      isDeleted:messageRes?.message?.message?.isDeleted,
      isEdited:messageRes?.message?.message?.isEdited,
      isPinned:messageRes?.message?.message?.isPinned,
      message:messageRes?.message?.message?.message,
      messageType:messageRes?.message?.message?.messageType,
      reactions:messageRes?.message?.message?.reactions,
      receiverDetails:messageRes?.message?.message?.receiver,
      senderDetails:messageRes?.message?.message?.sender,
      _id:messageRes?.message?.message?._id
    };
     setchatuserData([...chatuserData,newMessage]);
     setMessageText('');
  }
  const handleCall = (callType:Number)=>{
     switch (callType) {
      case 0:
         setCalModal(true);
        setCallType('audio_call');
        
        break;
        case 1:
          
          setCalModal(true);
          setCallType('video_call');
          break;
     
      default:
        break;
     }
  }
  const sendVideoCallRequest = async () => {
    const payload = {
      senderId: route?.params?.loginUserId,
      receiverId: (route?.params?.loginUserId===route?.params?.data?.lastMessage?.sender._id)?route?.params?.data?.lastMessage?.receiver._id:route?.params?.data?.lastMessage?.sender._id,
      type: callType || 'video_call',
    };
    const callStatus = await chatCalll(payload);
    let url = callStatus?.callStatus?.url; 
    if(url)
    {
      setCalModal(false); 
      navigation.navigate('WebViewScreen', {url});
    }
  };
 
  useEffect(()=>{
    handleFetchChatData(route?.params?.data?._id);
  },[route?.params?.data?._id])
  useEffect(() => {
    scrollViewRef.current?.scrollToEnd({ animated: true });
  }, [masseges, chatuserData]);

  return (
      <SafeAreaProvider>
        <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={{ flex: 1 }}
        keyboardVerticalOffset={hp(6)} 
      >
               <SafeAreaView style={style.mainContainer}>
              

                     <View style={style.containerOne}>
                      <View style={style.containerTwo}>
                      <TouchableOpacity onPress={()=>{navigation.pop()}}>
                        <Image source={images.backButton} style={style.backBtn}/>
                      </TouchableOpacity>
                          
                         <Image source={images.NoImgProfile} style={style.noprofileImg}/>
                          <View style={style.profileView}>
                          <Text style={style.nameText}>
                            {route?.params?.data?.lastMessage?.receiver?.firstName+" "+route?.params?.data?.lastMessage?.receiver?.firstName                             }
                          </Text>           
                          
                          </View>
                      </View>
                          <View style={style.iconBox}>
                             <TouchableOpacity onPress={()=>{handleCall(0)}}>
                                <Image source={images.voiceCallIcon} resizeMode='contain' style={style.iconImg}/>
                             </TouchableOpacity>
                             <TouchableOpacity onPress={()=>{handleCall(1)}}>
                              <Image source={images.videoCallIcon} resizeMode='contain' style={style.iconImg}/>
                             </TouchableOpacity>
                          </View>
                     </View>     
                     <KeyboardAwareScrollView 
                      style={style.scrolBox}
                      ref={scrollViewRef}
                      onContentSizeChange={() => scrollViewRef.current?.scrollToEnd({ animated: true })}
                      
                      >
                      {
                       masseges.length === 1 || 0?
                       [...chatuserData,...masseges].map((item:any,index:number)=>{
                          return(
                            <View key={index} style={style.scrolViewBoxOne}>
                            <View style={{padding:hp(1),width:'70%',borderColor:'green',borderWidth:0,alignSelf:(route?.params?.loginUserId===item?.senderDetails?._id)?'flex-end':'flex-start'}}>
                              <Text style={{fontSize:hp(2),width:'100%',borderRadius:10,flexWrap:'wrap',padding:hp(2),color:((route?.params?.loginUserId===item?.senderDetails?._id))?colors.black:colors.white,backgroundColor:((route?.params?.loginUserId===item?.senderDetails?._id))?colors.sendMsgBg:colors.blue}} 
                              //style={style.messageBox}
                              >
                                 {item?.message.replace(/^"|"$/g, '').replace(/<[^>]*>/g, '').trim()}
                              </Text>
                              <Text style={style.messagetime}>
                                 {moment(item.createdAt).format('hh:mm A')}
                              </Text>
                            </View>
                         </View>
                          )
                        }):
                        chatuserData&&chatuserData.map((item:any,index:number)=>{
                          return(
                       <View key={index} style={style.scrolViewBoxOne}>
                          <View style={{padding:hp(1),width:'70%',borderColor:'green',borderWidth:0,alignSelf:(route?.params?.loginUserId===item?.senderDetails?._id)?'flex-end':'flex-start'}}>
                            <Text style={{fontSize:hp(2),width:'100%',borderRadius:10,flexWrap:'wrap',padding:hp(2),color:((route?.params?.loginUserId===item?.senderDetails?._id))?colors.black:colors.white,backgroundColor:((route?.params?.loginUserId===item?.senderDetails?._id))?colors.sendMsgBg:colors.blue}} 
                            //style={style.messageBox}
                            >
                               {item?.message.replace(/^"|"$/g, '').replace(/<[^>]*>/g, '').trim()}
                            </Text>
                            <Text style={style.messagetime}>
                               {moment(item.createdAt).format('hh:mm A')}
                            </Text>
                          </View>
                       </View>
                          )
                        })
                      }
                     </KeyboardAwareScrollView>
                     <View style={style.sendMessageBox}>
                     
                            <View style={style.inputBox}>         
                              <TextInput 
                              value={messageText}
                              onChangeText={(text) => setMessageText(text)}
                              placeholderTextColor={colors.inputPlaceHolderColor}
                              placeholder={'Type your message'}
                              style={style.inputarea}/>
                            </View>
                            <TouchableOpacity style={{}} onPress={()=>{
                        // Alert.alert('Will send the message from here')
                        if(messageText==='')
                        {
                          Alert.alert("Please type the message before sending....");
                        }
                        else
                        {
                          sendMessage()
                        }
                        }}> 
                       <Image source={images.sendMessageIcon} resizeMode='cover' style={style.attachmentIcon}/>
                      </TouchableOpacity>
                            {(isHistoryFetching) && <Loader />}
                            <CallModal
                               show={calModal}
                               onCancel={() => setCalModal(false)}
                               onConfirm={() => {
                                 sendVideoCallRequest();
                               }}
                             />
                      </View>     
                   
               </SafeAreaView>

      </KeyboardAvoidingView>
        </SafeAreaProvider>
  )
}

export default ChatThreadScreen
const style = StyleSheet.create({
    mainContainer:{flex:1,backgroundColor:colors.white},
    containerOne:{height:hp(10),borderColor:'red',borderWidth:0,display:'flex',flexDirection:'row',gap:hp(1.5),alignItems:'center',paddingHorizontal:hp(2),justifyContent:'flex-start'},
    containerTwo:{flex:1,borderColor:'green',borderWidth:0,display:'flex',flexDirection:'row',alignItems:'center',gap:hp(1)},
    backBtn:{width:hp(3),height:hp(3)},
    noprofileImg:{width:hp(6),height:hp(6)},
    profileView:{flex:1,borderColor:'blue',borderWidth:0,display:'flex',flexDirection:'column',marginTop:hp(.75)},
    nameText:{color:colors.black,fontSize:hp(2),fontWeight:'600'},
    lastSeen:{color:colors.black,fontSize:hp(1.5),fontWeight:'300'},
    iconBox:{flex:.25,height:hp(5),display:'flex',flexDirection:'row',gap:hp(1),borderColor:'red',borderWidth:0,alignItems:'center',justifyContent:'space-between'},
    iconImg:{width:hp(3),height:hp(3)},//#E8E8E8
    scrolBox:{flex:.78,borderColor:'red',borderWidth:0},
    scrolViewBoxOne:{width:'100%',borderColor:'red',borderWidth:0,display:'flex',justifyContent:'flex-start'},
    scrollViewBoxtwo:{padding:hp(1),width:'70%',borderColor:'green',borderWidth:1,alignSelf:'flex-end'},
    messageBox:{fontSize:hp(2),width:'100%',borderRadius:10,flexWrap:'wrap',padding:hp(2),color:colors.white,backgroundColor:colors.blue},
    messagetime:{fontSize:hp(1.75),color:colors.textMuted,marginTop:hp(1)},
    sendMessageBox:{display:'flex',flexDirection:'row',alignItems:'center',borderColor:'green',borderWidth:0,backgroundColor:'#CBCBCB',paddingHorizontal:hp(2),gap:hp(1)},
    attachmentIcon:{width:hp(4),height:hp(4)},
    inputBox:{ height:'70%',width:'90%',marginVertical:hp(2),borderColor:'#D4D4D4',borderWidth:1,borderRadius:8,backgroundColor:colors.inputBgColor,display:'flex',flexDirection:'row',alignItems:'center',paddingHorizontal:hp(1)},
    inputarea:{flex:1,borderColor:'red',borderWidth:0,fontSize:hp(1.5)},
    camIconBox:{flex:1,borderColor:'red',borderWidth:0,display:'flex',flexDirection:'row',justifyContent:'flex-end',gap:hp(2),paddingEnd:hp(1)},
    camIcon:{width:hp(3),height:hp(3)},   
    chatFooter:{borderColor:'red',borderWidth:0,backgroundColor:colors.white,elevation:7,display:'flex',alignItems:'center',justifyContent:'center',padding:hp(1.25)}
})