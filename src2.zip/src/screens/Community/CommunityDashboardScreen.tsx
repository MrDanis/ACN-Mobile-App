import { View, Text, ScrollView,Image,TextInput, TouchableOpacity,StyleSheet,Alert } from 'react-native'
import React,{useEffect,useState,useRef} from 'react'
import { heightPercentageToDP as hp } from 'react-native-responsive-screen'
import MainLayout from '../../layout/MainLayout'
import { colors,images } from '../../config'
import CommunityMessageCard from './CommunityComponents/CommunityMessageCard'
// import { communityDashboardData } from '../data'
import { chatUsersAction,chatUsersConversationAction } from '../../actions/chatAction'
import Loader from '../../components/Loader/Loader'
import moment from 'moment'
import { NEXT_PUBLIC_BUCKET_URL } from "@env";
import { CommunitySearch } from '../data'
import AsyncStorage from '@react-native-async-storage/async-storage'
import connectionSocket from '../../../Socket'
import { useChat } from '../../../ChatProvider,'
import { showMessage } from 'react-native-flash-message'
const CommunityDashboardScreen = ({navigation}:any) => {
const {masseges, setMesseges} = useChat();
const socketRef = useRef(null);
const [loginUserId,setloginUserId] = useState('');
const [search, setSearch] = useState('');
const [isChatUserFetching,setisChatUserFetching] = useState(false);
const [isChatUserConversationFetching,setisChatUserConversationFetching] = useState(false);
const [recentChatUser,setrecentChatUser] = useState([]);
const [chatUsersConversation,setchatUsersConversation] = useState([]);
const [activeTab,setactiveTab] = useState(0);
const fetchChatUsers=async()=>{
  setisChatUserFetching(true);
  setisChatUserConversationFetching(true);
  const chatUser = await chatUsersAction();
  const chatUserConversation = await chatUsersConversationAction();
  setrecentChatUser(chatUser?.chatUsers);
  setchatUsersConversation(chatUserConversation?.conversations)
  setisChatUserFetching(false);
  setisChatUserConversationFetching(false);
  const user = await AsyncStorage.getItem("user") as string;
  handleSocketConnect(JSON.parse(user));
}
const handleSocketConnect=async(user:any)=>{
  let loginUserId = user?._id;
  setloginUserId(`${loginUserId}`);
}
const handleTabChange = (type:number)=>{
    switch (type) {
      case 0:
        setactiveTab(type);
        break;
      case 1:
        setactiveTab(type);
        break;
      case 2:
        setactiveTab(type);
        break;
    
      default:
        break;
    }
}
const handleSearch = (text:string) => {
  setSearch(text);

};
const handleChatThreadNavigation = (data:any)=>{
    let userMemberId = {};
    for(let i=0; i<chatUsersConversation.length;i++)
    {
      
      if(data._id===chatUsersConversation[i].lastMessage.receiver._id)
      {
        userMemberId = chatUsersConversation[i];
        break;
      }
    }
    let dataPlayload = userMemberId;
    if(Object.keys(dataPlayload).length === 0)
    {
         showMessage({
              message: "Error",
              description: "Can not chat with this user for now",
              type: "warning",
            });
    }
    setSearch('');
    navigation.navigate('SpecificChatThread',{data:dataPlayload,loginUserId:loginUserId});

}
useEffect(() => {
  fetchChatUsers();
}, [])

  return (
    <MainLayout navigation={navigation} activeTabIndex={4}>
    <View style={style.MainWrapper}>
        <View style={style.dorpdownContainer}>
            <View style={style.dropdownBox}>
               <Image source={images.searchIcon} style={style.searchImg}/>
                <TextInput 
                value={search}
                onChangeText={handleSearch}
                placeholderTextColor={colors.inputPlaceHolderColor}
                placeholder={'Search'} style={style.searchInput}/>
                {
                  search !== '' &&(
                    recentChatUser.filter((item:CommunitySearch)=>(item.firstName+' '+item.lastName).toLowerCase().includes(search.toLowerCase())).map((item:CommunitySearch,index)=>{
                      return(
                        <View style={style.searchInnerBox}>
                        <ScrollView style={style.searchInnerList}>
                       <TouchableOpacity 
                       onPress={()=>{handleChatThreadNavigation(item)}}
                          style={style.searchInnerBoxBtn}>
                          <View style={style.searchInnerBoxView}>
                           {
                            item?.profilePic?.path === undefined || null ?
                            <Image source={images.NoImgProfile} resizeMode='cover' style={{width:hp(4),height:hp(4),borderRadius:50}}/>
                            :
                            <Image source={{
                               uri: `${NEXT_PUBLIC_BUCKET_URL}/${item?.profilePic?.path}`
                            }} resizeMode='cover' style={{width:hp(4),height:hp(4),borderRadius:50}}/>
                           }
                          </View>
                          <View style={style.searchNameBox}>
                           <Text style={style.searchNameBoxText}>
                                {item.firstName+" "+item.lastName}
                           </Text>                          
                          </View>
                      </TouchableOpacity>
                </ScrollView>
                </View>
                    )
                   })
                 ) 
               }

            </View>
            <View style={style.chatTabView}>
              {
                ['All Chat','Unread Chat','Group Chat'].map((item,index)=>{
                  return(
                    <TouchableOpacity 
                     onPress={()=>{handleTabChange(index)}}
                     style={{backgroundColor:index===activeTab?colors.activeChatTab:colors.inputBgColor,paddingVertical:hp(1),paddingHorizontal:hp(2),borderRadius:50}} key={index}>
                      <Text style={{textAlign:'center',fontSize:hp(1.25),color:index===activeTab?colors.black:colors.textMuted,fontWeight:index===activeTab?'600':'400'}}>
                        {item}
                      </Text>
                    </TouchableOpacity>
                  )
                })
              }
            </View>
        </View>
        <ScrollView style={style.ChatlistingBox}>
               {
                 chatUsersConversation&&chatUsersConversation.map((item:any,index)=>{
                  return(
                    <CommunityMessageCard onPress={()=>{
                       navigation.navigate('SpecificChatThread',{data:item,loginUserId:loginUserId})
                    }} key={index} imgUrl={item?.profilePic?.path === undefined || null ?'':item?.profilePic?.path} memberName={item.lastMessage.receiver?.firstName+" "+item?.lastMessage.receiver?.lastName} lastMessage={item.lastMessage.message.replace(/^"|"$/g, '').replace(/<[^>]*>/g, '').trim()} messageTime={moment(item.lastMessage.createdAt).local().format('hh:mm A')} isRead={false} isMessagePined={false} isMemberOnline={false}/>
                  )
                 })
               }
            </ScrollView>
            {(isChatUserFetching || isChatUserConversationFetching) && <Loader />}
    </View>
    </MainLayout>
  )
}
export default CommunityDashboardScreen
const style = StyleSheet.create({
  MainWrapper:{
    flex:1
  },
  dorpdownContainer:{
    backgroundColor:colors.white,
    display:'flex',
    alignItems:'center',
    justifyContent:'center',
    width:'100%',
    borderColor:'red',
    borderWidth:0
  },
  dropdownBox:{
    width:'80%',
    marginVertical:hp(2),
    borderColor:'#D4D4D4',
    borderWidth:1,
    borderRadius:8,
    backgroundColor:colors.inputBgColor,
    display:'flex',
    flexDirection:'row',
    alignItems:'center',
    paddingHorizontal:hp(1),
    position:'relative'
  },
  searchImg:{
    width:hp(2),
    height:hp(2)
  },
  searchInput:{
     flex:1,
     borderColor:'red',
     borderWidth:0,
     fontSize:hp(1.5)
  },
  searchInnerBox:{
    width:'100%',
    position:'absolute',
    bottom:hp(-20),
    left:0,
    padding:hp(2),
    zIndex:500,
    borderColor:colors.textMuted,
    borderWidth:0.5,
    height:hp(20),
    backgroundColor:colors.white,
    borderRadius:10
  },
  searchInnerList:{
    flex:1,
    borderColor:'green',
    borderWidth:0
  },
  searchInnerBoxBtn:{
    width:'100%',marginBottom:hp(2),display:'flex',flexDirection:'row',flexWrap:'wrap',borderBottomColor:colors.textGray,alignItems:'center',justifyContent:'flex-start',borderBottomWidth:1,paddingBottom:hp(1),gap:hp(2)
  },
  searchInnerBoxView:{
    width:'16%',height:'100%',borderColor:'red',borderWidth:0,display:'flex'
  },
  searchNameBox:{
    width:'64%',borderColor:'green',borderWidth:0,display:'flex',flexDirection:'column',flexWrap:'wrap'
  },
  searchNameBoxText:{
    fontSize:hp(1.5),fontWeight:'600',color:colors.black
  },
  chatTabView:{
    width:'80%',borderColor:'red',borderWidth:0,display:'flex',flexDirection:'row',gap:hp(1),marginBottom:hp(2)
  },
  ChatlistingBox:{
    flex:1,width:'100%',borderColor:'red',borderWidth:0,marginTop:hp(2),padding:hp(2)
  }
  

})