import {
    View,
    Modal,
    StyleSheet,
    Dimensions,
    Text,
    TouchableOpacity,
  } from 'react-native';
  import React from 'react';
  import {useSelector} from 'react-redux';
  import {checkPermission} from '../../../redux/slices/PermissionSlice';
  
  const CallModal = ({show, onCancel, onConfirm}:any) => {
   
    return (
      <Modal visible={show} transparent>
        <View style={styles.modalView}>
          <View style={styles.mainView}>
            <Text style={styles.title}>Confirmation</Text>
            <View style={styles.separator} />
            <Text style={styles.message}>
              Are you sure you want {'\n'} to call the user?
            </Text>
            <Text style={styles.note}>
              Note: it will navigate you to another tab
            </Text>
            <View style={styles.buttonContainer}>
              
                <TouchableOpacity
                  style={styles.confirmButton}
                  onPress={onConfirm}>
                  <Text style={styles.buttonText}>Yes</Text>
                </TouchableOpacity>
              
              <TouchableOpacity style={styles.cancelButton} onPress={onCancel}>
                <Text style={{...styles.buttonText, color: 'black'}}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    );
  };
  
  export default CallModal;
  
  const styles = StyleSheet.create({
    modalView: {
      height: Dimensions.get('window').height,
      width: Dimensions.get('window').width,
      backgroundColor: 'rgba(0,0,0,0.6)',
      justifyContent: 'center',
      alignItems: 'center',
    },
    mainView: {
      height: 250,
      width: '80%',
      borderRadius: 10,
      backgroundColor: '#fff',
      padding: 15,
    },
    title: {
      fontSize: 20,
      marginLeft: 10,
      marginTop: 10,
      fontWeight: 'bold',
    },
    separator: {
      height: 1,
      backgroundColor: '#ccc',
      marginVertical: 10,
    },
    message: {
      fontSize: 16,
      marginHorizontal: 10,
      textAlign: 'center',
    },
    note: {
      fontSize: 14,
      marginHorizontal: 10,
      textAlign: 'center',
      color: 'red',
    },
    buttonContainer: {
      flexDirection: 'row',
      width: '80%',
      marginTop: 20,
      justifyContent: 'space-between',
      alignSelf: 'center',
    },
    confirmButton: {
      backgroundColor: '#6b21a8',
      height: 40,
      width: 100,
      borderRadius: 5,
      alignItems: 'center',
      justifyContent: 'center',
    },
    cancelButton: {
      backgroundColor: '#f0f0f0',
      height: 40,
      width: 100,
      borderRadius: 5,
      alignItems: 'center',
      justifyContent: 'center',
      borderWidth: 1,
    },
    buttonText: {
      textAlign: 'center',
      color: 'white',
      fontWeight: 'bold',
      fontSize: 16,
    },
  });
  