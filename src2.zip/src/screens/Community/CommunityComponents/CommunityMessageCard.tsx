import { View, Text, TouchableOpacity,Image,StyleSheet } from 'react-native'
import React from 'react'
import { MessageDataCard } from '../../data'
import { heightPercentageToDP as hp } from 'react-native-responsive-screen'
import { colors,images } from '../../../config'
import { NEXT_PUBLIC_BUCKET_URL } from "@env";
const CommunityMessageCard = ({imgUrl,memberName,lastMessage,messageTime,isRead,isMessagePined,isMemberOnline,onPress}:MessageDataCard) => {
  return (
    <TouchableOpacity 
     onPress={onPress}
    style={style.boxOne}>
    <View style={style.boxTwo}>
     {
      imgUrl === ''?
      <Image source={images.NoImgProfile} resizeMode='cover' style={style.noProfileImage}/>
      :
      <Image 
      source={{
         uri: `${NEXT_PUBLIC_BUCKET_URL}/${imgUrl}`
         }}
      resizeMode='cover' 
      style={style.profilePicImg}/>
     }
    </View>
    <View style={style.momberBox}>
     <Text style={style.memberText}>
          {memberName}
     </Text>
     <Text style={style.lastMessage}>
            {lastMessage}
     </Text>
    </View>
    <View style={style.messageBox}>
      <View style={style.messageInnerBox}>
      <Text style={style.messageInnerText}>
          {messageTime}
      </Text>
   <View style={style.messageImageBox}>
     {
        (isRead) && (
            <Image source={images.readMessageIcon} resizeMode='cover' style={style.readImage} />
        )
     }
     {
        (isMessagePined) && (
            <Image source={images.pinnedMessageIcon} resizeMode='cover'style={style.pinnedImage} /> 
        )
     }
   </View>
      </View>
    </View>
</TouchableOpacity>
  )
}

export default CommunityMessageCard
const style = StyleSheet.create({
 boxOne:{
  width:'100%',marginBottom:hp(4),display:'flex',flexDirection:'row',flexWrap:'wrap',borderColor:'green',alignItems:'center',justifyContent:'space-between',borderWidth:0
 },
 boxTwo:{width:'16%',height:'100%',borderColor:'red',borderWidth:0,display:'flex'},
 noProfileImage:{width:hp(6),height:hp(6),borderRadius:50},
 profilePicImg:{width:hp(6),height:hp(6),borderRadius:50},
 momberBox:{width:'64%',borderColor:'green',borderWidth:0,display:'flex',flexDirection:'column',flexWrap:'wrap'},
 memberText:{fontSize:hp(1.5),fontWeight:'600',color:colors.black},
 lastMessage:{width:'100%',flexWrap:'wrap',fontSize:hp(1.25),color:colors.textMuted,marginTop:hp(.5)},
 messageBox:{width:'16%',height:'100%',borderColor:'blue',borderWidth:0,display:'flex',flexDirection:'column'},
 messageInnerBox:{flex:1,borderColor:'red',borderWidth:0,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'space-between'},
 messageInnerText:{fontSize:hp(1.125),color:colors.textMuted},
 messageImageBox:{width:'100%',borderColor:'red',borderWidth:0,display:'flex',flexDirection:'row',alignItems:'center',gap:hp(1)},
 readImage:{width:hp(2.25),height:hp(1.5)},
 pinnedImage:{width:hp(3),height:hp(3)}
})