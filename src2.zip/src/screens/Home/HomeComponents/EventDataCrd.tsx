import {
  View,
  Text,
  TouchableOpacity,
  Alert,
  Image,
  ImageBackground,
} from "react-native";
import React from "react";
import { colors, images } from "../../../config";
import { heightPercentageToDP as hp } from "react-native-responsive-screen";
import { eventCrad } from "../../data";
import { NEXT_PUBLIC_BUCKET_URL } from "@env";
import moment from "moment";

const EventDataCrd = ({
  isOnline,
  eventBannerImage,
  eventEndTime,
  eventTime,
  eventName,
  eventStart,
  eventCategory,
  event_id,
  navigation,
}: any) => {
  const formattedDate = moment(eventTime).format("MMMM DD, YYYY"); // April 13, 2025
  const startTime = moment(eventTime).format("hh:mm A"); // 10:00 AM (Pakistan time is +5 offset)
  const endTime = moment(eventEndTime).format("hh:mm A");

  return (
    <TouchableOpacity
      onPress={() => {
        navigation.navigate("EventDetailsScreen",{id:event_id});
      }}
      style={{
        borderColor: "black",
        borderWidth: 0,
        width: "100%",
        borderRadius: 15,
        padding: hp(2),
        backgroundColor: colors.eventcardBg,
        display: "flex",
        flexDirection: "column",
        gap: hp(1),
      }}
    >
      <View
        style={{
          width: "100%",
          borderColor: "red",
          borderWidth: 0,
          display: "flex",
          flexDirection: "row",
        }}
      >
        <ImageBackground
          source={{
            uri: `${NEXT_PUBLIC_BUCKET_URL}/${eventBannerImage?.path}`,
          }}
          style={{ flex: 0.3, borderColor: "blue", borderWidth: 0 }}
        />

        <View
          style={{
            flex: 0.7,
            borderColor: "green",
            borderWidth: 0,
            padding: hp(1),
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "flex-start",
            gap: hp(2),
          }}
        >
          <View
            style={{
              width: "100%",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "space-between",
              gap: hp(1.25),
            }}
          >
            <View
              style={{
                width: "100%",
                borderColor: "black",
                borderWidth: 0,
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "flex-start",
                gap: hp(1),
              }}
            >
              <View
                style={{
                  paddingHorizontal: hp(1.25),
                  paddingVertical: hp(0.5),
                  borderRadius: 50,
                  backgroundColor: "#E8E8E8",
                }}
              >
                <Text
                  style={{
                    color: colors.black,
                    fontWeight: "600",
                    fontSize: hp(1.5),
                  }}
                >
                  {isOnline}
                </Text>
              </View>
              <View
                style={{
                  paddingHorizontal: hp(1.25),
                  paddingVertical: hp(0.5),
                  borderRadius: 50,
                  backgroundColor: "#E8E8E8",
                }}
              >
                <Text
                  style={{
                    color: colors.black,
                    fontWeight: "600",
                    fontSize: hp(1.5),
                  }}
                >
                  {eventCategory}
                </Text>
              </View>
            </View>
            <Text
              style={{
                color: colors.black,
                fontSize: hp(2.25),
                fontWeight: "600",
                width: "100%",
                flexWrap: "wrap",
              }}
            >
              {eventName}
            </Text>
          </View>

          <View
            style={{
              width: "100%",
              borderColor: "red",
              borderWidth: 0,
              display: "flex",
              alignItems: "flex-start",
              justifyContent: "flex-start",
            }}
          >
            <Text
              style={{
                color: colors.textMuted,
                fontWeight: "600",
                fontSize: hp(1.35),
              }}
            >
              {formattedDate} -
              <Text
                style={{
                  color: colors.primary,
                  fontWeight: "600",
                  fontSize: hp(1.35),
                }}
              >
                {` ${startTime}`}
              </Text>{" "}
              -
              <Text
                style={{
                  color: colors.primary,
                  fontWeight: "600",
                  fontSize: hp(1.35),
                }}
              >
                {` ${endTime}`}
              </Text>
            </Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
};

export default EventDataCrd;
