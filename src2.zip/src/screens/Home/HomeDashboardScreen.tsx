import { View, Text, ScrollView, Image, TouchableOpacity } from "react-native";
import React, { useEffect, useState, useRef } from "react";
import MainLayout from "../../layout/MainLayout";
import { colors, images } from "../../config";
import { heightPercentageToDP as hp } from "react-native-responsive-screen";
import EventDataCrd from "./HomeComponents/EventDataCrd";
import HeadingAndLead from "./HomeComponents/HeadingAndLead";
import CommunityDataCard from "./HomeComponents/CommunityDataCard";
import QuickAccessCrad from "./HomeComponents/QuickAccessCrad";
import { eventData, communityData, quickAccessData } from "../data";
import { getEventsAction } from "../../actions/eventAction";
import AsyncStorage from "@react-native-async-storage/async-storage";
import connectionSocket from "../../../Socket";
import { useChat } from "../../../ChatProvider,";
const HomeDashboardScreen = ({ navigation }: any) => {
  const [upcomingEvents, setUpcomingEvents] = useState([]);
  const socketRef = useRef(null);
  const {masseges, setMesseges} = useChat();
  const getEventData = async () => {
    const data = await getEventsAction(1, 10);
    const user = await AsyncStorage.getItem("user") as string;
    setUpcomingEvents(data.data.data.documents.slice(0,3));
    handleSocketConnect(JSON.parse(user));
  };
  const handleSocketConnect=async(user:any)=>{
    console.log('User is : ',user);
    let loginUserId = user?._id;
    let socket = await connectionSocket();
    console.log('connected socket is : ',socket); 
    console.log('Login user id is : ',loginUserId);
    socketRef.current = socket
    const checkAndRegisterListeners = () => {
      if (socket.connected && loginUserId) {
        // console.log('Socket connected:', socket.id);
        // Register event listeners only after connection
        
        socket.emit("authenticate", loginUserId);
        socket.on("new_message", (msg:any)=>{
          console.log('Messages before new message arrival : ',msg);
          let newMessage = {
            attachments:msg?.message?.attachments,
            conversation:msg?.message?.conversation,
            createdAt:msg?.message?.createdAt,
            forwardedMessage:msg?.message?.forwardedMessage,
            isDeleted:msg?.message?.isDeleted,
            isEdited:msg?.message?.isEdited,
            isPinned:msg?.message?.isPinned,
            message:msg?.message?.message,
            messageType:msg?.message?.messageType,
            reactions:msg?.message?.reactions,
            receiverDetails:msg?.message?.receiver,
            senderDetails:msg?.message?.sender,
            _id:msg?.message?._id
          };
          setMesseges([...masseges,newMessage]);
          console.log('New message is receives after update : ',newMessage)
        });
        // socket.on(INCOMING_CALL, handleCall);
        socket.on("incoming_call", (data:any)=>{
          let dataPayload = {...data,id:user?._id}
          navigation.navigate('IncommingCallScreen',{data:dataPayload});
          // Alert.alert('Receive the incooming call notification');
        });
      } else {
        // console.log('Socket not connected, retrying...');
        setTimeout(checkAndRegisterListeners, 500); // Retry after a short delay
      }
    };
    checkAndRegisterListeners();
      socket.on('error', (err:any) => {
      // console.error('Socket error:', err);
    });
  }
  useEffect(() => {
    getEventData();
  }, []);

  return (
    <MainLayout navigation={navigation} activeTabIndex={2}>
      <ScrollView style={{ flex: 1, backgroundColor: colors.white }}>
        <View
          style={{
            width: "100%",
            height: hp(25),
            borderColor: "red",
            borderWidth: 0,
            marginBottom: hp(3),
          }}
        >
          <Image
            source={images.dashboardBanner}
            resizeMode="cover"
            style={{ width: "100%", height: "100%" }}
          />
        </View>
        <View>
          <View
            style={{
              width: "100%",
              paddingHorizontal: hp(3),
              borderColor: "red",
              borderWidth: 0,
              display: "flex",
              flexDirection: "column",
              gap: hp(2),
            }}
          >
            <HeadingAndLead
              title="Events"
              text="View all events happening near you."
            />
            {upcomingEvents.map((item: any, index) => {
              return (
                <EventDataCrd
                  navigation={navigation}
                  key={index}
                  isOnline={item?.type?.type}
                  eventTime={item.startDateTime}
                  eventName={item.name}
                  eventStart={item.status}
                  eventEndTime={item.endDateTime}
                  eventCategory={item.category}
                  eventBannerImage={item.bannerImage}
                  event_id={item._id}
                />
              );
            })}
            <TouchableOpacity
              style={{
                backgroundColor: colors.primary,
                padding: hp(2),
                width: "100%",
                borderRadius: 10,
              }}
            >
              <Text style={{ color: colors.white }}>View All Events.</Text>
            </TouchableOpacity>
            <HeadingAndLead
              title="Community"
              text="View all events happening near you."
            />
            {communityData.map((item, index) => {
              return (
                <CommunityDataCard
                  key={index}
                  imgurl={item.imgurl}
                  memberName={item.memberName}
                  memberMessage={item.memberMessage}
                  isRead={item.isRead}
                  messageTime={item.messageTime}
                />
              );
            })}
            <TouchableOpacity
              style={{
                backgroundColor: colors.primary,
                padding: hp(2),
                width: "100%",
                borderRadius: 10,
              }}
            >
              <Text style={{ color: colors.white }}>View All Messages.</Text>
            </TouchableOpacity>
            <HeadingAndLead
              title="Quick Access"
              text="Click on interested topic to dive deep."
            />
            <View
              style={{
                width: "100%",
                display: "flex",
                flexDirection: "row",
                flexWrap: "wrap",
                gap: hp(1.25),
                borderColor: "red",
                borderWidth: 0,
              }}
            >
              {quickAccessData.map((item, index) => {
                return (
                  <QuickAccessCrad
                    key={index}
                    imgUrl={item.imgUrl}
                    name={item.name}
                    routeName={item.routeName}
                    navigation={navigation}
                  />
                );
              })}
              <TouchableOpacity
                style={{
                  backgroundColor: colors.primary,
                  padding: hp(2),
                  width: "100%",
                  borderRadius: 10,
                  marginBottom: hp(2),
                }}
              >
                <Text style={{ color: colors.white, textAlign: "center" }}>
                  View More
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </MainLayout>
  );
};
export default HomeDashboardScreen;
function setMesseges(arg0: any[]) {
  throw new Error("Function not implemented.");
}

