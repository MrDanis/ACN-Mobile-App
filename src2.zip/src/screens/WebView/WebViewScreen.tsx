import { useNavigation } from "@react-navigation/native";
import React, { useEffect, useState } from "react";
import {
  View,
  StyleSheet,
  PermissionsAndroid,
  Platform,
  Alert,
  SafeAreaView,
} from "react-native";
import { WebView } from "react-native-webview";
import Loader from "../../components/Loader/Loader";
import MainLayout from "../../layout/MainLayout";

const WebViewScreen = ({ route, navigation }: any) => {
  const { url } = route.params;
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const requestPermissions = async () => {
      if (Platform.OS === "android") {
        try {
          //permissions
          const granted = await PermissionsAndroid.requestMultiple([
            PermissionsAndroid.PERMISSIONS.CAMERA,
            PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
          ]);

          const cameraGranted =
            granted[PermissionsAndroid.PERMISSIONS.CAMERA] ===
            PermissionsAndroid.RESULTS.GRANTED;
          const micGranted =
            granted[PermissionsAndroid.PERMISSIONS.RECORD_AUDIO] ===
            PermissionsAndroid.RESULTS.GRANTED;

          if (!cameraGranted || !micGranted) {
            Alert.alert(
              "Permissions Required",
              "Both Camera and Microphone permissions are required for the video call to work. Please enable them in your settings.",
              [{ text: "OK" }]
            );
          }
        } catch (err) {
          console.warn(err);
        }
      }
    };

    requestPermissions();
  }, []);

  const handleLoadStart = () => setLoading(true);
  const handleLoadEnd = () => setLoading(false);

  return (
    <MainLayout navigation={navigation} activeTabIndex={6}>
      <View style={{ flex: 1 }}>
        {loading && <Loader />}
        <WebView
          source={{ uri: url }}
          style={{ flex: 1 }}
          onLoadStart={handleLoadStart}
          onLoadEnd={handleLoadEnd}
          javaScriptEnabled={true}
          domStorageEnabled={true}
          mediaPlaybackRequiresUserAction={false}
          allowsInlineMediaPlayback={true}
          onError={() => Alert.alert("Failed to load web page.")}
          onHttpError={(syntheticEvent) => {
            const { nativeEvent } = syntheticEvent;
            Alert.alert(`HTTP Error: ${nativeEvent.statusCode}`);
          }}
        />
      </View>
    </MainLayout>
  );
};

export default WebViewScreen;

