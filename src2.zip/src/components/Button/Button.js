import { TouchableOpacity, Text } from "react-native";
import React from "react";
import { btnStyle } from "./styles";
import { heightPercentageToDP as hp } from "react-native-responsive-screen";
import { colors } from "../../config";
// 0:primary 1:outline

const Button = ({ handlePress, text, type ,disable}) => {
  return (
    <TouchableOpacity
     disabled={disable}
      onPress={handlePress}
      style={type === 0 ? btnStyle.primaryBtn : btnStyle.outlineBtn}
    >
      <Text
        style={{
          fontSize: hp(2),
          borderColor: "red",
          borderWidth: 0,
          color: type === 0 ? colors.white : colors.black,
          fontWeight: "500",
        }}
      >
        {text}
      </Text>
    </TouchableOpacity>
  );
};

export default Button;
