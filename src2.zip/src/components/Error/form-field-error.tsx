import { Text, View } from "react-native";
import { useFormContext } from "react-hook-form";
import { heightPercentageToDP as hp } from "react-native-responsive-screen";
import Icon from "react-native-vector-icons/MaterialIcons";

interface FormFieldErrorProps {
  name: string;
}

const FormFieldError = ({ name }: FormFieldErrorProps) => {
  const form = useFormContext();
  const error = form.getFieldState(name, form.formState).error;

  return error ? (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        marginBottom: hp(0),
      }}
    >
      <Icon name="error" size={17} color="red" />
      <Text style={{ color: "red", marginLeft: hp(1) }}>{error.message}</Text>
    </View>
  ) : null;
};

export { FormFieldError };
