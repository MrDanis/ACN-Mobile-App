import { View, Modal, StyleSheet, Dimensions } from "react-native";
import React from "react";
import { WaveIndicator } from "react-native-indicators";
import { colors } from "../../config";

const Loader = () => {
  return (
    <Modal visible={true} transparent>
      <View style={styles.modalView}>
        <View style={styles.mainView}>
          {/* Make sure to not pass a 'key' prop here */}
          <WaveIndicator size={40} color={colors.primary} />
        </View>
      </View>
    </Modal>
  );
};

export default Loader;

const styles = StyleSheet.create({
  modalView: {
    height: Dimensions.get("window").height,
    width: Dimensions.get("window").width,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "center",
    alignItems: "center",
    //   borderRadius: 10,
  },
  mainView: {
    height: 100,
    width: 100,
    borderRadius: 50,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
  },
});
