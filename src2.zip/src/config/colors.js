const colors = {
    primary:'#977240',
    white:'#FFFFFF',
    black:'#000000',
    textMuted:'#A0A0A0',
    blue:'#3AA1F4',
    sendMsgBg:"#E8E8E8",
    headerBackColor:'#F4F5F7',
    inputPlaceHolderColor:'#8391A1',
    inputBorder:'#EDF1F3',
    forgotPasswordColor:'#4D81E7',
    textGray:'#6C7278',
    leadBg:'#CC3333',
    eventcardBg:'#F2F2F2',
    eventOnline:'#00B383',
    inputBgColor:'#F6F6F6',
    activeChatTab:'#FFE4CD'
}
export default colors;