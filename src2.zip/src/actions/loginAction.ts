import apiClient from "../utils/api";
import { LOGIN_ENDPOINT } from "./endpoint";
interface LoginRequest {
  email: string;
  password: string;
}

interface AuthResponse {
  user: Record<string, any>;
}

const loginAction = async ({
  email,
  password,
}: LoginRequest): Promise<AuthResponse> => {
  const response = await apiClient.post(LOGIN_ENDPOINT, { email, password });
  return {
    user: response.data,
  };
};

export { loginAction };
