import apiClient from "../utils/api";
import { START_EVENT } from "./endpoint";

interface StartEventParams {
  eventId: string;
}

const startEvent = async ({ eventId }: StartEventParams): Promise<any> => {
  try {
    const response = await apiClient.patch(START_EVENT(eventId), {});
    return {
      data: response.data,
    };
  } catch (error: any) {
    return {
      state: "error",
      error: error.message || "Failed to start event",
    };
  }
};

export { startEvent };
