import apiClient from "../utils/api";
import { CREATE_EVENTS } from "./endpoint";


interface EventApiPayload {
  name: string;
  startDateTime: string;
  endDateTime: string;
  noOfParticipants?: number;
  organizer: string[];
  attachment?: string[];
  description?: string;
  type: string;
  category?: string;
  participants?: string[];
  departmentIds?: string[];
  participantAccess?: string;
  location?: string;
  bannerImage?: string;
  [key: string]: any;
}
const createEvent = async (
  payload: EventApiPayload
): Promise<any> => {
  const response = await apiClient.post(CREATE_EVENTS, payload);

  if (response.state === "error") {
    return {
      state: "error",
      error: response.error,
    };
  }
  return {
    state: "success",
    data: response.data,
  };
};
export { createEvent };
