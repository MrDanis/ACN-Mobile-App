import apiClient from "../utils/api";
import { CANCEL_EVENT } from "./endpoint";

interface CancelEventParams {
  eventId: string;
}
const cancelEvent = async ({ eventId }: CancelEventParams): Promise<any> => {
  console.log(CANCEL_EVENT(eventId));
  const response = await apiClient.patch(CANCEL_EVENT(eventId), {
    status: "cancelled",
  });
  return {
    data: response.data,
  };
};

export { cancelEvent };
