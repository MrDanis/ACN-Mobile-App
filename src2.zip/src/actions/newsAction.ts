import apiClient from "../utils/api";
import { GET_CATEGORYIES, GET_NEWS } from "./endpoint";

interface AuthResponse {
  categories: Record<string, any>;
}

interface NewsResponse {
  news: Record<string, any>;
}

const getCategories = async (): Promise<AuthResponse> => {
  const response = await apiClient.get(GET_CATEGORYIES);
  return {
    categories: response.data,
  };
};

const getNews = async (id: any): Promise<NewsResponse> => {
  const response = await apiClient.get(`${GET_NEWS}${id}`);
  return {
    news: response.data,
  };
};
export { getCategories, getNews };