import apiClient from "../utils/api";
import { GET_EVENTS } from "./endpoint";
import moment from "moment";
interface DateRange {
  startDate: string;
  endDate: string;
}
const getEventsAction = async (
  page: number = 1,
  limit: number = 10,
  dateRange?: DateRange
): Promise<any> => {
  const url = new URL(GET_EVENTS);
 
  const startDateTime = dateRange?.startDate
    ? moment(dateRange.startDate).startOf("day").utc().toISOString()
    : moment().startOf("day").utc().toISOString();
 
  const endDateTime = dateRange?.endDate
    ? moment(dateRange.endDate).endOf("day").utc().toISOString()
    : moment().add(1, "year").endOf("day").utc().toISOString();
 
  // url.searchParams.append("page", page.toString());
  // url.searchParams.append("limit", limit.toString());
  url.searchParams.append("startDateTime", startDateTime);
  url.searchParams.append("endDateTime", endDateTime);
  console.log('Events fetching list is : ',url);
  const response = await apiClient.get(url.toString());
  if (response.state === "error") {
    return {
      state: "error",
      error: response.error,
    };
  }
  return {
    state: "success",
    data: response.data,
  };
};
 
export { getEventsAction };