import apiClient from "../utils/api";
import { GET_JOBS } from "./endpoint";

interface AuthResponse {
  user: Record<string, any>;
}

const jobAction = async (): Promise<AuthResponse> => {
  const response = await apiClient.get(GET_JOBS);
  return {
    user: response.data,
  };
};

export { jobAction };
