import apiClient from "../utils/api";
import { POST_FILE_UPLOAD } from "./endpoint";

interface UploadFileParams {
  file: File;
  fileBase64: string;
  type?: string;
  module?: string;
  isPrivate?: boolean;
}

const uploadFile = async ({
  file,
  fileBase64,
  type = "image",
  module = "event",
  isPrivate = false,
}: UploadFileParams): Promise<any> => {
  const payload = {
    files: [
      {
        fileName: file.name,
        contentType: file.type,
        size: `${Math.round((file.size / (1024 * 1024)) * 10) / 10} mb`,
        isSaved: true,
        data: fileBase64,
      },
    ],
  };
  const response = await apiClient.post(POST_FILE_UPLOAD, payload, {
    headers: {
      "Content-Type": "application/json",
    },
  });

  if (response.state === "error") {
    return {
      state: "error",
      error: response.error,
    };
  }
  return {
    state: "success",
    data: response.data,
  };
};

export { uploadFile };
