import apiClient from "../utils/api";
import { JOIN_EVENT } from "./endpoint";

interface JoinEventParams {
  eventId: string;
  participantId: any;
}

const joinEvent = async ({
  eventId,
  participantId,
}: JoinEventParams): Promise<any> => {
  try {
    const response = await apiClient.post(JOIN_EVENT, {
      eventId: eventId,
      participantId: participantId,
    });
    return {
      state: "success",
      data: response.data,
    };
  } catch (error: any) {
    return {
      state: "error",
      error: error.message || "Failed to join event",
    };
  }
};

export { joinEvent };
