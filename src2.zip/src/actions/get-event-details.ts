import apiClient from "../utils/api";
import { GET_EVENT_DETAILS } from "./endpoint";

interface EventDetailsParams {
  id: string;
}

const getEventDetails = async ({ id }: EventDetailsParams): Promise<any> => {
  const response = await apiClient.get(GET_EVENT_DETAILS(id));
  if (response.state === "error") {
    return {
      state: "error",
      error: response.error,
    };
  }
  return {
    state: "success",
    data: response.data,
  };
};

export { getEventDetails };
