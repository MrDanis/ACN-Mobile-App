import apiClient from "../utils/api";
import { GET_DEPARTMENTS, GET_EVENT_TYPE, GET_LOCATIONS, GET_USERS, GET_USERS_FOR_CHAT } from "./endpoint";

interface getLocations {
  locations: Record<string, any>;
}

interface getEventsTypes {
  eventType: Record<string, any>;
}

interface getUsersData {
    users: Record<string, any>;
  }

  interface getDepartmentData {
    invitees: Record<string, any>;
  }

const getLocations = async (name: any): Promise<getLocations> => {
  const response = await apiClient.get(GET_LOCATIONS(name));
  return {
    locations: response.data,
  };
};

const getEventsTypes = async (): Promise<getEventsTypes> => {
  const response = await apiClient.get(`${GET_EVENT_TYPE}`);
  return {
    eventType: response.data,
  };
};

const getUsersData = async (): Promise<getUsersData> => {
    const response = await apiClient.get(`${GET_USERS_FOR_CHAT}`);
    return {
        users: response.data,
    };
  };

  const getDepartmentData = async (): Promise<getDepartmentData> => {
    const response = await apiClient.get(`${GET_DEPARTMENTS}`);
    return {
        invitees: response.data,
    };
  };
export { getLocations, getEventsTypes ,getUsersData,getDepartmentData};
