import { SIGNUP_ENDPOINT } from "./endpoint";
import apiClient from "../utils/api";

interface SignUpRequest {
  firstName: string;
  lastName: string;
  treatyNo: string;
  drivingLicenseNo: string;
  phoneNo: string;
  email: string;
  password: string;
}

const signupAction = async ({
  firstName,
  lastName,
  treatyNo,
  drivingLicenseNo,
  phoneNo,
  email,
  password,
}: SignUpRequest): Promise<any> => {
  const response = await apiClient.post(SIGNUP_ENDPOINT, {
    firstName,
    lastName,
    treatyNo,
    drivingLicenseNo,
    phoneNo,
    email,
    password,
  });

  return {
    user: response.data,
  };
};

export { signupAction };
