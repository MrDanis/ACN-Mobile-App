import apiClient from "../utils/api";
import { CHAT_CONVERSATION_ENDPOINT,CHAT_USERS_ENDPOINT,CONVERSATION_ENDPOINT,CHAT_MESSAGING_PRIVATE,CHAT_MESSAGING_GROUP,CHAT_VOICE_CALL,CHAT_VOICE_CALL_JOIN_INCOMMING } from "./endpoint";
const chatUsersAction = async (): Promise<any> => {
    const response = await apiClient.get(CHAT_USERS_ENDPOINT);
    // console.log('User chat Endpoint : ',response);
    return {
        chatUsers:response?.data?.data
    }
};
const chatUsersConversationAction = async (): Promise<any> => {
    const response = await apiClient.get(CHAT_CONVERSATION_ENDPOINT);
    // console.log('User chat conversation Endpoint : ',response);
    return {
        conversations:response?.data?.data
    }
};
const SpecificChatUsersConversationAction = async (id:String): Promise<any> => {
     const response = await apiClient.get(`${CONVERSATION_ENDPOINT}/${id}?page=1&limit=20`);
    return {
        specificConversations:response?.data?.data
    }
};
const sendMessageChat = async (dataPayload:any,chatType:Number):Promise<any>=>{
    const response = await apiClient.post(chatType===0?CHAT_MESSAGING_PRIVATE:CHAT_MESSAGING_GROUP,dataPayload);
    // console.log('Response of the me ssage sending is : ',response);
    return {
        message:response?.data?.data
    }
}
const chatCalll = async(dataPayload:any):Promise<any>=>{
    const response = await apiClient.post(CHAT_VOICE_CALL,dataPayload);
    return { callStatus:response?.data?.data }
}
const joinIncommingCall = async(dataPayload:any):Promise<any>=>{
    const response = await apiClient.post(CHAT_VOICE_CALL_JOIN_INCOMMING,dataPayload)
    return { incommingCallStatus:response?.data?.data }
}
export { chatUsersAction,chatUsersConversationAction,SpecificChatUsersConversationAction,sendMessageChat,chatCalll,joinIncommingCall };