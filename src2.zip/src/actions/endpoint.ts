const LOGIN_ENDPOINT = `/v1/auth/login`; // Replace with your actual endpoint
const SIGNUP_ENDPOINT = `/v1/auth/signup`; // Replace with your actual endpoint
const CHAT_USERS_ENDPOINT = `/v1/user`;
const CHAT_GROUPS_ENDPOINT = `/v1/group`;
const CHAT_CONVERSATION_ENDPOINT = `v1/chat/getConversations`;
const CONVERSATION_ENDPOINT = `v1/chat/getConversation`;
const CHAT_MESSAGING_PRIVATE =`v1/chat/sendPrivateMessage`//for sending private message 
const CHAT_MESSAGING_GROUP =`v1/chat/sendGroupMessage`//for sending private message 
const CHAT_VOICE_CALL =`/v1/chat/callRequest`//for sending private message 
const CHAT_VOICE_CALL_JOIN_INCOMMING =`/v1/chat/joinCallRequest`//for sending private message 
const GET_EVENTS = `/v2/event`;
const GET_USER_PERMISSIONS = `/v1/permission/user`;
const GET_ACTIVITY_LOGS = `/v1/activity`;
const GET_USER_DETAILS = `/v1/auth/me`;
const UPDATE_USER_DETAILS = `/v1/user/profile`;
const CREATE_EVENTS = `/v1/event/create`;
const GET_EVENT_TYPE = `/v1/eventType`;
const GET_USERS = `/v1/user`;
const GET_JOBS = `/v1/job`;
const GET_NEWS = `/v1/blog?category=`;
const GET_CATEGORYIES=`/v1/blogCategory`
const GET_DEPARTMENT = `/v1/department`;
const POST_FILE_UPLOAD = `/v1/file/upload`;
const DELETE_FILE = `/v1/file`;
const GET_LOCATIONS = (name: string) => `/v1/location?search=${name}`;
const GET_EVENT_DETAILS = (id: string) => `/v1/event/${id}`;
const JOIN_EVENT  =`/v1/participant/joinEvent`;
const START_EVENT = (eventId: string) => `/v1/event/startEvent/${eventId}`;
const CANCEL_EVENT = (eventId: string) =>
  `/v1/event/status/${eventId}`;

const GET_DEPARTMENTS = `/v1/department`;
const GET_USERS_BY_DEPARTMENT = (departmentId: string) =>
  `/v1/user/department/${departmentId}`;
const GET_EVENT_NOTIFICATIONS = `/v1/participant/invitations`;
const GET_USERS_FOR_CHAT = `/v1/user/getUsersForChat`;

export {
  LOGIN_ENDPOINT,
  SIGNUP_ENDPOINT,
  CHAT_USERS_ENDPOINT,
  CHAT_GROUPS_ENDPOINT,
  CHAT_CONVERSATION_ENDPOINT,
  CONVERSATION_ENDPOINT,
  CHAT_MESSAGING_PRIVATE,
  CHAT_MESSAGING_GROUP,
  CHAT_VOICE_CALL,
  CHAT_VOICE_CALL_JOIN_INCOMMING,
  GET_EVENTS,
  GET_USER_DETAILS,
  UPDATE_USER_DETAILS,
  GET_USER_PERMISSIONS,
  GET_ACTIVITY_LOGS,
  CREATE_EVENTS,
  GET_EVENT_TYPE,
  GET_USERS,
  GET_DEPARTMENT,
  POST_FILE_UPLOAD,
  DELETE_FILE,
  GET_LOCATIONS,
  GET_EVENT_DETAILS,
  JOIN_EVENT,
  START_EVENT,
  CANCEL_EVENT,
  GET_DEPARTMENTS,
  GET_USERS_BY_DEPARTMENT,
  GET_EVENT_NOTIFICATIONS,
  GET_USERS_FOR_CHAT,
  GET_JOBS,
  GET_NEWS,
  GET_CATEGORYIES
};