import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { NEXT_PUBLIC_BACKEND_URL } from "@env";
import { showMessage } from "react-native-flash-message";

const api = axios.create({
  baseURL: NEXT_PUBLIC_BACKEND_URL,
  timeout: 10000,
  headers: {
    "Content-Type": "application/json",
  },
});

api.interceptors.request.use(
  async (config) => {
    const token = await AsyncStorage.getItem("authToken");

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor - handle token expiration
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      try {
        const refreshToken = await AsyncStorage.getItem("refreshToken");
        const response = await axios.post(
          `${NEXT_PUBLIC_BACKEND_URL}/v1/auth/refresh`,
          { refreshToken }
        );

        const { token, refreshToken: newRefreshToken } = response.data;
        await AsyncStorage.setItem("authToken", token);
        await AsyncStorage.setItem("refreshToken", newRefreshToken);

        originalRequest.headers.Authorization = `Bearer ${token}`;

        return api(originalRequest);
      } catch (refreshError) {
        await AsyncStorage.removeItem("authToken");
        await AsyncStorage.removeItem("refreshToken");
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

/**
 * Make API request
 * @param {string} method - HTTP method
 * @param {string} url - Endpoint
 * @param {object} data - Request body
 * @param {object} params - Query params
 * @param {object} headers - Additional headers
 * @returns {Promise} - Axios promise
 */
const makeRequest = async ({
  method,
  url,
  data = null,
  params = null,
  headers = {},
}) => {
  try {
    // console.log('Url Before calling is : ',`${NEXT_PUBLIC_BACKEND_URL}/${url}`);
    const response = await api({
      method,
      url,
      data,
      params,
      headers: {
        ...headers,
      },
    });
    console.log('response is : ',response);
    return response;
  } catch (error) {
    console.log('Api Error is : ',error.response)
    showMessage({
      message: "Error",
      description: `${error.response.data.message}`,
      type: "danger",
    });
    throw error;
  }
};

const apiClient = {
  get: (url, params, headers) =>
    makeRequest({ method: "get", url, params, headers }),
  post: (url, data, params, headers) =>
    makeRequest({ method: "post", url, data, params, headers }),
  put: (url, data, params, headers) =>
    makeRequest({ method: "put", url, data, params, headers }),
  patch: (url, data, params, headers) =>
    makeRequest({ method: "patch", url, data, params, headers }),
  delete: (url, data, params, headers) =>
    makeRequest({ method: "delete", url, data, params, headers }),
};

export default apiClient;
