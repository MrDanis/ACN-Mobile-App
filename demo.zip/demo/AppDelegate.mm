#import "AppDelegate.h"

#import <React/RCTBridge.h>
#import <React/RCTBundleURLProvider.h>
#import <React/RCTRootView.h>
//#import <GoogleSignIn/GoogleSignIn.h>
#import <Firebase.h>
#import <UserNotifications/UserNotifications.h>
#import <RNCPushNotificationIOS.h>
#import <PushKit/PushKit.h>
#import "RNVoipPushNotificationManager.h"
#import "RNCallKeep.h"
#ifdef FB_SONARKIT_ENABLED
#import <FlipperKit/FlipperClient.h>
#import <FlipperKitLayoutPlugin/FlipperKitLayoutPlugin.h>
#import <FlipperKitUserDefaultsPlugin/FKUserDefaultsPlugin.h>
#import <FlipperKitNetworkPlugin/FlipperKitNetworkPlugin.h>
#import <SKIOSNetworkPlugin/SKIOSNetworkAdapter.h>
#import <FlipperKitReactPlugin/FlipperKitReactPlugin.h>

static void InitializeFlipper(UIApplication *application) {
  FlipperClient *client = [FlipperClient sharedClient];
  SKDescriptorMapper *layoutDescriptorMapper = [[SKDescriptorMapper alloc] initWithDefaults];
  [client addPlugin:[[FlipperKitLayoutPlugin alloc] initWithRootNode:application withDescriptorMapper:layoutDescriptorMapper]];
  [client addPlugin:[[FKUserDefaultsPlugin alloc] initWithSuiteName:nil]];
  [client addPlugin:[FlipperKitReactPlugin new]];
  [client addPlugin:[[FlipperKitNetworkPlugin alloc] initWithNetworkAdapter:[SKIOSNetworkAdapter new]]];
  [client start];
}
#endif

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
  
  // Add me --- \/
    [FIRApp configure];
    // Add me --- /\
  
#ifdef FB_SONARKIT_ENABLED
  InitializeFlipper(application);
#endif

  RCTBridge *bridge = [[RCTBridge alloc] initWithDelegate:self launchOptions:launchOptions];
    RCTRootView *rootView = [[RCTRootView alloc] initWithBridge:bridge
                                                     moduleName:@"demo"
                                              initialProperties:nil];

    if (@available(iOS 13.0, *)) {
        rootView.backgroundColor = [UIColor systemBackgroundColor];
    } else {
        rootView.backgroundColor = [UIColor whiteColor];
    }
  
    [RNVoipPushNotificationManager voipRegistration];

    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    UIViewController *rootViewController = [UIViewController new];
    rootViewController.view = rootView;
    self.window.rootViewController = rootViewController;
    [self.window makeKeyAndVisible];
  
  UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
    center.delegate = self;
  
    return YES;
}

- (void)pushRegistry:(PKPushRegistry *)registry didUpdatePushCredentials:(PKPushCredentials *)credentials forType:(PKPushType)type {
  // Register VoIP push token (a property of PKPushCredentials) with server
  [RNVoipPushNotificationManager didUpdatePushCredentials:credentials forType:(NSString *)type];
}

- (void)pushRegistry:(PKPushRegistry *)registry didInvalidatePushTokenForType:(PKPushType)type
{
  // --- The system calls this method when a previously provided push token is no longer valid for use. No action is necessary on your part to reregister the push type. Instead, use this method to notify your server not to send push notifications using the matching push token.
}

// --- Handle incoming pushes
- (void)pushRegistry:(PKPushRegistry *)registry didReceiveIncomingPushWithPayload:(PKPushPayload *)payload forType:(PKPushType)type withCompletionHandler:(void (^)(void))completion {
  
  // Access the top-level dictionary
   NSDictionary *payloadDict = payload.dictionaryPayload;
   
   // Access the 'data' object
   NSDictionary *dataDict = payloadDict[@"data"];
   if (dataDict) {
     NSLog(@"Data Object: %@", dataDict);
     
     // Access the nested 'PayLoad' object inside 'data'
     NSDictionary *nestedPayload = dataDict[@"PayLoad"];
     if (nestedPayload) {
       NSLog(@"Nested PayLoad Object: %@", nestedPayload);
       
       // Extract values from the nested 'PayLoad'
       NSString *callerName = nestedPayload[@"CallerrName"];  // Note the key is 'CallerrName'
       NSString *uuid = [nestedPayload[@"CallerId"] lowercaseString];  // Correct key is 'CallerId'
       NSString *timeStampString = dataDict[@"TimeStamp"];  // TimeStamp is in 'data', not 'PayLoad'
       
       // Log the extracted values
       NSLog(@"Caller Name: %@", callerName);
       NSLog(@"UUID: %@", uuid);
       NSLog(@"Timestamp: %@", timeStampString);
       
       // Convert the timestamp string to NSDate
       NSDate *pushFireDate = [self dateFromUTCDateString:timeStampString];
       NSLog(@"Push Fire Date: %@", pushFireDate);
       
       if ([callerName length] == 0) {
         callerName = @"Physician";
       }
       
       if (fabs([pushFireDate timeIntervalSinceNow]) < 30) {
         [RNVoipPushNotificationManager didReceiveIncomingPushWithPayload:payload forType:(NSString *)type];
         if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) {
           [RNCallKeep reportNewIncomingCall:uuid handle:@"360PatientEngagement" handleType:@"generic" hasVideo:YES localizedCallerName:callerName supportsHolding:YES supportsDTMF:YES supportsGrouping:YES supportsUngrouping:YES fromPushKit:YES payload:payload.dictionaryPayload withCompletionHandler:^{
             completion();
           }];
         }
       }
       else {
         completion();
       }
       
     } else {
       NSLog(@"'PayLoad' object not found inside 'data'.");
     }
   } else {
     NSLog(@"'data' object not found in payload.");
   }
    
    // Notification under 20 seconds old, handle it, else ignore
    
  
}

//- (void)pushRegistry:(PKPushRegistry *)registry didUpdatePushCredentials:(PKPushCredentials *)credentials forType:(PKPushType)type {
//  // Register VoIP push token (a property of PKPushCredentials) with server
//  [RNVoipPushNotificationManager didUpdatePushCredentials:credentials forType:(NSString *)type];
//}
//
//- (void)pushRegistry:(PKPushRegistry *)registry didInvalidatePushTokenForType:(PKPushType)type
//{
//  // --- The system calls this method when a previously provided push token is no longer valid for use. No action is necessary on your part to reregister the push type. Instead, use this method to notify your server not to send push notifications using the matching push token.
//}
//
//
//
//- (void)pushRegistry:(PKPushRegistry *)registry didReceiveIncomingPushWithPayload:(PKPushPayload *)payload forType:(PKPushType)type withCompletionHandler:(void (^)(void))completion {
//  
//  NSString *callerName = payload.dictionaryPayload[@"caller"];
//  NSString *uuid = [payload.dictionaryPayload[@"call_id"] lowercaseString];
//  NSString *timeStampString = payload.dictionaryPayload[@"time"];
//  NSDate *pushFireDate = [self dateFromUTCDateString:timeStampString];
//  if ([callerName length] == 0) {
//    callerName = @"Physician";
//  }
//  // Notification under 20 seconds old, handle it, else ignore
//  if (fabs([pushFireDate timeIntervalSinceNow]) < 30) {
//    [RNVoipPushNotificationManager didReceiveIncomingPushWithPayload:payload forType:(NSString *)type];
//    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) {
//      [RNCallKeep reportNewIncomingCall:uuid handle:@"360 TeleWise" handleType:@"generic" hasVideo:YES localizedCallerName:callerName supportsHolding:YES supportsDTMF:YES supportsGrouping:YES supportsUngrouping:YES fromPushKit:YES payload:payload.dictionaryPayload withCompletionHandler:^{
//        completion();
//      }];
//    }
//  }
//  else {
//    completion();
//  }}

// AppDelegate.m
//- (BOOL)application:(UIApplication *)application openURL:(nonnull NSURL *)url options:(nonnull NSDictionary<NSString *,id> *)options {
//  return [[FBSDKApplicationDelegate sharedInstance] application:application openURL:url options:options] || [GIDSignIn.sharedInstance handleURL:url];
//}

// Required for the register event.
- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
 [RNCPushNotificationIOS didRegisterForRemoteNotificationsWithDeviceToken:deviceToken];
}
// Required for the notification event. You must call the completion handler after handling the remote notification.
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler
{
  [RNCPushNotificationIOS didReceiveRemoteNotification:userInfo fetchCompletionHandler:completionHandler];
}
// Required for the registrationError event.
- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
 [RNCPushNotificationIOS didFailToRegisterForRemoteNotificationsWithError:error];
}
// Required for localNotification event
- (void)userNotificationCenter:(UNUserNotificationCenter *)center
didReceiveNotificationResponse:(UNNotificationResponse *)response
         withCompletionHandler:(void (^)(void))completionHandler
{
  [RNCPushNotificationIOS didReceiveNotificationResponse:response];
}
//Called when a notification is delivered to a foreground app.
-(void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions options))completionHandler
{
  completionHandler(UNNotificationPresentationOptionSound | UNNotificationPresentationOptionList | UNNotificationPresentationOptionBanner | UNNotificationPresentationOptionBadge);
}
- (NSDate *)dateFromUTCDateString:(NSString *)dateString {
  NSDateFormatter *df = [NSDateFormatter new];
  df.timeZone = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
  df.locale = [NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];
  df.dateFormat = @"yyyy-MM-dd'T'HH:mm:ss.SSSZ";
  return [df dateFromString:dateString];
}





- (NSURL *)sourceURLForBridge:(RCTBridge *)bridge
{
#if DEBUG
    return [[RCTBundleURLProvider sharedSettings] jsBundleURLForBundleRoot:@"index"];
#else
  return [[NSBundle mainBundle] URLForResource:@"main" withExtension:@"jsbundle"];
#endif
}



@end
