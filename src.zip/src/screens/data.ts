
import { ReactNode } from "react";
import { images } from "../config";
export interface MainLayoutProps {
    children: ReactNode,
    navigation:any,
    activeTabIndex:number
}
type BottomTabs ={
    name:String,
    icon:any,
    navigationLink:String
}
export const bottomTabs:BottomTabs[] = [
  {
    name:'Event',
    icon:images.tabEventIcon,
    navigationLink:'EventDashboardScreen'
  },
  {
    name:'Notification',
    icon:images.tabNotificationtIcon,
    navigationLink:'NotificationDashboardScreen'
  },
  {
    name:'Home',
    icon:images.tabHomeIcon,
    navigationLink:'HomeDashboardScreen'
  },
  {
    name:'Jobs',
    icon:images.tabJobIcon,
    navigationLink:'JobDashboardScreen'
  },
  {
    name:'Community',
    icon:images.tabCommunityIcon,
    navigationLink:'CommunityDashboardScreen'
  }
]
//HomeDashboardScreen types
export type TextDiscription = {
  title:String,
  text:String
}
export type eventCrad = {
  isOnline:number,
  eventTime:String,
  eventName:String,
  eventStart:String
}
export const eventData:eventCrad[] = [
  {
    isOnline:1,
    eventTime:'10:00-13:00',
    eventName:'Design new UX flow for Michael',
    eventStart:'Start from screen 16'
  },
  {
    isOnline:1,
    eventTime:'10:00-13:00',
    eventName:'Design new UX flow for Michael',
    eventStart:'Start from screen 16'
  },
]
export type CommunityCard = {
  imgurl:any,
  memberName:String,
  memberMessage:String,
  isRead:boolean,
  messageTime:String
}
export const communityData:CommunityCard[] = [
  {
    imgurl:images.NoImgProfile,
    memberName:'Olivia Harper',
    memberMessage:'Let me know when you are free.',
    isRead:true,
    messageTime:'10:00 PM'
  },
  {
    imgurl:images.imgProfileAvatar,
    memberName:'Ava Bennett',
    memberMessage:'What’s the update?',
    isRead:true,
    messageTime:'12:30 PM'
  },
  {
    imgurl:images.NoImgProfile,
    memberName:'Kai Rivera',
    memberMessage:'Got it, thanks!',
    isRead:true,
    messageTime:'06:07 PM'
  },
]
export type quickAccessCard = {
  imgUrl:any,
  name:String
}
export const quickAccessData:quickAccessCard[] = [
  {
    imgUrl:images.employeeAccessIcon,
    name:'Employment'  
  },
  {
    imgUrl:images.communityAccessIcon,
    name:'Community'  
  },
  {
    imgUrl:images.eventsAccessIcon,
    name:'Events'  
  },
  {
    imgUrl:images.marketAccessIcon,
    name:'Market Place'  
  },
  {
    imgUrl:images.reportAccessIcon,
    name:'Reports'  
  },
  {
    imgUrl:images.servicesAccessIcon,
    name:'Services'  
  },
  {
    imgUrl:images.formsAccessIcon,
    name:'Forms'  
  },
  {
    imgUrl:images.blogAccessIcon,
    name:'Blogs'  
  },
]

type NotificationCard = {
  imgUrl:any,
  title:String,
  body:String,
  notificationTime:String,
  isConnected:boolean,
}
export const notificationData:NotificationCard[] = [
  {
    imgUrl:images.NoImgProfile,
    title:'Sam Smith',
    body:'trying to connect with you',
    notificationTime:'1m ago',
    isConnected:true,
  },
  {
    imgUrl:images.NoImgProfile,
    title:'Alex Lee',
    body:'Sent you a message',
    notificationTime:'5m ago',
    isConnected:false,
  },
  {
    imgUrl:images.NoImgProfile,
    title:'Ben Musk',
    body:'Sent you a message',
    notificationTime:'14m ago',
    isConnected:false,
  },
  {
    imgUrl:images.NoImgProfile,
    title:'Lora Smith',
    body:'Sent you a message',
    notificationTime:'29m ago',
    isConnected:false,
  },
  {
    imgUrl:images.NoImgProfile,
    title:'Jane Lama',
    body:'trying to connect with you',
    notificationTime:'1m ago',
    isConnected:true,
  },
  {
    imgUrl:images.NoImgProfile,
    title:'Mike Meyers',
    body:'Sent you a message',
    notificationTime:'5m ago',
    isConnected:true,
  },
  {
    imgUrl:images.NoImgProfile,
    title:'Dora Sun',
    body:'Sent you a message',
    notificationTime:'14m ago',
    isConnected:false,
  },
  {
    imgUrl:images.NoImgProfile,
    title:'James Barn',
    body:'Sent you a message',
    notificationTime:'29m ago',
    isConnected:false,
  },

] 
// Community dashboard types and data
export type MessageDataCard = {
  imgUrl:any,
  memberName:String,
  lastMessage:String,
  messageTime:String,
  isRead:boolean,
  isMessagePined:boolean,
  isMemberOnline:boolean,
  onPress?:()=>void
}
export const communityDashboardData:MessageDataCard[] = [
  {
    imgUrl:images.NoImgProfile,
    memberName:'Sophia Carter',
    lastMessage:'I had an amazing idea for the project. Let me know if you’re free to discuss!',
    messageTime:'10.24 PM',
    isRead:true,
    isMessagePined:true,
    isMemberOnline:true
  },
  {
    imgUrl:images.NoImgProfile,
    memberName:'Ethan Parker',
    lastMessage:'Can you send me the files? I couldn’t find them in the folder.',
    messageTime:'10.24 PM',
    isRead:true,
    isMessagePined:true,
    isMemberOnline:true
  },
  {
    imgUrl:images.NoImgProfile,
    memberName:'James Walker',
    lastMessage:'Don’t forget the deadline is this Friday at 5 PM.',
    messageTime:'10.24 PM',
    isRead:true,
    isMessagePined:false,
    isMemberOnline:false
  },
  {
    imgUrl:images.NoImgProfile,
    memberName:'Mia Davis',
    lastMessage:'It was great catching up earlier! Let’s plan something soon.',
    messageTime:'10.24 PM',
    isRead:true,
    isMessagePined:false,
    isMemberOnline:false
  },
  {
    imgUrl:images.NoImgProfile,
    memberName:'Noah Collins',
    lastMessage:'I’m on my way now. Should be there in 10 minutes.',
    messageTime:'10.24 PM',
    isRead:true,
    isMessagePined:false,
    isMemberOnline:false
  },
  {
    imgUrl:images.NoImgProfile,
    memberName:'Johnson Green',
    lastMessage:'Thanks for the update! I’ll review it and get back to you soon.',
    messageTime:'10.24 PM',
    isRead:true,
    isMessagePined:true,
    isMemberOnline:true
  },
  {
    imgUrl:images.NoImgProfile,
    memberName:'Liam Carter',
    lastMessage:'Just sent over the presentation slides. Check your inbox.',
    messageTime:'10.24 PM',
    isRead:true,
    isMessagePined:true,
    isMemberOnline:true
  },
]