import { View, Text, TouchableOpacity,Image } from 'react-native'
import React from 'react'
import { MessageDataCard } from '../../data'
import { heightPercentageToDP as hp } from 'react-native-responsive-screen'
import { colors,images } from '../../../config'
const CommunityMessageCard = ({imgUrl,memberName,lastMessage,messageTime,isRead,isMessagePined,isMemberOnline,onPress}:MessageDataCard) => {
  return (
    <TouchableOpacity 
     onPress={onPress}
    style={{width:'100%',marginBottom:hp(4),display:'flex',flexDirection:'row',flexWrap:'wrap',borderColor:'green',alignItems:'center',justifyContent:'space-between',borderWidth:0}}>
    <View style={{width:'16%',height:'100%',borderColor:'red',borderWidth:0,display:'flex'}}>
      <Image source={imgUrl} resizeMode='cover' style={{width:hp(6),height:hp(6)}}/>
    </View>
    <View style={{width:'64%',borderColor:'green',borderWidth:0,display:'flex',flexDirection:'column',flexWrap:'wrap'}}>
     <Text style={{fontSize:hp(1.5),fontWeight:'600',color:colors.black}}>
          {memberName}
     </Text>
     <Text style={{width:'100%',flexWrap:'wrap',fontSize:hp(1.25),color:colors.textMuted,marginTop:hp(.5)}}>
            {lastMessage}
     </Text>
    </View>
    <View style={{width:'16%',height:'100%',borderColor:'blue',borderWidth:0,display:'flex',flexDirection:'column'}}>
      <View style={{flex:1,borderColor:'red',borderWidth:0,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'space-between'}}>
      <Text style={{fontSize:hp(1.125),color:colors.textMuted}}>
          {messageTime}
      </Text>
   <View style={{width:'100%',borderColor:'red',borderWidth:0,display:'flex',flexDirection:'row',alignItems:'center',gap:hp(1)}}>
     {
        (isRead) && (
            <Image source={images.readMessageIcon} resizeMode='cover' style={{width:hp(2.25),height:hp(1.5)}} />
        )
     }
     {
        (isMessagePined) && (
            <Image source={images.pinnedMessageIcon} resizeMode='cover'style={{width:hp(3),height:hp(3)}} /> 
        )
     }
   </View>
      </View>
    </View>
</TouchableOpacity>
  )
}

export default CommunityMessageCard