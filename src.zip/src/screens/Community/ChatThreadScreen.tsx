import { View, Text,SafeAreaView, ScrollView,ImageBackground,Image, TouchableOpacity, Alert, TextInput } from 'react-native'
import React from 'react'
import {SafeAreaProvider} from 'react-native-safe-area-context';
import { colors,images } from '../../config';
import Footer from '../../components/Footer/Footer';
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';
import Button from '../../components/Button/Button';
const ChatThreadScreen = ({navigation}:any) => {
  return (
      <SafeAreaProvider>
               <SafeAreaView style={{flex:1,backgroundColor:colors.white}}>
                     <View style={{flex:.12,borderColor:'red',borderWidth:0,display:'flex',flexDirection:'row',gap:hp(1.5),alignItems:'center',paddingHorizontal:hp(2),justifyContent:'flex-start'}}>
                      <View style={{flex:1,borderColor:'green',borderWidth:0,display:'flex',flexDirection:'row',alignItems:'center',gap:hp(1)}}>
                      <TouchableOpacity onPress={()=>{navigation.pop()}}>
                        <Image source={images.backButton} style={{width:hp(3),height:hp(3)}}/>
                      </TouchableOpacity>
                          
                         <Image source={images.NoImgProfile} style={{width:hp(6),height:hp(6)}}/>
                          <View style={{flex:1,borderColor:'blue',borderWidth:0,display:'flex',flexDirection:'column',marginTop:hp(.75)}}>
                          <Text style={{color:colors.black,fontSize:hp(2),fontWeight:'600'}}>
                           Sophia Brown  
                          </Text>           
                          <Text style={{color:colors.black,fontSize:hp(1.5),fontWeight:'300'}}>
                          Last seen 2 hours ago 
                          </Text>           
                          </View>
                      </View>
                          <View style={{flex:.25,height:hp(5),display:'flex',flexDirection:'row',gap:hp(1),borderColor:'red',borderWidth:0,alignItems:'center',justifyContent:'space-between'}}>
                             <Image source={images.voiceCallIcon} resizeMode='contain' style={{width:hp(3),height:hp(3)}}/>
                             <Image source={images.videoCallIcon} resizeMode='contain' style={{width:hp(3),height:hp(3)}}/>
                          </View>
                     </View>     
                     <ScrollView style={{flex:.70,borderColor:'red',borderWidth:0}}>
                       <View style={{width:'100%',borderColor:'red',borderWidth:0,display:'flex',justifyContent:'flex-start'}}>
                          <View style={{padding:hp(1),width:'70%',borderColor:'green',borderWidth:0}}>
                            <Text style={{fontSize:hp(2),width:'100%',borderRadius:10,flexWrap:'wrap',padding:hp(2),color:colors.white,backgroundColor:colors.blue}}>
                              That’s good to hear! Take a look at this chart when you get a moment—it might help with the presentation section of the proposal.
                            </Text>
                            <Text style={{fontSize:hp(1.75),color:colors.textMuted,marginTop:hp(1)}}>
                               10.24 PM
                            </Text>
                          </View>
                       </View>
                       <View style={{width:'100%',borderColor:'green',borderWidth:0,display:'flex',alignItems:'flex-end',justifyContent:'flex-end'}}>
                          <View style={{padding:hp(1),width:'70%',borderColor:'green',borderWidth:0}}>
                            <Text style={{fontSize:hp(2),width:'100%',borderRadius:10,flexWrap:'wrap',padding:hp(2),color:colors.black,backgroundColor:'#E8E8E8'}}>
                              That’s good to hear! Take a look at this chart when you get a moment—it might help with the presentation section of the proposal.
                            </Text>
                            <Text style={{fontSize:hp(1.75),color:colors.textMuted,marginTop:hp(1),textAlign:'right'}}>
                               10.24 PM
                            </Text>
                          </View>
                       </View>
                       <View style={{width:'100%',borderColor:'red',borderWidth:0,display:'flex',justifyContent:'flex-start'}}>
                          <View style={{padding:hp(1),width:'70%',borderColor:'green',borderWidth:0}}>
                            <Text style={{fontSize:hp(2),width:'100%',borderRadius:10,flexWrap:'wrap',padding:hp(2),color:colors.white,backgroundColor:colors.blue}}>
                              That’s good to hear! Take a look at this chart when you get a moment—it might help with the presentation section of the proposal.
                            </Text>
                            <Text style={{fontSize:hp(1.75),color:colors.textMuted,marginTop:hp(1)}}>
                               10.24 PM
                            </Text>
                          </View>
                       </View>
                       <View style={{width:'100%',borderColor:'green',borderWidth:0,display:'flex',alignItems:'flex-end',justifyContent:'flex-end'}}>
                          <View style={{padding:hp(1),width:'70%',borderColor:'green',borderWidth:0}}>
                            <Text style={{fontSize:hp(2),width:'100%',borderRadius:10,flexWrap:'wrap',padding:hp(2),color:colors.black,backgroundColor:'#E8E8E8'}}>
                              That’s good to hear! Take a look at this chart when you get a moment—it might help with the presentation section of the proposal.
                            </Text>
                            <Text style={{fontSize:hp(1.75),color:colors.textMuted,marginTop:hp(1),textAlign:'right'}}>
                               10.24 PM
                            </Text>
                          </View>
                       </View>
                       <View style={{width:'100%',borderColor:'red',borderWidth:0,display:'flex',justifyContent:'flex-start'}}>
                          <View style={{padding:hp(1),width:'70%',borderColor:'green',borderWidth:0}}>
                            <Text style={{fontSize:hp(2),width:'100%',borderRadius:10,flexWrap:'wrap',padding:hp(2),color:colors.white,backgroundColor:colors.blue}}>
                              That’s good to hear! Take a look at this chart when you get a moment—it might help with the presentation section of the proposal.
                            </Text>
                            <Text style={{fontSize:hp(1.75),color:colors.textMuted,marginTop:hp(1)}}>
                               10.24 PM
                            </Text>
                          </View>
                       </View>
                       <View style={{width:'100%',borderColor:'green',borderWidth:0,display:'flex',alignItems:'flex-end',justifyContent:'flex-end'}}>
                          <View style={{padding:hp(1),width:'70%',borderColor:'green',borderWidth:0}}>
                            <Text style={{fontSize:hp(2),width:'100%',borderRadius:10,flexWrap:'wrap',padding:hp(2),color:colors.black,backgroundColor:'#E8E8E8'}}>
                              That’s good to hear! Take a look at this chart when you get a moment—it might help with the presentation section of the proposal.
                            </Text>
                            <Text style={{fontSize:hp(1.75),color:colors.textMuted,marginTop:hp(1),textAlign:'right'}}>
                               10.24 PM
                            </Text>
                          </View>
                       </View>
                       <View style={{width:'100%',borderColor:'red',borderWidth:0,display:'flex',justifyContent:'flex-start'}}>
                          <View style={{padding:hp(1),width:'70%',borderColor:'green',borderWidth:0}}>
                            <Text style={{fontSize:hp(2),width:'100%',borderRadius:10,flexWrap:'wrap',padding:hp(2),color:colors.white,backgroundColor:colors.blue}}>
                              That’s good to hear! Take a look at this chart when you get a moment—it might help with the presentation section of the proposal.
                            </Text>
                            <Text style={{fontSize:hp(1.75),color:colors.textMuted,marginTop:hp(1)}}>
                               10.24 PM
                            </Text>
                          </View>
                       </View>
                       <View style={{width:'100%',borderColor:'green',borderWidth:0,display:'flex',alignItems:'flex-end',justifyContent:'flex-end'}}>
                          <View style={{padding:hp(1),width:'70%',borderColor:'green',borderWidth:0}}>
                            <Text style={{fontSize:hp(2),width:'100%',borderRadius:10,flexWrap:'wrap',padding:hp(2),color:colors.black,backgroundColor:'#E8E8E8'}}>
                              That’s good to hear! Take a look at this chart when you get a moment—it might help with the presentation section of the proposal.
                            </Text>
                            <Text style={{fontSize:hp(1.75),color:colors.textMuted,marginTop:hp(1),textAlign:'right'}}>
                               10.24 PM
                            </Text>
                          </View>
                       </View>
                     </ScrollView>
                     <View style={{flex:.09,display:'flex',flexDirection:'row',alignItems:'center',borderColor:'green',borderWidth:0,backgroundColor:'#CBCBCB',paddingHorizontal:hp(2),gap:hp(1)}}>
                       <Image source={images.plusBlack} resizeMode='cover' style={{width:hp(2),height:hp(2)}}/>
                            <View style={{ height:'70%',width:'70%',marginVertical:hp(2),borderColor:'#D4D4D4',borderWidth:1,borderRadius:8,backgroundColor:colors.inputBgColor,display:'flex',flexDirection:'row',alignItems:'center',paddingHorizontal:hp(1)}}>         
                              <TextInput 
                              placeholderTextColor={colors.inputPlaceHolderColor}
                              placeholder={'Type your message'} style={{flex:1,borderColor:'red',borderWidth:0,fontSize:hp(1.5)}}/>
                            </View>
                            <View style={{flex:1,borderColor:'red',borderWidth:0,display:'flex',flexDirection:'row',justifyContent:'flex-end',gap:hp(2),paddingEnd:hp(1)}}>
                       <Image source={images.cameraBlack} resizeMode='contain' style={{width:hp(3),height:hp(3)}}/>
                       <Image source={images.micBlack} resizeMode='contain' style={{width:hp(3),height:hp(3)}}/>

                            </View>

                      </View>     
                     <View style={{flex:.08,borderColor:'red',borderWidth:0,backgroundColor:colors.white,elevation:7,display:'flex',alignItems:'center',justifyContent:'center',padding:hp(1.25)}}>
                      <Footer navigation={navigation} activeTab={3}/>
                     </View>     
               </SafeAreaView>
        </SafeAreaProvider>
  )
}

export default ChatThreadScreen