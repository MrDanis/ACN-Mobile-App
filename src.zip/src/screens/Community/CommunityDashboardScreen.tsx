import { View, Text, ScrollView,Image,TextInput, TouchableOpacity } from 'react-native'
import React from 'react'
import { heightPercentageToDP as hp } from 'react-native-responsive-screen'
import MainLayout from '../../layout/MainLayout'
import { colors,images } from '../../config'
import CommunityMessageCard from './CommunityComponents/CommunityMessageCard'
import { communityDashboardData } from '../data'
const CommunityDashboardScreen = ({navigation}:any) => {
  return (
    <MainLayout navigation={navigation} activeTabIndex={4}>
    <ScrollView style={{flex:1}}>
        <View style={{backgroundColor:colors.white,display:'flex',alignItems:'center',justifyContent:'center',width:'100%',borderColor:'red',borderWidth:0}}>
            <View style={{ width:'80%',marginVertical:hp(2),borderColor:'#D4D4D4',borderWidth:1,borderRadius:8,backgroundColor:colors.inputBgColor,display:'flex',flexDirection:'row',alignItems:'center',paddingHorizontal:hp(1)}}>
               <Image source={images.searchIcon} style={{width:hp(2),height:hp(2)}}/>
                <TextInput 
                placeholderTextColor={colors.inputPlaceHolderColor}
                placeholder={'Search'} style={{flex:1,borderColor:'red',borderWidth:0,fontSize:hp(1.5)}}/>
            </View>
            <View style={{width:'80%',borderColor:'red',borderWidth:0,display:'flex',flexDirection:'row',gap:hp(1),marginBottom:hp(2)}}>
              {
                ['All Chat','Unread Chat','Group Chat'].map((item,index)=>{
                  return(
                    <TouchableOpacity 
                     
                     style={{backgroundColor:index===0?colors.activeChatTab:colors.inputBgColor,paddingVertical:hp(1),paddingHorizontal:hp(2),borderRadius:50}} key={index}>
                      <Text style={{textAlign:'center',fontSize:hp(1.25),color:index===0?colors.black:colors.textMuted,fontWeight:index===0?'600':'400'}}>
                        {item}
                      </Text>
                    </TouchableOpacity>
                  )
                })
              }
            </View>
        </View>
            <View style={{width:'100%',borderColor:'red',borderWidth:0,marginTop:hp(2),padding:hp(2)}}>
               {/* <TouchableOpacity style={{width:'100%',display:'flex',flexDirection:'row',flexWrap:'wrap',borderColor:'green',alignItems:'center',justifyContent:'space-between',borderWidth:0}}>
                   <View style={{width:'16%',height:'100%',borderColor:'red',borderWidth:0,display:'flex'}}>
                     <Image source={images.NoImgProfile} resizeMode='cover' style={{width:hp(6),height:hp(6)}}/>
                   </View>
                   <View style={{width:'64%',borderColor:'green',borderWidth:0,display:'flex',flexDirection:'column',flexWrap:'wrap'}}>
                    <Text style={{fontSize:hp(1.5),fontWeight:'600',color:colors.black}}>
                         Sophia Carter
                    </Text>
                    <Text style={{width:'100%',flexWrap:'wrap',fontSize:hp(1.25),color:colors.textMuted,marginTop:hp(.5)}}>
                         I had an amazing idea for the project. Let me know if you’re free to discuss!
                    </Text>
                   </View>
                   <View style={{width:'16%',height:'100%',borderColor:'blue',borderWidth:0,display:'flex',flexDirection:'column'}}>
                     <View style={{flex:1,borderColor:'red',borderWidth:0,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'space-between'}}>
                     <Text style={{fontSize:hp(1.125),color:colors.textMuted}}>
                         10.24 PM
                     </Text>
                  <View style={{width:'100%',borderColor:'red',borderWidth:0,display:'flex',flexDirection:'row',alignItems:'center',gap:hp(1)}}>
                    <Image source={images.readMessageIcon} resizeMode='cover' style={{width:hp(2.25),height:hp(1.5)}} />
                    <Image source={images.pinnedMessageIcon} resizeMode='cover'style={{width:hp(3),height:hp(3)}} /> 
                  </View>

                     </View>
                    
                   </View>
               </TouchableOpacity> */}
               {
                 communityDashboardData.map((item,index)=>{
                  return(
                    <CommunityMessageCard onPress={()=>{navigation.navigate('SpecificChatThread')}} key={index} imgUrl={item.imgUrl} memberName={item.memberName} lastMessage={item.lastMessage} messageTime={item.messageTime} isRead={item.isRead} isMessagePined={item.isMessagePined} isMemberOnline={item.isMemberOnline}/>
                  )
                 })
               }
            </View>
    </ScrollView>
    </MainLayout>
  )
}

export default CommunityDashboardScreen