import { View, Text, ScrollView,Image, Pressable } from 'react-native'
import React from 'react'
import MainLayout from '../../layout/MainLayout'
import { heightPercentageToDP as hp } from 'react-native-responsive-screen'
import { colors,images } from '../../config'
import { notificationData } from '../data'
const NotificationDashboardScreen = ({navigation}:any) => {
  return (
    <MainLayout navigation={navigation} activeTabIndex={1}>
    <ScrollView style={{flex:1,padding:hp(3),borderColor:'red',borderWidth:0,backgroundColor:colors.white}}>
      <Text style={{color:colors.textMuted,fontSize:hp(2),marginBottom:hp(2)}}>
        Today
      </Text>
      {
        notificationData.slice(0,4).map((item,index)=>{
          return(

      <View style={{marginBottom:hp(2),width:'100%',display:'flex',flexDirection:'row',borderColor:'red',borderWidth:0,padding:hp(2),borderRadius:15,backgroundColor:colors.eventcardBg}}>
          <View style={{flex:1,display:'flex',flexDirection:'row',borderColor:'green',borderWidth:0,gap:hp(.5)}}>
                <Image source={item.imgUrl} style={{width:hp(6),height:hp(6)}}/>
                <View style={{flex:1,display:'flex',flexDirection:'column',gap:hp(.5),borderColor:'red',borderWidth:0}}>
                  <Text style={{marginTop:hp(1),fontSize:hp(2),fontWeight:'600',color:colors.black}}>
                     {item.title}
                  </Text>
                  <Text style={{fontSize:hp(1.25),fontWeight:'500',color:colors.black,width:'100%',flexWrap:'wrap'}}>
                   {item.body}
                  </Text>
                </View>
          </View>
          <View style={{flex:.45,borderColor:'blue',borderWidth:0,display:'flex',flexDirection:'column',alignItems:'flex-end',justifyContent:'space-between'}}>
            <Text style={{color:colors.textMuted,marginTop:hp(1),fontSize:hp(1.25)}}>
               {item.notificationTime}
            </Text>
            {
              (item.isConnected)&&(
            <Pressable style={{backgroundColor:colors.primary,borderRadius:5,padding:hp(.5),width:'80%'}}>
              <Text style={{color:colors.white,fontSize:hp(1.25),textAlign:'center'}}>
                Connect
              </Text>
            </Pressable>
              )
            }
          </View>
      </View>
          )
        })  
      }
      <Text style={{color:colors.textMuted,fontSize:hp(2),marginBottom:hp(2)}}>
        Yesterday
      </Text>
      {
        notificationData.slice(4,9).map((item,index)=>{
          return(

      <View style={{marginBottom:hp(2),width:'100%',display:'flex',flexDirection:'row',borderColor:'red',borderWidth:0,padding:hp(2),borderRadius:15,backgroundColor:colors.eventcardBg}}>
          <View style={{flex:1,display:'flex',flexDirection:'row',borderColor:'green',borderWidth:0,gap:hp(.5)}}>
                <Image source={item.imgUrl} style={{width:hp(6),height:hp(6)}}/>
                <View style={{flex:1,display:'flex',flexDirection:'column',gap:hp(.5),borderColor:'red',borderWidth:0}}>
                  <Text style={{marginTop:hp(1),fontSize:hp(2),fontWeight:'600',color:colors.black}}>
                     {item.title}
                  </Text>
                  <Text style={{fontSize:hp(1.25),fontWeight:'500',color:colors.black,width:'100%',flexWrap:'wrap'}}>
                   {item.body}
                  </Text>
                </View>
          </View>
          <View style={{flex:.45,borderColor:'blue',borderWidth:0,display:'flex',flexDirection:'column',alignItems:'flex-end',justifyContent:'space-between'}}>
            <Text style={{color:colors.textMuted,marginTop:hp(1),fontSize:hp(1.25)}}>
               {item.notificationTime}
            </Text>
            {
              (item.isConnected)&&(
            <Pressable style={{backgroundColor:colors.primary,borderRadius:5,padding:hp(.5),width:'80%'}}>
              <Text style={{color:colors.white,fontSize:hp(1.25),textAlign:'center'}}>
                Connect
              </Text>
            </Pressable>
              )
            }
          </View>
      </View>
          )
        })  
      }
      <View style={{width:'100%',height:hp(2)}}/>

    </ScrollView>
    </MainLayout>
  )
}

export default NotificationDashboardScreen