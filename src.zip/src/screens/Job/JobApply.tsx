import { View, Text,SafeAreaView, ScrollView,ImageBackground,Image, TouchableOpacity, Alert, TextInput } from 'react-native'
import React from 'react'
import {SafeAreaProvider} from 'react-native-safe-area-context';
import { colors,images } from '../../config';
import Footer from '../../components/Footer/Footer';
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';
import Button from '../../components/Button/Button';
const JobApply = ({navigation}:any) => {
  return (
    <SafeAreaProvider>
           <SafeAreaView style={{flex:1,backgroundColor:colors.white}}>
                 <View style={{flex:.08,borderColor:'red',borderWidth:0,display:'flex',flexDirection:'row',gap:hp(1.5),alignItems:'center',paddingHorizontal:hp(2),justifyContent:'flex-start'}}>
                  <TouchableOpacity onPress={()=>{navigation.pop()}}>
                    <Image source={images.backButton} style={{width:hp(3),height:hp(3)}}/>
                  </TouchableOpacity>
                      <Text style={{color:colors.black,fontSize:hp(2),fontWeight:'600'}}>
                         Job Details   
                      </Text>           
                 </View>     
                 <ScrollView style={{flex:.84,borderColor:'red',borderWidth:0}}>
                    <ImageBackground source={images.jobBg} resizeMode='stretch' style={{width:'100%',height:hp(35),display:'flex',alignItems:'center',justifyContent:'center',flexDirection:'column',gap:hp(1)}}>
                      <View style={{padding:hp(1),backgroundColor:colors.white,borderRadius:10}}>
                      <View style={{padding:hp(2),borderRadius:8,backgroundColor:'#50CA5D',width:hp(5),height:hp(5),display:'flex',alignItems:'center',justifyContent:'center'}}>
                        <Image source={images.jobOne} resizeMode='cover' style={{width:hp(3),height:hp(3)}}/>
                      </View>
                      </View>
                      <View style={{display:'flex',flexDirection:'column'}}>
                         <Text style={{fontSize:hp(3),textAlign:'center',color:colors.white,fontWeight:'600'}}>
                         Junior Business
                         </Text>
                         <Text style={{fontSize:hp(3),textAlign:'center',color:colors.white,fontWeight:'600',marginBottom:hp(2)}}>
                           Development
                         </Text>
                         <Text style={{fontSize:hp(2),textAlign:'center',color:colors.white,fontWeight:'600',marginBottom:hp(2)}}>
                           Meta
                         </Text>
                      </View>
                      <View style={{display:'flex',flexDirection:'row',gap:hp(2)}}>
                         <View style={{paddingHorizontal:hp(1.5),padding:hp(.75),backgroundColor:colors.primary,borderRadius:5,elevation:10}}>
                                                      <Text style={{color:colors.white,fontWeight:'500',fontSize:hp(1.75)}}>
                                                        Full Time
                                                      </Text>
                                                  </View>                          
                                                 <View style={{paddingHorizontal:hp(1.5),padding:hp(.75),backgroundColor:colors.primary,borderRadius:5,elevation:10}}>
                                                      <Text style={{color:colors.white,fontWeight:'500',fontSize:hp(1.75)}}>
                                                        On Site
                                                      </Text>
                                                  </View> 
                      </View>
                    </ImageBackground>
                     <View style={{width:'100%',padding:hp(2),borderColor:'red',borderWidth:0,marginTop:hp(2)}}>
                         <View style={{width:'100%',display:'flex',flexDirection:'column',gap:hp(.5)}}>
                           <Text style={{color:colors.black,fontSize:hp(2.5),fontWeight:'600'}}>
                               Provide details
                           </Text>
                            <View style={{ width:'100%',marginVertical:hp(2),borderColor:'#D4D4D4',borderWidth:1,borderRadius:8,backgroundColor:colors.white,display:'flex',flexDirection:'row',alignItems:'center',padding:hp(.75)}}>
                                         
                                           <TextInput 
                                           placeholderTextColor={colors.inputPlaceHolderColor}
                                           placeholder={'Name*'} style={{flex:1,borderColor:'red',borderWidth:0,fontSize:hp(1.5)}}/>
                                       </View>
                            <View style={{ width:'100%',borderColor:'#D4D4D4',borderWidth:1,borderRadius:8,backgroundColor:colors.white,display:'flex',flexDirection:'row',alignItems:'center',padding:hp(.75)}}>
                                         
                                           <TextInput 
                                           placeholderTextColor={colors.inputPlaceHolderColor}
                                           placeholder={'Name*'} style={{flex:1,borderColor:'red',borderWidth:0,fontSize:hp(1.5)}}/>
                                       </View>
                            <TouchableOpacity
                              onPress={()=>{Alert.alert('Upload resume here')}}
                             style={{ display:'flex',flexDirection:'row',width:'100%',marginVertical:hp(2),borderColor:'#D4D4D4',gap:hp(1),borderWidth:1,borderRadius:8,backgroundColor:colors.white,alignItems:'center',padding:hp(1.75)}}>
                                         <Image source={images.uploadResume} style={{width:hp(2),height:hp(2)}}/>
                                         <Text style={{flex:1,borderColor:'red',borderWidth:0,fontSize:hp(1.5),color:colors.textMuted}}>
                                          Upload Resume
                                         </Text>
                                         {/* <TouchableOpacity style={{}} onPress={()=>{Alert.alert('upload resume here')}}>
                                         </TouchableOpacity> */}
                                           {/* <TextInput 
                                           placeholderTextColor={colors.inputPlaceHolderColor}
                                           placeholder={'Upload Resume'} style={{flex:1,borderColor:'red',borderWidth:0,fontSize:hp(1.5)}}/> */}
                                       </TouchableOpacity>
                          
                         </View>
                        
                         <View style={{width:'100%',height:hp(7),borderColor:'red',borderWidth:0,marginTop:hp(2)}}> 
                         <Button type={0} text={'Submit'} handlePress={()=>{Alert.alert('This is the test')}}/>
                         </View>
                     </View>
                 </ScrollView>     
                 <View style={{flex:.08,borderColor:'red',borderWidth:0,backgroundColor:colors.white,elevation:7,display:'flex',alignItems:'center',justifyContent:'center',padding:hp(1.25)}}>
                  <Footer navigation={navigation} activeTab={3}/>
                 </View>     
           </SafeAreaView>
    </SafeAreaProvider>
  )
}

export default JobApply