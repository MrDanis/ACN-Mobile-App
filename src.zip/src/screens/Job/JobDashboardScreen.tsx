import { View, Text,ScrollView,Image,TextInput, TouchableOpacity } from 'react-native'
import React from 'react'
import MainLayout from '../../layout/MainLayout'
import { images,colors } from '../../config'
import { heightPercentageToDP as hp } from 'react-native-responsive-screen'
const JobDashboardScreen = ({navigation}:any) => {
  return (
    <MainLayout navigation={navigation} activeTabIndex={3}>
    <ScrollView style={{flex:1,borderColor:'red',borderWidth:0,padding:hp(2),backgroundColor:colors.white}}>
      <View style={{width:'100%',display:'flex',flexDirection:'column',gap:hp(1),borderColor:'red',borderWidth:0}}>
          <View style={{width:'100%',borderColor:'green',borderWidth:0,display:'flex',flexDirection:'row',alignItems:'center',gap:hp(1)}}>
            <View style={{ width:'80%',marginVertical:hp(2),borderColor:'#D4D4D4',borderWidth:1,borderRadius:8,backgroundColor:colors.inputBgColor,display:'flex',flexDirection:'row',alignItems:'center',paddingHorizontal:hp(1)}}>
               <Image source={images.searchIcon} style={{width:hp(2),height:hp(2)}}/>
                <TextInput 
                placeholderTextColor={colors.inputPlaceHolderColor}
                placeholder={'Search'} style={{flex:1,borderColor:'red',borderWidth:0,fontSize:hp(1.5)}}/>
            </View>
               <Image source={images.filterIcon} style={{width:hp(3),height:hp(3)}}/>   
          </View>
          <View style={{width:'100%',borderColor:'black',borderWidth:0,marginTop:hp(2),display:'flex',flexDirection:'column',gap:hp(2)}}>
              <Text style={{color:colors.black,fontWeight:'600',fontSize:hp(2.5),marginBottom:hp(2)}}>
                Recently Update
              </Text>
              {/* Job 1 */}
              <TouchableOpacity
                onPress={()=>{navigation.navigate('JobDetailsScreen')}}
                style={{borderColor:'#E6E6E6',borderWidth:1,borderRadius:10,padding:hp(2),display:'flex',flexDirection:'column',columnGap:hp(2)}}>
                  <View style={{borderColor:'green',borderWidth:0,width:'100%',display:'flex',flexDirection:'row',alignItems:'center',gap:hp(1)}}>
                  <View style={{borderColor:'green',borderWidth:0,width:'85%',display:'flex',flexDirection:'row',gap:hp(1)}}>
                     <View style={{padding:hp(1),borderRadius:8,backgroundColor:'#50CA5D',width:hp(5),height:hp(5),display:'flex',alignItems:'center',justifyContent:'center'}}>
                        <Image source={images.jobOne} resizeMode='cover' style={{width:hp(2.5),height:hp(2.5)}}/>
                     </View>
                     <View style={{flex:1,display:'flex',flexDirection:'column'}}>
                     <Text style={{width:'100%',flexWrap:'wrap',fontSize:hp(2),color:colors.black}}>
                     Junior Business Development
                     </Text>
                     <Text style={{fontSize:hp(1.5),fontWeight:'600',color:colors.black}}>
                      Meta
                     </Text>
                     </View>
                  </View>
                     <Image source={images.jobBookMark} resizeMode='cover' style={{width:hp(3),height:hp(3)}}/>
                  </View>
                  <Text style={{fontSize:hp(1.75),color:colors.textMuted,marginTop:hp(.5),marginBottom:hp(2)}}>
                     Saskatoon, Canada
                  </Text>
                  <View style={{width:'100%',borderColor:'red',flexWrap:'wrap',borderWidth:0,display:'flex',flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}>
                       <View style={{borderColor:'green',borderWidth:0,display:'flex',flexDirection:'row',gap:hp(1)}}>
                         <View style={{paddingHorizontal:hp(1),padding:hp(.5),backgroundColor:'#3583F91A'}}>
                              <Text style={{color:colors.primary,fontWeight:'500',fontSize:hp(1.5)}}>
                                Full Time
                              </Text>
                          </View>                          
                         <View style={{paddingHorizontal:hp(1.5),padding:hp(.5),backgroundColor:'#3583F91A',borderRadius:5}}>
                              <Text style={{color:colors.primary,fontWeight:'500',fontSize:hp(1.5)}}>
                                On Site
                              </Text>
                          </View>                          
                       </View>
                       <Text style={{color:colors.textMuted,fontSize:hp(1.5)}}>
                         2 Hours Ago
                       </Text>
                  </View>
              </TouchableOpacity>
              {/* Job 2 */}
              <View style={{borderColor:'#E6E6E6',borderWidth:1,borderRadius:10,padding:hp(2),display:'flex',flexDirection:'column',columnGap:hp(2)}}>
                  <View style={{borderColor:'green',borderWidth:0,width:'100%',display:'flex',flexDirection:'row',alignItems:'center',gap:hp(1)}}>
                  <View style={{borderColor:'green',borderWidth:0,width:'85%',display:'flex',flexDirection:'row',gap:hp(1)}}>
                     <View style={{padding:hp(1),borderRadius:8,backgroundColor:'#50CA5D',width:hp(5),height:hp(5),display:'flex',alignItems:'center',justifyContent:'center'}}>
                        <Image source={images.jobOne} resizeMode='cover' style={{width:hp(2.5),height:hp(2.5)}}/>
                     </View>
                     <View style={{flex:1,display:'flex',flexDirection:'column'}}>
                     <Text style={{width:'100%',flexWrap:'wrap',fontSize:hp(2),color:colors.black}}>
                     Junior Business Development
                     </Text>
                     <Text style={{fontSize:hp(1.5),fontWeight:'600',color:colors.black}}>
                      Meta
                     </Text>
                     </View>
                  </View>
                     <Image source={images.jobBookMark} resizeMode='cover' style={{width:hp(3),height:hp(3)}}/>
                  </View>
                  <Text style={{fontSize:hp(1.75),color:colors.textMuted,marginTop:hp(.5),marginBottom:hp(2)}}>
                     Saskatoon, Canada
                  </Text>
                  <View style={{width:'100%',borderColor:'red',flexWrap:'wrap',borderWidth:0,display:'flex',flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}>
                       <View style={{borderColor:'green',borderWidth:0,display:'flex',flexDirection:'row',gap:hp(1)}}>
                         <View style={{paddingHorizontal:hp(1),padding:hp(.5),backgroundColor:'#3583F91A'}}>
                              <Text style={{color:colors.primary,fontWeight:'500',fontSize:hp(1.5)}}>
                                Full Time
                              </Text>
                          </View>                          
                         <View style={{paddingHorizontal:hp(1.5),padding:hp(.5),backgroundColor:'#3583F91A',borderRadius:5}}>
                              <Text style={{color:colors.primary,fontWeight:'500',fontSize:hp(1.5)}}>
                                On Site
                              </Text>
                          </View>                          
                       </View>
                       <Text style={{color:colors.textMuted,fontSize:hp(1.5)}}>
                         2 Hours Ago
                       </Text>
                  </View>
              </View>
              {/* Job 3 */}
              <View style={{borderColor:'#E6E6E6',borderWidth:1,borderRadius:10,padding:hp(2),display:'flex',flexDirection:'column',columnGap:hp(2)}}>
                  <View style={{borderColor:'green',borderWidth:0,width:'100%',display:'flex',flexDirection:'row',alignItems:'center',gap:hp(1)}}>
                  <View style={{borderColor:'green',borderWidth:0,width:'85%',display:'flex',flexDirection:'row',gap:hp(1)}}>
                     <View style={{padding:hp(1),borderRadius:8,backgroundColor:'#50CA5D',width:hp(5),height:hp(5),display:'flex',alignItems:'center',justifyContent:'center'}}>
                        <Image source={images.jobOne} resizeMode='cover' style={{width:hp(2.5),height:hp(2.5)}}/>
                     </View>
                     <View style={{flex:1,display:'flex',flexDirection:'column'}}>
                     <Text style={{width:'100%',flexWrap:'wrap',fontSize:hp(2),color:colors.black}}>
                     Junior Business Development
                     </Text>
                     <Text style={{fontSize:hp(1.5),fontWeight:'600',color:colors.black}}>
                      Meta
                     </Text>
                     </View>
                  </View>
                     <Image source={images.jobBookMark} resizeMode='cover' style={{width:hp(3),height:hp(3)}}/>
                  </View>
                  <Text style={{fontSize:hp(1.75),color:colors.textMuted,marginTop:hp(.5),marginBottom:hp(2)}}>
                     Saskatoon, Canada
                  </Text>
                  <View style={{width:'100%',borderColor:'red',flexWrap:'wrap',borderWidth:0,display:'flex',flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}>
                       <View style={{borderColor:'green',borderWidth:0,display:'flex',flexDirection:'row',gap:hp(1)}}>
                         <View style={{paddingHorizontal:hp(1),padding:hp(.5),backgroundColor:'#3583F91A'}}>
                              <Text style={{color:colors.primary,fontWeight:'500',fontSize:hp(1.5)}}>
                                Full Time
                              </Text>
                          </View>                          
                         <View style={{paddingHorizontal:hp(1.5),padding:hp(.5),backgroundColor:'#3583F91A',borderRadius:5}}>
                              <Text style={{color:colors.primary,fontWeight:'500',fontSize:hp(1.5)}}>
                                On Site
                              </Text>
                          </View>                          
                       </View>
                       <Text style={{color:colors.textMuted,fontSize:hp(1.5)}}>
                         2 Hours Ago
                       </Text>
                  </View>
              </View>
              {/* Job 4 */}
              <View style={{borderColor:'#E6E6E6',borderWidth:1,borderRadius:10,padding:hp(2),display:'flex',flexDirection:'column',columnGap:hp(2)}}>
                  <View style={{borderColor:'green',borderWidth:0,width:'100%',display:'flex',flexDirection:'row',alignItems:'center',gap:hp(1)}}>
                  <View style={{borderColor:'green',borderWidth:0,width:'85%',display:'flex',flexDirection:'row',gap:hp(1)}}>
                     <View style={{padding:hp(1),borderRadius:8,backgroundColor:'#50CA5D',width:hp(5),height:hp(5),display:'flex',alignItems:'center',justifyContent:'center'}}>
                        <Image source={images.jobOne} resizeMode='cover' style={{width:hp(2.5),height:hp(2.5)}}/>
                     </View>
                     <View style={{flex:1,display:'flex',flexDirection:'column'}}>
                     <Text style={{width:'100%',flexWrap:'wrap',fontSize:hp(2),color:colors.black}}>
                     Junior Business Development
                     </Text>
                     <Text style={{fontSize:hp(1.5),fontWeight:'600',color:colors.black}}>
                      Meta
                     </Text>
                     </View>
                  </View>
                     <Image source={images.jobBookMark} resizeMode='cover' style={{width:hp(3),height:hp(3)}}/>
                  </View>
                  <Text style={{fontSize:hp(1.75),color:colors.textMuted,marginTop:hp(.5),marginBottom:hp(2)}}>
                     Saskatoon, Canada
                  </Text>
                  <View style={{width:'100%',borderColor:'red',flexWrap:'wrap',borderWidth:0,display:'flex',flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}>
                       <View style={{borderColor:'green',borderWidth:0,display:'flex',flexDirection:'row',gap:hp(1)}}>
                         <View style={{paddingHorizontal:hp(1),padding:hp(.5),backgroundColor:'#3583F91A'}}>
                              <Text style={{color:colors.primary,fontWeight:'500',fontSize:hp(1.5)}}>
                                Full Time
                              </Text>
                          </View>                          
                         <View style={{paddingHorizontal:hp(1.5),padding:hp(.5),backgroundColor:'#3583F91A',borderRadius:5}}>
                              <Text style={{color:colors.primary,fontWeight:'500',fontSize:hp(1.5)}}>
                                On Site
                              </Text>
                          </View>                          
                       </View>
                       <Text style={{color:colors.textMuted,fontSize:hp(1.5)}}>
                         2 Hours Ago
                       </Text>
                  </View>
              </View>
              {/* Job 5 */}
              <View style={{borderColor:'#E6E6E6',borderWidth:1,borderRadius:10,padding:hp(2),display:'flex',flexDirection:'column',columnGap:hp(2)}}>
                  <View style={{borderColor:'green',borderWidth:0,width:'100%',display:'flex',flexDirection:'row',alignItems:'center',gap:hp(1)}}>
                  <View style={{borderColor:'green',borderWidth:0,width:'85%',display:'flex',flexDirection:'row',gap:hp(1)}}>
                     <View style={{padding:hp(1),borderRadius:8,backgroundColor:'#50CA5D',width:hp(5),height:hp(5),display:'flex',alignItems:'center',justifyContent:'center'}}>
                        <Image source={images.jobOne} resizeMode='cover' style={{width:hp(2.5),height:hp(2.5)}}/>
                     </View>
                     <View style={{flex:1,display:'flex',flexDirection:'column'}}>
                     <Text style={{width:'100%',flexWrap:'wrap',fontSize:hp(2),color:colors.black}}>
                     Junior Business Development
                     </Text>
                     <Text style={{fontSize:hp(1.5),fontWeight:'600',color:colors.black}}>
                      Meta
                     </Text>
                     </View>
                  </View>
                     <Image source={images.jobBookMark} resizeMode='cover' style={{width:hp(3),height:hp(3)}}/>
                  </View>
                  <Text style={{fontSize:hp(1.75),color:colors.textMuted,marginTop:hp(.5),marginBottom:hp(2)}}>
                     Saskatoon, Canada
                  </Text>
                  <View style={{width:'100%',borderColor:'red',flexWrap:'wrap',borderWidth:0,display:'flex',flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}>
                       <View style={{borderColor:'green',borderWidth:0,display:'flex',flexDirection:'row',gap:hp(1)}}>
                         <View style={{paddingHorizontal:hp(1),padding:hp(.5),backgroundColor:'#3583F91A'}}>
                              <Text style={{color:colors.primary,fontWeight:'500',fontSize:hp(1.5)}}>
                                Full Time
                              </Text>
                          </View>                          
                         <View style={{paddingHorizontal:hp(1.5),padding:hp(.5),backgroundColor:'#3583F91A',borderRadius:5}}>
                              <Text style={{color:colors.primary,fontWeight:'500',fontSize:hp(1.5)}}>
                                On Site
                              </Text>
                          </View>                          
                       </View>
                       <Text style={{color:colors.textMuted,fontSize:hp(1.5)}}>
                         2 Hours Ago
                       </Text>
                  </View>
              </View>
              <View style={{width:'100%',marginVertical:hp(2)}} />
          </View> 
      </View>
    </ScrollView>
    </MainLayout>
  )
}

export default JobDashboardScreen