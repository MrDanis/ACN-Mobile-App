import { View, Text,SafeAreaView, ScrollView,ImageBackground,Image, TouchableOpacity, Alert } from 'react-native'
import React from 'react'
import {SafeAreaProvider} from 'react-native-safe-area-context';
import { colors,images } from '../../config';
import Footer from '../../components/Footer/Footer';
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';
import Button from '../../components/Button/Button';
const JobDetails = ({navigation}:any) => {
  return (
    <SafeAreaProvider>
           <SafeAreaView style={{flex:1,backgroundColor:colors.white}}>
                 <View style={{flex:.08,borderColor:'red',borderWidth:0,display:'flex',flexDirection:'row',gap:hp(1.5),alignItems:'center',paddingHorizontal:hp(2),justifyContent:'flex-start'}}>
                                   <TouchableOpacity onPress={()=>{navigation.pop()}}>
                                     <Image source={images.backButton} style={{width:hp(3),height:hp(3)}}/>
                                   </TouchableOpacity>
                                       <Text style={{color:colors.black,fontSize:hp(2),fontWeight:'600'}}>
                                          Job Details   
                                       </Text>           
                                  </View>     
                 <ScrollView style={{flex:.84,borderColor:'red',borderWidth:0}}>
                    <ImageBackground source={images.jobBg} resizeMode='stretch' style={{width:'100%',height:hp(35),display:'flex',alignItems:'center',justifyContent:'center',flexDirection:'column',gap:hp(1)}}>
                      <View style={{padding:hp(1),backgroundColor:colors.white,borderRadius:10}}>
                      <View style={{padding:hp(2),borderRadius:8,backgroundColor:'#50CA5D',width:hp(5),height:hp(5),display:'flex',alignItems:'center',justifyContent:'center'}}>
                        <Image source={images.jobOne} resizeMode='cover' style={{width:hp(3),height:hp(3)}}/>
                      </View>
                      </View>
                      <View style={{display:'flex',flexDirection:'column'}}>
                         <Text style={{fontSize:hp(3),textAlign:'center',color:colors.white,fontWeight:'600'}}>
                         Junior Business
                         </Text>
                         <Text style={{fontSize:hp(3),textAlign:'center',color:colors.white,fontWeight:'600',marginBottom:hp(2)}}>
                           Development
                         </Text>
                         <Text style={{fontSize:hp(2),textAlign:'center',color:colors.white,fontWeight:'600',marginBottom:hp(2)}}>
                           Meta
                         </Text>
                      </View>
                      <View style={{display:'flex',flexDirection:'row',gap:hp(2)}}>
                         <View style={{paddingHorizontal:hp(1.5),padding:hp(.75),backgroundColor:colors.primary,borderRadius:5,elevation:10}}>
                                                      <Text style={{color:colors.white,fontWeight:'500',fontSize:hp(1.75)}}>
                                                        Full Time
                                                      </Text>
                                                  </View>                          
                                                 <View style={{paddingHorizontal:hp(1.5),padding:hp(.75),backgroundColor:colors.primary,borderRadius:5,elevation:10}}>
                                                      <Text style={{color:colors.white,fontWeight:'500',fontSize:hp(1.75)}}>
                                                        On Site
                                                      </Text>
                                                  </View> 
                      </View>
                    </ImageBackground>
                     <View style={{width:'100%',padding:hp(2),borderColor:'red',borderWidth:0,marginTop:hp(2)}}>
                         <View style={{width:'100%',display:'flex',flexDirection:'row',gap:hp(1)}}>
                            <TouchableOpacity style={{backgroundColor:'#9E7C4D33',flex:1,padding:hp(1.5),borderRadius:10}}>
                              <Text style={{color:colors.primary,fontWeight:'600',fontSize:hp(2),textAlign:'center'}}>
                                About Company
                              </Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={{backgroundColor:colors.inputBgColor,flex:1,padding:hp(1.5),borderRadius:10}}>
                              <Text style={{color:colors.textMuted,fontWeight:'600',fontSize:hp(2),textAlign:'center'}}>
                                Details
                              </Text>
                            </TouchableOpacity>
                         </View>
                         <View style={{width:'100%',borderColor:'red',borderWidth:0,marginTop:hp(3)}}>
                           <Text style={{width:'100%',fontSize:hp(2),lineHeight:hp(3),color:colors.black}}>
                           As a UI Designer , you will mainly chart the design strategy of all web platforms and unite design themes. From this, you will learn how to analyze the trends of your target community and fine tune your technical skills by working creatively and analytically in a problem-solving environment. You will also develop your communication skills as you will have to explain your decisions and thoughts Benefits.
                           </Text>
                         </View>
                         <View style={{width:'100%',height:hp(7),borderColor:'red',borderWidth:0,marginTop:hp(2)}}> 
                         <Button type={0} text={'Apply'} handlePress={()=>{navigation.navigate('JobApply')}}/>
                         </View>
                     </View>
                 </ScrollView>     
                 <View style={{flex:.08,borderColor:'red',borderWidth:0,backgroundColor:colors.white,elevation:7,display:'flex',alignItems:'center',justifyContent:'center',padding:hp(1.25)}}>
                  <Footer navigation={navigation} activeTab={3}/>
                 </View>     
           </SafeAreaView>
    </SafeAreaProvider>
    
  )
}

export default JobDetails