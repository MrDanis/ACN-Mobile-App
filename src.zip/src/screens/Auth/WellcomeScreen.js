import { View, Text,SafeAreaView,ImageBackground,Image,Alert } from 'react-native'
import React from 'react'
import {SafeAreaProvider} from 'react-native-safe-area-context';
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';
import { colors,images } from '../../config';
import Button from '../../components/Button/Button';
const WellcomeScreen = ({navigation}) => {
  const handleNavigation =(type)=>{
   switch (type) {
      case 0:
       navigation.navigate('LoginScreen');  
      break;
      case 1:
       navigation.navigate('RegisterScreen');  
      break;
         
         default:
         navigation.navigate('LoginScreen');
         break;
   }
     console.log('here in navigation')
  } 
  return (
    <SafeAreaProvider>
     <SafeAreaView style={{flex:1,backgroundColor:colors.white}}>
       <View style={{flex:1,borderColor:'red',borderWidth:0,display:'flex',flexDirection:'column',backgroundColor:colors.white}}>
          <View style={{flex:1,borderColor:'green',borderWidth:0}}>
             <ImageBackground style={{flex:1}} source={images.welcomeBg} resizeMode='cover'/>
          </View>
          <View style={{flex:1,borderColor:'black',borderWidth:0,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'space-between'}}>
                    <View style={{flex:1,width:'100%',borderColor:'red',borderWidth:0,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'flex-start'}}>
                              <Image source={images.appLogo} resizeMode='cover' style={{width:hp(10),height:hp(12),marginTop:hp(-6)}}/>
                              <Text style={{fontWeight:'600',fontSize:hp(2.75),color:colors.primary}}>
                                 Ahtahkakoop
                              </Text>
                              <Text style={{fontWeight:'600',fontSize:hp(2.75),color:colors.primary}}>
                                 Cree Nation
                              </Text>
                    </View>
                    <View style={{flex:2,width:'100%',borderColor:'green',borderWidth:0,paddingHorizontal:hp(3),display:'flex',flexDirection:'column',gap:hp(2),paddingTop:hp(4)}}>
                      <View style={{width:'100%',height:'30%',borderColor:'blue',borderWidth:0}}>
                        <Button handlePress={()=>{handleNavigation(0)}} text={'Login'} type={0}/>
                      </View>
                      <View style={{width:'100%',height:'30%',borderColor:'red',borderWidth:0}}>
                        <Button handlePress={()=>{handleNavigation(1)}} text={'Register'} type={1}/>
                      </View>
                    </View>
                    <View style={{flex:1,width:'100%',borderColor:'blue',borderWidth:0,display:'flex',flexDirection:'column',justifyContent:'center',alignItems:'center'}}>
                     <Text style={{borderBottom:1,borderBottomWidth:1,borderColor:colors.primary,fontSize:hp(2.5),paddingHorizontal:hp(2.5),paddingBottom:hp(.5),marginBottom:hp(.5),color:colors.primary,fontWeight:'600'}}>
                        View what we offer
                     </Text>
                     <Text style={{color:colors.textMuted}}>
                         Designed by {" "} 
                            <Text style={{color:colors.blue}}>
                            Nomad Strategies  
                            </Text> 
                     </Text>
                    </View>
          </View>
       </View>

        </SafeAreaView>
    </SafeAreaProvider>
  )
}

export default WellcomeScreen
