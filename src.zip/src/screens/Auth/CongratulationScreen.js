import { View, Text, Image, SafeAreaView } from 'react-native'
import React from 'react'
import {SafeAreaProvider} from 'react-native-safe-area-context';
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';
import Button from '../../components/Button/Button';
import { colors,images } from '../../config';
const CongratulationScreen = ({navigation}) => {
  return (
    <SafeAreaProvider>
        <SafeAreaView style={{flex:1,display:'flex',alignItems:'center',justifyContent:'center'}}>
          <View style={{width:'100%',display:'flex',alignItems:'center',justifyContent:'center',flexDirection:'column'}}>
            <Image source={images.ResetPasswordSuccess} style={{width:hp(15),height:hp(15),marginBottom:hp(4)}}/>
                <Text style={{fontSize:hp(3.5),color:colors.black,fontWeight:'600'}}>Password Changed!</Text>
                <Text style={{fontSize:hp(2),color:colors.textGray}}>Your password has been</Text>
                <Text style={{fontSize:hp(2),color:colors.textGray}}>changed successfully.</Text>
                <View style={{width:'70%',height:hp(6),marginTop:hp(6   )}}>
                    <Button type={0} text={"Back to Login"} handlePress={()=>{navigation.navigate('LoginScreen')}}/>
                </View>
          </View>
        </SafeAreaView>
    </SafeAreaProvider>
  )
}

export default CongratulationScreen