import { View, Text } from 'react-native'
import React from 'react'
import { heightPercentageToDP as hp } from 'react-native-responsive-screen'
import { colors } from '../../../config'
const AuthBody = ({title,discription,children}:any) => {
  return (
    <View style={{width:'100%',borderColor:'green',borderWidth:0,display:'flex',flexDirection:'column'}}>
      <View style={{display:'flex',flexDirection:'column',flexWrap:'wrap'}}>
         <Text style={{fontSize:hp(3.25),fontWeight:'600',color:colors.black}}>
            {title}
         </Text>
         <Text style={{color:colors.textMuted,fontSize:hp(1.75),flexWrap:'wrap',width:'100%',lineHeight:hp(3)}}>
          {discription}
         </Text>        
      </View>
      {children}
    </View>
  )
}

export default AuthBody