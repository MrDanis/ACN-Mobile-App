import { View, Text,ImageBackground } from 'react-native'
import React,{useEffect} from 'react'
import { images } from '../../config'
const SplashScreen = ({navigation}) => {
useEffect(()=>{
    setTimeout(()=>{
     navigation.navigate('WellcomeScreen');
    },3000)
},[])
  return (
   <ImageBackground source={images.splashImg} style={{flex:1}} />
  )
}

export default SplashScreen