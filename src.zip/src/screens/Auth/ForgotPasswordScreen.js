import { View, Text,SafeAreaView,ImageBackground,TouchableOpacity, Image, Keyboard,TextInput,Pressable, Alert } from 'react-native'
import React,{useState} from 'react'
import {SafeAreaProvider} from 'react-native-safe-area-context';
import { colors, images } from '../../config';
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';
import AuthBody from './CommonComponent/AuthBody';
import Button from '../../components/Button/Button';
const ForgotPasswordScreen = ({navigation}) => {
  const [email, setemail] = useState('');
 
  const handleLogin = () =>{
    navigation.navigate('OtpVerificationScreen');
  }
  return (
    <SafeAreaProvider>
     <SafeAreaView style={{flex:1,backgroundColor:colors.white}}>
      <ImageBackground source={images.loginHeader} resizeMode='cover' style={{flex:.175,padding:hp(2)}}>
        <View style={{borderColor:'red',borderWidth:0,width:'100%',padding:hp(1)}}>
           <TouchableOpacity
            onPress={()=>{navigation.pop()}}
            style={{marginTop:hp(4),backgroundColor:colors.headerBackColor,borderRadius:8,padding:hp(1.25),alignSelf:'flex-start'}}>
              <Image source={images.acnBackArrow} style={{width:hp(1.125),height:hp(1.75)}}/>
           </TouchableOpacity>
        </View>
        </ImageBackground> 
         <View style={{borderColor:'red',borderWidth:0,flex:1,marginTop:hp(-2.5),padding:hp(3),borderTopLeftRadius:25,borderTopRightRadius:25,backgroundColor:colors.white}}>
             <AuthBody title={'Forgot Password?'} discription={'Do not worry! It occurs. Please enter the email address linked with your account.'}>
                 <View style={{
                  marginVertical:hp(2),
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'flex-start',
                  flexDirection: 'row',
                  width: '100%',
                  borderColor: colors.inputBorder,
                  borderWidth: 1,
                  backgroundColor: colors.inputBgColor,
                  borderRadius: 8,
                  margintTop:0,
                  marginBottom:hp(2),
                  paddingHorizontal: hp(1),
                  padding: hp(0.5)}}>
                 <TextInput
              style={{fontSize: hp(1.75),
                width: '90%',
                color:colors.black,
                marginLeft: hp(1),}}
              onSubmitEditing={() => {
                Keyboard.dismiss();
              }}
              onChangeText={(e) => {
                setemail(e);
              }}
              value={email}
              placeholderTextColor={colors.inputPlaceHolderColor}
              placeholder={'Enter your email'}
              keyboardType="default"
            />
                 </View>
                 {/* Password */}
         
          {/* LoginButton */}
          <View style={{width:'100%',borderColor:'red',borderWidth:0,marginTop:0,padding:hp(2),height:hp(11)}}>
               <Button type={0} text={'Send Code'} handlePress={()=>{handleLogin()}}/>
          </View>
             </AuthBody>
         
         </View>
     </SafeAreaView>
    </SafeAreaProvider>
  )
}

export default ForgotPasswordScreen