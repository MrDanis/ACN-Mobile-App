import { View, Text,SafeAreaView,ImageBackground,TouchableOpacity, Image, Keyboard,TextInput,Pressable, Alert } from 'react-native'
import React,{useState} from 'react'
import {SafeAreaProvider} from 'react-native-safe-area-context';
import { colors, images } from '../../config';
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';
import AuthBody from './CommonComponent/AuthBody';
import Button from '../../components/Button/Button';
const LoginScreen = ({navigation}) => {
  const [email, setemail] = useState('');
  const [password, setpassword] = useState('');
  const [showPassword, setshowPassword] = useState(true);
  const [isChecked, setIsChecked] = useState(false);
  const handleLogin = () =>{
    navigation.navigate("HomeDashboardScreen");
  }
  return (
    <SafeAreaProvider>
     <SafeAreaView style={{flex:1,backgroundColor:colors.white}}>
      <ImageBackground source={images.loginHeader} resizeMode='cover' style={{flex:.175,padding:hp(2)}}>
        <View style={{borderColor:'red',borderWidth:0,width:'100%',padding:hp(1)}}>
           <TouchableOpacity
            onPress={()=>{navigation.pop()}}
            style={{marginTop:hp(4),backgroundColor:colors.headerBackColor,borderRadius:8,padding:hp(1.25),alignSelf:'flex-start'}}>
              <Image source={images.acnBackArrow} style={{width:hp(1.125),height:hp(1.75)}}/>
           </TouchableOpacity>
        </View>
        </ImageBackground> 
         <View style={{borderColor:'red',borderWidth:0,flex:1,marginTop:hp(-2.5),padding:hp(3),borderTopLeftRadius:25,borderTopRightRadius:25,backgroundColor:colors.white}}>
             <AuthBody title={'Welcome back!'} discription={'Enter username and password below'}>
                 <View style={{marginBottom: hp(2),
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'flex-start',
                  flexDirection: 'row',
                  width: '100%',
                  borderColor: colors.inputBorder,
                  borderWidth: 1,
                  backgroundColor: colors.inputBgColor,
                  borderRadius: 8,
                  marginVertical:hp(3),
                  paddingHorizontal: hp(1),
                  padding: hp(0.5)}}>
                 <TextInput
              style={{fontSize: hp(1.75),
                width: '90%',
                color:colors.black,
                marginLeft: hp(1),}}
              onSubmitEditing={() => {
                Keyboard.dismiss();
              }}
              onChangeText={(e) => {
                setemail(e);
              }}
              value={email}
              placeholderTextColor={colors.inputPlaceHolderColor}
              placeholder={'Enter your email'}
              keyboardType="default"
            />
                 </View>
                 {/* Password */}
                 <View style={{marginBottom: hp(2),
                               display: 'flex',
                               alignItems: 'center',
                               justifyContent: 'flex-start',
                               flexDirection: 'row',
                               width: '100%',
                               borderColor: colors.inputBorder,
                               borderWidth: 1,
                               backgroundColor: colors.inputBgColor,
                               borderRadius: 8,
                               paddingHorizontal: hp(1),
                               padding: hp(0.5)}}>
           
            <TextInput
              style={{ fontSize: hp(1.75),
                width: '90%',
                color: colors.textMuted,
                marginLeft: hp(1)}}
              onSubmitEditing={() => {
                Keyboard.dismiss();
              }}
              onChangeText={(e) => {
                setpassword(e);
              }}
              value={password}
              placeholderTextColor={colors.inputPlaceHolderColor}
              placeholder={'Enter your password'}
              keyboardType="default"
              secureTextEntry={showPassword}
            />
            <Pressable onPress={()=>{setshowPassword(!showPassword)}}>
              <Image 
                  source={images.showPassword}
                  style={{width:hp(2.5),height:hp(2),marginLeft:hp(-1.5)}}
                 />

              </Pressable>
          </View>
          {/* Remember me and forgot password */}
          <View style={{ marginBottom: hp(2),
      display: 'flex',
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      borderColor: 'green',
      borderWidth: 0,}}>
            <View style={{width: '60%',
      borderColor: 'red',
      borderWidth: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'flex-start',
      flexDirection: 'row',}}>
              <TouchableOpacity
                style={{ width: 20,
                  height: 20,
                  borderWidth: 2,
                  borderRadius: 4,
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginHorizontal: hp(1),  borderColor: isChecked ? colors.primary : 'gray' }}
                onPress={() => setIsChecked(!isChecked)}
              >
                {isChecked && <View style={{width: 14,
      height: 14,
      backgroundColor: colors.primary,}} />}
              </TouchableOpacity>
              <Text style={{textAlign: 'left',color:colors.textGray,fontWeight:'600'}}>
                Remember me
              </Text>
            </View>
            <TouchableOpacity onPress={()=>{navigation.navigate('ForgotPassword')}}>
              <Text style={{color:colors.forgotPasswordColor,fontWeight:'600'}}>
               Forgot password?
              </Text>
            </TouchableOpacity>
          </View>
          {/* LoginButton */}
          <View style={{width:'100%',borderColor:'red',borderWidth:0,marginTop:hp(2),padding:hp(2),height:hp(11)}}>
               <Button type={0} text={'Log In'} handlePress={()=>{handleLogin()}}/>
          </View>
             </AuthBody>
         
         </View>
     </SafeAreaView>
    </SafeAreaProvider>
  )
}

export default LoginScreen