import { View, Text,SafeAreaView,ImageBackground,TouchableOpacity, Image, Keyboard,TextInput,Pressable, Alert } from 'react-native'
import React,{useState} from 'react'
import {SafeAreaProvider} from 'react-native-safe-area-context';
import { colors, images } from '../../config';
import { OtpInput } from "react-native-otp-entry";
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';
import AuthBody from './CommonComponent/AuthBody';
import Button from '../../components/Button/Button';
const OtpVerificationScreen = ({navigation}) => {
  const [email, setemail] = useState('');
 
  const handleLogin = () =>{
    navigation.navigate('CreateNewPasswordScreen');
  }
  return (
    <SafeAreaProvider>
     <SafeAreaView style={{flex:1,backgroundColor:colors.white}}>
      <ImageBackground source={images.loginHeader} resizeMode='cover' style={{flex:.175,padding:hp(2)}}>
        <View style={{borderColor:'red',borderWidth:0,width:'100%',padding:hp(1)}}>
           <TouchableOpacity
            onPress={()=>{navigation.pop()}}
            style={{marginTop:hp(4),backgroundColor:colors.headerBackColor,borderRadius:8,padding:hp(1.25),alignSelf:'flex-start'}}>
              <Image source={images.acnBackArrow} style={{width:hp(1.125),height:hp(1.75)}}/>
           </TouchableOpacity>
        </View>
        </ImageBackground> 
         <View style={{borderColor:'red',borderWidth:0,flex:1,marginTop:hp(-2.5),padding:hp(3),borderTopLeftRadius:25,borderTopRightRadius:25,backgroundColor:colors.white}}>
             <AuthBody title={'OTP Verification'} discription={'Enter the verification code we just sent on your email address.'}>
                 <View style={{
                  marginVertical:hp(2),
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexDirection: 'row',
                  width: '100%',
                  borderColor: colors.inputBorder,
                  borderWidth: 0,
                  backgroundColor: colors.inputBgColor,
                  borderRadius: 8,
                  margintTop:0,
                  marginBottom:hp(2),
                  paddingHorizontal: hp(1),
                  padding: hp(0.5)}}>
                <View style={{width:'80%',borderColor:'red',borderWidth:0,marginVertical:hp(3)}}>
                   <OtpInput  numberOfDigits={4}  />
                </View>
                 </View>
                 {/* Password */}
         
          {/* LoginButton */}
          <View style={{width:'100%',borderColor:'red',borderWidth:0,marginTop:0,padding:hp(2),height:hp(11)}}>
               <Button type={0} text={'Verify'} handlePress={()=>{handleLogin()}}/>
          </View>
             </AuthBody>
         
         </View>
     </SafeAreaView>
    </SafeAreaProvider>
  )
}

export default OtpVerificationScreen