import { View, Text, Image } from 'react-native'
import React from 'react'
import { heightPercentageToDP as hp } from 'react-native-responsive-screen'
import { colors,images } from '../../../config'
import { CommunityCard } from '../../data'
const CommunityDataCard = ({imgurl,memberName,memberMessage,isRead,messageTime}:CommunityCard) => {
  return (
    <View style={{display:'flex',flexDirection:'row',width:'100%',borderColor:'black',borderWidth:0,backgroundColor:colors.white,elevation:7,borderRadius:15,padding:hp(2)}}>
      <View style={{flex:1,borderColor:'red',borderWidth:0,display:'flex',flexDirection:'row',gap:hp(.75)}}>
         <Image source={imgurl} style={{width:hp(8),height:hp(8)}} />
         <View style={{flex:1,display:'flex',flexDirection:'column',gap:hp(.5),borderColor:'red',borderWidth:0,alignItems:'flex-start',justifyContent:'center'}}>
            <Text style={{fontSize:hp(2.5),color:colors.black,fontWeight:'600'}}>
                {memberName}
            </Text>
            <Text style={{fontSize:hp(1.5),color:colors.textMuted,fontWeight:'500'}}>
            {memberMessage}
            </Text>
         </View>
      </View>
      <View style={{flex:.25,borderColor:'red',borderWidth:0,display:'flex',flexDirection:'row',alignItems:'center',justifyContent:'flex-start',gap:hp(.25)}}>
          {
            isRead && (
                <Image source={images.readMessageTick} style={{width:hp(1.5),height:hp(1)}}/>
            )
          }
          <Text style={{color:colors.textMuted,fontSize:hp(1.25),width:'100',flexWrap:'wrap'}}>
             {messageTime} 
          </Text>          
      </View>
    </View>
  )
}

export default CommunityDataCard