import { View, Text } from 'react-native'
import React from 'react'
import { TextDiscription } from '../../data'
import { heightPercentageToDP as hp } from 'react-native-responsive-screen'
import { colors } from '../../../config'
const HeadingAndLead = ({title,text}:TextDiscription) => {
  return (
    <View style={{width:'100%',display:'flex',flexDirection:'column'}}>
       <Text style={{color:colors.black,fontSize:hp(3.25),fontWeight:'600'}}>
           {title}
       </Text>
       <Text style={{fontSize:hp(1.75),color:colors.textGray}}>
           {text}
       </Text>
    </View>
  )
}

export default HeadingAndLead