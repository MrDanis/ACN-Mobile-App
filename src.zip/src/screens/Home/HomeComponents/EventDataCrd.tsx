import { View, Text, TouchableOpacity, Alert } from 'react-native'
import React from 'react'
import { colors } from '../../../config'
import { heightPercentageToDP as hp } from 'react-native-responsive-screen'
import { eventCrad } from '../../data'
const EventDataCrd = ({isOnline,eventTime,eventName,eventStart}:eventCrad) => {
  return (
    <View style={{borderColor:'black',borderWidth:0,width:'100%',borderRadius:15,padding:hp(2),backgroundColor:colors.eventcardBg,display:'flex',flexDirection:'column',gap:hp(1)}}>
      <View style={{borderColor:'red',borderWidth:0,width:'100%',display:'flex',flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}>
         <View style={{display:'flex',flexDirection:'row',alignItems:'center',justifyContent:'flex-start',gap:hp(1)}}>
            <View style={{width:hp(1.5),height:hp(1.5),borderRadius:50,backgroundColor:isOnline===1?colors.eventOnline:colors.textGray,display:'flex',alignItems:'center',justifyContent:'center'}}>
               <View style={{width:'50%',height:'50%',backgroundColor:colors.eventcardBg,borderRadius:50}}/>               
            </View>
            <Text style={{color:colors.textGray,fontSize:hp(1.5)}}>{eventTime}</Text>
         </View>
         <TouchableOpacity 
           onPress={()=>{Alert.alert('App is uder development')}}
           style={{padding:hp(.5),display:'flex',flexDirection:'row',gap:hp(.25),borderColor:'red',borderWidth:0}}>
            {
                [0,1,2].map((item,index)=>{
                    return(
                        <View style={{width:hp(.75),height:hp(.75),backgroundColor:colors.textMuted,borderRadius:50}}/>
                    )
                })
            }
         </TouchableOpacity>
      </View> 
     <Text style={{color:colors.black,fontSize:hp(2.5),fontWeight:'600',width:'100%',flexWrap:'wrap'}}>
          {eventName}
        </Text>
        <Text style={{color:colors.textGray,fontSize:hp(1.5)}}>
          {eventStart}
            </Text>        
    </View>
  )
}

export default EventDataCrd