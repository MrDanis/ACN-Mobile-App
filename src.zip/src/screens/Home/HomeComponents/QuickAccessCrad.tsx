import { View, Text, Image } from 'react-native'
import React from 'react'
import { heightPercentageToDP as hp } from 'react-native-responsive-screen'
import {colors } from '../../../config'
import { quickAccessCard } from '../../data'
const QuickAccessCrad = ({imgUrl,name}:quickAccessCard) => {
  return (
    <View style={{display:'flex',alignItems:'center',width:'31%',padding:hp(2),borderColor:'red',borderWidth:0,borderRadius:15,backgroundColor:colors.white,elevation:7}}>
                         <Image source={imgUrl} style={{width:hp(7),height:hp(7)}}/>
                         <Text style={{color:colors.textMuted,fontSize:hp(1.25),width:'100%',flexWrap:'wrap',marginTop:hp(1),textAlign:'center'}}>
                            {name}
                          </Text>
                      </View>
  )
}

export default QuickAccessCrad