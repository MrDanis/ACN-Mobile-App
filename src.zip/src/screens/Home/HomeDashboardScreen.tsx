import { View, Text,ScrollView,Image, TouchableOpacity } from 'react-native'
import React from 'react'
import MainLayout from '../../layout/MainLayout'
import { colors, images } from '../../config'
import { heightPercentageToDP as hp } from 'react-native-responsive-screen'
import EventDataCrd from './HomeComponents/EventDataCrd'
import HeadingAndLead from './HomeComponents/HeadingAndLead'
import CommunityDataCard from './HomeComponents/CommunityDataCard'
import QuickAccessCrad from './HomeComponents/QuickAccessCrad'
import { eventData, communityData, quickAccessData } from '../data'
const HomeDashboardScreen = ({navigation}:any) => {
  return (
    <MainLayout navigation={navigation} activeTabIndex={2}>
      <ScrollView style={{flex:1,backgroundColor:colors.white}}>
        <View style={{width:'100%',height:hp(25),borderColor:'red',borderWidth:0,marginBottom:hp(3)}}>
          <Image source={images.dashboardBanner} resizeMode='cover' style={{width:'100%',height:'100%'}} />
        </View>
        <View>
           <View style={{width:'100%',paddingHorizontal:hp(3),borderColor:'red',borderWidth:0,display:'flex',flexDirection:'column',gap:hp(2)}}>
             <HeadingAndLead title='Events' text='View all events happening near you.'/>
             {
              eventData.map((item,index)=>{
                return(
                  <EventDataCrd key={index} isOnline={item.isOnline} eventTime={item.eventTime} eventName={item.eventName} eventStart={item.eventStart}/> 
                )
              })
             }
             <TouchableOpacity style={{backgroundColor:colors.primary,padding:hp(2),width:'100%',borderRadius:10}}>
              <Text style={{color:colors.white}}>
                View All Events.
              </Text>
             </TouchableOpacity>
             <HeadingAndLead title='Community' text='View all events happening near you.'/>
             {
              communityData.map((item,index)=>{
                return(
                    <CommunityDataCard 
                    key={index}
                    imgurl={item.imgurl}
                    memberName={item.memberName}
                    memberMessage={item.memberMessage}
                    isRead={item.isRead} 
                    messageTime={item.messageTime}
                    />
                )
              })
             }
              <TouchableOpacity style={{backgroundColor:colors.primary,padding:hp(2),width:'100%',borderRadius:10}}>
              <Text style={{color:colors.white}}>
                View All Messages.
              </Text>
             </TouchableOpacity>
             <HeadingAndLead title='Quick Access' text='Click on interested topic to dive deep.'/>
             <View style={{width:'100%',display:'flex',flexDirection:'row',flexWrap:'wrap',gap:hp(1.25),borderColor:'red',borderWidth:0}}>
                {
                  quickAccessData.map((item,index)=>{
                    return(
                      <QuickAccessCrad key={index} imgUrl={item.imgUrl} name={item.name}/>
                    )
                  })
                }
             <TouchableOpacity style={{backgroundColor:colors.primary,padding:hp(2),width:'100%',borderRadius:10,marginBottom:hp(2)}}>
              <Text style={{color:colors.white,textAlign:'center'}}>
                View More
              </Text>
             </TouchableOpacity> 
             </View>
           </View>
        </View>
        
      </ScrollView>
    </MainLayout>
  )
}
export default HomeDashboardScreen