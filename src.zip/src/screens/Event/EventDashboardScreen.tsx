import { View, Text, ScrollView,TextInput,Image, TouchableOpacity } from 'react-native'
import React,{useState} from 'react'
import MainLayout from '../../layout/MainLayout'
import {Calendar} from 'react-native-calendars';
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';
import EventDataCrd from '../Home/HomeComponents/EventDataCrd';
import { eventData } from '../data';
import { colors,images } from '../../config';
const EventDashboardScreen = ({navigation}:any) => {
  const [isModalOpen,setisModalOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState('');
  return (
    <MainLayout navigation={navigation} activeTabIndex={0}>
    <ScrollView style={{borderColor:'red',borderWidth:0,width:'100%',backgroundColor:colors.white}}>
    <Calendar
    onDayPress={(day:any) => {
      setSelectedDate(day.dateString); // e.g., '2025-04-08'
    }}
    markedDates={{
      [selectedDate]: {
        selected: true,
        selectedColor: colors.primary,
        selectedTextColor: colors.white
      }
    }}
    dayComponent={({ date, state }:any) => {
      const isSelected = date.dateString === selectedDate;

      return (
        <TouchableOpacity
          onPress={() => setSelectedDate(date.dateString)}
          style={{
            backgroundColor: isSelected ? colors.primary : 'transparent',
            borderRadius: 8,
            padding: 8,
            alignItems: 'center',
            justifyContent: 'center',
            width: 40,
            height: 40
          }}
        >
          <Text
            style={{
              color: isSelected ? '#fff' : (state === 'disabled' ? '#ccc' : '#000'),
              fontWeight: isSelected ? 'bold' : 'normal'
            }}
          >
            {date.day}
          </Text>
        </TouchableOpacity>
      );
    }}
    renderArrow={(direction:any) => (
      <Text style={{
        fontSize: hp(3),
        color: '#000000',
        padding: 10,
      }}>
       {direction === 'left' ? '<' : '>'}
      </Text>
    )}
      style={{
        borderWidth: 0,
        borderColor: 'gray',
        height: 350
      }}
      theme={{
        backgroundColor: '#ffffff',
        calendarBackground: '#ffffff',
        textSectionTitleColor: '#000000',
        selectedDayBackgroundColor: '#000000',
        selectedDayTextColor: '#ffffff',
        todayTextColor: '#000000',
        dayTextColor: '#000000',
        textDisabledColor: '#000000'
      }}>
    </Calendar>
    <View style={{borderColor:'red',borderWidth:0,display:'flex',alignItems:'center',flexDirection:'column',gap:hp(2),padding:hp(2)}}>
      <View style={{width:'100%',borderColor:'green',borderWidth:0,display:'flex',flexDirection:'row',alignItems:'center',gap:hp(1),justifyContent:'center'}}>
            <View style={{ width:'80%',marginVertical:hp(2),borderColor:'#D4D4D4',borderWidth:1,borderRadius:8,backgroundColor:colors.inputBgColor,display:'flex',flexDirection:'row',alignItems:'center',paddingHorizontal:hp(1)}}>
               <Image source={images.searchIcon} style={{width:hp(2),height:hp(2)}}/>
                <TextInput 
                placeholderTextColor={colors.inputPlaceHolderColor}
                placeholder={'Search'} style={{flex:1,borderColor:'red',borderWidth:0,fontSize:hp(1.5)}}/>
            </View>
               <Image source={images.filterIcon} style={{width:hp(3),height:hp(3)}}/>   
      </View>
      {
        eventData.map((item,index)=>{
          return(
            <EventDataCrd key={index} isOnline={item.isOnline} eventTime={item.eventTime} eventName={item.eventName} eventStart={item.eventStart}/> 
          )
        })
      }
    </View>
    </ScrollView>
    <TouchableOpacity
     onPress={()=>{navigation.navigate('CreateEventScreen')}}
     style={{width:hp(6),height:hp(6),borderRadius:50,backgroundColor:colors.primary,borderColor:'green',borderWidth:0,position:'absolute',bottom:10,right:15,display:'flex',alignItems:'center',justifyContent:'center'}}>
      <Image source={images.plus} resizeMode='cover' style={{width:hp(3),height:hp(3)}}/>
    </TouchableOpacity>

    </MainLayout>
  )
}

export default EventDashboardScreen