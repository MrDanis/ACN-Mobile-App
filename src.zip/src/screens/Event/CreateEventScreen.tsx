import { View, Text, ScrollView,Image,TextInput, Alert } from 'react-native'
import React from 'react'
import MainLayout from '../../layout/MainLayout'
import { heightPercentageToDP as hp } from 'react-native-responsive-screen'
import { colors,images } from '../../config'
import Button from '../../components/Button/Button'
const CreateEventScreen = ({navigation}:any) => {
  return (
    <MainLayout navigation={navigation} activeTabIndex={1}>
    <ScrollView style={{flex:1,borderColor:'black',borderWidth:0,backgroundColor:colors.white}}>
      <View style={{display:'flex',flexDirection:'column',padding:hp(2),width:'100%',borderColor:'red',borderWidth:0}}>
        <Text style={{textAlign:'center',fontSize:hp(2),fontWeight:'600',color:colors.black}}>
          Add New Event
        </Text>
        <View style={{width:'100%',borderColor:'red',borderWidth:0,marginTop:hp(4),display:'flex',flexDirection:'column'}}>
        <View style={{ width:'100%',marginVertical:hp(2),borderColor:'#D4D4D4',borderWidth:1,borderRadius:8,backgroundColor:colors.white,display:'flex',flexDirection:'row',alignItems:'center',paddingHorizontal:hp(1)}}>
                <TextInput 
                placeholderTextColor={colors.inputPlaceHolderColor}
                placeholder={'Event name*'} style={{flex:1,borderColor:'red',borderWidth:0,fontSize:hp(1.5)}}/>
            </View>
        <View style={{ width:'100%',height:hp(13),marginVertical:hp(2),borderColor:'#D4D4D4',borderWidth:1,borderRadius:8,backgroundColor:colors.white,display:'flex',flexDirection:'row',alignItems:'flex-start',paddingHorizontal:hp(1)}}>
                <TextInput 
                placeholderTextColor={colors.inputPlaceHolderColor}
                placeholder={'Type the note here...'} style={{flex:1,borderColor:'red',borderWidth:0,fontSize:hp(1.5)}}/>
        </View>
        <View style={{ width:'100%',marginVertical:hp(2),borderColor:'#D4D4D4',borderWidth:1,borderRadius:8,backgroundColor:colors.white,display:'flex',flexDirection:'row',alignItems:'center',paddingHorizontal:hp(1) }}>
                               <TextInput 
                               placeholderTextColor={colors.inputPlaceHolderColor}
                               placeholder={'Date'} style={{flex:1,borderColor:'red',borderWidth:0,fontSize:hp(1.5)}}/>
                <Image source={images.tabEventIcon} style={{width:hp(3),height:hp(3)}}/>
        </View>
        <View style={{width:'100%',display:'flex',flexDirection:'row',alignItems:'center',justifyContent:'space-between',borderColor:'red',borderWidth:0,marginBottom:hp(1)}}>
        <View style={{ width:'48%',marginVertical:hp(2),borderColor:'#D4D4D4',borderWidth:1,borderRadius:8,backgroundColor:colors.white,display:'flex',flexDirection:'row',alignItems:'center',paddingHorizontal:hp(1) }}>
                               <TextInput 
                               placeholderTextColor={colors.inputPlaceHolderColor}
                               placeholder={'Start Time'} style={{flex:1,borderColor:'red',borderWidth:0,fontSize:hp(1.5)}}/>
                <Image source={images.timeIcon} style={{width:hp(3),height:hp(3)}}/>
        </View>
        <View style={{ width:'48%',marginVertical:hp(2),borderColor:'#D4D4D4',borderWidth:1,borderRadius:8,backgroundColor:colors.white,display:'flex',flexDirection:'row',alignItems:'center',paddingHorizontal:hp(1) }}>
                               <TextInput 
                               placeholderTextColor={colors.inputPlaceHolderColor}
                               placeholder={'End Time'} style={{flex:1,borderColor:'red',borderWidth:0,fontSize:hp(1.5)}}/>
                <Image source={images.timeIcon} style={{width:hp(3),height:hp(3)}}/>
        </View>
        </View>
        <View style={{width:'100%',borderColor:'green',borderWidth:0,display:'flex',flexDirection:'column',gap:hp(1)}}>
           <Text style={{color:colors.black,fontWeight:'600',fontSize:hp(2),marginBottom:hp(1)}}>
            Select Catgeory
           </Text>
            <View style={{width:'100%',display:'flex',flexDirection:'row',gap:hp(1)}}>
               <View style={{flex:1,borderColor:'red',borderWidth:0,backgroundColor:'#f8f6f3',padding:hp(1.5),display:'flex',flexDirection:'row',alignItems:'center',gap:hp(1),borderRadius:10}}>
                <View style={{width:hp(1.75),height:hp(1.75),borderRadius:50,backgroundColor:colors.primary,display:'flex',alignItems:'center',justifyContent:'center'}}>
                  <View style={{width:'50%',height:'50%',backgroundColor:colors.eventcardBg,borderRadius:50}}/>               
                </View>
                <Text>
                    Brainstorm
                </Text>
               </View>
               <View style={{flex:1,borderColor:'red',borderWidth:0,backgroundColor:'#edfaf6',padding:hp(1.5),display:'flex',flexDirection:'row',alignItems:'center',gap:hp(1),borderRadius:10}}>
                <View style={{width:hp(1.75),height:hp(1.75),borderRadius:50,backgroundColor:colors.eventOnline,display:'flex',alignItems:'center',justifyContent:'center'}}>
                  <View style={{width:'50%',height:'50%',backgroundColor:colors.eventcardBg,borderRadius:50}}/>               
                </View>
                <Text>
                    Design
                </Text>
               </View>
               <View style={{flex:1,borderColor:'red',borderWidth:0,backgroundColor:'#edf8ff',padding:hp(1.5),display:'flex',flexDirection:'row',alignItems:'center',gap:hp(1),borderRadius:10}}>
                <View style={{width:hp(1.75),height:hp(1.75),borderRadius:50,backgroundColor:colors.blue,display:'flex',alignItems:'center',justifyContent:'center'}}>
                  <View style={{width:'50%',height:'50%',backgroundColor:colors.eventcardBg,borderRadius:50}}/>               
                </View>
                <Text>
                 Workout
                </Text>
               </View>
            </View>
            <View style={{width:'100%',height:hp(6),marginTop:hp(2)}}>
               <Button text={'Create Event'} type={0} handlePress={()=>{Alert.alert('This module is under development')}}/> 
            </View>
        </View>
        </View>
      </View>
    </ScrollView>
    </MainLayout>
  )
}

export default CreateEventScreen