import { View, Text,SafeAreaView, Image, TouchableOpacity } from 'react-native'
import React from 'react'
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';
import {SafeAreaProvider} from 'react-native-safe-area-context';
import { MainLayoutProps } from '../screens/data';
import Header from '../components/Header/Header';
import Footer from '../components/Footer/Footer';
import { colors } from '../config';
const MainLayout:React.FC<MainLayoutProps> = ({children,navigation,activeTabIndex}) => {
  return (
   <SafeAreaProvider>
    <SafeAreaView style={{flex:1}}>
      <Header navigation={navigation} activeIndex={activeTabIndex}/>
      <View style={{width:'100%',height:'84%',borderColor:'green',borderWidth:0}}>   
          <View style={{backgroundColor:colors.leadBg,paddingVertical:hp(2),display:'flex',flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}>
           {
             ['Ticker','Alert Ticker','Alert Ticker','Alert Ticker','Alert'].map((item,index)=>{
              return(
                <Text style={{color:colors.white,fontWeight:'600',fontSize:hp(2)}}>
                  {item}
                </Text>
              )
             })
           }
          </View>
        {children}
      </View>
      <View style={{width:'100%',height:'9%',backgroundColor:colors.white,elevation:7,borderColor:'blue',borderWidth:0,display:'flex',alignItems:'center',justifyContent:'center',padding:hp(1.25)}}>
        <Footer navigation={navigation} activeTab={activeTabIndex}/>
      </View>

    </SafeAreaView>
   </SafeAreaProvider>
  )
}

export default MainLayout