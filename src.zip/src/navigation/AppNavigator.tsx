//main navigation all screen handle
import { Platform } from 'react-native'
import React from 'react'
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {NavigationContainer} from '@react-navigation/native';
import SplashScreen from '../screens/Auth/SplashScreen';
import WellcomeScreen from '../screens/Auth/WellcomeScreen';
import RegisterScreen from '../screens/Auth/RegisterScreen';
import LoginScreen from '../screens/Auth/LoginScreen';
import ForgotPasswordScreen from '../screens/Auth/ForgotPasswordScreen';
import OtpVerificationScreen from '../screens/Auth/OtpVerificationScreen';
import CreateNewPassword from '../screens/Auth/CreateNewPassword';
import CongratulationScreen from '../screens/Auth/CongratulationScreen';
import EventDashboardScreen from '../screens/Event/EventDashboardScreen';
import NotificationDashboardScreen from '../screens/Notification/NotificationDashboardScreen';
import HomeDashboardScreen from '../screens/Home/HomeDashboardScreen';
import JobDashboardScreen from '../screens/Job/JobDashboardScreen';
import CommunityDashboardScreen from '../screens/Community/CommunityDashboardScreen';
import ChatThreadScreen from '../screens/Community/ChatThreadScreen';
import JobDetails from '../screens/Job/JobDetails';
import JobApply from '../screens/Job/JobApply';
import CreateEventScreen from '../screens/Event/CreateEventScreen';
const Stack = createNativeStackNavigator();
const AppNavigator = () => {
  return (
    <NavigationContainer>
        <Stack.Navigator 
          screenOptions={{
            gestureEnabled: Platform.OS === 'android' ? false : true,
            animation: 'fade',
          }}
        >
         <Stack.Screen 
         name='SplashScreen'
         component={SplashScreen}
         options={{headerShown:false}}
         />
         <Stack.Screen 
         name='WellcomeScreen'
         component={WellcomeScreen}
         options={{headerShown:false}}
         />
         <Stack.Screen 
         name='RegisterScreen'
         component={RegisterScreen}
         options={{headerShown:false}}
         />
         <Stack.Screen 
         name='LoginScreen'
         component={LoginScreen}
         options={{headerShown:false}}
         />
         <Stack.Screen 
         name='ForgotPassword'
         component={ForgotPasswordScreen}
         options={{headerShown:false}}
         />
         <Stack.Screen 
         name='OtpVerificationScreen'
         component={OtpVerificationScreen}
         options={{headerShown:false}}
         />
         <Stack.Screen 
         name='CreateNewPasswordScreen'
         component={CreateNewPassword}
         options={{headerShown:false}}
         />
         <Stack.Screen 
         name='CongratulationScreen'
         component={CongratulationScreen}
         options={{headerShown:false}}
         />
         <Stack.Screen 
         name='EventDashboardScreen'
         component={EventDashboardScreen}
         options={{headerShown:false}}
         />
         <Stack.Screen 
         name='NotificationDashboardScreen'
         component={NotificationDashboardScreen}
         options={{headerShown:false}}
         />
         <Stack.Screen 
         name='HomeDashboardScreen'
         component={HomeDashboardScreen}
         options={{headerShown:false}}
         />
         <Stack.Screen 
         name='JobDashboardScreen'
         component={JobDashboardScreen}
         options={{headerShown:false}}
         />
         <Stack.Screen 
         name='CommunityDashboardScreen'
         component={CommunityDashboardScreen}
         options={{headerShown:false}}
         />
         <Stack.Screen 
         name='SpecificChatThread'
         component={ChatThreadScreen}
         options={{headerShown:false}}
         />
         <Stack.Screen 
         name='JobDetailsScreen'
         component={JobDetails}
         options={{headerShown:false}}
         />
         <Stack.Screen 
         name='JobApply'
         component={JobApply}
         options={{headerShown:false}}
         />
         <Stack.Screen 
         name='CreateEventScreen'
         component={CreateEventScreen}
         options={{headerShown:false}}
         />
         
        </Stack.Navigator>
    </NavigationContainer>
  )
}

export default AppNavigator