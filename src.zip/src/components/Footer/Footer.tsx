import { View, Text,TouchableOpacity,Image } from 'react-native'
import React from 'react'
import { bottomTabs } from '../../screens/data'
import { colors } from '../../config'
import { heightPercentageToDP as hp } from 'react-native-responsive-screen'
const Footer = ({navigation,activeTab}:any) => {
  return (
    <View style={{flex:1,width:'100%',borderColor:'black',borderWidth:0,display:'flex',flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}>
    {
     bottomTabs.map((item,index)=>{
       return(
         <TouchableOpacity
           key={index}
           onPress={()=>{navigation.navigate(item.navigationLink)}}
           style={{display:'flex',alignItems:'center',justifyContent:'center',borderColor:'red',borderWidth:0}}>
           <Image source={item.icon} resizeMode='cover' style={{width:hp(4),height:hp(4)}}/>
            <Text style={{color:index===activeTab?colors.primary:colors.textGray,fontSize:hp(1.25),fontWeight:'400',marginTop:hp(.25)}}>
               {item.name}
            </Text>
          </TouchableOpacity>
       )
     })

    }
  </View>
  )
}

export default Footer