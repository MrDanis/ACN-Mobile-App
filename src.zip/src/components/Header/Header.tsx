import { View, Text,Image } from 'react-native'
import React from 'react'
import { colors,images } from '../../config'
import { heightPercentageToDP as hp } from 'react-native-responsive-screen'
const Header = ({navigation,activeIndex}:any) => {
  return (
    <View style={{width:'100%',height:'7%',borderColor:'red',borderWidth:0}}>
         {
            (activeIndex+1 === 3 || 4)&&(
                <View style={{height:'100%',width:'100%',borderColor:'green',borderWidth:0,backgroundColor:colors.primary,display:'flex',flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingHorizontal:hp(1.5)}}>
                  <View style={{display:'flex',flexDirection:'row',gap:hp(1),alignItems:'center'}}>
                       <Image source={images.homeWhiteIcon} style={{width:hp(3),height:hp(3)}}/>
                        {
                          (activeIndex+1 === 3)&&(
                            <Text style={{fontWeight:'600',color:colors.white,fontSize:hp(2.5)}}>
                              Home
                            </Text>
                          )
                        }
                        {
                          (activeIndex+1 === 4)&&(
                            <Text style={{fontWeight:'600',color:colors.white,fontSize:hp(2.5)}}>
                              Jobs
                            </Text>
                          )
                        }
                        {
                          (activeIndex+1 === 1)&&(
                            <Text style={{fontWeight:'600',color:colors.white,fontSize:hp(2.5)}}>
                              Events
                            </Text>
                          )
                        }
                        {
                          (activeIndex+1 === 5)&&(
                            <Text style={{fontWeight:'600',color:colors.white,fontSize:hp(2.5)}}>
                              Community
                            </Text>
                          )
                        }
                  </View>
                  <Image source={images.notificationWhiteIcon} style={{width:hp(3),height:hp(3)}}/>

                </View>
            )
         }
          {
            (activeIndex+1 === 2)&&(
                <View style={{width:'100%',height:'100%',borderColor:'green',borderWidth:0,backgroundColor:colors.primary,display:'flex',flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingHorizontal:hp(1.5)}}>
                  <View style={{display:'flex',flexDirection:'row',gap:hp(1)}}>
                  <Image source={images.notificationWhiteIcon} style={{width:hp(3),height:hp(3)}}/>
                       {/* <Image source={images.homeWhiteIcon} style={{width:hp(3),height:hp(3)}}/> */}
                       <Text style={{fontWeight:'600',color:colors.white,fontSize:hp(2.5)}}>
                        Notification
                       </Text>
                  </View>

                </View>
            )
         }
          {
            (activeIndex+1 === 5)&&(
                <View style={{width:'100%',height:'100%',borderColor:'green',borderWidth:0,backgroundColor:colors.white,display:'flex',flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingHorizontal:hp(1.5)}}>
                  <View style={{display:'flex',flexDirection:'row',gap:hp(1)}}>
                       <Text style={{fontWeight:'600',color:colors.black,fontSize:hp(2.5)}}>
                        Community
                       </Text>
                  </View>

                </View>
            )
         }
{/* 
         <Text>
          {activeIndex+1===5}
         </Text> */}
    </View>
  )
}

export default Header