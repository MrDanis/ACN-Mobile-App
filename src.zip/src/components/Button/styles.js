import { StyleSheet } from "react-native";
import { colors } from "../../config";
import { heightPercentageToDP as hp } from "react-native-responsive-screen";
export const btnStyle = StyleSheet.create({
    primaryBtn:{ flex:1,padding:hp(1),display:'flex',alignItems:'center',justifyContent:'center',backgroundColor:colors.primary,borderRadius:10,color:colors.white},
    outlineBtn:{ flex:1,padding:hp(1.5),display:'flex',alignItems:'center',justifyContent:'center',backgroundColor:colors.white,borderRadius:10,color:colors.primary,borderColor:colors.primary,borderWidth:2}
})