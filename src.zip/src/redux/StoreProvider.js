import { Provider } from "react-redux";
import { makeStore } from ".";
import { useRef } from "react";
export let storeInstance;
export function StoreProvider({ children }) {
  const storeRef = useRef();
  if (!storeRef.current) {
    storeRef.current = makeStore();
  }
  storeInstance = storeRef.current;
  return <Provider store={storeRef.current}>{children}</Provider>;
}
