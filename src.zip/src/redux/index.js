import { configureStore } from "@reduxjs/toolkit";
import authReducer from "./slices/AuthSlice";
import blogReducer from "./slices/BlogSlice";
import permissionReducer from "./slices/PermissionSlice"
import chatNavReducer from "./slices/ChatNavSlice"

export const makeStore = () => {
  return configureStore({
    reducer: {
      auth: authReducer,
      blog:blogReducer,
      permissions:permissionReducer,
      chatNav: chatNavReducer
    },
  });
};
