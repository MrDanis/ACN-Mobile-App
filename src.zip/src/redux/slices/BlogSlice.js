import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  categories:[]
};

export const blogSlice = createSlice({
  name: "blog",
  initialState,
  reducers: {
    setCategories: (state,payload) => {

        state.categories=payload.payload
    },
  },
});


export const { setCategories } = blogSlice.actions;

export default blogSlice.reducer;
