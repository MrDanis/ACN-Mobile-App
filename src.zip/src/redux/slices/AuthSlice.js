import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  user: null,
};

export const AuthSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    logIn: (state, payload) => {
      state.user = payload.payload;
    },
  },
});

export const { logIn } = AuthSlice.actions;

export default AuthSlice.reducer;
