import { createSlice } from '@reduxjs/toolkit';
 
const initialState = {
  permissionsList: []
};
 
const permissionSlice = createSlice({
  name: 'permissions',
  initialState,
  reducers: {
    setPermissions: (state, action) => {
      state.permissionsList = action.payload;
    },
    clearPermissions: (state) => {
      state.permissionsList = [];
    }
  },
});
 
export const { setPermissions, clearPermissions } = permissionSlice.actions;
 
 
export const checkPermission = (rightspayload) => (state) => {
  try {
    debugger
    const permissions = state.permissions.permissionsList;
    if (!permissions || !Array.isArray(permissions)) {
      return false;
    }
 
    const { key1, key2 } = rightspayload;
    if (!key1 || !key2) return false;
 
    const category = permissions.find(
      (perm) => perm.category?.toLowerCase().replace(/\s+/g, '') === key1.toLowerCase()
    );
   
    if (!category?.permissions) return false;
 
    return category.permissions.some(
      (perm) => perm.key?.toLowerCase() === `${key2.toLowerCase()}`
    );
  } catch (error) {
    console.error('Error checking permissions:', error);
    return false;
  }
};
 
export default permissionSlice.reducer;