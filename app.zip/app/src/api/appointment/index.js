import request from '../NetworkHelper';

function addAppointment(data) {
  return request(true, {
    url: '/api/Appointment/AddAppointment',
    method: 'POST',
    data: data,
  });
}

function getlocationsProvider() {
  return request(true, {
    url: '/api/Appointment/GetlocationsProvider',
    method: 'GET',
  });
}

function getAppointment() {
  return request(true, {
    url: '/api/Appointment/GetAppointment',
    method: 'GET',
  });
}

function getTimeSlots(data) {
  return request(true, {
    url: '/api/Appointment/GetTimeSlots',
    method: 'POST',
    data,
  });
}
function createAppointment(data) {
  return request(true, {
    url: '/api/Appointment/CreateAppointment',
    method: 'POST',
    data,
  });
}
function roomCallWithProvider(data)
{
  return request(true, {
    url: `/api/common/StartCallFromPatient?appointmentId=${data}`,
    method: 'GET'
  })
}

const AppointmentService = {
  addAppointment,
  getAppointment,
  getlocationsProvider,
  getTimeSlots,
  createAppointment,
  roomCallWithProvider
};

export default AppointmentService;
