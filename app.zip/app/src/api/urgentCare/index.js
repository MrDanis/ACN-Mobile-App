import request from '../NetworkHelper';
function getUrgentCareDoctorList(name) {
  return request(true, {
    url: `/api/Shortcuts/UrgentCare?state=${name}`,
    method: 'GET',
  });
}
const UrgentCareService = {
  getUrgentCareDoctorList,
};
export default UrgentCareService;
