/* istanbul ignore file */
import request from '../NetworkHelper';

function getAllergiesData() {
  return request(true, {
    url: '/api/Alergies/GetAllPatientAlergies',
    method: 'GET',
  });
}

const AllergiesService = {
  getAllergiesData,
};

export default AllergiesService;
