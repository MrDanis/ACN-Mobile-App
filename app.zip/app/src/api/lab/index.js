/* istanbul ignore file */
import request from '../NetworkHelper';

function getLabsData() {
  return request(true, {
    url: '/api/Labs/GetLabs',
    method: 'GET',
  });
}
function getLabsContactData() {
  return request(true, {
    url: '/api/Contact/GetPatientLab',
    method: 'GET',
  });
}

function uploadLabData(labsData, imageData) {
  console.log(labsData);
  const formdata = new FormData();
  formdata.append('TestName', labsData.TestName);
  formdata.append('LabName', labsData.LabName);
  formdata.append('Description', labsData.Description);
  console.log('====================================');
  console.log('formdata', formdata);
  console.log('====================================');
  if (
    imageData &&
    imageData !== null &&
    imageData.name &&
    imageData.name !== null
  ) {
    formdata.append('Files', {
      uri: imageData.uri,
      name: imageData.name,
      type: imageData.type,
    });
  }
  console.log('formdata updateProfileData');
  console.log('hola', formdata);
  return request(true, {
    url: '/api/Labs/AddLabs',
    method: 'POST',
    data: formdata,
  });
}

function getListOfDocumnetTypeData(data) {
  return request(true, {
    url: '/api/Labs/Listofdocumenttype',
    method: 'POST',
    data: data,
  });
}

const LabService = {
  getLabsData,
  uploadLabData,
  getLabsContactData,
  getListOfDocumnetTypeData,
};

export default LabService;
