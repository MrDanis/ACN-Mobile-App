import request from '../NetworkHelper';
function getACStokenForCalling() {
  return request(true, {
    url: '/api/common/AzureAccessToken',
    method: 'GET',
  });
}
const AudioVedioCallingTokenService = {
  getACStokenForCalling,
};

export default AudioVedioCallingTokenService;
