/* istanbul ignore file */
import request from '../NetworkHelper';
import {CURRENT_TARGET} from '../../../config/AppConfig';

function getAllVitals() {
  return request(true, {
    url: '/api/Vitals/GetAllVitals',
    method: 'GET',
  });
}
function getVitalCategoryData() {
  return request(true, {
    url: '/api/Vitals/VitalCategoryData',
    method: 'GET',
  });
}

function getVitalSubTypeData(ionic) {
  return request(true, {
    url: `/api/Vitals/VitalSubTypes?loinc=${ionic}`,
    method: 'GET',
  });
}

function addVital(dataObject) {
  console.log('====================================');
  console.log('dataObject', dataObject);
  console.log('====================================');
  return request(true, {
    url: `/api/Vitals/AddVital`,
    method: 'POST',
    data: dataObject,
  });
}

function getVitalCategoryHistory(vitalCategoryId, date, type, ionic) {
  return request(true, {
    url:
      '/api/Vitals/VitalHistory?VitalTypeId=' +
      vitalCategoryId +
      '&date=' +
      date +
      '&type=' +
      type +
      '&loinc=' +
      ionic,
    method: 'GET',
  });
}
const VitalsService = {
  getAllVitals,
  getVitalCategoryData,
  getVitalSubTypeData,
  addVital,
  getVitalCategoryHistory,
};

export default VitalsService;
