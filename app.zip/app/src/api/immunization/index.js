/* istanbul ignore file */
import request from '../NetworkHelper';

function getImmunizationData() {
  return request(true, {
    url: '/api/Immunization/GetAllPatientImmunization',
    method: 'GET',
  });
}

const ImmunizationService = {
  getImmunizationData,
};

export default ImmunizationService;
