/* istanbul ignore file */
import axios from 'axios';
import {CURRENT_TARGET} from '../../config/AppConfig';
import {HeaderInfo, source} from './constants';
import {Alert, Platform} from 'react-native';
import RNExitApp from 'react-native-exit-app';
import {
  AuthToken,
  BlueButtonAccessToken,
  BlueButtonRefreshToken,
  RefreshToken,
  retrieveItem,
  storeItem,
} from '../helpers/LocalStorage';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {showMessage, hideMessage} from 'react-native-flash-message';
import NetInfo from '@react-native-community/netinfo';
import Colors from '../../config/Colors';

/**
 * Request Wrapper with default success/error actions
 */
const request = async function (isHeader, options) {
  console.log('====================================');
  console.log('option.url', options.url);
  console.log('====================================');
  let authToken = null;
  let blueButtonToken = null;
  if (isHeader) {
    authToken = await retrieveItem(AuthToken);
    blueButtonToken = await retrieveItem(BlueButtonAccessToken);
    console.log('Inside the request rn');
    console.log('AuthToken ', authToken);
    console.log(blueButtonToken);
  }
  const multipartUrls = [
    '/api/Labs/AddLabs',
    '/api/Imaging/AddImaging',
    '/api/Chat/SaveVoiceNotes',
    '/api/PatientProfile/SaveUserProfile',
  ];
  const networkCheck = multipartUrls.some(substring =>
    options.url.includes(substring),
  );
  const isMultipart = multipartUrls.includes(options.url);
  const isUserProfile = options.url === '/api/PatientProfile/SaveUserProfile';
  const contentType = isMultipart
    ? Platform.OS === 'ios' && isUserProfile
      ? 'application/json, multipart/form-data'
      : 'multipart/form-data'
    : 'application/json';

  console.log('Netwrok check is : ', networkCheck);
  const client = axios.create({
    baseURL: CURRENT_TARGET,
    headers: {
      Accept: 'application/json',
      'Security-Key': 'lSWQ9NyZ1c2VyTmFtZT1TeWVkIFNoYWgmcGF0aWVudElkPTMwMD',
      'Content-Type': contentType,

      Authorization: 'Bearer '.concat(authToken === null ? '' : authToken),
      ...(blueButtonToken && {access_token: blueButtonToken}),
    },
  });

  console.log('====================================');
  console.log('client', client);
  console.log('====================================');

  const onSuccess = async function (response) {
    console.log('success response', response);
    // condition to check if token needs to be refreshed
    if (
      response?.data?.data[0]?.restApiStatusCode != undefined &&
      response?.data?.data[0]?.restApiStatusCode === 401
    ) {
      console.log(
        'this is inside the success fun',
        response,
        response?.data.data[0],
      );
      const originalRequest = response.config;

      if (!originalRequest._retry) {
        originalRequest._retry = true; // Mark this request as retried
        try {
          const newBlueButtonToken = await refreshBlueButtonToken();
          originalRequest.headers['access_token'] = newBlueButtonToken;
          return axios(originalRequest);
        } catch (error) {
          console.error('Failed to retry original request:', error);
          return Promise.reject(error);
        }
      }
    }
    const {status} = response;
    if (status === 200) {
      return response.data;
    }
  };

  const onError = async function (error) {
    NetInfo.fetch().then(state => {
      if (!state.isConnected && !state.isInternetReachable) {
        showMessage({
          message: 'Network Error',
          description: 'Internet is not available',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      }
    });
    if (error && error.response && error.response.status) {
      if (error.response.status === 401) {
        console.log('intercepter is called for 401', error);
        if (error.response.data && error.response.data.isError) {
          // showMessage({
          //   message: 'Something went wrong!',
          //   description: error.response.data.Message,
          //   type: 'default',
          //   icon: {icon: 'info', position: 'left'},
          //   backgroundColor: Colors.red,
          // });
        }
      } else if (error.response.status === 96) {
        if (error.response.data && error.response.data.isError) {
          showMessage({
            message: 'Something went wrong!',
            description: error.response.data.Message,
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        }
      } else if (error.response.status === 520) {
        if (error.response.data && error.response.data.isError) {
          showMessage({
            message: 'Something went wrong!',
            description: error.response.data.Message,
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        }
      } else if (error.response.status === 404) {
        if (error.response.data && error.response.data.isError) {
          showMessage({
            message: 'Something went wrong!',
            description: error.response.data.Message,
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        }
      } else if (error.response.status === 500) {
        console.log('====================================');
        console.log('error', error);
        console.log('====================================');
        if (error.response.data && error.response.data.detail) {
          showMessage({
            message: 'Something went wrong',
            description: '',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        }
      }
      console.log('Status:', error.response);
      console.log('Data:', error.response.data);
    } else {
      // Something else happened while setting up the request
      // triggered the error
      error && error.response && error.response.status;
      showMessage({
        message: 'Something went wrong!',
        description: error?.response?.data?.detail,
        type: 'default',
        icon: {icon: 'info', position: 'left'},
        backgroundColor: Colors.red,
      });
      console.log('Error Message:', error);
    }
    console.log('====================================');
    console.log('here in error', error);
    console.log('====================================');
    return Promise.reject(error.response.data);
  };
  return client(options).then(onSuccess).catch(onError);
};
const refreshBlueButtonToken = async () => {
  try {
    const authToken = await retrieveItem(AuthToken);

    const response = await axios.post(
      `${CURRENT_TARGET}/api/PatientHistory/AuthenticateWithBlueButton`,
      {},
      {
        headers: {
          Authorization: `Bearer ${authToken}`,
        },
      },
    );
    console.log('this is refreshed token response', response);
    const newAccessToken = response.data.data.accessToken;
    const newRefreshToken = response.data.data.refreshToken;

    storeItem(BlueButtonAccessToken, newAccessToken);
    storeItem(BlueButtonRefreshToken, newRefreshToken);

    return newAccessToken;
  } catch (error) {
    console.error('Failed to refresh token:', error);
    throw error;
  }
};
function exitApp() {
  AsyncStorage.clear();
  Alert.alert(
    'Care Management',
    'Your care has been stopped.\nPlease contact your Care Manager.',
    [{text: 'Close App', onPress: () => RNExitApp.exitApp()}],
    {cancelable: false},
  );
  return true;
}
export const TokenType = {
  FIREBASE: 0,
  VOIP: 1,
  CLEAR_TOKEN: 2,
};

export default request;
