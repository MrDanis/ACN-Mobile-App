/* istanbul ignore file */
import request from '../NetworkHelper';

function getChatHistoryData(cmId, pageNo, appointmentId) {
  console.log('====================================');
  console.log('pageNo', pageNo);
  console.log('====================================');
  return request(true, {
    url: '/api/Chat/ChatHistory?receiverId=' + cmId + '&pageNo=' + pageNo,
    method: 'GET',
  });
}

function getCareCoordinationContacts() {
  return request(true, {
    url: '/api/Contact/GetCareCoordination',
    method: 'GET',
  });
}

function getPhysicianContacts() {
  return request(true, {
    url: '/api/Contact/GetPhysician',
    method: 'GET',
  });
}

function uploadAttachments(dataObject) {
  return request(true, {
    url: 'PatientTouchService/api/Chat/UploadChatFile',
    method: 'POST',
    data: dataObject,
  });
}
function uploadVoiceNote(audioPath) {
  console.log(audioPath);
  const formData = new FormData();
  formData.append('Files', {
    uri: audioPath,
    type: 'audio/x-m4a', // MIME type of the file
    name: 'hello.m4a', // Name of the file
  });

  formData.append('DisplayName', 'hello.m4a');
  console.log('formdata audio recording');
  console.log('voice data', formData);
  return request(true, {
    url: '/api/Chat/SaveVoiceNotes',
    method: 'POST',
    data: formData,
  });
}

const ChatService = {
  getChatHistoryData,
  uploadAttachments,
  getPhysicianContacts,
  getCareCoordinationContacts,
  uploadVoiceNote,
};

export default ChatService;
