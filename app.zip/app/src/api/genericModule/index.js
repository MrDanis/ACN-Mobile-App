import request from '../NetworkHelper';

function getGenericModuleWise(data) {
  console.log('====================================');
  console.log('data', data);
  console.log('====================================');
  return request(true, {
    url:
      '/api/Common/GenericModuleWiseMethod?ModuleName=' +
      data.ModuleName +
      '&id=' +
      data.id +
      '&IsEmr=' +
      data.isEmr,
    method: 'GET',
  });
}
const ModuleWiseService = {
  getGenericModuleWise,
};

export default ModuleWiseService;
