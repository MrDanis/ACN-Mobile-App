import request from '../NetworkHelper';

function getHomeApi() {
  return request(true, {
    url: '/api/Configuration/GetConfiguration',
    method: 'GET',
  });
}

function getDashboardDataApi() {
  return request(true, {
    url: '/api/Dashboard/DashboardDataList',
    method: 'GET',
  });
}

function UpdateWidgetsSelected(data) {
  return request(true, {
    url: '/api/Dashboard/LandingPageModuleStatus',
    method: 'POST',
    data: data,
  });
}
function getWidget() {
  return request(true, {
    url: '/api/Dashboard/LandingPageModule',
    method: 'GET',
  });
}
function getWidgetNew() {
  return request(true, {
    url: '/api/Dashboard/AllModulesAndStatus',
    method: 'GET',
  });
}
const HomeService = {
  getHomeApi,
  getDashboardDataApi,
  UpdateWidgetsSelected,
  getWidget,
  getWidgetNew,
};

export default HomeService;
