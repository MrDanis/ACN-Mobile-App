import request from '../NetworkHelper';

function changeCatStatus(id, isActive) {
  return request(true, {
    url: `/api/Dashboard/HealthCategoryStatus?categoryId=${id}&status=${isActive}`,
    method: 'PUT',
  });
}
function changeCatgoalStatus(id, goal) {
  return request(true, {
    url: `/api/Dashboard/UpdatePatientGoal?categoryId=${id}&patientGoal=${goal}`,
    method: 'PUT',
  });
}

function getCategories() {
  return request(true, {
    url: `/api/Dashboard/HealthCategories`,
    method: 'GET',
  });
}

function getHealthCategoryById(id, date, type) {
  return request(true, {
    url: `/api/Dashboard/GetHistoryPatientHealthCategory?categoryId=${id}&date=${date}&type=${type}`,
    method: 'GET',
  });
}
function postHealthCategoryById(dataObject) {
  console.log('data before sending to api is : ', dataObject);
  return request(true, {
    url: `/api/Dashboard/HealthCategoryData`,
    method: 'POST',
    data: dataObject,
  });
}

const DiscoverService = {
  changeCatStatus,
  getCategories,
  getHealthCategoryById,
  postHealthCategoryById,
  changeCatgoalStatus,
};

export default DiscoverService;
