import {combineReducers} from 'redux';
import {userProfileData} from '../features/profile/reducers';
import {
  appLogoutTime,
  appointmentData,
  diseasesHistoryData,
  emailSharingResourceData,
  locationProvider,
  timeSlots,
} from '../features/bluebutton/reducers';
import {
  careCoordinationContactList,
  cmStatusData,
  historyData,
  physicianContactList,
  unReadMessageData,
  newMessage,
} from '../features/chat/reducers';
import {homeApiData} from '../features/home/reducers';
import {
  allMedicationData,
  allTodayMedicationData,
  medicationByIdData,
  medicationLookUpData,
  modalHandlerReducer,
  userLocationData,
  // cmCallEndStatus
} from '../features/medication/reducers';
import {allergiesData} from '../features/allergies/reducers';
import {allCategoriesData} from '../features/discover/reducers';
import {imagingData} from '../features/imaging&Radiology/reducers';
import {immunizationData} from '../features/immunization/reducers';
import {documentListData, labsData} from '../features/lab/reducers';
import {getUserSiganture} from '../features/profile/reducers';
import {
  liveStepsData,
  liveDistanceData,
  liveSpeedData,
  liveHeartData,
  liveWeightData,
  isEmail,
} from '../features/welcome/reducers';
import {
  callHistoryData,
  getCallIncomming,
  getCallStatus,
  cmCallEndStatus,
} from '../features/telehealth/reducers';
import {
  vitalsData,
  vitalCategoryData,
  vitalSubTypeData,
} from '../features/mycare/reducers';
export default combineReducers({
  userProfileData,
  getUserSiganture,
  liveStepsData,
  liveDistanceData,
  liveSpeedData,
  liveHeartData,
  liveWeightData,
  homeApiData,
  allCategoriesData,
  diseasesHistoryData,
  appLogoutTime,
  vitalsData,
  vitalCategoryData,
  vitalSubTypeData,
  medicationLookUpData,
  allMedicationData,
  allTodayMedicationData,
  medicationByIdData,
  modalHandlerReducer,
  userLocationData,
  historyData,
  cmStatusData,
  cmCallEndStatus,
  callHistoryData,
  getCallStatus,
  getCallIncomming,
  careCoordinationContactList,
  physicianContactList,
  labsData,
  documentListData,
  imagingData,
  emailSharingResourceData,
  appointmentData,
  locationProvider,
  timeSlots,
  allergiesData,
  immunizationData,
  isEmail,
  unReadMessageData,
  newMessage,
});
