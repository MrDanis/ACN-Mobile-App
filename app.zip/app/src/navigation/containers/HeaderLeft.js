import React from 'react';
import {TouchableOpacity, View,Image} from 'react-native';

import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {SvgCss} from 'react-native-svg';
import {Colors, Svgs} from '../../../config';
import {baseUrl} from '../../../config/AppConfig';

const HeaderLeft = ({image, name, width, height, navigation}) => {
  return (
    <View
      style={{
        width: '100%',
        flexDirection: 'row',
        alignItems: 'center',
        borderColor: 'red',
        borderWidth: 0,
      }}>
      {name === 'Discover' || name === 'Home' || !global.isPatientTouch ? (
        image !== null && image !== '' ? (
          <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
            <Image
              style={{
                width: hp(5), //width,
                height: hp(5), //height,
                marginLeft: hp(2.3),
                borderRadius: 10,
              }}
              source={{
                uri: baseUrl + '/' + image + '?' + new Date(),
                //priority: Image.priority.high,
              }}
            />
          </TouchableOpacity>
        ) : (
          <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
            <Image
              style={{
                width: width,
                height: height,
                borderRadius: 10,

                borderRadius: 10,
                marginLeft: hp(2),
                marginTop: hp(0.9),
              }}
              resizeMode="contain"
              source={require('../../../../assets/images/user_logo.png')}
            />
          </TouchableOpacity>
        )
      ) : (
        <SvgCss
          xml={Svgs.arrowHeadLeft}
          width={hp(5)}
          height={hp(5)}
          fill={Colors.black}
          onPress={() => navigation.pop()}
          style={{marginHorizontal: hp(1)}}
        />
      )}
    </View>
  );
};

export default HeaderLeft;
