// /* istanbul ignore file */
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import React from 'react';
import MeasureVitals from '../../features/mycare/screens/MeasureVitals';
import VitalBloodPressureScreen from '../../features/mycare/screens/VitalBloodPressureScreen';
import VitalHeightScreen from '../../features/mycare/screens/VitalHeightScreen';
import VitalHistory from '../../features/mycare/screens/VitalHistory';
import VitalPulseRateScreen from '../../features/mycare/screens/VitalPulseRateScreen';
import VitalTemperatureScreen from '../../features/mycare/screens/VitalTemperatureScreen';
import VitalWeightScreen from '../../features/mycare/screens/VitalWeightScreen';
import VitalsScreen from '../../features/mycare/screens/VitalsScreen';

const Stack = createNativeStackNavigator();
const VitalsStack = ({navigation}) => {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Vitals"
        component={VitalsScreen}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="MeasureVitals"
        component={MeasureVitals}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="VitalHistory"
        component={VitalHistory}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="VitalWeight"
        component={VitalWeightScreen}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="VitalTemperature"
        component={VitalTemperatureScreen}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="VitalBloodPressure"
        component={VitalBloodPressureScreen}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="VitalHeight"
        component={VitalHeightScreen}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="VitalPulseRate"
        component={VitalPulseRateScreen}
        options={{
          headerShown: false,
        }}
      />
    </Stack.Navigator>
  );
};
export default VitalsStack;
