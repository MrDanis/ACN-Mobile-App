/* istanbul ignore file */
import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import WellnessScreen from '../../features/wellness/screen/WellnessScreen';

const Stack = createNativeStackNavigator();
const WellnessStack = () => {
  return (
    <Stack.Navigator screenOptions={{gestureEnabled: false}}>
      <Stack.Screen
        name="WellnessStack"
        component={WellnessScreen}
        options={{headerShown: false}}
      />
    </Stack.Navigator>
  );
};
export default WellnessStack;
