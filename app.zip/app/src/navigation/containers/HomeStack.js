/* istanbul ignore file */
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import React from 'react';
import Allergies from '../../features/allergies/screens/allergiesScreen';
import AppointmentScreen from '../../features/bluebutton/screens/AppointmentScreen';
import ScheduleAppointment from '../../features/bluebutton/screens/component/ScheduleAppointment';
import HomeScreen from '../../features/home/screens/HomeScreen';
import WidgetSelection from '../../features/home/screens/WidgetSelection';
import ImagingRadiology from '../../features/imaging&Radiology/screens/ImagingScreen';
import Immunization from '../../features/immunization/screens/immunizationScreen';
import Labs from '../../features/lab/screens/labScreen';
import SettingScreen from '../../features/settings/screens/SettingScreen';
import UrgentCareMainScreen from '../../features/urgentCare/screens/UrgrntCareMainScreen';
import AssessmentStack from './AssessmentStack';
import FindDocStack from './FindDocStack';
import MedicationStack from './MedicationStack';
import SymptomsStack from './SymptomsStack';
import VitalsStack from './VitalsStack';
import WellnessStack from './WellnessStack';
import CaprePlanStack from './CarePlanStack';
import careCoordinatorScreen from '../../features/chat/screens/careCoordinatorScreen';
import MedicalHistoryStack from './MedicalHistoryStack';
const Stack = createNativeStackNavigator();
const HomeStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="HomeScreen"
        component={HomeScreen}
        options={{headerShown: false, gestureEnabled: false}}
      />
      <Stack.Screen
        name="urgentCare"
        component={UrgentCareMainScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="Lab"
        component={Labs}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="Imaging"
        component={ImagingRadiology}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="AllergiesScreen"
        component={Allergies}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="ImmunizationScreen"
        component={Immunization}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="MedicationStack"
        component={MedicationStack}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="VitalsStack"
        component={VitalsStack}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="AppointmentScreen"
        component={AppointmentScreen}
        options={{headerShown: false}}
      />

      <Stack.Screen
        name="AssessmentStack"
        component={AssessmentStack}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="FindDocStack"
        component={FindDocStack}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="Wellnesss"
        component={WellnessStack}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="CarePlans"
        component={CaprePlanStack}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="ScheduleAppointment"
        component={ScheduleAppointment}
        options={{headerShown: false}}
      />

      <Stack.Screen
        name="WidgetSelection"
        component={WidgetSelection}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="SettingScreen"
        component={SettingScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="CareCoordinatorScreen"
        component={careCoordinatorScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="MedHistoryStackScreen"
        component={MedicalHistoryStack}
        options={{headerShown: false}}
      />
    </Stack.Navigator>
  );
};
export default HomeStack;
