import React from 'react'
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import EmrSelection from '../../features/emr/EmrSelection';
import SpecificEmr from '../../features/emr/SpecificEmr';
import SpecificEMRdata from '../../features/emr/SpecificEMRdata';
const Stack = createNativeStackNavigator();
const EmrStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="EmrSelection"
        component={EmrSelection}
        options={{headerShown: false, gestureEnabled: false}}
      />
      <Stack.Screen
        name="SpecificEmr"
        component={SpecificEmr}
        options={{headerShown: false, gestureEnabled: false}}
      />
      <Stack.Screen
        name="SpecificEMRdata"
        component={SpecificEMRdata}
        options={{headerShown: false, gestureEnabled: false}}
      />

    </Stack.Navigator>
  )
}

export default EmrStack