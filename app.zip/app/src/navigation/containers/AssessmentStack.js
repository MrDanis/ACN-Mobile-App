/* istanbul ignore file */
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import React from 'react';
import AssessmentChildQuestions from '../../features/mycare/screens/assessment/AssessmentChildQuestions';
import AssessmentDashboard from '../../features/mycare/screens/assessment/AssessmentDashboard';
import AssessmentDetail from '../../features/mycare/screens/assessment/AssessmentDetail';
import AssessmentParentQuestions from '../../features/mycare/screens/assessment/AssessmentParentQuestions';
import AssessmentParentQuestionsUnComplete from '../../features/mycare/screens/assessment/AssessmentParentQuestionsUnComplete';
const Stack = createNativeStackNavigator();
const AssessmentStack = () => {
  return (
    <Stack.Navigator screenOptions={{gestureEnabled: true}}>
      <Stack.Screen
        name="AssessmentDashboard"
        component={AssessmentDashboard}
        options={{headerShown: false}}
      />

      <Stack.Screen
        name="AssessmentDetail"
        component={AssessmentDetail}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="AssessmentParentQuestions"
        component={AssessmentParentQuestions}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="AssessmentParentQuestionsUnComplete"
        component={AssessmentParentQuestionsUnComplete}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="AssessmentChildQuestions"
        component={AssessmentChildQuestions}
        options={{headerShown: false}}
      />
    </Stack.Navigator>
  );
};
export default AssessmentStack;
