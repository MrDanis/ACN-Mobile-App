import React from 'react';
import {TouchableOpacity, View,Image} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {useSelector} from 'react-redux';
import {Images} from '../../../config';

const HeaderRight = ({image, name, navigation}) => {
  const homeApiData = useSelector(state => state.homeApiData);

  return (
    <View
      style={{width: '100%', alignItems: 'flex-end', justifyContent: 'center'}}>
      {name === 'Contacts' || name === 'Home' ? (
        <View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              alignContent: 'center',
              flex: 1,
            }}>
            <TouchableOpacity
              onPress={() => navigation.navigate('NotificationStack')}>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'flex-start',
                  alignItems: 'center',
                  alignContent: 'center',
                  marginRight: hp(2),
                }}>
                <Image
                  style={{
                    width: hp(2),
                    height: hp(2.5),
                  }}
                  source={Images.notification_dashboard}
                />
              </View>
            </TouchableOpacity>
          </View>
        </View>
      ) : (
        name === 'Notifications' && (
          <View
            style={{
              flex: 1,
              marginHorizontal: hp(2),
            }}></View>
        )
      )}
    </View>
  );
};

export default HeaderRight;
