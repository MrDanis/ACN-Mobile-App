/* istanbul ignore file */
import React, {useState} from 'react';
import {Image, Platform, Pressable, Text, View} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Colors from '../../../config/Colors';
import images from '../../../config/Images';

import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {useFocusEffect} from '@react-navigation/native';
import {showMessage} from 'react-native-flash-message';
import {connect, useDispatch} from 'react-redux';
import {isACOUserLogin} from '../../helpers/Common';
import ChatStack from './ChatStack';
import HeaderLeft from './HeaderLeft';
import HeaderRight from './HeaderRight';
import HomeStack from './HomeStack';
import MedicalHistoryStack from './MedicalHistoryStack';
// import ProfileStack from './ProfileStack';
import {Fonts} from '../../../config/AppConfig';
import ProfileScreen from '../../features/profile/screens/ProfileScreen';

import {
  getAllergiesHistory,
  getCoverageHistory,
  getDiseasesHistory,
  getHospitalVisitHistory,
  getMedicationHistory,
  getProceduresHistory,
  getProviderHistory,
} from '../../features/bluebutton/action';
import {
  BlueButtonAccessToken,
  IsAcoUserLogin,
  removeItemValue,
  storeItem,
} from '../../helpers/LocalStorage';
// import {connect, useSelector} from 'react-redux';
const Tab = createBottomTabNavigator();

const HomeTabNavigation = function ({
  navigation,
  route,
  homeApiData,
  userProfileData,
  modalHandlerReducer,
}) {
  const [isModalVisible, setIsModalVisible] = useState(modalHandlerReducer);
  const dispatch = useDispatch();

  const clearStoreData = () => {
    dispatch(getMedicationHistory([]));
    dispatch(getProviderHistory([]));
    dispatch(getHospitalVisitHistory([]));
    dispatch(getDiseasesHistory([]));
    dispatch(getCoverageHistory([]));
    dispatch(getAllergiesHistory([]));
    dispatch(getProceduresHistory([]));
  };
  var isLogin = false;

  useFocusEffect(
    React.useCallback(() => {
      navigation.setOptions({tabBarVisible: false});
      const login = async () => {
        isLogin = await isACOUserLogin();

        setIsModalVisible(modalHandlerReducer);
      };
    }, [modalHandlerReducer]),
  );

  const goToMedicalHistoryAco = async () => {
    if (
      userProfileData &&
      userProfileData.firstName !== '' &&
      userProfileData.lastName !== '' &&
      userProfileData.dateOfBirth !== '' &&
      userProfileData.gender !== ''
    ) {
      navigation.navigate('ACOLogin', {
        screenName: 'HomeTab',
      });
    } else {
      showMessage({
        message: 'Information',
        description: 'Please complete your profile',
        type: 'default',
        icon: {icon: 'info', position: 'left'},
        backgroundColor: Colors.red,
      });
    }
  };

  return (
    <Tab.Navigator
      gestureEnabled={false}
      initialRouteName="Home"
      screenOptions={{
        tabBarActiveTintColor: Colors.blueTextColor,
        tabBarStyle: {
          backgroundColor: Colors.white,
          minHeight: Platform.OS === 'ios' ? 90 : 70,
          alignItems: 'center',
          justifyContent: 'center',
        },
        tabBarHideOnKeyboard: true,
        tabBarActiveBackgroundColor: Colors.backgroundGrey,
        tabBarIconStyle: {width: '100%'},
      }}>
      {userProfileData?.isCM || userProfileData?.isEMR ? (
        <>
          <Tab.Screen
            name="Home"
            options={{
              tabBarLabel: '',
              tabBarIcon: ({color, size, focused}) => {
                return (
                  <View
                    style={{
                      alignItems: 'center',
                      justifyContent: 'space-evenly',
                      minHeight: '100%',
                      width: '100%',
                      borderTopWidth: focused ? 0 : 0,
                      borderTopColor: Colors.blueTextColor,
                    }}>
                    <Image
                      style={{
                        width: 18,
                        height: 18,
                        marginTop: hp(1),
                      }}
                      source={focused ? images.IconHomeBlue : images.IconHome}
                    />
                    <Text
                      style={{
                        color: Colors.black,
                        fontSize: 10,
                        marginTop: hp(1),
                      }}>
                      Home
                    </Text>
                  </View>
                );
              },
              headerShown: false,
              gestureEnabled: true,
              headerShadowVisible: false,
              headerTitle: '',
              tabBarStyle: {
                display: modalHandlerReducer ? 'flex' : 'none',
                height: 90,
              },
            }}
            component={HomeStack}
          />
          {/* {userProfileData?.isCM ? (
            <Tab.Screen
              name="Medical History"
              options={{
                tabBarLabel: '',
                tabBarIcon: ({color, size, focused}) => (
                  <View
                    style={{
                      alignItems: 'center',
                      justifyContent: 'space-evenly',
                      minHeight: '100%',
                      width: '100%',
                      borderTopWidth: focused ? 1.5 : 0,
                      borderTopColor: Colors.blueTextColor,
                    }}>
                    <Image
                      style={{
                        width: 21,
                        height: 21,
                        marginTop: hp(1),
                      }}
                      source={
                        focused
                          ? images.medical_history_colored
                          : images.medical_history_grey
                      }
                    />
                    <Text
                      style={{
                        color: Colors.black,
                        fontSize: 10,
                        marginTop: hp(1),
                      }}>
                      Medical History
                    </Text>
                  </View>
                ),
                headerShown: false,
              }}
              component={MedicalHistoryStack}
            />
          ) :
           homeApiData?.blueButton?.featureEnabled === true ? (
            <Tab.Screen
              name="Medical History"
              options={{
                tabBarLabel: '',
                tabBarIcon: ({color, size, focused}) => (
                  <Pressable
                    onPress={() => {
                      clearStoreData();
                      storeItem(IsAcoUserLogin, 'false').then(login => {
                        console.log(login);
                      });
                      navigation.navigate('Medical History', {
                        screen: 'MainDashboard',
                        params: {
                          params: 0,
                        },
                      });
                    }}
                    style={{
                      alignItems: 'center',
                      justifyContent: 'space-evenly',
                      minHeight: '100%',
                      width: '100%',
                      borderTopWidth: focused ? 1.5 : 0,
                      borderTopColor: Colors.blueTextColor,
                    }}>
                    <Image
                      style={{
                        width: 21,
                        height: 21,
                        marginTop: hp(1),
                      }}
                      source={
                        focused
                          ? images.medical_history_colored
                          : images.medical_history_grey
                      }
                    />
                    <Text
                      style={{
                        color: Colors.black,
                        fontSize: 10,
                        marginTop: hp(1),
                      }}>
                      Medical History
                    </Text>
                  </Pressable>
                ),
                headerShown: false,
                tabBarStyle: {
                  display: modalHandlerReducer ? 'flex' : 'none',
                  height: 90,
                },
              }}
              component={MedicalHistoryStack}
              initialParams={userProfileData}
            />
          ) :
           null} */}

          <Tab.Screen
            name="Contacts"
            options={{
              tabBarLabel: '',
              tabBarIcon: ({color, size, focused}) => (
                <View
                  style={{
                    alignItems: 'center',
                    justifyContent: 'space-evenly',
                    minHeight: '100%',
                    width: '100%',
                    borderTopWidth: focused ? 1.5 : 0,
                    borderTopColor: Colors.blueTextColor,
                  }}>
                  <Image
                    style={{
                      width: 15,
                      height: 19,
                      marginTop: hp(1),
                    }}
                    source={
                      focused
                        ? images.contatcs_icon_colored
                        : images.contatcs_icon
                    }
                  />
                  <Text
                    style={{
                      color: Colors.black,
                      fontSize: 10,
                      marginTop: hp(1),
                    }}>
                    Contacts
                  </Text>
                </View>
              ),
              headerRight: () => (
                <HeaderRight name="Contacts" navigation={navigation} />
              ),
              headerLeft: () => (
                <HeaderLeft
                  image={userProfileData?.imagePath}
                  name="Home"
                  width={30}
                  height={30}
                  navigation={navigation}
                />
              ),
              headerStyle: {
                backgroundColor: Colors.BgColor,
              },
              headerShadowVisible: false,
              headerTitleAlign: 'center',
            }}
            component={ChatStack}
          />
          <Tab.Screen
            name="Profile"
            options={{
              tabBarLabel: '',
              tabBarIcon: ({color, size, focused}) => (
                <View
                  style={{
                    alignItems: 'center',
                    justifyContent: 'space-evenly',
                    minHeight: '100%',
                    width: '100%',
                    borderTopWidth: focused ? 1.5 : 0,
                    borderTopColor: Colors.blueTextColor,
                  }}>
                  <Image
                    style={{
                      width: 19,
                      height: 19,
                      marginTop: hp(1),
                    }}
                    resizeMode="contain"
                    source={
                      focused ? images.IconProfileBlue : images.IconProfileBlack
                    }
                  />
                  <Text
                    style={{
                      color: Colors.black,
                      fontSize: 10,
                      marginTop: hp(1),
                    }}>
                    Profile
                  </Text>
                </View>
              ),
              headerTitleStyle: {
                fontFamily: Fonts.SourceSansBold,
                fontSize: hp(2.5),
              },
              headerStyle: {
                backgroundColor: Colors.BgColor,
              },
              headerShadowVisible: false,
              headerTitleAlign: 'center',
            }}
            component={ProfileScreen}
          />
        </>
      ) : (
        <>
          <Tab.Screen
            name="Home"
            options={{
              tabBarLabel: '',
              tabBarIcon: ({color, size, focused}) => {
                return (
                  <View
                    style={{
                      alignItems: 'center',
                      justifyContent: 'space-evenly',
                      minHeight: '100%',
                      width: '100%',
                      borderTopWidth: focused ? 1.5 : 0,
                      borderTopColor: Colors.blueTextColor,
                    }}>
                    <Image
                      style={{
                        width: 18,
                        height: 18,
                        marginTop: hp(1),
                      }}
                      source={focused ? images.IconHomeBlue : images.IconHome}
                    />
                    <Text
                      style={{
                        color: Colors.black,
                        fontSize: 10,
                        marginTop: hp(1),
                      }}>
                      Home
                    </Text>
                  </View>
                );
              },
              headerShown: false,
              gestureEnabled: true,
              headerShadowVisible: false,
              headerTitle: '',
              tabBarStyle: {
                display: modalHandlerReducer ? 'flex' : 'none',
                height: 90,
              },
            }}
            component={HomeStack}
          />

          {/* {homeApiData?.blueButton?.featureEnabled === true && (
            <Tab.Screen
              name="Medical History"
              options={{
                tabBarLabel: '',
                tabBarIcon: ({color, size, focused}) => (
                  <Pressable
                    onPress={() => {
                      removeItemValue(BlueButtonAccessToken);
                      clearStoreData();
                      storeItem(IsAcoUserLogin, 'false').then(login => {});
                      navigation.navigate('Medical History', {
                        screen: 'MainDashboard',
                        params: {
                          params: 0,
                        },
                      });
                    }}
                    style={{
                      alignItems: 'center',
                      justifyContent: 'space-evenly',
                      minHeight: '100%',
                      width: '100%',
                      borderTopWidth: focused ? 1.5 : 0,
                      borderTopColor: Colors.blueTextColor,
                    }}>
                    <Image
                      style={{
                        width: 21,
                        height: 21,
                        marginTop: hp(1),
                      }}
                      source={
                        focused
                          ? images.medical_history_colored
                          : images.medical_history_grey
                      }
                    />
                    <Text
                      style={{
                        color: Colors.black,
                        fontSize: 10,
                        marginTop: hp(1),
                      }}>
                      Medical History
                    </Text>
                  </Pressable>
                ),
                headerShown: false,
                tabBarStyle: {
                  display: modalHandlerReducer ? 'flex' : 'none',
                  height: 90,
                },
              }}
              component={MedicalHistoryStack}
              initialParams={userProfileData}
            />
          )} */}

          <Tab.Screen
            name="Profile"
            options={{
              tabBarLabel: '',
              tabBarIcon: ({color, size, focused}) => (
                <View
                  style={{
                    alignItems: 'center',
                    justifyContent: 'space-evenly',
                    minHeight: '100%',
                    width: '100%',
                    borderTopWidth: focused ? 1.5 : 0,
                    borderTopColor: Colors.blueTextColor,
                  }}>
                  <Image
                    style={{
                      width: 19,
                      height: 19,
                      marginTop: hp(1),
                    }}
                    resizeMode="contain"
                    source={
                      focused ? images.IconProfileBlue : images.IconProfileBlack
                    }
                  />
                  <Text
                    style={{
                      color: Colors.black,
                      fontSize: 10,
                      marginTop: hp(1),
                    }}>
                    Profile
                  </Text>
                </View>
              ),
              headerTitleStyle: {
                fontFamily: Fonts.SourceSansBold,
                fontSize: hp(2.5),
              },
              headerStyle: {
                backgroundColor: Colors.BgColor,
              },
              headerShadowVisible: false,
              headerTitleAlign: 'center',
            }}
            component={ProfileScreen}
          />
        </>
      )}
    </Tab.Navigator>
  );
};
const mapStateToProps = ({
  homeApiData,
  userProfileData,
  modalHandlerReducer,
}) => ({
  homeApiData,
  userProfileData,
  modalHandlerReducer,
});

export default connect(mapStateToProps)(HomeTabNavigation);
