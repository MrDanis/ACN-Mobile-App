/* istanbul ignore file */
import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import CarePlan from '../../features/carePlan/CarePlan';
import Interventions from '../../features/carePlan/Interventions';

const Stack = createNativeStackNavigator();
const CaprePlanStack = () => {
  return (
    <Stack.Navigator screenOptions={{gestureEnabled: false}}>
      <Stack.Screen
        name="CarePlanStack"
        component={CarePlan}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="interventions"
        component={Interventions}
        options={{headerShown: false}}
      />
    </Stack.Navigator>
  );
};
export default CaprePlanStack;
