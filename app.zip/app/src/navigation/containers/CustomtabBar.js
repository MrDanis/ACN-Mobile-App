/* istanbul ignore file */
import React from 'react';
import {Text, View} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {createStackNavigator} from 'react-navigation-stack';
import {createMaterialTopTabNavigator} from 'react-navigation-tabs';
import Colors from '../../../config/Colors';
import ShareHistory from '../../features/bluebutton/screens/ShareHistory';

import {Fonts} from '../../../config/AppConfig';
import MedicationScreen from '../../features/bluebutton/screens/Medication/MedicationScreen';

const CustomTabNav = createMaterialTopTabNavigator(
  {
    Medicines: MedicationScreen,
    History: ShareHistory,
  },
  {
    navigationOptions: {
      tabBarVisible: false,
    },
    headerMode: 'none',
    tabBarPosition: 'top',
    swipeEnabled: true,
    animationEnabled: true,
    lazy: true,
    tabBarOptions: {
      activeTintColor: Colors.blueTextColor,
      inactiveTintColor: Colors.black3,
      style: {
        backgroundColor: Colors.white,
      },
      labelStyle: {
        textAlign: 'center',
      },
      indicatorStyle: {
        borderBottomColor: Colors.blueTextColor,
        borderBottomWidth: 3,
      },
    },
    defaultNavigationOptions: ({navigation}) => ({
      tabBarLabel: ({focused, tintColor}) => {
        const {routeName} = navigation.state;
        let label;
        switch (routeName) {
          case 'Medicines':
            return (
              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <Text
                  style={{
                    fontSize: hp(2),
                    fontFamily: Fonts.NunitoBold,
                    color: tintColor,
                    marginLeft: hp(1.5),
                  }}>
                  Medicines
                </Text>
              </View>
            );
          case 'History':
            return (
              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <Text
                  style={{
                    fontSize: hp(2),
                    fontFamily: Fonts.NunitoBold,
                    color: tintColor,
                    marginLeft: hp(1.5),
                  }}>
                  History
                </Text>
              </View>
            );
        }
        return label;
      },
    }),
  },
);
const Medicines = createStackNavigator(
  {
    Medicines: MedicationScreen,
  },
  {
    headerMode: 'none',
  },
);
const History = createStackNavigator(
  {
    History: ShareHistory,
  },
  {
    headerMode: 'none',
  },
);
const CustomTabNavigation = {
  CustomTabNav,
};

export default CustomTabNavigation;
