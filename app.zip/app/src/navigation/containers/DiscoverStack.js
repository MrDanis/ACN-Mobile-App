/* istanbul ignore file */

import React from 'react';
import ProfileScreen from '../../features/profile/screens/ProfileScreen';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import DiscoverMainScreen from '../../features/discover/screens/DiscoverMainScreen';

const Stack = createNativeStackNavigator();
const DiscoverStack = () => {
  return (
    <Stack.Navigator screenOptions={{gestureEnabled: false}}>
      <Stack.Screen
        name="Discover"
        component={DiscoverMainScreen}
        options={{headerShown: false}}
      />
    </Stack.Navigator>
  );
};
export default DiscoverStack;
