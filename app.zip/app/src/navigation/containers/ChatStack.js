/* istanbul ignore file */
import Contacts from '../../features/chat/screens/contacts';
/* istanbul ignore file */
import React from 'react';

import {createNativeStackNavigator} from '@react-navigation/native-stack';

const Stack = createNativeStackNavigator();
const ChatStack = () => {
  return (
    <Stack.Navigator screenOptions={{gestureEnabled: false}}>
      <Stack.Screen
        name="Contacts"
        component={Contacts}
        options={{
          headerShown: false,
        }}
      />
      {/* <Stack.Screen
        name="Video"
        component={VideoScreen}
        options={{
          headerShown: false,
        }}
      /> */}
    </Stack.Navigator>
  );
};
export default ChatStack;
