/* istanbul ignore file */
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import React from 'react';
import Colors from '../../../config/Colors';
import AllergiesScreen from '../../features/bluebutton/screens/AllergiesScreen';
import AppointmentScreen from '../../features/bluebutton/screens/AppointmentScreen';
import AuthenticationType from '../../features/bluebutton/screens/AuthenticationTypeACOLogin';
import CoverageScreen from '../../features/bluebutton/screens/CoverageScreen';
import DiseasesScreen from '../../features/bluebutton/screens/DiseasesScreen';
import HospitalVisits from '../../features/bluebutton/screens/HospitalVisits';
import MainDashboardScreen from '../../features/bluebutton/screens/MainDashboard';
import InteractionScreen from '../../features/bluebutton/screens/Medication/Interaction';
import InteractionDetailScreen from '../../features/bluebutton/screens/Medication/InteractionDetails';
import MedicationScreen from '../../features/bluebutton/screens/Medication/MedicationScreen';
import ProceduresScreen from '../../features/bluebutton/screens/ProceduresScreen';
import Providers from '../../features/bluebutton/screens/Providers';
import ShareHistory from '../../features/bluebutton/screens/ShareHistory';
import ProviderHistory from '../../features/bluebutton/screens/component/ProviderHistory';
import {connect, useDispatch} from 'react-redux';

const Stack = createNativeStackNavigator();

const MedicalHistoryStack = function ({userProfileData}) {
  console.log(
    'this is from med history stack ' + JSON.stringify(userProfileData),
  );
  return (
    <Stack.Navigator
      screenOptions={{gestureEnabled: false, headerShown: false}}
      initialRouteName={
        userProfileData?.isCM ? AuthenticationType : MainDashboardScreen
      }>
      <Stack.Screen
        name="AuthenticationType"
        component={AuthenticationType}
        options={{
          headerTitle: 'Authentication',
          headerStyle: {backgroundColor: Colors.BgColor},
        }}
      />
      <Stack.Screen
        name="MainDashboard"
        component={MainDashboardScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="Medication"
        component={MedicationScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="Diseases"
        component={DiseasesScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="AllergiesScreen"
        component={AllergiesScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="CoverageScreen"
        component={CoverageScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="ProviderScreen"
        component={Providers}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="Procedure"
        component={ProceduresScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="HospitalVisitScreen"
        component={HospitalVisits}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="ShareHistoryScreen"
        component={ShareHistory}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="AppointmentScreen"
        component={AppointmentScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="InteractionScreen"
        component={InteractionScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="InteractionDetailScreen"
        component={InteractionDetailScreen}
      />
      <Stack.Screen name="ProviderHistoryScreen" component={ProviderHistory} />
    </Stack.Navigator>
  );
};

const mapStateToProps = ({homeApiData, userProfileData}) => ({
  homeApiData,
  userProfileData,
});

export default connect(mapStateToProps)(MedicalHistoryStack);
