/* istanbul ignore file */
import React, {useEffect} from 'react';
import InputEmailScreen from '../../features/welcome/screens/InputEmailScreen';
import InputPhoneScreen from '../../features/welcome/screens/InputPhoneScreen';
import Login from '../../features/welcome/screens/LoginScreen';
import OTPScreen from '../../features/welcome/screens/OTPScreen';
import SplashScreen from '../../features/welcome/screens/SplashScreen';
import HomeTabNavigation from '../containers/HomeTabNavigation';

import IncomingVideoCallScreen from '../../features/telehealth/screens/IncomingVideoCallScreen';
import IncomingVideoCallScreenEMR from '../../features/telehealth/screens/IncomingVideoCallScreenEMR';
import ChatStack from '../containers/ChatStack';
import {
  NavigationContainer,
  createNavigationContainerRef,
} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {Colors, Svgs} from '../../../config';

import EditProfileScreen from '../../features/profile/screens/EditProfileScreen';
import NotificationStack from '../containers/NotificationStack';

import {
  Platform,
  TouchableOpacity,
  PermissionsAndroid,
  NativeModules,
} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {SvgCss} from 'react-native-svg';
import StepCounterScreen from '../../features/home/screens/components/activities_screen_components.js/step_counter_screen';
import DiscoverStack from '../containers/DiscoverStack';
import HomeStack from '../containers/HomeStack';

import HealthCategoriesEditValuesScreen from '../../features/home/screens/components/activities_screen_components.js/health_activities_edit_values';
import SleepCounterScreen from '../../features/home/screens/components/activities_screen_components.js/sleep_counter_screen';

import ChatScreen from '../../features/chat/screens/ChatScreen';
import HeartCounterScreen from '../../features/home/screens/components/activities_screen_components.js/heart_counter_screen';
import ViewReport from '../../features/lab/screens/ViewReport';
import PulseRateEditScreen from '../../features/mycare/components/Pulse_Rate_Edit_Screen';
import AssessmentSummary from '../../features/mycare/screens/assessment/AssessmentSummary';
import MedicationEssentialScreen from '../../features/wellness/screen/medication_essentials_screen';
import WellnessStack from '../containers/WellnessStack';
import messaging from '@react-native-firebase/messaging';
import Apps from '../../../../Apps';
import EmrStack from '../containers/EmrStack';
import RNNotificationCall from 'react-native-full-screen-notification-incoming-call';
import RNCallKeep from 'react-native-callkeep';
import careCoordinatorScreen from '../../features/chat/screens/careCoordinatorScreen';
import NewChatScreen from '../../features/home/screens/NewChatScreen';
const Stack = createNativeStackNavigator();
export const navigationRef = createNavigationContainerRef();
PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS);
export default function AppContainer() {
  const requestUserPermission = async () => {
    const authStatus = await messaging().requestPermission();
    const enabled =
      authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
      authStatus === messaging.AuthorizationStatus.PROVISIONAL;

    if (enabled) {
      console.log('Authorization status:', authStatus);
    }
  };

  useEffect(() => {
    requestUserPermission();
  }, []);
  return (
    <NavigationContainer ref={navigationRef}>
      <Stack.Navigator
        screenOptions={{
          gestureEnabled: Platform.OS === 'android' ? false : true,
          animation: 'fade',
        }}>
        <Stack.Screen
          name="AuthLoading"
          component={SplashScreen}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name="LoginScreen"
          component={Login}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name="MeetingWithCM"
          component={Apps}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name="EmailScreen"
          component={InputEmailScreen}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name="PhoneScreen"
          component={InputPhoneScreen}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name="OTP"
          component={OTPScreen}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name="HomeStack"
          component={HomeStack}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name="EmrSelection"
          component={EmrStack}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name="ViewReport"
          component={ViewReport}
          options={{headerShown: false}}
        />

        <Stack.Screen
          name="StepCounter"
          component={StepCounterScreen}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name="HeartCounter"
          component={HeartCounterScreen}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name="SleepCounter"
          component={SleepCounterScreen}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name="HealthCategoriesEditValuesScreen"
          options={{headerShown: false}}
          component={HealthCategoriesEditValuesScreen}
        />
        <Stack.Screen
          name="PulseRateEditScreen"
          options={{headerShown: false}}
          component={PulseRateEditScreen}
        />
        <Stack.Screen
          name="EditProfile"
          component={EditProfileScreen}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name="HomeTab"
          component={HomeTabNavigation}
          options={{headerShown: false, gestureEnabled: false}}
        />

        <Stack.Screen
          name="DiscoverScreen"
          component={DiscoverStack}
          options={{headerShown: false}}
        />
        <Stack.Screen name="ChatMain" component={ChatStack} />
        <Stack.Screen
          name="IncomingCallScreen"
          component={IncomingVideoCallScreen}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name="IncomingCallScreenEMR"
          component={IncomingVideoCallScreenEMR}
          options={{headerShown: false}}
        />
        {/* <Stack.Screen
          name="CallUI"
          component={TwilioCallScreen}
          options={{headerShown: false}}
        /> */}

        <Stack.Screen
          name="WellnessStack"
          component={WellnessStack}
          options={{headerShown: false}}
        />

        <Stack.Screen
          name="MedicationEssentialScreen"
          component={MedicationEssentialScreen}
          options={{
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="Chat"
          component={ChatScreen}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name="NotificationStack"
          component={NotificationStack}
          options={({navigation}) => ({
            headerShadowVisible: false,
            headerStyle: {backgroundColor: Colors.BgColor},
            title: 'Notifications',
            headerLeft: () => (
              <SvgCss
                xml={Svgs.arrowHeadLeft}
                width={hp(5)}
                height={hp(5)}
                fill={Colors.black}
                onPress={() => navigation.pop()}
              />
            ),
            headerRight: () => <TouchableOpacity></TouchableOpacity>,
            headerTitleAlign: 'center',
          })}
        />

        <Stack.Screen
          name="AssessmentSummary"
          component={AssessmentSummary}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name="NewChatScreen"
          component={NewChatScreen}
          options={{headerShown: false}}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
