export const HtmlElementRemover = (text) => {
    let incommingText = text; 
    let resultenText = incommingText.replace(/[^a-zA-Z'-]/g, '')//.replace(/<\/?[^>]*>/g, "").replace(/[<>]/g, ""); 
    console.log('Incomming text : ',incommingText,'Resulten text is : ',resultenText)
    return resultenText;
}