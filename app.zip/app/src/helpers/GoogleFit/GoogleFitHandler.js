/* istanbul ignore file */
import GoogleFit, {Scopes, BucketUnit} from 'react-native-google-fit';
import {Alert, Linking} from 'react-native';
//import AsyncStorage from '@react-native-async-storage/async-storage';
export const checkGoogleFitAppInstalled = async () => {
  return new Promise((resolve, reject) => {
    GoogleFit.isAvailable(res => {
      console.log('Response of the app is : ',res);
      if (res) {
        // startGoogleFit();
        res ? resolve(res) : reject(false);
      } else {
        showAlert();
      }
    });
  });
};
function showAlert() {
  Alert.alert(
    'GoogleFit',
    'Please Install GoogleFit From Play Store',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
      },
      // {
      //   text: 'Already Installed',
      //   onPress: () => startGoogleFit()//getTodaySteps(),//startGoogleFit(),
      // },
      {
        text: 'OK',
        onPress: () => {
          Linking.openURL(
            'https://play.google.com/store/apps/details?id=com.google.android.apps.fitness',
          ).catch(err => console.error('An error occurred', err));
        },
      },
    ],
    {cancelable: false},
  );
}

export function startGoogleFit() {
  const options = {
    scopes: [
      Scopes.FITNESS_ACTIVITY_READ_WRITE,
      Scopes.FITNESS_BODY_READ_WRITE,
    ],
  };
  console.log('options are taken');
  GoogleFit.authorize(options)
    .then(authResult => {
      if (authResult.success) {
      }
    })
    .catch(() => {
      console.log('AUTH_ERROR');
    });
}
const startDate = () => {
  const d = new Date();
  d.setDate(d.getDate() - 7);
  return d.toISOString();
};

const endDate = () => {
  const now = new Date();
  now.setMinutes(now.getMinutes() + 2);
  return now.toISOString();
};

export const checkIsAuthorized = async () => {
  return new Promise((resolve, reject) => {
    const opt = {
      unit: 'kg', // required; default 'kg'
      startDate: startDate(), // required
      endDate: endDate(), // required
      ascending: false, // optional; default false
    };
    GoogleFit.getWeightSamples(opt, (err, res) => {
      res ? resolve(res) : reject(false);
    });
  });
};
export const getTodaySteps = async () => {
  return new Promise((resolve, reject) => {
    const options = {
      scopes: [
        Scopes.FITNESS_ACTIVITY_READ,
        Scopes.FITNESS_ACTIVITY_WRITE,
        Scopes.FITNESS_BODY_READ,
        Scopes.FITNESS_BODY_WRITE,
        Scopes.FITNESS_BLOOD_PRESSURE_READ,
        Scopes.FITNESS_BLOOD_PRESSURE_WRITE,
        Scopes.FITNESS_BLOOD_GLUCOSE_READ,
        Scopes.FITNESS_BLOOD_GLUCOSE_WRITE,
        Scopes.FITNESS_HEART_RATE_WRITE,
        Scopes.FITNESS_HEART_RATE_READ,
        Scopes.FITNESS_BODY_READ,
      ],
    };
    GoogleFit.authorize(options)
      .then(authResult => {
        console.log('here it is authorize : ',authResult);
        if (authResult.success) {
          GoogleFit.getDailySteps(new Date().toISOString())
            .then(res => {
              if (res) {
                let distanceObjOptions = {
                  startDate: '2017-01-01T00:00:17.971Z', // required
                  endDate: new Date().toISOString(), // required
                  bucketUnit: BucketUnit.DAY, // optional - default "DAY". Valid values: "NANOSECOND" | "MICROSECOND" | "MILLISECOND" | "SECOND" | "MINUTE" | "HOUR" | "DAY"
                  bucketInterval: 1, // optional - default 1.
                };
                GoogleFit.getDailyDistanceSamples(distanceObjOptions)
                  .then(ress => {
                    res
                      ? resolve({res, auth: true, miles: ress})
                      : reject(false);
                  })
                  .catch(err => {
                    res ? resolve({res, auth: true}) : reject(false);
                  });
              } else {
                res ? resolve({res, auth: true}) : reject(false);
              }
            })
            .catch(err => {
              reject(false);
              console.log('Daily steps456 >>> ', err);
            });
        } else {
          console.log('AUTH_DENIED', authResult.message);
        }
      })
      .catch(() => {
        console.log('AUTH_ERROR');
      });
  });
};
export const getTodayActivities = async () => {
  return new Promise((resolve, reject) => {
    const options = {
      scopes: [
        Scopes.FITNESS_ACTIVITY_READ,
        Scopes.FITNESS_BODY_READ,
        Scopes.FITNESS_LOCATION_READ,
      ],
    };
    GoogleFit.authorize(options)
      .then(authResult => {
        if (authResult.success) {
          let opt = {
            startDate: startDate(), // required
            endDate: endDate(), // required
            bucketUnit: 'MINUTE', // optional - default "DAY". Valid values: "NANOSECOND" | "MICROSECOND" | "MILLISECOND" | "SECOND" | "MINUTE" | "HOUR" | "DAY"
            bucketInterval: 15, // optional - default 1.
          };

          GoogleFit.getActivitySamples(opt)
            .then(res => {
              res ? resolve(res) : reject(false);
            })
            .catch(err => {
              console.log('activity error');
              console.log(err);
            });
        } else {
          console.log('AUTH_DENIED', authResult.message);
        }
      })
      .catch(() => {
        console.log('AUTH_ERROR');
      });
  });
};

export const getWeightFromGoogleFit = async () => {
  return new Promise((resolve, reject) => {
    const options = {
      scopes: [Scopes.FITNESS_BODY_READ],
    };

    GoogleFit.authorize(options)
      .then(authResult => {
        if (authResult.success) {
          const opt = {
            unit: 'kg', // required; default 'kg'
            startDate: startDate(), // required
            endDate: endDate(), // required
            ascending: false, // optional; default false
          };
          GoogleFit.getWeightSamples(opt)
            .then(res => {
              if (res && res.length > 0) {
                resolve(res);
              } else {
                reject(false);
              }
            })
            .catch(error => {
              console.log('Error fetching weight  data:', error);
              reject(false);
            });
        } else {
          console.log('AUTH_DENIED', authResult.message);
          reject(false);
        }
      })
      .catch(error => {
        console.log('AUTH_ERROR', error);
        reject(false);
      });
  });
};
export const getBloodPressureFromGoogleFit = async () => {
  return new Promise((resolve, reject) => {
    const options = {
      scopes: [
        Scopes.FITNESS_BLOOD_PRESSURE_READ,
        Scopes.FITNESS_BLOOD_PRESSURE_WRITE,
        Scopes.FITNESS_BLOOD_GLUCOSE_READ,
        Scopes.FITNESS_BLOOD_GLUCOSE_WRITE,
        Scopes.FITNESS_HEART_RATE_WRITE,
      ],
    };
    GoogleFit.authorize(options)
      .then(authResult => {
        if (authResult.success) {
          const opt = {
            startDate: startDate(), // required
            endDate: endDate(), // required
          };
          GoogleFit.getBloodPressureSamples(opt)
            .then(res => {
              if (res && res.length > 0) {
                resolve(res);
              } else {
                console.log('No blood pressure data found.');
                reject(false);
              }
            })
            .catch(error => {
              console.log('Error fetching blood pressure data:', error);
              reject(false);
            });
        } else {
          console.log('AUTH_DENIED', authResult.message);
          reject(false);
        }
      })
      .catch(error => {
        console.log('AUTH_ERROR', error);
        reject(false);
      });
  });
};
export const getHeartRateFromGoogleFit = async () => {
  return new Promise((resolve, reject) => {
    const options = {
      scopes: [Scopes.FITNESS_ACTIVITY_READ, Scopes.FITNESS_HEART_RATE_READ],
    };
    GoogleFit.authorize(options)
      .then(authResult => {
        if (authResult.success) {
          const opt = {
            startDate: startDate(), // required
            endDate: endDate(), // required
          };
          GoogleFit.getHeartRateSamples(opt)
            .then(res => {
              if (res && res.length > 0) {
                resolve(res);
              } else {
                reject(false);
              }
            })
            .catch(error => {
              console.log('Error fetching heart rate data:', error);
              reject(false);
            });
        } else {
          console.log('AUTH_DENIED', authResult.message);
          reject(false);
        }
      })
      .catch(error => {
        console.log('AUTH_ERROR', error);
        reject(false);
      });
  });
};
export const getBloodGulocoseFromGoogleFit = async () => {
  return new Promise((resolve, reject) => {
    const options = {
      scopes: [
        Scopes.FITNESS_NUTRITION_READ_WRITE,
        Scopes.FITNESS_BODY_READ_WRITE,
        Scopes.FITNESS_BLOOD_GLUCOSE_READ_WRITE,
      ],
    };
    GoogleFit.authorize(options)
      .then(authResult => {
        if (authResult.success) {
          const opt = {
            startDate: startDate(), // required
            endDate: endDate(), // required
          };

          GoogleFit.getDailyNutritionSamples(opt, (err, res) => {
            res ? resolve(res) : reject(false);
          });
        } else {
          console.log('AUTH_DENIED', authResult.message);
        }
      })
      .catch(() => {
        console.log('AUTH_ERROR');
      });
  });
};
