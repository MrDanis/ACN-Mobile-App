/* istanbul ignore file */
import {AppState, Platform} from 'react-native';
import RNCallKeep from 'react-native-callkeep';
import {CallActionType} from '../Constants';
import {NavigationHelper} from '../NavigationHelper';
import {TwilioHelper} from '../Twilio/TwilioHelper';
import {CallAction} from '../signalR/SignalRService';

var number = '360 TeleWise™';

export var currentCallID: String = '';

export default function runCallKeep(data) {
  console.log('====================================');
  console.log('data under', data);
  console.log('====================================');
  const isIOS = Platform.OS === 'ios';
  RNCallKeep.setup({
    ios: {
      appName: '360PatientEngagement',
      imageName: '../../assets/images/IconTemplateImage.png',
      supportsVideo: true,
      maximumCallGroups: '1',
      maximumCallsPerCallGroup: '1',
      ringtoneSound: 'default',
    },
    android: {
      alertTitle: 'Permissions required',
      alertDescription: 'This application needs to access your phone accounts',
      cancelButton: 'Cancel',
      okButton: 'ok',
      // Required to get audio in background when using Android 11
      foregroundService: {
        channelId: 'com.wisemani.patientEngagement',
        channelName: 'Incomming Call',
        notificationTitle: 'Incomming Video call',
      },
    },
  });

  RNCallKeep.displayIncomingCall(
    data.call_id,
    data.caller_id,
    data.caller,
    'generic',
    true,
  );

  const answerCall = ({callUUID}) => {
    currentCallID = callUUID;
    console.log('answer call');
    if (isIOS) {
      global.isIncomingCall = true;
      let navigation = NavigationHelper.sharedInstance().navigation;
      console.log('====================================');
      console.log('navigation', navigation);
      console.log('====================================');

      setTimeout(function () {
        navigation.navigate('MeetingWithCM', {data: data});
      }, 300);
      // endCurrentCall();
    } else {
      if (
        AppState.currentState === 'background' ||
        AppState.currentState === 'active'
      ) {
        // wakeUpApp();
        NavigationHelper.sharedInstance().navigation.navigate(
          'IncomingCallScreen',
          {
            data: data,
          },
        );
      } else {
        global.isIncomingCall = true;
        // wakeUpApp();
      }
    }
  };

  const hangup = callUUID => {
    RNCallKeep.endAllCalls(callUUID);
  };

  const setOnHold = (callUUID, held) => {
    RNCallKeep.setOnHold(callUUID, held);
  };

  const setOnMute = (callUUID, muted) => {
    RNCallKeep.setMutedCall(callUUID, muted);
  };
  const updateDisplay = callUUID => {
    // Workaround because Android doesn't display well displayName, se we have to switch ...
    if (isIOS) {
      RNCallKeep.updateDisplay(callUUID, 'New Name', number);
    } else {
      RNCallKeep.updateDisplay(callUUID, number, 'New Name');
    }
  };
  RNCallKeep.addEventListener('answerCall', answerCall);

  RNCallKeep.addEventListener('endCall', jsonBody => {
    let {callUUID} = jsonBody;
    hangup(callUUID);
    // CallAction(CallActionType.reject);
  });
  RNCallKeep.addEventListener('didPerformSetMutedCallAction', jsonBody => {
    let {callUUID} = jsonBody;
    let {muted} = jsonBody;
    TwilioHelper.sharedInstance().didPerformSetMuted(muted);
  });
}

//To report the call in callkit when call is answered from In-App incoming call screen.
export function answerIncomingIOSCall(callID: string) {
  currentCallID = callID;
  RNCallKeep.startCall(callID, number, '', 'generic', true);
}

export function setMutedCurrentCall(muted: Boolean) {
  RNCallKeep.setMutedCall(currentCallID, muted);
}
export function endCurrentCall() {
  RNCallKeep.endAllCalls();
}

export function displayIncomingCallNow({
  callUUID,
  handle,
  localizedCallerName,
}) {
  console.log('====================================');
  console.log('data in display', callUUID, handle, localizedCallerName);
  console.log('====================================');
  TwilioHelper.sharedInstance().currentRoom = handle;
  TwilioHelper.sharedInstance().callerName = localizedCallerName;
  currentCallID = callUUID;
  const callId = callUUID;
  const name = handle;
  const localCallerName = localizedCallerName;

  RNCallKeep.displayIncomingCall(
    callId,
    name,
    localCallerName,
    'generic',
    true,
  );

  // RNCallKeep.endAllCalls();
}
