/* istanbul ignore file */
import {AppState, Platform} from 'react-native';
import {NavigationHelper} from '../NavigationHelper';
import {CallAction} from '../signalR/SignalRService';
import runCallKeep from '../CallKeep/CallKeepHelper';
import RNCallKeep from 'react-native-callkeep';
export const CallStatus = {
  CONNECTING: 1,
  CONNECTED: 2,
  DISCONNECTED: 3,
  INCOMING: 4,
};

export class TwilioHelper {
  constructor() {}
  // Variables
  currentCallStatus = CallStatus.DISCONNECTED;
  currentCallDuration = 0;
  participantStatus = false;
  currentRoom = '';
  // Added to join call from appointments module
  currentAppointmentID = '0';
  callerName = '';
  callerId = '';
  callUUID = '';
  isMicEnabled = true;
  isLocalVideoEnabled = true;
  participants = new Map();
  videoTracks = new Map();
  isSpeakerEnabled = true;
  timer = null;
  timerCallBack = null;
  callEndedFromCallKitCallBack = null;
  callEndedFromSignalRCallBack = null;
  mutedSetFromCallKitCallBack = null;
  speakerSetBackgroundCallBack = null;
  autoEndTimer = null;
  token = '';
  // Singleton Class
  static _instance = null;
  static sharedInstance() {
    if (this._instance === null) {
      this._instance = new TwilioHelper();
    }
    return this._instance;
  }

  reset = () => {
    this.stopCallTimer();
    TwilioHelper._instance = null;
  };
  handleVOIPIncomingPush = notificationPayload => {
    // console.log('Push Received for the background', notificationPayload);
    // console.log('Current Call Apt ID', this.currentAppointmentID);
    console.log('Notification JSON : ', notificationPayload); 
    // let jsonOfNotification = notificationPayload?.data?.PayLoad;
    // if (Platform.OS === 'ios' && AppState.currentState === 'active') {
    //   let temData = {
    //     asc_token: jsonOfNotification?.AcccessToken,
    //     caller: jsonOfNotification?.CallerrName,
    //     room: jsonOfNotification?.RoomId,
    //     caller_id: jsonOfNotification?.CallerId,
    //     call_id: notificationPayload?.data?.CallId,
    //     time: notificationPayload?.data?.TimeStamp,
    //   };
    //   NavigationHelper.sharedInstance().navigation.navigate(
    //     'IncomingCallScreen',
    //     {
    //       data: temData,
    //     },
    //   );
    // } else {
    //   console.log(
    //     'Android Notificaion is : ',
    //     JSON.parse(notificationPayload?.data?.payLoad).PayLoad,
    //   );
    //   let androidNotificationJson = JSON.parse(
    //     notificationPayload?.data?.payLoad,
    //   ).PayLoad;
    //   let temData = {
    //     asc_token: androidNotificationJson.AcccessToken,
    //     caller: androidNotificationJson?.CallerrName,
    //     room: androidNotificationJson?.RoomId,
    //     caller_id: androidNotificationJson?.CallerId,
    //     apt_id: androidNotificationJson?.AppointmentId,
    //   };
    //   NavigationHelper.sharedInstance().navigation.navigate(
    //     'IncomingCallScreen',
    //     {
    //       data: temData,
    //     },
    //   );
    // }
  };
}
