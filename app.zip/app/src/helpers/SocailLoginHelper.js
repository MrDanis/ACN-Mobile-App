import {
  GoogleSignin,
  statusCodes,
} from '@react-native-google-signin/google-signin';
import { LoginMethod, retrieveItem } from './LocalStorage';
// import {
//   AccessToken,
//   GraphRequest,
//   GraphRequestManager,
//   LoginManager,
// } from 'react-native-fbsdk-next';

export async function loginWithGoogle() {
  await GoogleSignin.hasPlayServices();

  console.log('reached google sign in');
  return new Promise((resolve, reject) => {
    try {
      GoogleSignin.configure({
        webClientId:
          '726634767999-33eg7ichbi76s40da30ia1cun283sc3r.apps.googleusercontent.com',
        offlineAccess: true,
        forceCodeForRefreshToken: true,
        forceConsentPrompt: true,
      });
      const userInfo = GoogleSignin.signIn();
      console.log(userInfo);
      userInfo ? resolve(userInfo) : reject(false);
    } catch (error) {
      if (error.code === statusCodes.SIGN_IN_CANCELLED) {
        // user cancelled the login flow
      } else if (error.code === statusCodes.IN_PROGRESS) {
        // operation (e.g. sign in) is in progress already
      } else if (error.code === statusCodes.PLAY_SERVICES_NOT_AVAILABLE) {
        // play services not available or outdated
      } else {
        // some other error happened
        console.log(error);
      }
    }
  });
}
// export function getInfoFromToken(token) {
//   return new Promise((resolve, reject) => {
//     const PROFILE_REQUEST_PARAMS = {
//       fields: {
//         string: 'id,name,first_name,last_name,email,birthday,about',
//       },
//     };
//     const profileRequest = new GraphRequest(
//       '/me',
//       {token, parameters: PROFILE_REQUEST_PARAMS},
//       (error, user) => {
//         if (error) {
//           console.log('login info has error: ' + error);
//         } else {
//           user ? resolve(user) : reject(false);
//         }
//       },
//     );
//     new GraphRequestManager().addRequest(profileRequest).start();
//   });
// }
// export function loginWithFacebookID() {
//   return new Promise((resolve, reject) => {
//     LoginManager.logInWithPermissions(['public_profile', 'email']).then(
//       login => {
//         if (login.isCancelled) {
//         } else {
//           AccessToken.getCurrentAccessToken().then(data => {
//             const accessToken = data.accessToken.toString();
//             console.log(accessToken);
//             accessToken ? resolve(accessToken) : reject(false);
//             // getInfoFromToken(accessToken).then(user => {
//             //   user ? resolve(user) : reject(false);
//             // });
//           });
//         }
//       },
//       error => {
//         console.log('Login fail with error: ' + error);
//       },
//     );
//   });
//   // Attempt a login using the Facebook login dialog asking for default permissions.
// }
export const signOut = async () => {
  try {
    const isGoogleSignedIn = await retrieveItem(LoginMethod);

    console.log('isGoogleSignedIn   ' + isGoogleSignedIn);
    if (isGoogleSignedIn === 'Google') {
      console.log('User is signed in via Google. Proceeding to sign out.');
      await GoogleSignin.revokeAccess();
      await GoogleSignin.signOut();
      console.log('Google sign-out successful');
    } else {
      console.log(
        'User is not signed in with Google. Skipping Google sign-out.',
      );
    }
  } catch (error) {
    console.log('google error', error);
    // console.error(error);
  }
};
// export const FBLogout = accessToken => {
//   AccessToken.getCurrentAccessToken().then(data => {
//     const accessToken = data.accessToken.toString();
//     let logout = new GraphRequest(
//       'me/permissions/',
//       {
//         accessToken: accessToken,
//         httpMethod: 'DELETE',
//       },
//       (error, result) => {
//         if (error) {
//           console.log('Error fetching data: ' + error.toString());
//         } else {
//           console.log('logout successfully');
//           LoginManager.logOut();
//         }
//       },
//     );
//     new GraphRequestManager().addRequest(logout).start();
//   });
// };
