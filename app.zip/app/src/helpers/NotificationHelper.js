/* istanbul ignore file */
import messaging from '@react-native-firebase/messaging';
import {Alert} from 'react-native';
import {source} from '../api/constants';
import FCMTokenService from '../api/notification';
import {HandleNotification} from './NotificationHandler';
import { TokenType } from '../api/NetworkHelper';
var myRef = null;
export const checkPermission = async ref => {
  myRef = ref;

  const enabled = await messaging().hasPermission();
  console.log('Here in the notification permission : ',enabled);
  if (enabled) {
   let fcmIOSToken =  getFcmToken();
   console.log('FCM Token is : ',fcmIOSToken);
  } else {
    requestPermission();
  }
};

export const getFcmToken = async () => {
  const fcmToken = await messaging().getToken();
  console.log('token from the firebase for IOS : ',fcmToken);
  if (fcmToken) {
    console.log('IOSSSSSS : ',fcmToken)
    sendFCMTokenIOS(fcmToken);
    return fcmToken;
  } else {
    showAlert('Failed', 'No token received');
  }
};

const sendFCMTokenIOS = async(token)=>{
  console.log('Token before sending to the backend : ',token);
  savePushTokenOnServer(token,2);
}


const requestPermission = async () => {
  try {
    await messaging().requestPermission();
    // User has authorised
  } catch (error) {
    // User has rejected permissions
  }
};

export const messageListener = async () => {
  const notification = messaging.notifications();
  this.notificationOnNotification = messaging()
    .notifications()
    .onNotification(async notification => {
      // HandleNotification(notification, myRef);
    });

  this.notificationOpenedListener = messaging().onNotificationOpenedApp(
    async notificationOpen => {
      const {data} = notificationOpen.notification;
      const {type} = data;
    },
  );

  const notificationOpen = await messaging().getInitialNotification();
  if (notificationOpen) {
    const {data} = notificationOpen.notification;
    const {type} = data;
  }
  this.onMessageListener = messaging().onMessage(async remoteMessage => {
    setTimeout(function () {
      HandleNotification(remoteMessage, myRef);
    }, 1000);
  });

  messaging().setBackgroundMessageHandler(async remoteMessage => {});
};

const showAlert = (title, message) => {
  Alert.alert(
    title,
    message,
    [{text: 'OK', onPress: () => console.log('OK Pressed')}],
    {cancelable: false},
  );
};

export function savePushTokenOnServer(token, type) {
  // 0 for Android, 1 for iOS
  // let source = Platform.OS === 'ios' ? 1 : 0;
  let data = JSON.stringify({
    token: token,
    source: source,
    type: type,
  });
  console.log('Data before posting the FCM token : ',data);
  FCMTokenService.postFCMToken(data)
    .then(response => {
      console.log('====================================');
      console.log('response', response);
      console.log('====================================');
      let responseData = JSON.parse(JSON.stringify(response));
      if (responseData) {
        console.log('FCM token is successfully save to backend : ',token);
      }
    })
    .catch(error => {
      console.log('token error');
    });
}
