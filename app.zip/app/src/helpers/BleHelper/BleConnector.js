import {NativeEventEmitter, NativeModules} from 'react-native';
import BleManager from 'react-native-ble-manager';
import ConnectivityManager from 'react-native-connectivity-status';

export default function BleConnector() {
  const BleManagerModule = NativeModules.BleManager;
  const bleManagerEmitter = new NativeEventEmitter(BleManagerModule);
  // Permission Check
  isBTConnected().then(status => {
    if (status) {
      if (Platform.OS === 'ios') {
        // BLuetooth ON, iOS

        startBle();
      } else {
        // Bluetooth ON, Android
        checkBTPermissionsOnAndroid();
      }
    } else if (Platform.OS === 'ios') {
      // Bluetooth OFF, iOS
      st();
    } else {
      // Bluetooth OFF, Android
      this.enableBluetoothOnAndroid();
      this.startBTStatusListener();
    }
  });

  function checkBTPermissionsOnAndroid() {
    requestBluetoothPermission().then(statuses => {
      if (statuses.bluetoothPermission === 'granted') {
        this._startManager();
      } else {
        checkBluetoothPermission();
      }
    });
  }

  function startBle() {
    BleManager.start({showAlert: false});
    bleManagerEmitter.addListener(
      'BleManagerDiscoverPeripheral',
      peripheral => {},
    );
  }

  BleManager.scan([], 5, true)
    .then(() => {})
    .catch(error => {});

  async function isBTConnected() {
    let isBluetoothEnabled = await ConnectivityManager.isBluetoothEnabled();
    return isBluetoothEnabled;
  }
}
