export default function useBle() {
  const BloodPressureMeasurementCharacteristicUUID =
    '00002a23-0000-1000-8000-00805f9b34fb';
  const PulseCharacteristicUUID = '7274782e-6a69-7561-6e2e-504f56313100';
  const BloodPressureServiceUUID = '0000180a-0000-1000-8000-00805f9b34fb';
  const PulseServiceUUID = '636f6d2e-6a69-7561-6e2e-504f56313100';
  const QnScaleServiceUUID = '0000ffe0-0000-1000-8000-00805f9b34fb';
  const BpDeviceId = '1208F9D3-530B-2783-9C9B-ABE39434B9C9';
  const scanAndConnect = async (manager, setDeviceName) => {
    manager.startDeviceScan(null, null, (error, device) => {
      if (error) {
        return;
      }
      if (device.name === 'aaa') {
        manager.stopDeviceScan();
        setDeviceName(device.name);
        device
          .connect()
          .then(device => {
            return device.discoverAllServicesAndCharacteristics();
          })
          .then(device => {
            device.isConnected().then(data => {});

            // Enable notifications or indications

            device.services().then(services => {
              services[0]
                .readCharacteristic(BloodPressureMeasurementCharacteristicUUID)
                .then(data => {});

              services[0].characteristics().then(characteristics => {
                device
                  .readCharacteristicForService(
                    characteristics[0].serviceUUID,
                    characteristics[0].uuid,
                  )
                  .then(characteristic => {
                    // Handle successful characteristic read
                  })
                  .catch(error => {
                    // Handle error: log the specific error message or take appropriate action
                  });
              }); // Array of Characteristic objects
            });

            setInterval(() => {
              device
                .readCharacteristicForService(
                  BloodPressureServiceUUID,
                  BloodPressureMeasurementCharacteristicUUID,
                )
                .then(readData => {
                  const originalString = atob(readData.value);
                })
                .catch(error => {
                  console.log('====================================');
                  console.log('error in reading data', error);
                  console.log('====================================');
                });
              device.isConnected().then(data => {});
            }, 3000);
            // Do work on device with services and characteristics
          })
          .catch(error => {
            // Handle errors
          });

        // Proceed with connection.
      }
    });
  };
  return {
    scanAndConnect,
  };
}
