import AsyncStorage from '@react-native-async-storage/async-storage';
import PushNotificationIOS from '@react-native-community/push-notification-ios';
import {Alert, AppState, Platform, NativeModules} from 'react-native';
import {showMessage} from 'react-native-flash-message';
import {PERMISSIONS, RESULTS, check, request} from 'react-native-permissions';
import PushNotification, {Importance} from 'react-native-push-notification';
import {Colors} from '../../config';
import MedicationService from '../api/medication';
import * as Constants from './Constants';
import {getTodayMedicationData} from './NotificationApis';
import {TwilioHelper} from './Twilio/TwilioHelper';
import Tts from 'react-native-tts';
var myRef = null;
const {AlarmPermissionModule} = NativeModules;

createChannel(
  Constants.NOTIFICATION_MED_REMINDER_CHANNEL_ID,
  Constants.NOTIFICATION_MED_REMINDER_CHANNEL_NAME,
  Constants.NOTIFICATION_REMINDER_SOUND_NAME,
);
export async function HandleNotification(notification, ref) {
  myRef = ref;
  showNotification(notification);
}
function showNotification(notification) {
  console.log('12112121212121212121    : ', notification);
  const {data} = notification;
  const {body} = notification;
  let type = JSON.parse(notification?.data?.payLoad)?.NotificationType;
  let callData = JSON.parse(notification?.data?.payLoad).PayLoad;
  console.log('Type of the notification is : ', type);
  switch (type) {
    case Constants.NotificationType.chatMessage:
      showPatientInAppNotification(notification);
      break;
    case Constants.NotificationType.CallInitiated:
      if (Platform.OS !== 'ios') {
        let {data} = notification;
        TwilioHelper.sharedInstance().handleVOIPIncomingPush(data, true);
      }
      break;
    case 1:
      console.log('Notification payload for the call : ', callData);
      TwilioHelper.sharedInstance().handleVOIPIncomingPush(notification, true);
      break;
    case 2:
      console.log('Notification payload from the EMR is : ', callData);
      PushNotification.localNotification({
        title: 'EMR notification',
        message: notification.message,
      });
      break;
    default:
      showDefaultPushNotification(notification);
      // let title = `${notification.data.name} • (${notification.data.dose})`;
      // let reminderMessage = `Quantity: ${notification.data.qty} • ${
      //   notification.data.meal ? 'After Meal' : 'Before Meal'
      // }`;
      // scheduleLocalNotification(title, reminderMessage, notification.data);
      // fireLocalNotificationNow(title, reminderMessage);
      break;
  }
}

export function setNavigation(nav) {
  navigation = nav;
}

export function createChannel(channelID, channelName, soundName) {
  PushNotification.createChannel(
    {
      channelId: channelID,
      channelName: channelName, // (required)
      importance: Importance.HIGH,
      vibrate: true,
    },
    created => console.log(`createChannel ${channelID} returned '${created}'`), // (optional) callback returns whether the channel was created, false means it already existed.
  );
  if (Platform.OS === 'ios') {
    PushNotificationIOS.setNotificationCategories([
      {
        id: 'userAction',
        actions: [
          {
            id: 'Taken',
            title: 'TAKEN',
            options: {foreground: true, destructive: false},
          },
          {
            id: 'Missed',
            title: 'MISSED',
            options: {foreground: true, destructive: false},
          },
        ],
      },
    ]);
  }
}

export async function showDefaultPushNotification(remoteMessage) {
  const {notification} = remoteMessage;
  console.log('Here in the default notification call is : ', remoteMessag);
  // Create the notification channel first
  PushNotification.createChannel(
    {
      channelId: 'GENERAL_NOTIF_CHANNEL_ID1', // (required)
      channelName: 'Default channel', // (required)
      channelDescription: 'A default channel', // (optional) default: undefined.
      soundName: 'default', // (optional) See `soundName` parameter of `localNotification`
      importance: 4, // (optional) default: 4. Int value of the Android notification importance
      vibrate: true, // (optional) default: true. Creates the default vibration pattern if true.
    },
    created => {
      console.log(
        `createChannel 'GENERAL_NOTIF_CHANNEL_ID1' returned '${created}'`,
      );

      // Trigger the local notification after the channel is created
      PushNotification.localNotification({
        /* Android Only Properties */
        channelId: 'GENERAL_NOTIF_CHANNEL_ID1', // (required) channelId, if the channel doesn't exist, it will be created with options passed above
        smallIcon: 'icon_tp', // (optional) default: "ic_notification" with fallback for "ic_launcher"
        color: Colors.colorPrimary, // (optional) default: system default
        vibrate: true, // (optional) default: true
        vibration: 300, // vibration length in milliseconds
        priority: 'high', // (optional) set notification priority, default: high
        visibility: 'private', // (optional) set notification visibility, default: private
        ignoreInForeground: false, // (optional) if true, the notification will not be visible when the app is in the foreground
        autoCancel: true, // (optional) default: true
        alertAction: 'view', // (optional) default: view
        category: '', // (optional) default: empty string
        title: 'This is the test message', // Title of the notification
        message: 'This is the test body', // Body of the notification
        playSound: true, // (optional) default: true
        soundName: 'medicationmessage.mp3', // (optional) Sound to play when the notification is shown
        number: 10, // (optional) Valid 32-bit integer specified as string
      });
    },
    created => {
      console.log(`createChannel 'default-channel-id' returned '${created}'`), // (optional) callback returns whether the channel was created, false means it already existed.
        PushNotification.localNotification({
          /* Android Only Properties */
          channelId: 'GENERAL_NOTIF_CHANNEL_ID1', // (required) channelId, if the channel doesn't exist, it will be created with options passed above (importance, vibration, sound). Once the channel is created, the channel will not be update. Make sure your channelId is different if you change these options. If you have created a custom channel, it will apply options of the channel.
          smallIcon: 'icon_tp', // (optional) default: "ic_notification" with fallback for "ic_launcher". Use "" for default small icon.
          color: Colors.colorPrimary, // (optional) default: system default
          vibrate: true, // (optional) default: true
          vibration: 300, // vibration length in milliseconds, ignored if vibrate=false, default: 1000
          priority: 'high', // (optional) set notification priority, default: high
          visibility: 'private', // (optional) set notification visibility, default: private
          ignoreInForeground: false, // (optional) if true, the notification will not be visible when the app is in the foreground (useful for parity with how iOS notifications appear)
          autoCancel: true, // (optional) default: true
          /* iOS only properties */
          alertAction: 'view', // (optional) default: view
          category: '', // (optional) default: empty string
          userInfo: remoteMessage.data,

          /* iOS and Android properties */
          title: notification.title, // (optional)
          message: notification.body, // (required)
          data: remoteMessage.data,
          playSound: true, // (optional) default: true
          soundName: 'medicationmessage.mp3', // (optional) Sound to play when the notification is shown. Value of 'default' plays the default sound. It can be set to a custom sound such as 'android.resource://com.xyz/raw/my_sound'. It will look for the 'my_sound' audio file in 'res/raw' directory and play it. default: 'default' (default sound is played)
          number: 10, // (optional) Valid 32 bit integer specified as string. default: none (Cannot be zero)
        });
    },
  );
  PushNotification.localNotification({
    /* Android Only Properties */
    channelId: 'GENERAL_NOTIF_CHANNEL_ID1', // (required) channelId, if the channel doesn't exist, it will be created with options passed above (importance, vibration, sound). Once the channel is created, the channel will not be update. Make sure your channelId is different if you change these options. If you have created a custom channel, it will apply options of the channel.
    smallIcon: 'icon_tp', // (optional) default: "ic_notification" with fallback for "ic_launcher". Use "" for default small icon.
    color: Colors.colorPrimary, // (optional) default: system default
    vibrate: true, // (optional) default: true
    vibration: 300, // vibration length in milliseconds, ignored if vibrate=false, default: 1000
    priority: 'high', // (optional) set notification priority, default: high
    visibility: 'private', // (optional) set notification visibility, default: private
    ignoreInForeground: false, // (optional) if true, the notification will not be visible when the app is in the foreground (useful for parity with how iOS notifications appear)
    autoCancel: true, // (optional) default: true
    /* iOS only properties */
    alertAction: 'view', // (optional) default: view
    category: '', // (optional) default: empty string
    userInfo: remoteMessage.data,

    /* iOS and Android properties */
    title: notification.title, // (optional)
    message: notification.body, // (required)
    data: remoteMessage.data,
    playSound: true, // (optional) default: true
    soundName: 'medicationmessage.mp3', // (optional) Sound to play when the notification is shown. Value of 'default' plays the default sound. It can be set to a custom sound such as 'android.resource://com.xyz/raw/my_sound'. It will look for the 'my_sound' audio file in 'res/raw' directory and play it. default: 'default' (default sound is played)
    number: 10, // (optional) Valid 32 bit integer specified as string. default: none (Cannot be zero)
  });
}
// export async function showDefaultPushNotification(remoteMessage) {
//   const {notification} = remoteMessage;
//   PushNotification.createChannel(
//     {
//       channelId: 'GENERAL_NOTIF_CHANNEL_ID1', // (required)
//       channelName: 'Default channel', // (required)
//       channelDescription: 'A default channel', // (optional) default: undefined.
//       soundName: 'default', // (optional) See `soundName` parameter of `localNotification` function
//       importance: 4, // (optional) default: 4. Int value of the Android notification importance
//       vibrate: true, // (optional) default: true. Creates the default vibration patten if true.
//     },
//     created =>
//       console.log(`createChannel 'default-channel-id' returned '${created}'`), // (optional) callback returns whether the channel was created, false means it already existed.
//     PushNotification.localNotification({
//       /* Android Only Properties */
//       channelId: 'GENERAL_NOTIF_CHANNEL_ID1', // (required) channelId, if the channel doesn't exist, it will be created with options passed above (importance, vibration, sound). Once the channel is created, the channel will not be update. Make sure your channelId is different if you change these options. If you have created a custom channel, it will apply options of the channel.
//       smallIcon: 'icon_tp', // (optional) default: "ic_notification" with fallback for "ic_launcher". Use "" for default small icon.
//       color: Colors.colorPrimary, // (optional) default: system default
//       vibrate: true, // (optional) default: true
//       vibration: 300, // vibration length in milliseconds, ignored if vibrate=false, default: 1000
//       priority: 'high', // (optional) set notification priority, default: high
//       visibility: 'private', // (optional) set notification visibility, default: private
//       ignoreInForeground: false, // (optional) if true, the notification will not be visible when the app is in the foreground (useful for parity with how iOS notifications appear)
//       autoCancel: true, // (optional) default: true
//       alertAction: 'view', // (optional) default: view
//       category: '', // (optional) default: empty string
//       title:'This is the test message',
//       message:'This is the test body',
//       /* iOS only properties */
//       //  userInfo: remoteMessage.data,
//       /* iOS and Android properties */
//       //  title: notification.title, // (optional)
//       //  message: notification.body, // (required)
//       // data: remoteMessage.data,
//       playSound: true, // (optional) default: true
//       soundName: 'default', // (optional) Sound to play when the notification is shown. Value of 'default' plays the default sound. It can be set to a custom sound such as 'android.resource://com.xyz/raw/my_sound'. It will look for the 'my_sound' audio file in 'res/raw' directory and play it. default: 'default' (default sound is played)
//       number: 10, // (optional) Valid 32 bit integer specified as string. default: none (Cannot be zero)
//     })
//   );
// }

export async function fireLocalNotificationNow(
  title: string = title,
  body: string = body,
  data: NotificationSchedule,
) {
  PushNotification.localNotification({
    /* Android Only Properties */
    channelId: Constants.NOTIFICATION_DEFAULT_CHANNEL_ID, // (required) channelId, if the channel doesn't exist, it will be created with options passed above (importance, vibration, sound). Once the channel is created, the channel will not be update. Make sure your channelId is different if you change these options. If you have created a custom channel, it will apply options of the channel.
    smallIcon: 'icon_tp', // (optional) default: "ic_notification" with fallback for "ic_launcher". Use "" for default small icon.
    color: 'blue', // (optional) default: system default
    vibrate: true, // (optional) default: true
    vibration: 300, // vibration length in milliseconds, ignored if vibrate=false, default: 1000
    priority: 'high', // (optional) set notification priority, default: high
    visibility: 'private', // (optional) set notification visibility, default: private
    ignoreInForeground: false, // (optional) if true, the notification will not be visible when the app is in the foreground (useful for parity with how iOS notifications appear)
    autoCancel: true, // (optional) default: true
    /* iOS only properties */
    // id: data.id,
    alertAction: 'view', // (optional) default: view
    category: '', // (optional) default: empty string
    userInfo: data,

    /* iOS and Android properties */
    title: title, // (optional)
    message: body, // (required)
    data: data,
    // playSound: true, // (optional) default: true
    // soundName: Constants.NOTIFICATION_REMINDER_SOUND_NAME,
    // number: 10, // (optional) Valid 32 bit integer specified as string. default: none (Cannot be zero)
  });
}

export function scheduleLocalNotification(
  title = 'Medicine Reminder',
  message,
  data,
) {
  let notification = createNotificationObject(title, message, data);
  let quantityTaken = data.meal === '1' ? ' Before Meal' : ' After Meal';
  let voiceMessage =
    'Medicine Reminder. Please take ' +
    data.name.toLowerCase() +
    quantityTaken +
    ' of Quantity ' +
    data.dose;
  if (Platform.OS === 'ios') {
    // PushNotificationIOS.addNotificationRequest(notification);
    // PushNotificationIOS.addNotificationRequest({
    //   id: notification.id,
    //   title: title,
    //   body: message,
    //   // sound: Constants.NOTIFICATION_REMINDER_SOUND_NAME_WAV,
    //   badge: 0,
    //   // category: 'userAction',
    //   userInfo: {id: data.id, meal: data.meal, time: data.time},
    // });
    // Tts.setDucking(true);
    // Tts.setDefaultPitch(1);
    // Tts.setDefaultRate(1, true);
    // Tts.speak(voiceMessage, {
    //   androidParams: {
    //     KEY_PARAM_PAN: -1,
    //     KEY_PARAM_VOLUME: 1,
    //     KEY_PARAM_STREAM: 'STREAM_NOTIFICATION',
    //   },
    // });
  } else {
    PushNotification.localNotificationSchedule(notification);
    Tts.setDucking(true);
    Tts.setDefaultPitch(1);
    Tts.setDefaultRate(1, true);
    Tts.speak(voiceMessage, {
      androidParams: {
        KEY_PARAM_PAN: -1,
        KEY_PARAM_VOLUME: 1,
        KEY_PARAM_STREAM: 'STREAM_NOTIFICATION',
      },
    });
  }
}

function createNotificationObject(title, message, data) {
  return {
    /* Android Only Properties */
    channelId: Constants.NOTIFICATION_MED_REMINDER_CHANNEL_ID, // (required) channelId, if the channel doesn't exist, it will be created with options passed above (importance, vibration, sound). Once the channel is created, the channel will not be update. Make sure your channelId is different if you change these options. If you have created a custom channel, it will apply options of the channel.
    smallIcon: 'icon_tp', // (optional) default: "ic_notification" with fallback for "ic_launcher". Use "" for default small icon.
    color: 'blue', // (optional) default: system default
    vibrate: true, // (optional) default: true
    vibration: 300, // vibration length in milliseconds, ignored if vibrate=false, default: 1000
    priority: 'high', // (optional) set notification priority, default: high
    visibility: 'private', // (optional) set notification visibility, default: private
    ignoreInForeground: false, // (optional) if true, the notification will not be visible when the app is in the foreground (useful for parity with how iOS notifications appear)
    autoCancel: true, // (optional) default: true
    id: data.id,
    subText: 'Medicine Reminder',
    tag: data.tag,
    alertAction: 'view', // (optional) default: view
    actions: ['Taken', 'Missed'],
    invokeApp: false,
    category: 'userAction', // (optional) default: empty string
    title: title,
    message: message,
    alertTitle: title, // For iOS
    alertBody: message, // For iOS
    data: data,
    userInfo: data,
    date: new Date(Date.now()),
    // playSound: false,
    // soundName: Constants.NOTIFICATION_REMINDER_SOUND_NAME,
    number: 0,
    /* iOS only properties */
    subtitle: 'Medicine Reminder',
    body: message,
    // sound: Constants.NOTIFICATION_REMINDER_SOUND_NAME_WAV, // iOS
    badge: 0,
  };
}
export function cancelLocalNotificationWithTag(tag: string) {
  PushNotification.cancelLocalNotifications({tag: tag});
}
function handleButtonAction(NotificationData) {
  if (NotificationData && NotificationData.action === 'Taken') {
    var data = {};
    data.id = parseInt(NotificationData.data.id);
    data.taken = true;
    data.mealStatus = NotificationData.data.meal === '1' ? true : false;
    data.doseTime = NotificationData.data.time;
    MedicationService.UpdateTakenMedication(data)
      .then(response => {
        getTodayMedicationData();
      })
      .catch(error => {
        console.log(error);
      });
  } else if (NotificationData && NotificationData.action === 'Missed') {
    var data = {};
    data.id = parseInt(NotificationData.data.id);
    data.taken = false;
    data.mealStatus = NotificationData.data.meal === '1' ? true : false;
    data.doseTime = NotificationData.data.time;
    MedicationService.UpdateTakenMedication(data)
      .then(response => {
        getTodayMedicationData();
      })
      .catch(error => {
        console.log(error);
      });
  }
}
export const scheduleNotificationx = async (
  timeToRemindMins,
  medication,
  incomingTime,
  clearData,
  Refresh,
) => {
  console.log(incomingTime, 'This is incoming time');
  console.log('local notif fired', timeToRemindMins * 60 * 1000);
  console.log(
    'local notif fired3',
    new Date(Date.now() + timeToRemindMins * 60 * 1000) - new Date(),
  );

  // check that if the reminder exist with same time or not
  const remDetails = await AsyncStorage.getItem('reminderDetails');
  let genericText = false;
  // Check if there are any reminders stored and parse them into an array
  if (remDetails) {
    const reminders = JSON.parse(remDetails);

    console.log('Time to take the medication is: ', reminders, incomingTime);

    // Loop through the reminders to check if the time matches the incoming time
    for (let i = 0; i < reminders.length; i++) {
      // Compare the time in the reminder with the incoming time
      if (reminders[i].time === incomingTime) {
        // Cancel the notification if the time matches
        PushNotification.cancelLocalNotification({
          id: reminders[i].id.toString(),
        });
        genericText = true;
        console.log('Notification cancelled for reminder id:', reminders[i].id);
      }
    }
  }

  // if not then proceed
  // else first cancel the previous reminder then proceed

  if (Platform.OS === 'android') {
    const permissionResult = await requestNotificationPermission();

    switch (permissionResult) {
      case RESULTS.UNAVAILABLE:
        console.log('Notification feature is not available on this device.');
        clearData();
        return;

      case RESULTS.DENIED:
        console.log('Notification permission denied, but requestable.');
        Alert.alert(
          'Permission Required',
          'Notification permission is required to set reminders. Please enable it in the settings and set the reminder again.',
        );
        clearData();
        return;

      case RESULTS.BLOCKED:
        console.log(
          'Notification permission is blocked. Cannot be requested again.',
        );
        Alert.alert(
          'Permission Blocked',
          'Notification permission has been permanently blocked. Please enable it from settings.',
        );
        clearData();
        return;

      case RESULTS.GRANTED:
        console.log('Notification permission granted!');
        break;

      default:
        console.log('Unknown permission result.');
        clearData();
        return;
    }
  }

  if (
    !(
      medication?.fdaMedicine?.proprietaryname === undefined ||
      medication?.fdaMedicine?.proprietaryname === null
    )
  ) {
    setTimeout(() => {
      Tts.speak(
        genericText
          ? 'Please take your medicines'
          : `It's Time to take ${medication?.fdaMedicine?.proprietaryname}`,
      );
    }, new Date(Date.now() + timeToRemindMins * 60 * 1000) - new Date());
    try {
      PushNotification.localNotificationSchedule({
        channelId: Constants.NOTIFICATION_MED_REMINDER_CHANNEL_ID,
        id: medication?.fdaMedicine?.productid,
        message: genericText
          ? 'Please take your medicines'
          : `It's Time to take ${medication?.fdaMedicine?.proprietaryname}`, // Message to be displayed
        date: new Date(Date.now() + timeToRemindMins * 60 * 1000), // * 1000 = 1second
        repeatType: 'day',
        repeatTime: 1,
        playSound: true,
        soundName: 'medicationmessage.mp3',
        userInfo: {screen: 'Medications', data: 0},
      });
      let reminderIds = await AsyncStorage.getItem('reminderIds');
      reminderIds = reminderIds ? JSON.parse(reminderIds) : [];
      reminderIds.push(medication?.fdaMedicine?.productid);
      await AsyncStorage.setItem('reminderIds', JSON.stringify(reminderIds));
      let reminderDetails = await AsyncStorage.getItem('reminderDetails');
      reminderDetails = reminderDetails ? JSON.parse(reminderDetails) : [];

      reminderDetails.push({
        id: medication?.fdaMedicine?.productid,
        time: incomingTime,
      });
      await AsyncStorage.setItem(
        'reminderDetails',
        JSON.stringify(reminderDetails),
      );
      Refresh();
      clearData();
    } catch (error) {
      console.log(
        'An error occurred while trying to schedule the reminder',
        error,
      );
    }
  } else if (
    medication?.fdaMedicine?.proprietaryname === undefined ||
    medication?.fdaMedicine?.proprietaryname === null
  ) {
    showMessage({
      message: 'Error',
      description: 'Unexpected Error Occured.Please try again.',
      type: 'default',
      icon: {icon: 'info', position: 'left'},
      backgroundColor: Colors.red,
    });
    clearData();
  }
};
export async function cancelReminder(
  notificationId,
  refresh,
  swiperCloser,
  index,
) {
  // Cancel the notification with the given ID
  console.log(
    'this is the notification id inside cancel reminder ' + notificationId,
  );

  const localnotifications = await AsyncStorage.getItem('reminderDetails');
  let parseArray = JSON.parse(localnotifications);
  console.log(parseArray, 'for test local data', notificationId);

  let arr = []; // Declare the array outside of the loop for access after

  for (let i in parseArray) {
    if (parseArray[i].id === notificationId) {
      let time = parseArray[i].time;

      // Loop through the array to find all matching times
      for (let j in parseArray) {
        if (parseArray[j].time === time) {
          arr.push(parseArray[j]);
        }
      }

      // Exit the loop once the matching notificationId is found
      break;
    }
  }

  console.log('Grouped notifications with the same time:', arr);

  if (arr.length > 1) {
    // Find the notification to be removed
    const filternotification = arr.filter(item => item.id === notificationId);

    // Check if the item to remove exists
    if (filternotification.length > 0) {
      // Remove the item from the array
      const updatedArray = parseArray.filter(
        item => item.id !== notificationId,
      );

      // Update AsyncStorage with the new array (without the removed item)
      await AsyncStorage.setItem(
        'reminderDetails',
        JSON.stringify(updatedArray),
      );

      console.log(
        'Updated reminder details without the notification:',
        updatedArray,
      );
      let reminderIds = await AsyncStorage.getItem('reminderIds');
      reminderIds = reminderIds ? JSON.parse(reminderIds) : [];
      reminderIds = reminderIds.filter(id => id !== notificationId);
      await AsyncStorage.setItem('reminderIds', JSON.stringify(reminderIds));
      // Optionally, show a message to the user
      showMessage({
        message: 'Reminder Cancelled',
        description: 'The reminder has been successfully cancelled.',
        type: 'default',
        icon: {icon: 'info', position: 'left'},
        backgroundColor: Colors.green,
      });
      refresh();
      swiperCloser(index);
    }
    return;
  }

  const updatedArray = parseArray.filter(item => item.id !== notificationId);
  await AsyncStorage.setItem('reminderDetails', JSON.stringify(updatedArray));

  PushNotification.cancelLocalNotification({id: notificationId.toString()});
  let reminderIds = await AsyncStorage.getItem('reminderIds');
  reminderIds = reminderIds ? JSON.parse(reminderIds) : [];
  reminderIds = reminderIds.filter(id => id !== notificationId);
  await AsyncStorage.setItem('reminderIds', JSON.stringify(reminderIds));
  // Optionally, show a message to the user
  showMessage({
    message: 'Reminder Cancelled',
    description: 'The reminder has been successfully cancelled.',
    type: 'default',
    icon: {icon: 'info', position: 'left'},
    backgroundColor: Colors.green,
  });
  refresh();
  swiperCloser(index);
}
export async function isReminderSet(medicationId) {
  let reminderIds = await AsyncStorage.getItem('reminderIds');
  reminderIds = reminderIds ? JSON.parse(reminderIds) : [];
  console.log(
    reminderIds,
    'reminder check ran',
    medicationId,
    reminderIds.includes(medicationId),
  );

  return reminderIds.includes(medicationId);
}
export function configurePushNotification(ref) {
  myRef = ref;
  PushNotification.configure({
    // (required) Called when a remote or local notification is opened or received
    onRegister: token => {
      console.log('Device registered for notifications:', token);
    },
    onNotification: notification => {
      console.log(
        AppState.currentState,
        'Remote Notification REceived:',
        notification,
      );
      // console.log(
      //   JSON.parse(notification?.data?.payLoad)?.NotificationType,
      //   'App state when the background notification is received : ',
      //   AppState.currentState,
      // );
      console.log('here in receiving the notification : ', notification);
      if (AppState.currentState === 'active') {
        HandleNotification(notification);
      }
      if (AppState.currentState === 'background') {
        HandleNotification(notification);
      }
      if (notification.userInteraction) {
        console.log('User Interaction', notification);
        handleButtonAction(notification);
      }
    },
    onAction: NotificationData => {
      handleButtonAction(NotificationData);
    },

    // IOS ONLY (optional): default: all - Permissions to register.
    permissions: {
      alert: true,
      badge: true,
      sound: true,
    },

    // Should the initial notification be popped automatically
    // default: true
    popInitialNotification: true,

    /**
     * (optional) default: true
     * - Specified if permissions (ios) and token (android and ios) will requested or not,
     * - if not, you must call PushNotificationsHandler.requestPermissions() later
     */
    requestPermissions: true,
  });
}
export const requestNotificationPermission = async () => {
  let permissionResult;

  if (Platform.OS === 'ios') {
    permissionResult = await check(PERMISSIONS.IOS.NOTIFICATIONS);
    if (permissionResult !== RESULTS.GRANTED) {
      permissionResult = await request(PERMISSIONS.IOS.NOTIFICATIONS);
    }
  } else if (Platform.OS === 'android') {
    permissionResult = await check(PERMISSIONS.ANDROID.POST_NOTIFICATIONS);
    if (permissionResult !== RESULTS.GRANTED) {
      permissionResult = await request(PERMISSIONS.ANDROID.POST_NOTIFICATIONS);
    }
  }
  console.log('thos is tje permission', permissionResult);
  return permissionResult;
};

class NotificationSchedule {
  id: string;
  fireDate: string;
  repeatInterval: string; // month, week, day, hour, minute, time
  endDate: string;
  tag: string;
}
