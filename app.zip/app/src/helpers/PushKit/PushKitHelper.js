/* istanbul ignore file */
import {DeviceEventEmitter} from 'react-native';
import VoipPushNotification from 'react-native-voip-push-notification';
import {TwilioHelper} from '../Twilio/TwilioHelper';

export var voipPushToken = '';
export default function startPushKit() {
  VoipPushNotification.addEventListener('register', token => {
    // send token to your apn provider server
    console.log('VoIP token', token);
    voipPushToken = token;
  });

  DeviceEventEmitter.addListener(
    'RNVoipPushNotificationRemoteNotificationsRegisteredEvent',
    data => {
      const voipToken = data.voipToken;
      console.log('====================================');
      console.log('voipToken last', data.voipToken);
      console.log('====================================');

      // Handle the registered VoIP token here
    },
  );
  // ...// Remove event listeners and clean up when necessary
  DeviceEventEmitter.removeAllListeners(
    'RNVoipPushNotificationRemoteNotificationsRegisteredEvent',
  );
  VoipPushNotification.addEventListener('notification', notification => {
    // register your VoIP client, show local notification, etc.
    // e.g.
    console.log('====================================');
    console.log('voip notification', notification);
    console.log('====================================');

    TwilioHelper.sharedInstance().handleVOIPIncomingPush(notification);

    /* there is a boolean constant exported by this module called
     *
     * wakeupByPush
     *
     * you can use this constant to distinguish the app is launched
     * by VoIP push notification or not
     *
     * e.g.
     */
    if (VoipPushNotification.wakeupByPush) {
      // do something...

      // remember to set this static variable to false
      // since the constant are exported only at initialization time
      // and it will keep the same in the whole app
      VoipPushNotification.wakeupByPush = true;
    }
  });
  VoipPushNotification.registerVoipToken(); // --- required
}
