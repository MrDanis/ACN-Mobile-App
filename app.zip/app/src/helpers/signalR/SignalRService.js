//import liraries
import * as signalR from '@microsoft/signalr';
import moment from 'moment';
import {StyleSheet} from 'react-native';
import {
  getCMCallStatus,
  getCMStatus,
  getHistoryData,
  getUnreadMessagesData,
  newMsg,
  sendMessage,
} from '../../features/chat/actions';
import {setCallIncomming} from '../../features/telehealth/actions';
import {SignalREvents, SignalRMethods, parserType} from '../Constants';
import {TwilioHelper} from '../Twilio/TwilioHelper';
import EventEmitter from 'eventemitter3';
var connectionHub = null;
var myData = null;
export const eventEmitter = new EventEmitter();
// create a component userProfileData, userSignature, props)
export const startSignalR = (
  homaApiData,
  userProfileData,
  userSignature,
  props,
) => {
  const myProps = props;
  myData = homaApiData;
  console.log(userSignature, 'srar', props);
  connectionHub = new signalR.HubConnectionBuilder()
    // .withUrl(
    // 'https://www.wmi360.com/360CommunicationKitChat/chathub',
    .withUrl(
      'https://pre-release.wmi360.com/360CommunicationKitchat/chathub',

      {
        skipNegotiation: true,
        transport: signalR.HttpTransportType.WebSockets,
      },
    )
    .configureLogging(signalR.LogLevel.Debug)
    .withAutomaticReconnect()
    .build();
  connectionHub.serverTimeoutInMilliseconds = 100000;

  // --------------------------------- INITIALIZING ----------------------------- //
  connectionHub
    .start()
    .then(() => {
      console.log(
        'this is the connection id of signal r *********************** ',
        connectionHub,
        connectionHub.baseUrl,
      );
      updateUserConnection(homaApiData, connectionHub.connectionId);
      getUserRecentChats(userSignature, userProfileData.phone, 0);
    })
    .catch(err => {
      console.log('connection error here' + err);
    });

  // ---------------------------------------------------------------------------- //
  // ---------------------------- SIGNAL - R EVENTS ----------------------------- //
  connectionHub.on(
    SignalREvents.CHAT_MESSAGE_RECEIVED,
    (argOne, argTwo, argThree, argFour) => {
      console.log('message recieveing from signalr', argOne);
      myProps.dispatch(newMsg(argOne));

      if (myProps !== null && argOne !== undefined) {
        const mData = {};

        mData.id = argOne.id; //careid
        mData.senderId = argOne.senderId; //pat or careid
        mData.receiverId = argOne.receiverId; //pat or careid
        mData.isRead = argOne.isRead; //
        mData.messageType = argOne.messageType;

        mData.message =
          argOne.messageType === 6
            ? jsonParser(1, argOne.message)
            : argOne.message;
        mData.signatureStampVn =
          argOne.messageType === 6 ? jsonParser(2, argOne.message) : null;
        mData.timeStamp = argOne.timeStamp;
        mData.messageSenderName = argOne.senderUserName;
        mData.showTime = argOne.showTime; //
        myProps.dispatch(sendMessage(mData));
      }
      if (
        myProps !== null &&
        argOne !== undefined &&
        argOne?.message === 'Call cancelled' &&
        argOne?.type === 6
      ) {
        myProps.dispatch(setCallIncomming(Math.random()));
      }
      // myProps.dispatch(sendMessage(argOne));
    },
  );
  connectionHub.on(SignalREvents.updateMessageReadStatus, argOne => {
    console.log('message ticks update recieved from signalr', argOne);
    eventEmitter.emit('messageReadStatusUpdate', argOne);
  });

  connectionHub.on(SignalREvents.CM_CALL_END, (argOne, argTwo) => {
    let endCallReturn = {
      roomId: argOne,
      isCallEndedbeforeJoining: true,
    };
    console.log('cm call end status ', endCallReturn);
    if (myProps !== null && argOne !== undefined) {
      console.log(
        'Here in dispatching the action for call end from the CM before joining from the patient end : ',
        myProps,
      );
      myProps.dispatch(getCMCallStatus(endCallReturn));
    }
  });

  connectionHub?.on(
    SignalREvents.CHAT_HISTORY,
    (argOne, argTwo, argThree, argFour) => {
      console.log('Received history in the chat channel is this', argOne);
      const updatedVnHistoryData = argOne.map((item, index) => {
        console.log(index, 'item on parser', item);
        if (item.messageType === 6) {
          return {
            ...item,
            message: jsonParser(parserType.message, item.message),
            signatureStampVn: jsonParser(parserType.signature, item.message),
          };
        } else {
          return item;
        }
      });
      console.log('data after going through parser', updatedVnHistoryData);

      myProps.dispatch(getHistoryData(updatedVnHistoryData));
    },
  );
  connectionHub?.on('UserRecentChats', argOne => {
    console.log('Received unread count from singnal e', argOne);

    myProps.dispatch(getUnreadMessagesData(argOne));
  });
  connectionHub.on(
    SignalREvents.CM_STATUS_UPDATED,
    (argOne, argTwo, argThree, argFour) => {
      //Here I could response by calling something else on the server...
      if (myProps !== null && argOne !== undefined) {
        myProps.dispatch(getCMStatus({argOne, argTwo}));
      }
    },
  );
};
// --------------------- ------------------------------------------------------- //
// ---------------------------- SIGNAL R - ACTIONS ----------------------------- //
export function sendMessagetoCM(
  data,
  userProfileData,
  receiverId,
  appointmentID,
  message,
  messageType,
) {
  let tempProps = {data, receiverId, appointmentID, message};
  const sendMsgObj = {
    SenderName: userProfileData?.fullName,
    ReceiverName: data?.slectedCmName, //data?.careManagerName,
    SenderId: data?.senderId, //`PAT_${data?.patientId.toString()}_${data?.acoKey.toString()}`,
    ReceiverId: receiverId,
    Message: message, // sending voice url here
    MessageType: messageType, // 3 for voice note message
    ApplicationSource: 2,
  };
  console.log('messenger sending object', sendMsgObj);
  connectionHub
    .invoke(SignalRMethods.chat, sendMsgObj)
    .then(directResponse => {});
  // getUserRecentChats(data?.senderId, userProfileData.phone, 0);

  console.log('message sent successfully');
}
export function CallAction(action) {
  connectionHub
    .invoke(
      SignalRMethods.callAction,
      TwilioHelper.sharedInstance().callerId.toString(),
      myData.common.patientId.toString(),
      parseInt(myData.common.acoKey),
      action,
    )
    .then(directResponse => {});
}
//GetChatHistory(data, receiverId)
export function GetChatHistory(senderId, receiverId) {
  const sendMsgObj = {
    SenderId: senderId,
    ReceiverId: receiverId,
  };
  console.log('getting chat history form sendMsgObjsignalr', sendMsgObj);
  connectionHub?.invoke('getChatHistory', sendMsgObj);
}

export function updateUserConnection(data, connectionId) {
  const updateObj = {
    ConnectionId: connectionId,
    ConnectedTime: moment(new Date()).toISOString(),
    ChatUserId: `PAT_${data?.common?.patientId}_${data?.common?.acoKey}`,
    ApplicationSource: 2,
  };
  connectionHub
    .invoke(SignalRMethods.updateUserConnection, updateObj)
    .then(directResponse => {});
}
//sending online status updates
let onlineStatusInterval;

export function updateUserChatStatus(patientId, status) {
  console.log('sending online status update', patientId, status);
  if (onlineStatusInterval) {
    clearInterval(onlineStatusInterval);
  }
  onlineStatusInterval = setInterval(() => {
    // console.log('this is the check for online status', typeof patientId);
    connectionHub.invoke(
      SignalREvents.PATIENT_STATUS_UPDATE,
      patientId,
      status,
    );
  }, 5000);
}
export function stopUserChatStatus() {
  console.log('inside stopUserChatStatus', onlineStatusInterval);
  if (onlineStatusInterval) {
    try {
      clearInterval(onlineStatusInterval);
    } catch (error) {
      console.log('stoping erroe', error);
    }
    onlineStatusInterval = null; // Reset the variable
    console.log('Stopped the online status interval');
  }
}
export function getUserRecentChats(patientId, UserPhoneNo, AppSource) {
  //unread chats
  connectionHub.invoke(
    SignalREvents.getRecentChats,
    patientId,
    UserPhoneNo,
    AppSource,
  );
}
function jsonParser(type, value) {
  const extractedJson = JSON.parse(value);
  if (type === 1) {
    return extractedJson.filePath;
  } else if (type === 2) {
    return extractedJson.signatureStampVn;
  }
}
export function getUserUnreadChatsCounts(ReceiverId) {
  //unread chats
  connectionHub.invoke(SignalREvents.getUserUnreadCount, ReceiverId);
}
export function updateReadStatus(messageIds, userId) {
  //unread chats
  console.log(
    'invoking update message read status with this payload',
    messageIds,
    userId,
  );
  connectionHub.invoke(
    SignalREvents.updateMessageReadStatus,
    messageIds,
    userId,
  );
}
// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#2c3e50',
  },
});
