import messaging from '@react-native-firebase/messaging';
import {AppRegistry,AppState} from 'react-native';
import App from '../../../App';
import RNNotificationCall from 'react-native-full-screen-notification-incoming-call';
import { NavigationHelper } from './NavigationHelper';
// import wakeUpApp from 'react-native-wakeup-screen';
// import RNCallKeep from 'react-native-callkeep';
// import {TwilioHelper} from './Twilio/TwilioHelper';

// Register background handler

messaging().setBackgroundMessageHandler(async remoteMessage => {
  //   // handle your message
  let {data} = remoteMessage;
  console.log('Message recieve in the background is : ',remoteMessage);
  let type = JSON.parse(data?.payLoad)?.NotificationType;
  console.log('type is : ',type);
  if((AppState.currentState === 'background') && (type === 1))
    {
      let jsonOfNotification = JSON.parse(data?.payLoad);
      let teamData =  {
        asc_token : jsonOfNotification?.PayLoad.AcccessToken,
        caller:jsonOfNotification?.PayLoad?.CallerrName,
        room:jsonOfNotification?.PayLoad?.RoomId,
        caller_id:jsonOfNotification?.PayLoad?.CallerId,
        apt_id:jsonOfNotification?.PayLoad?.AppointmentId,
        call_id:jsonOfNotification?.CallId,
        time:jsonOfNotification?.TimeStamp,
      }
      console.log('Data payload for the call  is : ',teamData);
      RNNotificationCall.displayNotification(
        '22221a97-8eb4-4ac2-b2cf-0a3c0b9100ad',
        null,
        30000,
        {
          channelId: 'com.abc.incomingcall',
          channelName: teamData.caller,
          notificationIcon: 'ic_launcher', //mipmap
          notificationTitle: teamData.caller,
          notificationBody: 'Incoming video call',
          answerText: 'Answer',
          declineText: 'Decline',
          notificationColor: 'colorAccent',
          isVideo:true,
          notificationSound: null, //raw
          mainComponent:'BackgroundCall',//AppRegistry.registerComponent('MyReactNativeApp', () => CustomIncomingCall);
          payload:teamData
        }
      );
    }
  // wakeUpApp();
  //RNCallKeep.backToForeground();
  //TwilioHelper.sharedInstance().handleVOIPIncomingPush(data, true);

  //return Promise.resolve();
});

AppRegistry.registerComponent('app', () => App);
