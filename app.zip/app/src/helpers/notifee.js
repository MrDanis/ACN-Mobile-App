import notifee, {TimeUnit, TriggerType} from '@notifee/react-native';

export async function scheduleDailyNotification() {
  // Create the trigger for the notification
  const date = new Date(Date.now());
  date.setHours(16, 30, 0, 0); // Schedule for 9 AM daily

  // Create notification trigger
  const trigger = {
    type: TriggerType.TIMESTAMP,
    timestamp: date.getTime(), // Trigger time
    repeatFrequency: TimeUnit.DAILY, // Repeat daily
  };

  // Display the notification
  await notifee.createTriggerNotification(
    {
      title: 'Medicine Reminder',
      body: 'This is your daily notification!',
      android: {
        channelId: 'daily-reminder',
      },
    },
    trigger,
  );
}
