import React, {useEffect, useState} from 'react';
import {
  Alert,
  Linking,
  Pressable,
  SafeAreaView,
  ScrollView,
  Share,
  Text,
  View,
  Image
} from 'react-native';

import {showMessage} from 'react-native-flash-message';
// import LocalAuth from 'react-native-local-auth';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {connect, useSelector} from 'react-redux';
// import LocalAuthentication from 'rn-local-authentication';
import ToggleSwitch from 'toggle-switch-react-native';
import {Colors} from '../../../../config';
import {CURRENT_TARGET, Fonts} from '../../../../config/AppConfig';
import colors from '../../../../config/Colors';
import images from '../../../../config/Images';
import ProfileService from '../../../api/profile';
import {requestAndHandleBiometricPermission} from '../../../helpers/Common';
import {
  BlueButtonAccessToken,
  BlueButtonRefreshToken,
  LoginMethod,
  removeItemValue,
  retrieveValue,
  storeItem,
  storeValue,
} from '../../../helpers/LocalStorage';
import {signOut} from '../../../helpers/SocailLoginHelper';
import {
  getAllergiesHistory,
  getCoverageHistory,
  getDiseasesHistory,
  getHospitalVisitHistory,
  getMedicationHistory,
  getProceduresHistory,
  getProviderHistory,
} from '../../bluebutton/action';

import {getHomeApiData} from '../../home/action';
import MainHeader from '../../mycare/components/MainHeader';
import {stopUserChatStatus} from '../../../helpers/signalR/SignalRService';
import { TouchableOpacity } from 'react-native-gesture-handler';

const SettingScreen = props => {
  const [imageObject, setImageObject] = useState(null);
  const [authToggler, setAuthToggler] = useState(false);
  const userProfileData = useSelector(state => state.userProfileData);
  const userCommonData = useSelector(state => state.homeApiData);

  useEffect(() => {
    console.log('Common data is : ', userCommonData?.common?.environmentURL);
    retrieveValue('isAuthEnabled')
      .then(res => {
        setAuthToggler(JSON.parse(res));
      })
      .catch(err => {
        console.log('error', err);
      });
    if (
      userProfileData.imagePath !== null &&
      userProfileData.imagePath !== ''
    ) {
      let imageData = {};
      imageData.uri = CURRENT_TARGET + '/' + userProfileData.imagePath;
      setImageObject(imageData);
    }
  }, []);

  const clearStoreData = () => {
    props.dispatch(getMedicationHistory([]));
    props.dispatch(getProviderHistory([]));
    props.dispatch(getHospitalVisitHistory([]));
    props.dispatch(getDiseasesHistory([]));
    props.dispatch(getCoverageHistory([]));
    props.dispatch(getAllergiesHistory([]));
    props.dispatch(getProceduresHistory([]));
    props.dispatch(getHomeApiData({}));
  };
  // stable
  const getAvailableAuthMethods = newValue => {
    FingerprintScanner.isSensorAvailable()
      .then(res => {
        console.log('this is the availiability for auth', res);
        if (Platform.OS === 'ios') {
          console.log('reached ios');
          LocalAuthentication.authenticateAsync({
            reason: 'Please, authenticate!',
            fallbackEnabled: true,
            fallbackTitle: 'Use PassCode',
            fallbackToPinCodeAction: false,
          }).then(response => {
            if (response.success) {
              console.log('success ios', response);
              if (newValue === true) {
                setAuthToggler(true);
                storeValue('isAuthEnabled', 'true');
              } else {
                setAuthToggler(newValue);
                storeValue('isAuthEnabled', 'false');
              }
            } else {
              console.log('Something went wrong');
            }
          });
        } else if (Platform.OS === 'android') {
          console.log('reached android');
          LocalAuth.authenticate({
            reason: 'Please Authenticate yourself',
            fallbackToPasscode: true, // fallback to passcode on cancel
            suppressEnterPassword: true, // disallow Enter Password fallback
          })
            .then(success => {
              console.log('success android', success);
              if (newValue === true) {
                setAuthToggler(true);
                storeValue('isAuthEnabled', 'true');
              } else {
                setAuthToggler(newValue);
                storeValue('isAuthEnabled', 'false');
              }
            })
            .catch(error => {
              console.log('error', error);
            });
        }
      })
      .catch(err => {
        console.log('error from availiability for auth', err);
        err = String(err);
        const parts = err.split(':');
        if (parts[0].trim() === 'FingerprintScannerNotEnrolled') {
          console.log('error trimed', parts[0].trim());
          showMessage({
            message: 'Info',
            description: 'No Biometrics enrolled',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        } else if (parts[0].trim() === 'FingerprintScannerNotAvailable') {
          console.log('FingerprintScannerNotAvailable');
          requestAndHandleBiometricPermission()
            .then(res => {
              console.log('res', res);
            })
            .catch(err => {
              console.log('err', err);
            });
        }
      });
  };
  const onShare = async () => {
    let appLink =
      Platform.OS === 'ios'
        ? 'https://testflight.apple.com/join/ldWlg3fY'
        : 'https://play.google.com';
    try {
      const optionMessage =
        Platform.OS === 'ios'
          ? 'Please install 360 Patient Engagement application for your care'
          : 'Please install 360 Patient Engagement application for your care ' +
            '\n' +
            appLink;
      const result = await Share.share({
        title: 'App link',
        message: optionMessage,
        url: appLink,
      });
      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with activity type of result.activityType
        } else {
          // shared
        }
      } else if (result.action === Share.dismissedAction) {
        // dismissed
      }
    } catch (error) {
      alert(error.message);
    }
  };

  return (
    <>
      <SafeAreaView style={{flex: 0, backgroundColor: colors.BgColor}} />
      <MainHeader
        name={'Settings'}
        navigation={props.navigation}
        notifDisabled={true}>
        <View
          style={{
            backgroundColor: colors.white,
            marginTop: hp(3.5),
            flex: 1,
            borderTopRightRadius: 24,
            borderTopLeftRadius: 24,
            shadowOffset: {width: 0.5, height: 0.5},
            shadowOpacity: 0.1,
            shadowRadius: 24,
            elevation: 3,
          }}>
          <ScrollView
            contentContainerStyle={{
              flex: 1,
              width: '100%',
              alignItems: 'center',
            }}>
            {/* EMR selection (START) */}
             {/* <Pressable
              onPress={() =>
                props.navigation.navigate('EmrSelection', {
                  flagforback: true,
                })
              }
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                width: '90%',
                marginTop: hp(3),
              }}>
              <View
                style={{
                  width: hp(4),
                  height: hp(4),
                  backgroundColor: colors.bleLayer4,
                  borderRadius: 4,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                <Image
                  style={{
                    width: hp(2),
                    height: hp(2),
                  }}
                  resizeMode="contain"
                  source={images.landingWidgetNavigatorIcon}
                />
              </View>
              <Text
                style={{
                  fontFamily: Fonts.SourceSansRegular,
                  fontSize: hp(2),
                  color: colors.black,
                  textTransform: 'capitalize',
                  padding: hp(1),
                  marginLeft: hp(1),
                }}>
                Choose Any EMR
              </Text>
              <View style={{flex: 1, alignItems: 'flex-end'}}>
                <Image
                  style={{
                    width: hp(2),
                    height: hp(1.7),
                  }}
                  resizeMode="contain"
                  source={images.forwardImage}
                />
              </View>
            </Pressable> */}
            {/* EMR selection (END) */}
            <Pressable
              onPress={() =>
                props.navigation.navigate('WidgetSelection', {
                  flagforback: true,
                })
              }
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                width: '90%',
                marginTop: hp(3),
              }}>
              <View
                style={{
                  width: hp(4),
                  height: hp(4),
                  backgroundColor: colors.bleLayer4,
                  borderRadius: 4,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                <Image
                  style={{
                    width: hp(2),
                    height: hp(2),
                  }}
                  resizeMode="contain"
                  source={images.landingWidgetNavigatorIcon}
                />
              </View>
              <Text
                style={{
                  fontFamily: Fonts.SourceSansRegular,
                  fontSize: hp(2),
                  color: colors.black,
                  textTransform: 'capitalize',
                  padding: hp(1),
                  marginLeft: hp(1),
                }}>
                Landing page Settings
              </Text>
              <View style={{flex: 1, alignItems: 'flex-end'}}>
                <Image
                  style={{
                    width: hp(2),
                    height: hp(1.7),
                  }}
                  resizeMode="contain"
                  source={images.forwardImage}
                />
              </View>
            </Pressable>

            <View
              style={{
                display: 'none',
                flexDirection: 'row',
                alignItems: 'center',
                width: '90%',
                marginTop: hp(2),
              }}>
              <View
                style={{
                  width: hp(4),
                  height: hp(4),
                  backgroundColor: colors.bleLayer4,
                  borderRadius: 4,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                <Image
                  style={{
                    width: hp(2),
                    height: hp(2),
                  }}
                  resizeMode="contain"
                  source={images.authentication}
                />
              </View>
              <Text
                style={{
                  fontFamily: Fonts.SourceSansRegular,
                  fontSize: hp(2),
                  color: colors.black,
                  textTransform: 'capitalize',
                  padding: hp(1),
                  marginLeft: hp(1),
                }}>
                Authentication
              </Text>
              <View style={{flex: 1, alignItems: 'flex-end'}}>
                <ToggleSwitch
                  isOn={authToggler}
                  onColor={colors.blueTextColor}
                  offColor={colors.sliderGrey}
                  onToggle={newValue => {
                    getAvailableAuthMethods(newValue);
                  }}
                  size="small"
                />
              </View>
            </View>
            <Pressable
              onPress={() => Linking.openURL('mailto:helpdesk@wisemani.com')}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                width: '90%',
                marginTop: hp(2),
              }}>
              <View
                style={{
                  width: hp(4),
                  height: hp(4),
                  backgroundColor: colors.bleLayer4,
                  borderRadius: 4,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                <Image
                  style={{
                    width: hp(2),
                    height: hp(2),
                  }}
                  resizeMode="contain"
                  source={images.icon_help}
                />
              </View>
              <Text
                style={{
                  fontFamily: Fonts.SourceSansRegular,
                  fontSize: hp(2),
                  color: colors.black,
                  textTransform: 'capitalize',
                  padding: hp(1),
                  marginLeft: hp(1),
                }}>
                Help
              </Text>
              <View style={{flex: 1, alignItems: 'flex-end'}}>
                <Image
                  style={{
                    width: hp(2),
                    height: hp(1.7),
                  }}
                  resizeMode="contain"
                  source={images.forwardImage}
                />
              </View>
            </Pressable>
            <Pressable
              onPress={() => onShare()}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                width: '90%',
                marginTop: hp(2),
              }}>
              <View
                style={{
                  width: hp(4),
                  height: hp(4),
                  backgroundColor: colors.bleLayer4,
                  borderRadius: 4,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                <Image
                  style={{
                    width: hp(2),
                    height: hp(2),
                  }}
                  resizeMode="contain"
                  source={images.icon_share}
                />
              </View>
              <Text
                style={{
                  fontFamily: Fonts.SourceSansRegular,
                  fontSize: hp(2),
                  color: colors.black,
                  textTransform: 'capitalize',
                  padding: hp(1),
                  marginLeft: hp(1),
                }}>
                Share with Friends
              </Text>
              <View style={{flex: 1, alignItems: 'flex-end'}}>
                <Image
                  style={{
                    width: hp(2),
                    height: hp(1.7),
                  }}
                  resizeMode="contain"
                  source={images.forwardImage}
                />
              </View>
            </Pressable>

            <View
              style={{
                borderWidth: 0.5,
                borderColor: Colors.line,
                width: '100%',
                marginTop: hp(3),
              }}
            />
            <Pressable
              onPress={() => {
                Alert.alert(
                  'Delete Account',
                  'You will be logged out of this account.',
                  [
                    {
                      text: 'Cancel',
                      onPress: () => {},
                      style: 'cancel',
                    },
                    {
                      text: 'Yes',
                      onPress: () => {
                        ProfileService.userLogout()
                          .then(res => {
                            if (res.statusCode === 200) {
                              clearStoreData();
                              removeItemValue('isAcoUserLogin');
                              removeItemValue('authCode');
                              removeItemValue('authToken');
                              removeItemValue('userEmail');
                              removeItemValue('isEmailORPhone');
                              removeItemValue('drawOverlay');
                              removeItemValue('refreshToken');
                              removeItemValue('skipIntro');
                              removeItemValue('reminderIds');
                              storeItem(BlueButtonAccessToken, '');
                              storeItem(BlueButtonRefreshToken, '');
                              storeValue('isAuthEnabled', 'false');
                              stopUserChatStatus();
                              Linking.openURL(
                                `${userCommonData?.common?.environmentURL}`,
                                // 'https://prodpatientengagementapi.wmi360.com/Home/DeleteAccount',
                              );
                              props.navigation.navigate('LoginScreen');
                              props.navigation.reset({
                                index: 0,
                                routes: [{name: 'Home'}],
                              });
                              console.log('deletePatientProfile');
                              console.log(res);
                            }
                          })
                          .catch(err => {
                            console.log('deletePatientProfile');
                            console.log(err);
                          });
                        signOut();
                      },
                      style: 'ok',
                    },
                  ],
                );
              }}
              style={{
                flexDirection: 'row',
                width: '85%',
                marginTop: hp(3),
                alignItems: 'center',
              }}>
              <Image
                style={{
                  width: hp(2),
                  height: hp(2),
                }}
                resizeMode="contain"
                source={images.deleteUser}
              />
              <Text
                style={{
                  fontFamily: Fonts.SourceSansSemibold,
                  fontSize: hp(2),
                  color: colors.red2,
                  textTransform: 'capitalize',
                  marginLeft: hp(3),
                }}>
                Delete Account
              </Text>
            </Pressable>

            <View
              style={{
                borderWidth: 0.5,
                borderColor: Colors.line,
                width: '100%',
                marginTop: hp(3),
              }}
            />
            <Pressable
              onPress={() => {
                props.navigation.reset({
                  index: 0,
                  routes: [{name: 'Home'}],
                });
                ProfileService.userLogout()
                  .then(res => {
                    clearStoreData();
                    console.log('userLogout');
                    console.log(res);
                  })
                  .catch(err => {
                    console.log('userLogoutError');
                    console.log(err);
                  });
                signOut();
                removeItemValue('reminderIds');
                removeItemValue('isAcoUserLogin');
                removeItemValue('authCode');
                removeItemValue('authToken');
                removeItemValue('userEmail');
                removeItemValue('isEmailORPhone');
                removeItemValue('drawOverlay');
                removeItemValue('refreshToken');
                removeItemValue('skipIntro');
                stopUserChatStatus();

                storeItem(LoginMethod, '');
                storeItem(BlueButtonAccessToken, '');
                storeItem(BlueButtonRefreshToken, '');
                storeValue('isAuthEnabled', 'false');
                props.navigation.navigate('LoginScreen');
              }}
              style={{
                flexDirection: 'row',
                width: '85%',
                marginTop: hp(3),
                alignItems: 'center',
              }}>
              <Image
                style={{
                  width: hp(2),
                  height: hp(2),
                }}
                resizeMode="contain"
                source={images.sign_off}
              />
              <Text
                style={{
                  fontFamily: Fonts.SourceSansSemibold,
                  fontSize: hp(2),
                  color: colors.red2,
                  textTransform: 'capitalize',
                  marginLeft: hp(3),
                }}>
                Sign out
              </Text>
            </Pressable>
           {/* Test Card View (START) */}
        
           {/* Test Card View (End) */}
          </ScrollView>
        </View>
      </MainHeader>
    </>
  );
};

const mapStateToProps = ({userProfileData}) => ({
  userProfileData,
});
export default connect(mapStateToProps)(SettingScreen);
