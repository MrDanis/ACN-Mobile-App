import {useFocusEffect} from '@react-navigation/native';
import React, {useState} from 'react';
import {
  Alert,
  Linking,
  PermissionsAndroid,
  Platform,
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  Image
} from 'react-native';
import LocationServicesDialogBox from 'react-native-android-location-services-dialog-box';

import {ScrollView} from 'react-native-gesture-handler';
import Spinner from 'react-native-loading-spinner-overlay';
import {PERMISSIONS, RESULTS, check, request} from 'react-native-permissions';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {SvgCss} from 'react-native-svg';
import {getLocation, getWeather, showWeather} from 'react-native-weather-api';
import {Colors, Svgs} from '../../../../config';
import {ApiKeyWeather, Fonts} from '../../../../config/AppConfig';
import colors from '../../../../config/Colors';
import MainHeader from '../../mycare/components/MainHeader';
const WellnessScreen = ({navigation}) => {
  let temp;
  let wind;
  const [currentWeather, setCurrentWeather] = useState(0);
  const [data, setData] = useState();
  const [loader, setLoader] = useState(false);
  useFocusEffect(
    React.useCallback(() => {
      // getWeatherUpdate();
    }, []),
  );

  async function requestLocationPermission() {
    if (Platform.OS === 'android') {
      try {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
          {
            title: 'Location Permission',
            message:
              'This app needs access to your location to provide weather updates',
            buttonNeutral: 'Ask Me Later',
            buttonNegative: 'Cancel',
            buttonPositive: 'OK',
          },
        );
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
          return true;
        } else {
          return false;
        }
      } catch (err) {
        console.warn(err);
        return false;
      }
    } else {
      const permissionStatus = await check(
        PERMISSIONS.IOS.LOCATION_WHEN_IN_USE,
      );
      if (permissionStatus === RESULTS.DENIED) {
        const requestStatus = await request(
          PERMISSIONS.IOS.LOCATION_WHEN_IN_USE,
        );
        return requestStatus === RESULTS.GRANTED;
      }
      return permissionStatus === RESULTS.GRANTED;
    }
  }
  async function checkAndEnableLocationServices() {
    if (Platform.OS === 'android') {
      return LocationServicesDialogBox.checkLocationServicesIsEnabled({
        message:
          '<h2>Use Location?</h2>This app wants to change your device settings:<br/><br/>Use GPS, Wi-Fi, and cell network for location',
        ok: 'YES',
        cancel: 'NO',
        enableHighAccuracy: true, // true => GPS AND NETWORK PROVIDER, false => GPS OR NETWORK PROVIDER
        showDialog: true, // false => Opens the Location access page directly
        openLocationServices: true, // false => Directly catch method is called if location services are turned off
        preventOutSideTouch: false, // true => To prevent the location services dialog from closing when it is touched outside
        preventBackClick: false, // true => To prevent the location services dialog from closing when the back button is pressed
        providerListener: true, // true ==> Trigger "locationProviderStatusChange" listener when the location state changes
      })
        .then(function (success) {
          return true;
        })
        .catch(error => {
          console.log(error.message); // error.message => "disabled"
          return false;
        });
    }
    return true;
  }

  async function getWeatherUpdate() {
    const hasLocationPermission = await requestLocationPermission();
    if (!hasLocationPermission) {
      if (Platform.OS === 'ios') {
        Alert.alert(
          'Location Services Required',
          'Please enable location services for this app. You can do this in your device settings.',
          [
            {
              text: 'Cancel',
              onPress: () => console.log('Cancel Pressed'),
              style: 'cancel',
            },
            {
              text: 'Open Settings',
              onPress: () => Linking.openURL('app-settings:'),
            },
          ],
          {cancelable: false},
        );
      } else {
        alert('Location permission is required to fetch weather data.');
      }
      return;
    }
    const locationServicesEnabled = await checkAndEnableLocationServices();
    if (!locationServicesEnabled) {
      return;
    }
    setLoader(true);
    getLocation().then(location => {
      getWeather({
        key: ApiKeyWeather,
        lat: location.coords.latitude,
        lon: location.coords.longitude,
        unit: 'metric',
      }).then(() => {
        let data = new showWeather();
        setData(data);
        temp = Math.floor(data.temp);
        wind = data.wind;

        setCurrentWeather(temp);
        setLoader(false);
      });
    });
  }

  const StormCloud = (
    <View
      style={{
        marginTop: hp(1),
        backgroundColor: 'white',
        paddingHorizontal: hp(1),
        borderTopLeftRadius: hp(3),
        borderBottomLeftRadius: hp(3),
        paddingVertical: hp(0.5),
        alignItems: 'flex-end',
        alignContent: 'flex-end',
        alignSelf: 'flex-end',
        flexDirection: 'row',
        elevation: 2,
        backgroundColor: colors.white,
        shadowOffset: {width: 0.5, height: 0.5},
        shadowOpacity: 0.05,
        shadowRadius: 5,
      }}>
      <Image
        style={{
          width: hp(3.5),
          height: hp(5.5),
        }}
        source={{
          uri: data?.icon, // Pass the image URL as the source
          priority: Image.priority.normal,
        }}
      />
      <View
        style={{
          flexDirection: 'column',
        }}>
        <Text
          style={{
            alignSelf: 'flex-end',
            paddingRight: hp(0.1),
            fontFamily: Fonts.SourceSansPro,
            fontSize: hp(2),
            fontWeight: '400',
            color: Colors.black,
          }}>
          {currentWeather}°
        </Text>
        <Text
          style={{
            fontFamily: Fonts.SourceSansPro,
            fontSize: hp(1.6),
            fontWeight: '400',
            color: Colors.black,
          }}>
          {data?.description}
        </Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: Colors.BgColor}}>
      <MainHeader name={'Wellness'} navigation={navigation}>
        <ScrollView
          style={{
            flex: 1,
            height: '100%',
            backgroundColor: Colors.backgroundMainLogin,
          }}>
          <Spinner
            visible={loader}
            textContent={'Loading...'}
            textStyle={{color: '#FFF'}}
          />
          <ScrollView>
            {StormCloud}

            <ScrollView
              contentContainerStyle={{
                justifyContent: 'space-evenly',
                alignItems: 'center',
                width: '100%',
              }}>
              <Pressable
                style={{
                  width: '100%',
                  alignItems: 'center',
                }}
                onPress={() => {
                  navigation.navigate('MedicationEssentialScreen');
                }}>
                <View
                  style={{
                    width: '90%',

                    marginTop: hp(2),
                    borderColor: colors.line,
                    borderRadius: hp(1),
                    paddingVertical: hp(0.8),

                    borderWidth: 0.3,
                    elevation: 20,
                    borderBottomWidth: 1,
                    backgroundColor: Colors.white,
                    shadowOffset: {width: 0.5, height: 0.5},
                    shadowOpacity: 0.1,
                    shadowRadius: 8,
                  }}>
                  <View
                    style={{
                      width: '90%',
                      alignSelf: 'center',

                      flexDirection: 'row',
                    }}>
                    <View
                      style={{
                        alignSelf: 'center',
                      }}>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansPro,
                          fontSize: hp(2),
                          fontWeight: '400',
                          color: Colors.black,
                        }}>
                        Meditation Essentials
                      </Text>
                    </View>
                    <View
                      style={{
                        marginLeft: hp(3),
                        marginBottom: hp(-4.5),
                        marginTop: hp(-4.5),
                      }}>
                      <SvgCss
                        xml={Svgs.wellness_meditation_icon_full}
                        width={hp(17.5)}
                        height={hp(18)}
                        fill={Colors.black}
                      />
                    </View>
                  </View>
                </View>
              </Pressable>

              <Pressable
                style={{
                  width: '90%',

                  marginTop: hp(2),
                  borderColor: colors.line,
                  borderRadius: hp(1),
                  paddingVertical: hp(0.8),

                  borderWidth: 0.3,
                  elevation: 20,
                  borderBottomWidth: 1,
                  backgroundColor: Colors.white,
                  shadowOffset: {width: 0.5, height: 0.5},
                  shadowOpacity: 0.1,
                  shadowRadius: 8,
                }}
                onPress={() => {
                  navigation.navigate('MedicationEssentialScreen');
                }}>
                <View
                  style={{
                    width: '90%',

                    alignSelf: 'center',

                    flexDirection: 'row',
                  }}>
                  <View
                    style={{
                      alignSelf: 'center',
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansPro,
                        fontSize: hp(2),
                        fontWeight: '400',
                        color: Colors.black,
                      }}>
                      Stress & Anxiety
                    </Text>
                  </View>
                  <View>
                    <View
                      style={{
                        marginTop: hp(-5.4),
                        marginLeft: hp(4.8),
                        marginBottom: hp(-5.2),
                      }}>
                      <SvgCss
                        xml={Svgs.wellness_stress_icon_full}
                        width={hp(20)}
                        height={hp(20)}
                        fill={Colors.black}
                      />
                    </View>
                  </View>
                </View>
              </Pressable>
              <Pressable
                style={{
                  width: '90%',

                  marginTop: hp(2),
                  borderColor: colors.line,
                  borderRadius: hp(1),
                  paddingVertical: hp(0.8),

                  borderWidth: 0.3,
                  elevation: 20,
                  borderBottomWidth: 1,
                  backgroundColor: Colors.white,
                  shadowOffset: {width: 0.5, height: 0.5},
                  shadowOpacity: 0.1,
                  shadowRadius: 8,
                }}
                onPress={() => {
                  navigation.navigate('MedicationEssentialScreen');
                }}>
                <View
                  style={{
                    width: '90%',

                    alignSelf: 'center',
                    flexDirection: 'row',
                  }}>
                  <View
                    style={{
                      alignSelf: 'center',
                      zIndex: 1,
                    }}>
                    <Text
                      style={{
                        zIndex: -1,
                        fontFamily: Fonts.SourceSansPro,
                        fontSize: hp(2),
                        fontWeight: '400',
                        color: Colors.black,
                      }}>
                      Falling a sleep & waking up
                    </Text>
                  </View>
                  <View>
                    <View
                      style={{
                        marginTop: hp(-4.7),
                        marginLeft: hp(-1),
                        marginBottom: hp(-4.6),
                      }}>
                      <SvgCss
                        xml={Svgs.wellness_sleep_icon_full}
                        width={hp(16.5)}
                        height={hp(18)}
                        fill={Colors.black}
                      />
                    </View>
                  </View>
                </View>
              </Pressable>
              <Pressable
                style={{
                  width: '90%',

                  marginTop: hp(2),
                  borderColor: colors.line,
                  borderRadius: hp(1),
                  paddingVertical: hp(0.8),
                  borderWidth: 0.3,
                  elevation: 20,
                  borderBottomWidth: 1,
                  backgroundColor: Colors.white,
                  shadowOffset: {width: 0.5, height: 0.5},
                  shadowOpacity: 0.1,
                  shadowRadius: 8,
                }}
                onPress={() => {
                  navigation.navigate('MedicationEssentialScreen');
                }}>
                <View
                  style={{
                    width: '90%',

                    alignSelf: 'center',
                    flexDirection: 'row',
                  }}>
                  <View
                    style={{
                      alignSelf: 'center',
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansPro,
                        fontSize: hp(2),
                        fontWeight: '400',
                        color: Colors.black,
                      }}>
                      Personal Growth
                    </Text>
                  </View>
                  <View>
                    <View
                      style={{
                        marginTop: hp(-5),
                        marginLeft: hp(7.2),
                        marginBottom: hp(-4.9),
                      }}>
                      <SvgCss
                        xml={Svgs.wellnes_personalGrowth_icon_full}
                        width={hp(17.5)}
                        height={hp(18.5)}
                        fill={Colors.black}
                      />
                    </View>
                  </View>
                </View>
              </Pressable>
              <Pressable
                style={{
                  width: '90%',

                  marginTop: hp(2),
                  borderColor: colors.line,
                  borderRadius: hp(1),
                  paddingVertical: hp(0.8),

                  borderWidth: 0.3,
                  elevation: 20,
                  borderBottomWidth: 1,
                  backgroundColor: Colors.white,
                  shadowOffset: {width: 0.5, height: 0.5},
                  shadowOpacity: 0.1,
                  shadowRadius: 8,
                }}
                onPress={() => {
                  navigation.navigate('MedicationEssentialScreen');
                }}>
                <View
                  style={{
                    width: '90%',

                    alignSelf: 'center',

                    flexDirection: 'row',
                  }}>
                  <View
                    style={{
                      alignSelf: 'center',
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansPro,
                        fontSize: hp(2),
                        fontWeight: '400',
                        color: Colors.black,
                      }}>
                      Healthy Eating
                    </Text>
                  </View>
                  <View>
                    <View
                      style={{
                        marginTop: hp(-5.5),
                        marginLeft: hp(6.7),
                        marginBottom: hp(-5.5),
                      }}>
                      <SvgCss
                        xml={Svgs.wellnes_healthyEating_icon}
                        width={hp(20)}
                        height={hp(20)}
                        fill={Colors.black}
                      />
                    </View>
                  </View>
                </View>
              </Pressable>
            </ScrollView>
          </ScrollView>
        </ScrollView>
      </MainHeader>
    </SafeAreaView>
  );
};

export default WellnessScreen;

const styles = StyleSheet.create({});
