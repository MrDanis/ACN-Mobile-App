import React from 'react';
import {Pressable, StyleSheet, Text, View} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';

import {ScrollView} from 'react-native-gesture-handler';
import {SvgCss} from 'react-native-svg';
import {Colors, Svgs} from '../../../../../config';
import {Fonts} from '../../../../../config/AppConfig';
import colors from '../../../../../config/Colors';

const MeditationCardComponent = ({navigation}) => {
  return (
    <ScrollView
      contentContainerStyle={{
        justifyContent: 'space-evenly',
        alignItems: 'center',
        width: '100%',
      }}>
      <Pressable
        style={{
          width: '100%',
          alignItems: 'center',
        }}
        onPress={() => {
          console.log('MedicationEssentialScreen Screen');
          navigation.navigate('MedicationEssentialScreen', {
            navigation: navigation,
          });
        }}>
        <View
          style={{
            width: '90%',
            marginTop: hp(2),
            borderColor: colors.line,
            borderRadius: hp(1),
            paddingVertical: hp(0.8),
            borderWidth: 0.3,
            elevation: 20,
            borderBottomWidth: 1,
            backgroundColor: Colors.white,
            shadowOffset: {width: 0.5, height: 0.5},
            shadowOpacity: 0.1,
            shadowRadius: 8,
          }}>
          <View
            style={{
              width: '90%',
              alignSelf: 'center',
              flexDirection: 'row',
            }}>
            <View
              style={{
                alignSelf: 'center',
              }}>
              <Text
                style={{
                  fontFamily: Fonts.SourceSansPro,
                  fontSize: hp(2),
                  fontWeight: '400',
                  color: Colors.black,
                }}>
                Meditation Essentials
              </Text>
            </View>
            <View
              style={{
                marginLeft: hp(3),
                marginBottom: hp(-4.5),
                marginTop: hp(-4.5),
              }}>
              <SvgCss
                xml={Svgs.wellness_meditation_icon_full}
                width={hp(17.5)}
                height={hp(18)}
                fill={Colors.black}
              />
            </View>
          </View>
        </View>
      </Pressable>

      <View
        style={{
          width: '90%',
          marginTop: hp(2),
          borderColor: colors.line,
          borderRadius: hp(1),
          paddingVertical: hp(0.8),
          borderWidth: 0.3,
          elevation: 20,
          borderBottomWidth: 1,
          backgroundColor: Colors.white,
          shadowOffset: {width: 0.5, height: 0.5},
          shadowOpacity: 0.1,
          shadowRadius: 8,
        }}>
        <View
          style={{
            width: '90%',

            alignSelf: 'center',
            flexDirection: 'row',
          }}>
          <View
            style={{
              alignSelf: 'center',
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansPro,
                fontSize: hp(2),
                fontWeight: '400',
                color: Colors.black,
              }}>
              Stress & Anxiety
            </Text>
          </View>
          <View>
            <View
              style={{
                marginTop: hp(-5.4),
                marginLeft: hp(4.8),
                marginBottom: hp(-5.2),
              }}>
              <SvgCss
                xml={Svgs.wellness_stress_icon_full}
                width={hp(20)}
                height={hp(20)}
                fill={Colors.black}
                onPress={() => navigation.pop()}
              />
            </View>
          </View>
        </View>
      </View>
      <View
        style={{
          width: '90%',
          marginTop: hp(2),
          borderColor: colors.line,
          borderRadius: hp(1),
          paddingVertical: hp(0.8),
          borderWidth: 0.3,
          elevation: 20,
          borderBottomWidth: 1,
          backgroundColor: Colors.white,
          shadowOffset: {width: 0.5, height: 0.5},
          shadowOpacity: 0.1,
          shadowRadius: 8,
        }}>
        <View
          style={{
            width: '90%',

            alignSelf: 'center',
            flexDirection: 'row',
          }}>
          <View
            style={{
              alignSelf: 'center',
              zIndex: 1,
            }}>
            <Text
              style={{
                zIndex: -1,
                fontFamily: Fonts.SourceSansPro,
                fontSize: hp(2),
                fontWeight: '400',
                color: Colors.black,
              }}>
              Falling a sleep & waking up
            </Text>
          </View>
          <View>
            <View
              style={{
                marginTop: hp(-4.7),
                marginLeft: hp(-1),
                marginBottom: hp(-4.6),
              }}>
              <SvgCss
                xml={Svgs.wellness_sleep_icon_full}
                width={hp(16.5)}
                height={hp(18)}
                fill={Colors.black}
                onPress={() => navigation.pop()}
              />
            </View>
          </View>
        </View>
      </View>
      <View
        style={{
          width: '90%',
          marginTop: hp(2),
          borderColor: colors.line,
          borderRadius: hp(1),
          paddingVertical: hp(0.8),
          borderWidth: 0.3,
          elevation: 20,
          borderBottomWidth: 1,
          backgroundColor: Colors.white,
          shadowOffset: {width: 0.5, height: 0.5},
          shadowOpacity: 0.1,
          shadowRadius: 8,
        }}>
        <View
          style={{
            width: '90%',

            alignSelf: 'center',
            flexDirection: 'row',
          }}>
          <View
            style={{
              alignSelf: 'center',
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansPro,
                fontSize: hp(2),
                fontWeight: '400',
                color: Colors.black,
              }}>
              Personal Growth
            </Text>
          </View>
          <View>
            <View
              style={{
                marginTop: hp(-5),
                marginLeft: hp(7.2),
                marginBottom: hp(-4.9),
              }}>
              <SvgCss
                xml={Svgs.wellnes_personalGrowth_icon_full}
                width={hp(17.5)}
                height={hp(18.5)}
                fill={Colors.black}
                onPress={() => navigation.pop()}
              />
            </View>
          </View>
        </View>
      </View>
      <View
        style={{
          width: '90%',
          marginTop: hp(2),
          borderColor: colors.line,
          borderRadius: hp(1),
          paddingVertical: hp(0.8),
          borderWidth: 0.3,
          elevation: 20,
          borderBottomWidth: 1,
          backgroundColor: Colors.white,
          shadowOffset: {width: 0.5, height: 0.5},
          shadowOpacity: 0.1,
          shadowRadius: 8,
        }}>
        <View
          style={{
            width: '90%',

            alignSelf: 'center',
            flexDirection: 'row',
          }}>
          <View
            style={{
              alignSelf: 'center',
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansPro,
                fontSize: hp(2),
                fontWeight: '400',
                color: Colors.black,
              }}>
              Healthy Eating
            </Text>
          </View>
          <View>
            <View
              style={{
                marginTop: hp(-5.5),
                marginLeft: hp(6.7),
                marginBottom: hp(-5.5),
              }}>
              <SvgCss
                xml={Svgs.wellnes_healthyEating_icon}
                width={hp(20)}
                height={hp(20)}
                fill={Colors.black}
                onPress={() => navigation.pop()}
              />
            </View>
          </View>
        </View>
      </View>
    </ScrollView>
  );
};

export default MeditationCardComponent;

const styles = StyleSheet.create({});
