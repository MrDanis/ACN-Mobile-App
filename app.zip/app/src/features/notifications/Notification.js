import {default as Moment, default as moment} from 'moment';
import React, {useCallback, useEffect, useRef, useState} from 'react';
import {
  FlatList,
  Image,
  Platform,
  Pressable,
  SafeAreaView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {showMessage} from 'react-native-flash-message';
import Spinner from 'react-native-loading-spinner-overlay';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {useSelector} from 'react-redux';
import {Fonts} from '../../../config/AppConfig';
import Colors from '../../../config/Colors';
import Images from '../../../config/Images';
import NotificationService from '../../api/notification/index';
import NotificationItem from './component/NotificationItem';

const Notification = props => {
  const userProfileData = useSelector(state => state.userProfileData);
  const [notificationList, setNotificationList] = useState([]);
  const [dummyNotificationList, setDummyNotificationList] = useState([]);
  const [loader, setLoader] = useState(false);
  const [enablePhysicianView, setEnablePhysicianView] = useState(false);
  const [collapsed, setCollapsed] = useState(true);
  const [careManagerData, setCareManagerData] = useState({});
  const [listData, setListData] = useState([]);
  const [connectedWithPhysician, setConnectedWithPhysician] = useState(false);
  const [physicianInviteFound, setPhysicianInvite] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const modalizeRef = useRef();
  const [pageNum, setPageNumber] = useState(0);
  const forceUpdate = useCallback(() => setPageNumber({}), []);

  useEffect(() => {
    let willFocusSubscription = props.navigation.addListener(
      'willFocus',
      () => {
        console.log('WIllFocus Called');
        setPageNumber(0);
        forceUpdate();
        setNotificationList([]);
        setDummyNotificationList([]);
        setCareManagerData({});
        setPhysicianInvite(false);
        setConnectedWithPhysician(false);
        getNotificationCall(0);

        return;
      },
    );
    setPageNumber(0);
    forceUpdate();
    setNotificationList([]);
    setDummyNotificationList([]);
    setCareManagerData({});
    setPhysicianInvite(false);
    setConnectedWithPhysician(false);
    getNotificationCall(0);
  }, []);

  const getNotificationCall = clearCallPageNumber => {
    setLoader(true);
    NotificationService.getUserNotification(
      clearCallPageNumber === '' ? pageNum : clearCallPageNumber,
    )
      .then(response => {
        setLoader(false);

        if (response && response.statusCode === 200) {
          setCareManagerData({});
          setPhysicianInvite(false);
          setConnectedWithPhysician(false);
          setDataWRTDate(response.data);
          setPageNumber(pageNum + 1);
          NotificationService.readUserNotification()
            .then(response => {})
            .catch(error => {
              setLoader(false);
              console.log('error in readUserNotification');
            });
        }
      })
      .catch(error => {
        setLoader(false);
        console.log('error');
        console.log(error);
        showMessage({
          message: 'Info',
          description: 'Internal Server Error',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  };

  const refreshNotificationListAfterClearCall = type => {
    if (type === 'Clear') {
      setPageNumber(0);
      forceUpdate();
      setNotificationList([]);
      setDummyNotificationList([]);
      getNotificationCall(0);
    } else {
      getNotificationCall('');
    }
  };
  const clearNotificationServiceCall = notificationID => {
    setLoader(true);
    NotificationService.clearUserNotification(notificationID)
      .then(response => {
        console.log('clearUserNotification');
        console.log(response);
        setLoader(false);
        if (response && response.statusCode === 200) {
          setCareManagerData({});
          setPhysicianInvite(false);
          setConnectedWithPhysician(false);
          refreshNotificationListAfterClearCall('Clear');
        }
      })
      .catch(error => {
        setLoader(true);
        console.log('error');
        console.log(error);
        showMessage({
          message: 'Info',
          description: 'Internal Server Error',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  };

  const onRefresh = () => {
    //set isRefreshing to true
    console.log('PageNumber On refresh', pageNum);
    getNotificationCall(0);
    // and set isRefreshing to false at the end of your callApiMethod()
  };

  const setDataWRTDate = data => {
    let dateArr = [];
    if (data.length > 0) {
      data.map(objAtIndex => {
        if (objAtIndex.moduleSubType === 8) {
          setCareManagerData(objAtIndex);
          setPhysicianInvite(true);
        } else {
          let notificationDate = objAtIndex.createdDate.split('T')[0];
          if (dateArr.indexOf(notificationDate) === -1) {
            dateArr.push(notificationDate);
          }
        }
      });
      let notificationData = [];
      dateArr.map(dateAtIndex => {
        let objData = [];
        data.map(objAtIndex => {
          if (
            dateAtIndex === objAtIndex.createdDate.split('T')[0] &&
            objAtIndex.moduleSubType !== 8
          ) {
            objData.push(objAtIndex);
          }
        });
        notificationData.push({
          key: dateAtIndex,
          value: objData,
        });
      });
      const dummyList = dummyNotificationList.concat(notificationData);

      setNotificationList(notificationData);
      setDummyNotificationList(dummyList);
      setListData(notificationData);
    }
  };

  return (
    <SafeAreaView
      style={{flex: 1, height: '100%', backgroundColor: Colors.BgColor}}>
      <StatusBar backgroundColor={Colors.BgColor} />

      <Spinner
        visible={loader}
        textContent={'Loading...'}
        textStyle={{color: '#FFF'}}
      />

      <View
        style={{
          width: '100%',
          alignItems: 'center',
          justifyContent: 'center',
          marginTop: hp(2),
          borderTopLeftRadius: hp(2.5),
          borderTopRightRadius: hp(2.5),
          shadowOffset: {width: 0.5, height: 0.5},
          shadowOpacity: 0.1,
          shadowRadius: 5,
          elevation:Platform.OS === 'ios'?5:0,
        }}>
        {
          notificationList.length<=0?
         <Text
         style={{
          alignSelf: 'flex-end',
          marginRight: hp(2.5),
          marginTop: hp(2.5),
          marginBottom: hp(-3),
          zIndex: 4,
           color: Colors.fontGrey,
           fontFamily: Fonts.SourceSansRegular,
           fontSize: hp(2),
         }}>
         Clear All 
       </Text>:
        <Pressable
          onPress={() => {
            clearNotificationServiceCall(0);
          }}
          style={{
            alignSelf: 'flex-end',
            marginRight: hp(2.5),
            marginTop: hp(2),
            marginBottom: hp(-3),
            zIndex: 4,
          }}>
          <Text
            style={{
              color: Colors.blueTextColor,
              fontFamily: Fonts.SourceSansRegular,
              fontSize: hp(2),
            }}>
            Clear All 
          </Text>
        </Pressable>

        }  
        <FlatList
          nestedScrollEnabled={true}
          data={notificationList}
          contentContainerStyle={{
            flexGrow: Platform.OS === 'android' ? 1 : null,
          }}
          style={{
            flexGrow: 1,
            width: '100%',
            backgroundColor: Colors.BgColor,
            height: '100%',
          }}
          onRefresh={() => {
            setPageNumber(0);
            forceUpdate();
            setNotificationList([]);
            setDummyNotificationList([]);
            onRefresh();
          }}
          refreshing={isRefreshing}
          renderItem={({item}) => {
            return (
              <NotificationItem
                item={item}
                navigation={props.navigation}
                reloadNotification={() =>
                  refreshNotificationListAfterClearCall('Clear')
                }
              />
            );
          }}
          ListFooterComponent={() =>
            loader === false &&
            notificationList.length === 0 &&
            Object.entries(careManagerData).length === 0 && (
              <View
                style={{
                  width: '100%',
                  flexDirection: 'column',
                  justifyContent: 'center',
                  alignSelf: 'center',
                  height: '100%',
                  flex: 1,
                  alignItems: 'center',
                  marginTop: 200,
                }}>
                <Image
                  source={Images.emptyIcon}
                  style={{
                    alignSelf: 'center',
                    height: hp(16),
                    width: hp(18),
                  }}
                />
                <Text
                  style={{
                    fontSize: hp(2.5),
                    fontFamily: Fonts.SourceSansSemibold,
                    color: Colors.regularLabel,
                    marginTop: hp(4),
                    marginRight: hp(10),
                    marginLeft: hp(10),
                    textAlign: 'center',
                  }}>
                  No Record Found
                </Text>
              </View>
            )
          }
        />
      </View>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    flex: 1,
  },
  backTextWhite: {
    color: '#FFF',
  },
  rowFront: {
    alignItems: 'center',
    backgroundColor: '#CCC',
    borderBottomColor: 'black',
    borderBottomWidth: 1,
    justifyContent: 'center',
    height: 50,
    flex: 1,
  },
  rowBack: {
    alignItems: 'center',
    backgroundColor: '#DDD',
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 15,
  },
  backRightBtn: {
    alignItems: 'center',
    bottom: 0,
    justifyContent: 'center',
    position: 'absolute',
    top: 0,
    width: 75,
  },
  backRightBtnLeft: {
    backgroundColor: 'blue',
    right: 75,
  },
  backRightBtnRight: {
    backgroundColor: 'red',
    right: 0,
  },
});

export default Notification;
