import {default as Moment, default as moment} from 'moment';
import React, {useRef} from 'react';
import {Platform, Text, View} from 'react-native';
import {showMessage} from 'react-native-flash-message';
import {Swipeable} from 'react-native-gesture-handler';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import MedicationIconNew from '../../../../../assets/svg/notificationIcons/newNotificationMedication.svg';
import ProfileIconNew from '../../../../../assets/svg/notificationIcons/newNotificationProfile.svg';
import MedicationIcon from '../../../../../assets/svg/notificationIcons/notificationMedication.svg';
import {Colors} from '../../../../config';
import {Fonts} from '../../../../config/AppConfig';
import NotificationService from '../../../api/notification';
import { Svgs } from '../../../../config';
import {SvgCss} from 'react-native-svg';
const NotificationItem = props => {
  const swipeableRef = useRef(null);
  const LeftSwipeActions = () => {
    return (
      <View
        style={{flex: 1, backgroundColor: '#ccffbd', justifyContent: 'center'}}>
        <Text
          style={{
            color: '#40394a',
            paddingHorizontal: 10,
            fontWeight: '600',
            paddingVertical: 20,
          }}>
          Bookmark
        </Text>
      </View>
    );
  };
  const rightSwipeActions = itemID => {
    return (
      <View
        style={{
          backgroundColor: Colors.backgroundMain,
          justifyContent: 'center',
          alignItems: 'flex-end',
          flex: 1,
        }}>
        <Text
          style={{
            color: '#1b1a17',
            paddingHorizontal: 10,
            fontWeight: '600',
            paddingVertical: 20,
          }}>
          Clear
        </Text>
      </View>
    );
  };
  const isTodayYesterday = date => {
    let today = moment().format('YYYY-MM-DD');
    let yesterday = moment().subtract(1, 'day').format('YYYY-MM-DD');
    const formattedDate = moment(date).format('YYYY-MM-DD');

    if (moment(formattedDate).isSame(today, 'day')) {
      return 'Today';
    } else if (moment(formattedDate).isSame(yesterday, 'day')) {
      return 'Yesterday';
    } else {
      return moment(new Date(formattedDate)).format('M/D/YYYY').toUpperCase();
    }
  };
  const swipeFromLeftOpen = () => {
    alert('Swipe from left');
  };
  const swipeFromRightOpen = data => {
    closeSwipeable();
    clearNotificationServiceCall(data.id);
  };
  const closeSwipeable = () => {
    swipeableRef.current.close();
  };
  const getModuleName = modulesubTypeID => {
    var name = '';
    if (
      modulesubTypeID === 1 ||
      modulesubTypeID === 2 ||
      modulesubTypeID === 3 ||
      modulesubTypeID === 5 ||
      modulesubTypeID === 6
    ) {
      name = 'Medication';
    } else if (modulesubTypeID === 4 || modulesubTypeID === 7) {
      name = 'Profile';
    }
    return name;
  };

  const getModuleIcon = modulesubTypeID => {
    if (
      modulesubTypeID === 1 ||
      modulesubTypeID === 2 ||
      modulesubTypeID === 3 ||
      modulesubTypeID === 5 ||
      modulesubTypeID === 6
    ) {
      return  <SvgCss xml={Svgs.MedicationIcon} width={hp(4)} height={hp(4)} fill={Colors.black}/>
      // return    <MedicationIcon />;
    } else if (modulesubTypeID === 4 || modulesubTypeID === 7) {
      return <SvgCss xml={Svgs.MedicationIcon} width={hp(4)} height={hp(4)} fill={Colors.black} />
      // <MedicationIcon />;
    }
  };

  const convertUTCDateToLocalDate = date => {
    if(Platform.OS === 'android')
    {
      const dateTimeAndroid = moment.utc(date).local().format('hh:mm A');
      return dateTimeAndroid;  
    }
    else
    {
      var newDate = new Date(
          date.getTime() + date.getTimezoneOffset() * 60 * 1000,
        );
        var offset = date.getTimezoneOffset() / 60;
        var hours = date.getHours();
        newDate.setHours(hours - offset);
      const dateTimeIos = Moment(new Date(newDate)).format('hh:mm A');
      return dateTimeIos // Platform.OS === 'ios' ? dateTimeIos : dateTimeAndroid;

    }
      //moment.utc(new Date(date)).local().format('hh:mm A');
    // const dateTimeAndroid = moment.utc(newDate).local().format('hh:mm A')//moment.utc(new Date(date)).local().format('hh:mm A');



  };

  const clearNotificationServiceCall = notificationID => {
    NotificationService.clearUserNotification(notificationID)
      .then(response => {
        if (response && response.statusCode === 200) {
          props.reloadNotification('Clear');
        }
      })
      .catch(error => {
        console.log('error');
        console.log(error);
        showMessage({
          message: 'Info',
          description: 'Internal Server Error',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  };
  return (
    <View
      style={{
        backgroundColor: Colors.white,
      }}>
      <Text
        style={{
          fontFamily: Fonts.SourceSansSemibold,
          color: Colors.black4,
          marginLeft: hp(2),
          marginBottom: hp(2),
          marginTop: hp(2),
          fontSize: hp(2),
        }}>
        {isTodayYesterday(
          Moment(new Date(props.item.key)).format('YYYY-MM-DD')
        )}
      </Text>
      {props.item.value && props.item.value.length
        ? props.item.value.map((data, index) => {
            return (
              <Swipeable
                ref={swipeableRef}
                renderRightActions={() => rightSwipeActions(data)}
                onSwipeableRightOpen={() => swipeFromRightOpen(data)}>
                <View
                  style={{
                    flexDirection: 'row',
                    marginVertical: hp(1),
                    alignItems: 'center',
                  }}>
                  <View
                    style={{
                      borderRadius: hp(1),
                      backgroundColor: Colors.bleLayer4,
                      marginHorizontal: hp(2),
                      paddingVertical: hp(1.5),
                      width: Platform.OS === 'ios' ? hp(6.5) : hp(7),
                      height: Platform.OS === 'android' ? hp(7) : hp(6.5),
                      display: 'flex',
                      flexDirection: 'row',
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}>
                    {data.moduleSubType === 1 ||
                    data.moduleSubType === 2 ||
                    data.moduleSubType === 3 ||
                    data.moduleSubType === 5 ||
                    data.moduleSubType === 6 ? (
                      <SvgCss
                      xml={Svgs.MedicationIconNew}
                      width={hp(4)}
                      height={hp(4)}
                      fill={Colors.black}
                    />
                      // <MedicationIconNew
                      //   height="30"
                      //   width="30"
                      //   style={{marginHorizontal: hp(2)}}
                      // />
                    ) : (
                      <SvgCss
                      xml={Svgs.ProfileIconNew}
                      width={hp(4)}
                      height={hp(4)}
                      fill={Colors.black}
                    />
                      // <ProfileIconNew
                      //   height="25"
                      //   width="25"
                      //   style={{marginHorizontal: hp(2)}}
                      // />
                    )}
                  </View>
                  <View
                    style={{
                      flexDirection: 'column',
                      width: '75%',
                      alignItems: 'flex-start',
                      justifyContent: 'space-around',
                      marginVertical: hp(1.5),
                    }}>
                    <Text
                      style={{
                        fontSize: hp(2),
                        fontFamily: Fonts.SourceSansSemibold,
                        color: Colors.black4,
                        marginTop: hp(0.3),
                      }}>
                      {data.description}
                    </Text>
                    <View
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'flex-start',
                      }}>
                      <Text
                        style={{
                          fontSize: hp(2),
                          fontFamily: Fonts.SourceSansRegular,
                          color: Colors.noRecordFound,
                          marginTop: Platform.OS === 'ios' ? hp(0.5) : hp(0),
                        }}>
                          
                        {/* {convertUTCDateToLocalDate(new Date(data.createdDate))} */}
                        {Platform.OS==='ios'?convertUTCDateToLocalDate(new Date(data.createdDate)):convertUTCDateToLocalDate(data.createdDate)}
                      </Text>
                    </View>
                  </View>
                </View>
                <View
                  style={{
                    display: 'flex',
                    justifyContent: 'flex-end',
                    flexDirection: 'row',
                  }}>
                  <View
                    style={{
                      borderWidth: 0.5,
                      borderColor: Colors.line,
                      width: Platform.OS === 'ios' ? '78%' : '77%',
                    }}
                  />
                </View>
              </Swipeable>
            );
          })
        : null}
    </View>
  );
};

export default NotificationItem;
