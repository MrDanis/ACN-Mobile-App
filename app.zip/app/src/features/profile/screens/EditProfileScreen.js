/* istanbul ignore file */
import React, {Fragment, useCallback, useEffect, useRef, useState} from 'react';
import {
  Alert,
  BackHandler,
  Image,
  PermissionsAndroid,
  Platform,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import {
  heightPercentageToDP,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {Colors} from '../../../../config';
import {
  AZURE_PRE_RELEASE,
  AZURE_PRODUCTION,
  CURRENT_TARGET,
  DEMO,
  Fonts,
  PRE_RELEASE,
  baseUrl,
} from '../../../../config/AppConfig';
import Moment from 'moment';
import DatePicker from 'react-native-date-picker';

import {showMessage} from 'react-native-flash-message';
import * as ImagePicker from 'react-native-image-picker';
import ImageResizer from 'react-native-image-resizer';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import Spinner from 'react-native-loading-spinner-overlay';
import {TextInputMask} from 'react-native-masked-text';
import DateTimePicker from 'react-native-modal-datetime-picker';
import {Modalize} from 'react-native-modalize';
import {SvgCss} from 'react-native-svg';
import {NavigationActions} from 'react-navigation';
import {connect, useDispatch} from 'react-redux';
import Images from '../../../../config/Images';
import svgs from '../../../../config/Svgs';
import ProfileService from '../../../api/profile';
import {AttachmentHelper} from '../../../helpers/AttachmentHelper';
import {
  checkCameraPermission,
  requestMicCameraPermission,
} from '../../../helpers/Common';
import {
  AuthToken,
  retrieveItem,
  retrieveValue,
} from '../../../helpers/LocalStorage';
import {getUserProfile} from '../action';
import {HtmlElementRemover} from '../../../utility/HtmlTagRemoverText';
import AsyncStorage from '@react-native-async-storage/async-storage';
const EditProfileScreen = ({navigation, route}) => {
  const {profileDetails, screenName} = route?.params;
  const [isGmail, setIsGmail] = useState(null);
  const [isEmail, setIsEmail] = useState(null);
  const [isStartDate, setIsStartDate] = useState(false);
  const [patientData, setPatientData] = useState(profileDetails);
  const [screenname, setScreenName] = useState(screenName);
  const [isCamera, setIsCamera] = useState(false);
  const [androidDate, setandroidDate] = useState(false);
  const modalizeRef = useRef();
  const dispatch = useDispatch();
  let attachmentHelper = AttachmentHelper.sharedInstance();
  const [email, set_email] = useState(
    Object.keys(patientData).length > 0
      ? patientData.email !== ''
        ? patientData.email
        : ''
      : '',
  );
  const [firstName, set_FirstName] = useState(
    Object.keys(patientData).length > 0
      ? patientData.firstName !== ''
        ? patientData.firstName
        : ''
      : '',
  );
  const [lastName, set_lastName] = useState(
    Object.keys(patientData).length > 0
      ? patientData.lastName !== ''
        ? patientData.lastName
        : ''
      : '',
  );

  const [open, set_open] = useState(null);
  const [address, set_address] = useState(
    Object.keys(patientData).length > 0
      ? patientData.address !== ''
        ? patientData.address
        : ''
      : '',
  );
  const [value, setValue] = useState(
    Object.keys(patientData).length > 0
      ? patientData.gender !== ''
        ? patientData.gender
        : null
      : null,
  );
  const [phone, setPhone] = useState(
    Object.keys(patientData).length > 0
      ? patientData.phone !== ''
        ? patientData.phone.replace(/^\+1?(\d{3})(\d{3})(\d{4})$/, '($1) $2 $3') //(/(\d{3})(\d{3})(\d{4})/, '($1) $2 $3')
        : ''
      : '',
  );

  // const [gender, setGender] = useState('female');
  const [gender, setGender] = useState(
    Object.keys(patientData).length > 0
      ? patientData.gender !== ''
        ? patientData.gender
        : null
      : null,
  );

  const [isDatePickerVisible, setIsDatePickerVisible] = useState(false);
  const forceUpdate = useCallback(() => setIsDatePickerVisible({}), []);
  {
    console.log('Patient Data : ', patientData);
  }
  const [date, setDate] = useState(
    Object.keys(patientData).length > 0
      ? patientData.dateOfBirth !== '01/01/1900 00:00:00' &&
        patientData.dateOfBirth !== ''
        ? Moment(patientData?.dateOfBirth, [
            'YYYY-MM-DD',
            'MM/DD/YYYY HH:mm:ss',
          ]).format('MM/DD/yyyy')
        : Moment(new Date()).format('MM/DD/yyyy')
      : Moment(new Date()).format('MM/DD/yyyy'),
  );
  console.log('date is ', date);
  const [startDate, setStartDate] = useState(
    Object.keys(patientData).length > 0
      ? patientData.startDate !== '01/01/1900 00:00:00' ||
        patientData.startDate !== '' ||
        patientData.startDate !== null
        ? Moment(new Date(patientData.startDate)).format('MM/DD/yyyy')
        : Moment(new Date()).format('MM/DD/yyyy')
      : Moment(new Date()).format('MM/DD/yyyy'),
  );
  const [referenceNumber, setReferenceNumber] = useState(
    Object.keys(patientData).length > 0
      ? patientData.referenceNumber !== ''
        ? patientData.referenceNumber
        : ''
      : '',
  );
  const [imageObject, setImageObject] = useState(
    Object.keys(patientData).length > 0
      ? patientData.imagePath !== ''
        ? patientData.imagePath
        : ''
      : '',
  );
  const [emailError, set_emailError] = useState('');
  const [emailValidation, setEmailValidation] = useState(false);
  const [phoneError, setPhoneError] = useState('');
  const [phoneValidation, setPhoneValidation] = useState(false);
  const [loader, showLoader] = useState(false);
  // Handle HTML TAG validation
  const handleHtmlValidator = text => {
    console.log('incomming text for the Address : ', text);
    let filterText = HtmlElementRemover(text);
    set_address(filterText);
    console.log('Filter text is : ', filterText);
  };
  useEffect(() => {
    showLoader(false);
    retrieveValue('loginMethod')
      .then(res => {
        console.log('Response of the gmail flag is : : ', typeof res, res);
        if (typeof res === 'string' && res !== '') {
          setIsGmail(true);
        } else {
          setIsGmail(false);
        }
      })
      .catch(err => {
        console.log('Error of the async is : ', err);
      });
    retrieveValue('isEmail')
      .then(res => {
        console.log('Response of retriving the Email is : ', typeof res, res);
        setIsEmail(JSON.parse(res));
      })
      .catch(err => {
        console.log('error', err);
      });
    if (patientData.imagePath !== null && patientData.imagePath !== '') {
      let imageData = {};
      imageData.uri = baseUrl + '/' + patientData.imagePath;
      setImageObject(imageData);
    }

    BackHandler.addEventListener('hardwareBackPress', handleBackButtonClick);
    return () => {
      console.log('Screen is unfocused');
      BackHandler.removeEventListener(
        'hardwareBackPress',
        handleBackButtonClick,
      );
    };
  }, []);
  const singleFilePicker = async () => {
    let options = {
      mediaType: 'photo',
      includeBase64: false,
      maxWidth: 300,
      maxHeight: 400,
      cropping: true,
      cameraType: 'back',
    };
    ImagePicker.launchImageLibrary(options)
      .then(fileData => {
        console.log('data received');
        console.log(fileData);
        if (fileData && fileData.didCancel !== true) {
          setIsCamera(true);
          ImageResizer.createResizedImage(
            fileData.assets[0].uri,
            180,
            180,
            'JPEG',
            100,
          )
            .then(({uri}) => {
              fileData.path = uri;
              let imageData = {};
              const fileExtension = String(fileData.assets[0].type).substr(
                String(fileData.assets[0].type).indexOf('/') + 1,
              );
              imageData.uri = fileData.path;
              imageData.name = `Mobile_Upload_${Moment().unix()}.${fileExtension}`;
              imageData.type = fileData.assets[0].type;

              setImageObject(imageData);
            })
            .catch(err => {
              console.log(err);
              return Alert.alert(
                'Unable to resize the photo',
                'Check the console for full the error message',
              );
            });
          let imageData = {};
          const fileExtension = String(fileData.assets[0].type).substr(
            String(fileData.assets[0].type).indexOf('/') + 1,
          );
          imageData.uri = fileData.assets[0].uri;
          imageData.name = `Mobile_Upload_${Moment().unix()}.${fileExtension}`;
          imageData.type = fileData.assets[0].type;
          setImageObject(imageData);
        } else {
        }
      })
      .catch(error => {
        console.log('error');
        console.log(error);
      });
  };
  const openCamera = () => {
    if (Platform.OS === 'android') {
      PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.CAMERA).then(
        async response => {
          if (response === true) {
            let options = {
              mediaType: 'photo',
              includeBase64: false,
              maxWidth: 300,
              maxHeight: 400,
              cropping: true,
              cameraType: 'back',
            };
            ImagePicker.launchCamera(options).then(result => {
              if (result && result.didCancel !== true) {
                setIsCamera(true);
                let image = result.assets[0];
                ImageResizer.createResizedImage(
                  image.uri,
                  180,
                  180,
                  'JPEG',
                  100,
                )
                  .then(({uri}) => {
                    image.uri = uri;
                    if (image) {
                      let imageData = {};
                      imageData.uri = image.uri;
                      imageData.name = image.fileName;
                      imageData.type = image.type;
                      imageData.size = image.fileSize;
                      console.log(imageData);
                      setImageObject(imageData);
                    }
                  })
                  .catch(err => {
                    console.log(err);
                    return Alert.alert(
                      'Unable to resize the photo',
                      'Check the console for full the error message',
                    );
                  });
              }
            });
          } else {
            const granted = await PermissionsAndroid.request(
              PermissionsAndroid.PERMISSIONS.CAMERA,
              {
                title: '360PatientEngagement App Camera Permission',
                message:
                  '360PatientEngagement App needs access to your camera ' +
                  'so you can take awesome pictures.',
                buttonNeutral: 'Ask Me Later',
                buttonNegative: 'Cancel',
                buttonPositive: 'OK',
              },
            );
            console.log('====================================');
            console.log('granted', granted);
            console.log('====================================');
            if (granted === 'granted') {
              console.log('open camera');
              let options = {
                mediaType: 'photo',
                includeBase64: false,
                maxWidth: 300,
                maxHeight: 400,
                cropping: true,
                cameraType: 'back',
              };
              ImagePicker.launchCamera(options).then(result => {
                if (result && result.didCancel !== true) {
                  setIsCamera(true);
                  let image = result.assets[0];
                  ImageResizer.createResizedImage(
                    image.uri,
                    180,
                    180,
                    'JPEG',
                    100,
                  )
                    .then(({uri}) => {
                      image.uri = uri;
                      if (image) {
                        let imageData = {};
                        imageData.uri = image.uri;
                        imageData.name = image.fileName;
                        imageData.type = image.type;
                        imageData.size = image.fileSize;
                        console.log(imageData);
                        setImageObject(imageData);
                      }
                    })
                    .catch(err => {
                      console.log(err);
                      return Alert.alert(
                        'Unable to resize the photo',
                        'Check the console for full the error message',
                      );
                    });
                }
              });
            }
          }
        },
      );
    } else {
      requestMicCameraPermission().then(statuses => {
        if (statuses.cameraPermission !== 'granted') {
          checkCameraPermission();
        } else {
          let options = {
            mediaType: 'photo',
            includeBase64: false,
            maxWidth: 300,
            maxHeight: 400,
            cropping: true,
            cameraType: 'front',
          };
          ImagePicker.launchCamera(options).then(result => {
            if (result && result.didCancel !== true) {
              setIsCamera(true);
              let image = result.assets[0];
              ImageResizer.createResizedImage(image.uri, 180, 180, 'JPEG', 100)
                .then(({uri}) => {
                  console.log('====================================');
                  console.log('uri of image', uri);
                  console.log('====================================');
                  image.uri = uri;
                  if (image) {
                    let imageData = {};
                    imageData.uri = image.uri;
                    imageData.name = image.fileName;
                    imageData.type = image.type;
                    imageData.size = image.fileSize;
                    console.log(imageData);
                    setImageObject(imageData);
                  }
                })
                .catch(err => {
                  console.log(err);
                  return Alert.alert(
                    'Unable to resize the photo',
                    'Check the console for full the error message',
                  );
                });
            }
          });
        }
      });
    }
  };

  function handleBackButtonClick() {
    if (screenname === 'profile') {
      navigation.pop();
    } else {
      navigation.navigate('LoginScreen');
    }

    return true;
  }

  function hideDatePicker() {
    setIsDatePickerVisible(false);
  }

  function startDatePicker() {
    setandroidDate(true);
  }

  const onOpen = () => {
    modalizeRef.current?.open();
  };
  const onClose = () => {
    modalizeRef.current?.close();
  };

  const onSubmitProfileDataCall = async () => {
    console.log(
      email,
      'this is the current state of email address: ',
      emailError,
    );
    if (emailError !== '' && email !== '') {
      showMessage({
        message: 'Error',
        description: 'Please enter valid email address',
        type: 'default',
        icon: {icon: 'info', position: 'left'},
        backgroundColor: Colors.red,
      });
    } else if (phoneError !== '' && phone !== '') {
      showMessage({
        message: 'Error',
        description: 'Please enter valid phone number',
        type: 'default',
        icon: {icon: 'info', position: 'left'},
        backgroundColor: Colors.red,
      });
    } else if (
      firstName !== '' &&
      lastName !== '' &&
      gender !== '' &&
      gender !== null &&
      gender !== 0 &&
      gender !== '0' 
      //&& value !== null
    ) {
      let data = {};
      data.FirstName = firstName;
      data.LastName = lastName;
      data.Email = email; // both +1 is added because of QA request
      data.Phone = isEmail
        ? `+1${phone.replace(/[()\s-]/g, '')}`
        : `+1${phone.replace(/[()\s-]/g, '')}`;
      data.Gender = gender;
      data.Address = address;
      data.DateOfBirth = /^\d{2}\/\d{2}\/\d{4}$/.test(date)
        ? date
        : Moment(date, 'YYYY-MM-DD').format('YYYY-MM-DD[T]HH:mm:ss');
      data.ReferenceNumber = referenceNumber === null ? '' : referenceNumber;
      data.StartDate = Moment(startDate).isValid()
        ? Moment(startDate).format('MM/DD/yyyy')
        : startDate;
      if (phone.length === 0) {
        data.Phone = '';
      }
      console.log(isEmail, 'Data payload for the profile is : ', data);
      showLoader(true);
      if (Platform.OS === 'ios') {
        const formdata = new FormData();
        formdata.append('FirstName', data.FirstName);
        formdata.append('LastName', data.LastName);
        formdata.append('Email', data.Email);
        formdata.append('Phone', data.Phone);
        formdata.append('Gender', data.Gender);
        formdata.append('Address', data.Address);
        formdata.append('DateOfBirth', data.DateOfBirth);
        // formdata.append('ReferenceNumber', data.ReferenceNumber);
        // formdata.append('startDate', data.StartDate);
        console.log('====================================');
        console.log('formdata', formdata);
        console.log('====================================');
        if (
          imageObject &&
          imageObject !== null &&
          imageObject.name &&
          imageObject.name !== null
        ) {
          formdata.append('Files', {
            uri: imageObject.uri,
            name: imageObject.name,
            type: imageObject.type,
          });
        }
        console.log('formdata updateProfileData');
        console.log(JSON.stringify(formdata));
        let authToken = null;
        authToken = await retrieveItem(AuthToken);
        fetch(`${CURRENT_TARGET}/api/PatientProfile/SaveUserProfile`, {
          method: 'POST',
          'Security-Key': 'lSWQ9NyZ1c2VyTmFtZT1TeWVkIFNoYWgmcGF0aWVudElkPTMwMD',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json, multipart/form-data',
            Authorization: 'Bearer '.concat(
              authToken === null ? '' : authToken,
            ),
          },
          body: formdata,
        })
          .then(response => response.json())
          .then(json => {
            if (json.errors && json.errors[0]) {
              showLoader(false);
              showMessage({
                message: 'Info',
                description: 'Something went wrong',
                type: 'default',
                icon: {icon: 'info', position: 'left'},
                backgroundColor: Colors.red,
              });
            } else {
              showLoader(false);
              console.log('====================================');
              console.log('res', json);
              console.log('====================================');
              dispatch(getUserProfile(json?.data));
              if (screenName === 'otp' || screenName === 'splash') {
                navigation.navigate('HomeTab');
              } else {
                navigation.navigate('HomeTab', {screen: 'Profile'});
              }
              showMessage({
                message: 'Success',
                description: 'Profile has been updated successfully',
                type: 'default',
                icon: {icon: 'success', position: 'left'},
                backgroundColor: Colors.green,
              });
            }
          })
          .catch(err => {
            showLoader(false);
            console.log('====================================');
            console.log('err', err);
            console.log('====================================');
          });
      } else {
        ProfileService.updateProfileData(data, imageObject)
          .then(response => {
            showLoader(false);
            if (response && response?.data?.isError === true) {
              showMessage({
                message: 'Info',
                description: response?.data?.errorMessage,
                type: 'default',
                icon: {icon: 'info', position: 'left'},
                backgroundColor: Colors.red,
              });
            } else {
              if (response && response.statusCode === 200 && response?.data) {
                dispatch(getUserProfile(response?.data));
                if (screenName === 'otp' || screenName === 'splash') {
                  navigation.navigate('HomeTab');
                } else {
                  navigation.navigate('HomeTab', {screen: 'Profile'});
                }
                showMessage({
                  message: 'Success',
                  description: 'Profile has been updated successfully',
                  type: 'default',
                  icon: {icon: 'success', position: 'left'},
                  backgroundColor: Colors.green,
                });
              } else {
                console.log('response error', response);
                alert(response.Error.ErrorMessage);
              }
            }
          })
          .catch(err => {
            showLoader(false);
            console.log('error in saveprofile is : ', err);
            showMessage({
              message: err.title,
              description: err.detail,
              type: 'default',
              icon: {icon: 'info', position: 'left'},
              backgroundColor: Colors.red,
            });
          });
      }
    } else {
      showLoader(false);
      showMessage({
        message: 'Error',
        description: 'Please fill required fields.',
        type: 'default',
        icon: {icon: 'info', position: 'left'},
        backgroundColor: Colors.red,
      });
    }
  };
  const onSubmitEmail = email => {
    if (validateEmail(email)) {
      set_emailError('');
    } else {
      set_emailError('Enter valid email address');
      validateEmail(email);
    }
  };
  const validateEmail = text => {
    var reg = new RegExp(
      '^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$',
    );
    if (reg.test(text) === false) {
      setEmailValidation(false);
      return false;
    } else {
      console.log('email true');
      setEmailValidation(true);
      return true;
    }
  };

  /* istanbul ignore next */
  function validatePhone(text) {
    var regex = new RegExp('(d{3})sd{3}sd{4}');
    if (regex.test(text) === false) {
      return false;
    } else {
      setPhoneValidation(true);
      setPhoneError('');
      return true;
    }
  }

  const onChangeLastName = e => {
    if (e !== ' ') {
      set_lastName(e);
    }
  };
  const onChangeFirstName = e => {
    if (e !== ' ') {
      set_FirstName(e);
    }
  };
  const handleNameInput = text => {
    // Allow only letters (a-z, A-Z), apostrophe ('), and hyphen (-)
    const formattedText = text.replace(/[^a-zA-Z'-]/g, '');
    return formattedText;
  };

  return (
    <Fragment>
      <Modalize
        ref={modalizeRef}
        adjustToContentHeight={true}
        modalStyle={{borderTopRightRadius: 25, borderTopLeftRadius: 25}}>
        <View style={{padding: hp(3)}}>
          <TouchableOpacity
            onPress={() => {
              onClose();
              openCamera();
            }}
            style={{
              flexDirection: 'row',
              marginTop: hp(4),
              marginBottom: hp(2),
              marginLeft: hp(3),
              marginRight: hp(3),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2.2),
                flex: 1,
                color: Colors.black1,
              }}>
              Take Photo
            </Text>
          </TouchableOpacity>
          <View
            style={{
              height: 1,
              backgroundColor: Colors.line,
              width: '90%',
              alignSelf: 'center',
            }}
          />
          <TouchableOpacity
            onPress={() => {
              onClose();
              singleFilePicker();
            }}
            style={{
              flexDirection: 'row',
              marginTop: hp(2),
              marginBottom: hp(2),
              marginLeft: hp(3),
              marginRight: hp(3),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2.2),
                flex: 1,
                color: Colors.black1,
              }}>
              Choose Photo
            </Text>
          </TouchableOpacity>
          <View
            style={{
              height: 1,
              backgroundColor: Colors.line,
              width: '90%',
              alignSelf: 'center',
            }}
          />
        </View>
      </Modalize>
      {Platform.OS === 'ios' ? (
        <DatePicker
          modal
          open={androidDate}
          maximumDate={new Date()}
          date={
            isStartDate
              ? new Date(startDate)
              : isNaN(new Date(date))
              ? new Date()
              : new Date(date)
          }
          mode="date"
          onConfirm={date => {
            console.log('====================================');
            console.log('date', date);
            console.log('====================================');
            setDate(date);
            setandroidDate(false);
          }}
          onCancel={() => {
            setandroidDate(false);
          }}
        />
      ) : (
        <DatePicker
          modal
          open={androidDate}
          maximumDate={new Date()}
          date={
            isStartDate
              ? new Date(startDate)
              : isNaN(new Date(date))
              ? new Date()
              : new Date(date)
          }
          mode="date"
          onConfirm={date => {
            if (isStartDate === true) {
              setStartDate(date);
              setandroidDate(false);
            } else {
              setDate(date);
              setandroidDate(false);
            }
          }}
          onCancel={() => {
            setandroidDate(false);
          }}
        />
      )}

      <SafeAreaView
        style={{
          backgroundColor: Colors.backgroundMainLogin,
        }}
      />
      <SafeAreaView
        style={{
          flex: 1,
          backgroundColor: Colors.backgroundMainLogin,
          width: '100%',
        }}>
        <View
          style={{
            flexDirection: 'row',
            alignContent: 'center',
            alignItems: 'center',
            backgroundColor: Colors.BgColor,
          }}>
          {screenName === 'profile' && (
            <TouchableOpacity
              onPress={() => {
                console.log('screenname from back button press', screenname);
                navigation.navigate('HomeTab', {screen: 'Profile'});
              }}
              style={{padding: hp(2), maxWidth: '15%'}}>
              <SvgCss
                xml={svgs.arrowHeadLeft}
                width={hp(4)}
                height={hp(4)}
                fill={Colors.black}
              />
            </TouchableOpacity>
          )}
          <View
            style={{
              maxWidth: screenname === 'profile' ? '65%' : '100%',
              flex: 1,
            }}>
            <Text
              style={{
                textAlign: 'center',
                fontFamily: Fonts.SourceSansBold,
                marginLeft: heightPercentageToDP(8.8),
                marginRight: heightPercentageToDP(5),
                fontSize: heightPercentageToDP(2.5),
                color: Colors.notificationGray,
                fontWeight: '600',
              }}>
              Edit Profile
            </Text>
          </View>
          <View style={{maxWidth: '15%', flex: 1}}></View>
        </View>

        <View
          style={{
            flex: 1,
            backgroundColor: Colors.backgroundMainLogin,
          }}>
          <ScrollView
            style={{
              marginTop: hp(3),
              width: '100%',
              borderTopRightRadius: 24,
              borderTopLeftRadius: 24,
              backgroundColor: Colors.white,
            }}
            contentContainerStyle={{
              alignItems: 'center',
              alignSelf: 'center',
              alignContent: 'center',
              shadowOffset: {width: 0.5, height: 0.5},
              shadowOpacity: 0.1,
              shadowRadius: 24,
              elevation: 3,
            }}>
            <KeyboardAwareScrollView
              contentInsetAdjustmentBehavior="automatic"
              contentContainerStyle={{
                flex: 1,
                shadowOffset: {width: 0.5, height: 0.5},
                shadowOpacity: 0.1,
                shadowRadius: 8,
                elevation: 3,
                width: '100%',
              }}
              nestedScrollEnabled={true}
              enableAutomaticScroll>
              {/* /Header Image and Pen */}
              <View
                style={{
                  justifyContent: 'center',
                  marginVertical: hp(1.5),
                  flexDirection: 'row',
                  alignItems: 'flex-end',
                }}>
                {/* Change imageObject !== null to make it work with navigation state props */}

                {imageObject !== null && imageObject !== '' ? (
                  <Image
                    style={{
                      width: 100,
                      height: 100,
                      // marginTop:hp(1),
                      marginBottom: hp(1),
                      marginRight: hp(-2),
                      borderRadius: 10,
                    }}
                    source={{
                      uri: isCamera
                        ? imageObject.uri + '?' + new Date()
                        : patientData.imagePath,
                    }}
                  />
                ) : (
                  <Image
                    style={{
                      width: 100,
                      height: 100,
                      marginBottom: hp(1),
                      marginRight: hp(-2),
                      borderRadius: 10,
                    }}
                    source={Images.userLogoDemo}
                  />
                )}

                <TouchableOpacity onPress={() => onOpen()}>
                  <View
                    style={{
                      alignContent: 'center',
                      alignItems: 'center',
                      alignSelf: 'center',
                    }}>
                    <View
                      style={{
                        backgroundColor: Colors.blueBackground,
                        color: Colors.blueBackground,
                        borderRadius: 30,
                        borderColor: Colors.white,
                        borderWidth: 2,
                        width: 30,
                        height: 30,
                        paddingTop: 5,
                        alignContent: 'center',
                        alignItems: 'center',
                        alignSelf: 'center',
                      }}>
                      <Image
                        style={{
                          zIndex: 10,

                          width: 13,
                          height: 15,
                        }}
                        source={require('../../../../../assets/images/edit_profile_pen.png')}></Image>
                    </View>
                  </View>
                </TouchableOpacity>
              </View>
              <View
                style={{
                  maxWidth: '85%',
                  minWidth: '85%',
                  alignSelf: 'center',
                  marginBottom: hp(5),
                  zIndex: Platform.OS === 'ios' ? 100 : 100,
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansRegular,
                    fontSize: hp(2),
                    color: Colors.noRecordFound,
                    marginBottom: hp(0.5),
                  }}>
                  First Name<Text style={{color: 'red'}}>*</Text>
                </Text>
                {/*Custom TextField Name */}
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'flex-start',
                    alignItems: 'center',
                    alignContent: 'center',
                    backgroundColor: '#fff',
                    borderWidth: 1,
                    borderColor: Colors.line,
                    borderRadius: 8,
                    backgroundColor: Colors.white,
                  }}>
                  <Image
                    style={{
                      width: 16,
                      height: 16,
                      marginLeft: hp(1),
                      marginRight: hp(1),
                    }}
                    source={Images.personIconPlaceHolder}
                  />

                  <TextInput
                    onChangeText={e => onChangeFirstName(handleNameInput(e))}
                    value={firstName}
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      paddingVertical: hp(1.35),
                      flex: 1,
                      fontSize: hp(2),
                      marginTop: hp(0.2),
                      color: Colors.black4,
                    }}
                    keyboardType="email-address"
                    selectionColor={Colors.blueTextColor}
                    placeholder="First Name"
                    placeholderTextColor={Colors.placeHoldaerColor}
                    maxLength={50}
                  />
                </View>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansRegular,
                    fontSize: hp(2),
                    color: Colors.noRecordFound,
                    marginTop: hp(2),
                    marginBottom: hp(0.5),
                  }}>
                  Last Name<Text style={{color: 'red'}}>*</Text>
                </Text>

                <View
                  style={{
                    flex: 1,
                    flexDirection: 'row',
                    justifyContent: 'flex-start',
                    alignItems: 'center',
                    alignContent: 'center',
                    backgroundColor: '#fff',
                    borderWidth: 1,
                    borderColor: Colors.line,
                    borderRadius: 8,
                    backgroundColor: Colors.white,
                  }}>
                  <Image
                    style={{
                      width: 16,
                      height: 16,
                      marginLeft: hp(1),
                      marginRight: hp(1),
                    }}
                    source={Images.personIconPlaceHolder}
                  />

                  <TextInput
                    onChangeText={e => onChangeLastName(handleNameInput(e))}
                    value={lastName}
                    style={{
                      flex: 1,
                      fontFamily: Fonts.SourceSansRegular,
                      paddingVertical: hp(1.35),
                      fontSize: hp(2),
                      marginTop: hp(0.2),
                      color: Colors.black4,
                    }}
                    keyboardType="email-address"
                    selectionColor={Colors.blueTextColor}
                    placeholder="Last Name"
                    placeholderTextColor={Colors.placeHoldaerColor}
                    maxLength={25}
                  />
                </View>

                <Text
                  style={{
                    fontFamily: Fonts.SourceSansRegular,
                    fontSize: hp(2),
                    color: Colors.noRecordFound,
                    marginTop: hp(2),
                    marginBottom: hp(0.5),
                  }}>
                  Email Address {console.log('Editable emial is : ', isEmail)}
                </Text>
                <View
                  style={{
                    flex: 1,
                    flexDirection: 'row',
                    justifyContent: 'flex-start',
                    alignItems: 'center',
                    alignContent: 'center',
                    backgroundColor: '#fff',
                    borderWidth: 1,
                    borderColor: Colors.line,
                    borderRadius: 8,
                    backgroundColor: Colors.white,
                  }}>
                  <Image
                    style={{
                      width: 20,
                      height: 20,
                      paddingLeft: hp(2),
                      marginLeft: hp(1),
                    }}
                    source={Images.emailIconProfileSignUp}
                  />
                  <View style={{paddingRight: hp(0.8)}}></View>
                  <TextInput
                    onChangeText={text => {
                      set_email(text);
                      onSubmitEmail(text);
                    }}
                    value={email}
                    editable={!isEmail || !isGmail ? true : false}
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      flex: 1,
                      paddingVertical: hp(1.35),
                      fontSize: hp(2),
                      marginTop: hp(0.2),
                      color: Colors.black4,
                    }}
                    keyboardType="email-address"
                    selectionColor={Colors.blueTextColor}
                    placeholder="xyz@gmail.com"
                    placeholderTextColor={Colors.placeHoldaerColor}
                  />
                </View>
                <View>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontSize: hp(2),
                      color: Colors.noRecordFound,
                      marginTop: hp(2),
                      marginBottom: hp(0.5),
                    }}>
                    Phone Number
                    {console.log(
                      'These are the keys : ',
                      AsyncStorage.getAllKeys(),
                    )}
                  </Text>
                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'flex-start',
                      alignItems: 'center',
                      alignContent: 'center',
                      backgroundColor: '#fff',
                      borderWidth: 1,
                      borderColor: Colors.line,
                      borderRadius: 8,
                      backgroundColor: Colors.white,
                      marginBottom: hp(1),
                    }}>
                    <Image
                      style={{
                        width: 20,
                        height: 20,
                        marginLeft: hp(1),
                        marginRight: hp(1),
                      }}
                      source={Images.call_Icon_Black}
                    />
                    <TextInputMask
                      type={'custom'}
                      editable={isEmail !== false}
                      options={{
                        mask: '(999) 999 9999',
                      }}
                      onChangeText={text => {
                        setPhone(text);
                      }}
                      value={phone}
                      style={{
                        flex: 1,

                        fontFamily: Fonts.SourceSansRegular,
                        paddingVertical: hp(1.35),
                        fontSize: hp(2),
                        marginTop: hp(0.2),
                        color: Colors.black4,
                      }}
                      placeholderTextColor={Colors.placeHoldaerColor}
                      placeholder={'(999) 999-9999'}
                      keyboardType="phone-pad"
                      selectionColor={Colors.blueTextColor}
                    />
                  </View>
                  <View>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansRegular,
                        fontSize: hp(2),
                        color: Colors.noRecordFound,
                        marginBottom: hp(0.5),
                      }}>
                      DOB<Text style={{color: 'red'}}>*</Text>
                    </Text>
                    <TouchableOpacity
                      style={{
                        width: '100%',
                        borderRadius: 10,
                        paddingVertical: hp(0.35),
                        alignItems: 'center',
                        justifyContent: 'center',
                        borderWidth: 1,

                        borderColor: Colors.lightGrey,
                      }}
                      onPress={() => {
                        startDatePicker();
                        setIsStartDate(false);
                      }}>
                      <View
                        style={{
                          flexDirection: 'row',
                          alignItems: 'center',
                          padding: hp(1),
                          flex: 1,
                          width: '100%',
                          borderRadius: 10,
                          backgroundColor: Colors.white,
                        }}>
                        <Image
                          source={Images.calenderBlack}
                          style={{
                            tintColor: Colors.black,
                            height: hp(2.5),
                            width: hp(2.5),
                            marginRight: hp(1),
                            alignSelf: 'center',
                          }}
                        />
                        <Text
                          style={{
                            fontFamily: Fonts.SourceSansRegular,
                            fontSize: hp(2.2),
                            color: Colors.black,
                            justifyContent: 'center',
                          }}>
                          {/^\d{2}\/\d{2}\/\d{4}$/.test(date)
                            ? date
                            : Moment(date, 'YYYY-MM-DD').format('DD/MM/YYYY')}
                          {/* {Moment(date).isValid() ? Moment(date).format('MM/DD/YYYY') : date} */}
                          {/* {Moment(date).format('MM/DD/yyyy')} */}
                        </Text>
                      </View>
                    </TouchableOpacity>
                  </View>
                </View>
                <View>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontSize: hp(2),
                      color: Colors.noRecordFound,
                      marginTop: hp(1),
                      marginBottom: hp(0.5),
                    }}>
                    Address
                  </Text>
                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'flex-start',
                      alignItems: 'center',
                      alignContent: 'center',
                      backgroundColor: '#fff',
                      borderWidth: 1,
                      borderColor: Colors.line,
                      borderRadius: 8,
                      backgroundColor: Colors.white,
                      marginBottom: hp(0.5),
                    }}>
                    <Image
                      style={{
                        width: 20,
                        height: 20,
                        marginLeft: hp(1),
                        marginRight: hp(1),
                      }}
                      source={Images.homeIconProfileSignUp}
                    />

                    <TextInput
                      onChangeText={text => {
                        set_address(text.replace(/[^a-zA-Z0-9#'-]/g, ''));
                      }}
                      value={address}
                      style={{
                        flex: 1,
                        fontFamily: Fonts.SourceSansRegular,
                        paddingVertical: hp(1.35),
                        fontSize: hp(2),
                        marginTop: hp(0.2),
                        color: Colors.black4,
                      }}
                      keyboardType="email-address"
                      selectionColor={Colors.blueTextColor}
                      placeholder="Address"
                      placeholderTextColor={Colors.placeHoldaerColor}
                    />
                  </View>
                </View>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansRegular,
                    fontSize: hp(2),
                    color: Colors.noRecordFound,
                    marginTop: hp(2),
                  }}>
                  Gender<Text style={{color: 'red'}}>*</Text>
                </Text>

                <View
                  style={{
                    flexDirection: 'row',
                    paddingTop: 12,
                  }}>
                  <TouchableOpacity
                    onPress={() => {
                      setGender('2');
                    }}>
                    <View
                      style={{
                        alignItems: 'center',
                        backgroundColor: '#fff',
                        borderWidth: 1,
                        borderColor: Colors.line,
                        borderRadius: 8,
                        borderColor:
                          gender === '2' ? Colors.homePink : Colors.line,
                        backgroundColor: Colors.white,
                        paddingVertical: hp(2.5),
                        paddingHorizontal: hp(5),
                      }}>
                      <Image
                        source={Images.femaleIcon}
                        style={{width: 22, height: 34, marginBottom: 10}}
                      />
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansRegular,
                          color: Colors.black4,
                        }}>
                        Female
                      </Text>
                    </View>
                  </TouchableOpacity>
                  <View style={{paddingHorizontal: 10}}></View>
                  <TouchableOpacity
                    onPress={() => {
                      setGender('1');
                    }}>
                    <View
                      style={{
                        alignItems: 'center',
                        backgroundColor: '#fff',
                        borderWidth: 1,
                        borderColor:
                          gender === '1' ? Colors.bluetoothColor : Colors.line,
                        borderRadius: 8,
                        backgroundColor: Colors.white,
                        paddingVertical: hp(2.5),
                        paddingHorizontal: hp(5),
                      }}>
                      <Image
                        source={Images.maleIcon}
                        style={{width: 34, height: 34, marginBottom: 10}}
                      />
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansRegular,
                          color: Colors.black4,
                        }}>
                        Male
                      </Text>
                    </View>
                  </TouchableOpacity>
                </View>

                <View>
                  {profileDetails?.isCM && profileDetails?.isEMR && (
                    <>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansRegular,
                          fontSize: hp(2),
                          color: Colors.noRecordFound,
                          marginTop: hp(2),
                          marginBottom: hp(0.5),
                        }}>
                        Medicare Number(Optional-Add for medical history)
                      </Text>
                      <View
                        style={{
                          flexDirection: 'row',
                          justifyContent: 'flex-start',
                          alignItems: 'center',
                          alignContent: 'center',
                          backgroundColor: '#fff',
                          borderWidth: 1,
                          borderColor: Colors.line,
                          borderRadius: 8,
                          backgroundColor: Colors.white,
                        }}>
                        <Image
                          style={{
                            width: 21,
                            height: 23,
                            marginLeft: hp(1),
                            marginRight: hp(1),
                          }}
                          source={Images.mrnIconProfileSignUp}
                        />

                        <TextInput
                          onChangeText={text => {
                            setReferenceNumber(text);
                          }}
                          value={referenceNumber}
                          style={{
                            flex: 1,
                            fontFamily: Fonts.SourceSansRegular,
                            paddingVertical: hp(1.35),
                            fontSize: hp(2),
                            marginTop: hp(0.2),
                            color: Colors.black4,
                          }}
                          keyboardType="email-address"
                          selectionColor={Colors.blueTextColor}
                          placeholder="44678"
                          editable={
                            profileDetails?.source === 0 ||
                            profileDetails?.source === 1
                              ? false
                              : true
                          }
                          placeholderTextColor={Colors.placeHoldaerColor}
                        />
                      </View>
                    </>
                  )}
                </View>
              </View>
              <TouchableOpacity
                onPress={() => {
                  console.log(phone, 'Submit Tapped', phone.length);
                  if (phone.length !== 0 && phone.length !== 14) {
                    showMessage({
                      message: 'Error',
                      description: `Please enter valid phone number`,
                      type: 'default',
                      icon: {icon: 'info', position: 'left'},
                      backgroundColor: Colors.red,
                    });
                    // onSubmitProfileDataCall();
                  } else {
                    // showMessage({
                    //   message: 'Warning',
                    //   description: 'Proceed with api calling',
                    //   type: 'default',
                    //   icon: {icon: 'info', position: 'left'},
                    //   backgroundColor: Colors.red,
                    // });
                    onSubmitProfileDataCall();
                  }
                }}
                style={{
                  backgroundColor: Colors.blueTextColor,
                  minHeight: hp(6),
                  borderRadius: 8,
                  justifyContent: 'center',
                  maxWidth: '85%',
                  minWidth: '85%',
                  alignSelf: 'center',
                }}>
                {loader ? (
                  <Spinner
                    visible={loader}
                    textContent={'Loading...'}
                    textStyle={{color: '#FFF'}}
                  />
                ) : (
                  <Text
                    style={{
                      textAlign: 'center',
                      fontFamily: Fonts.SourceSansSemibold,
                      fontSize: heightPercentageToDP(2.2),
                      color: Colors.white,
                    }}>
                    Submit
                  </Text>
                )}
              </TouchableOpacity>
              <View
                style={{
                  height: hp(10),
                  minHeight: hp(6),
                }}
              />
            </KeyboardAwareScrollView>
          </ScrollView>
        </View>
      </SafeAreaView>
    </Fragment>
  );
};

const styles = StyleSheet.create({});

const mapStateToProps = ({userProfileData}) => ({
  userProfileData,
});

export default connect(mapStateToProps)(EditProfileScreen);
