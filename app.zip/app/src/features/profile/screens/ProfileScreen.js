import React, {useEffect, useState} from 'react';
import {
  Pressable,
  SafeAreaView,
  ScrollView,
  Share,
  Text,
  View,
  Image
} from 'react-native';

import {showMessage} from 'react-native-flash-message';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {connect, useDispatch, useSelector} from 'react-redux';
// import LocalAuthentication from 'rn-local-authentication';
import {Fonts, baseUrl} from '../../../../config/AppConfig';
import colors from '../../../../config/Colors';
import {
  isACOUserLogin,
  requestAndHandleBiometricPermission,
} from '../../../helpers/Common';

// import LocalAuth from 'react-native-local-auth';
import {Colors, Images} from '../../../../config';
import {retrieveValue, storeValue} from '../../../helpers/LocalStorage';
import {
  getAllergiesHistory,
  getCoverageHistory,
  getDiseasesHistory,
  getHospitalVisitHistory,
  getMedicationHistory,
  getProceduresHistory,
  getProviderHistory,
} from '../../bluebutton/action';

import moment from 'moment';
import LinearGradient from 'react-native-linear-gradient';
import {getHomeApiData} from '../../home/action';

const ProfileScreen = props => {
  const [imageObject, setImageObject] = useState(null);
  const [authToggler, setAuthToggler] = useState(false);
  const userProfileData = useSelector(state => state.userProfileData);
  console.log('====================================');
  console.log('userProfileData', userProfileData);
  console.log('====================================');
  useEffect(() => {
    retrieveValue('isAuthEnabled')
      .then(res => {
        setAuthToggler(JSON.parse(res));
      })
      .catch(err => {
        console.log('error', err);
      });
    if (
      userProfileData.imagePath !== null &&
      userProfileData.imagePath !== ''
    ) {
      let imageData = {};
      imageData.uri = baseUrl + '/' + userProfileData.imagePath;
      setImageObject(imageData);
    }
  }, []);

  const clearStoreData = () => {
    props.dispatch(getMedicationHistory([]));
    props.dispatch(getProviderHistory([]));
    props.dispatch(getHospitalVisitHistory([]));
    props.dispatch(getDiseasesHistory([]));
    props.dispatch(getCoverageHistory([]));
    props.dispatch(getAllergiesHistory([]));
    props.dispatch(getProceduresHistory([]));
    props.dispatch(getHomeApiData({}));
  };
  const getAvailableAuthMethods = newValue => {
    // FingerprintScanner.isSensorAvailable()
    //   .then(res => {
    //     console.log('this is the availiability for auth', res);
    //     if (Platform.OS === 'ios') {
    //       console.log('reached ios');
    //       LocalAuthentication.authenticateAsync({
    //         reason: 'Please, authenticate!',
    //         fallbackEnabled: true,
    //         fallbackTitle: 'Use PassCode',
    //         fallbackToPinCodeAction: false,
    //       }).then(response => {
    //         if (response.success) {
    //           console.log('success ios', response);
    //           if (newValue === true) {
    //             setAuthToggler(true);
    //             storeValue('isAuthEnabled', 'true');
    //           } else {
    //             setAuthToggler(newValue);
    //             storeValue('isAuthEnabled', 'false');
    //           }
    //         } else {
    //           console.log('Something went wrong');
    //         }
    //       });
    //     } else if (Platform.OS === 'android') {
    //       console.log('reached android');
    //       LocalAuth.authenticate({
    //         reason: 'Please Authenticate yourself',
    //         fallbackToPasscode: true, // fallback to passcode on cancel
    //         suppressEnterPassword: true, // disallow Enter Password fallback
    //       })
    //         .then(success => {
    //           console.log('success android', success);
    //           if (newValue === true) {
    //             setAuthToggler(true);
    //             storeValue('isAuthEnabled', 'true');
    //           } else {
    //             setAuthToggler(newValue);
    //             storeValue('isAuthEnabled', 'false');
    //           }
    //         })
    //         .catch(error => {
    //           console.log('error', error);
    //         });
    //     }
    //   })
    //   .catch(err => {
    //     console.log('error from availiability for auth', err);
    //     err = String(err);
    //     const parts = err.split(':');
    //     if (parts[0].trim() === 'FingerprintScannerNotEnrolled') {
    //       console.log('error trimed', parts[0].trim());
    //       showMessage({
    //         message: 'Info',
    //         description: 'No Biometrics enrolled',
    //         type: 'default',
    //         icon: {icon: 'info', position: 'left'},
    //         backgroundColor: Colors.red,
    //       });
    //     } else if (parts[0].trim() === 'FingerprintScannerNotAvailable') {
    //       console.log('FingerprintScannerNotAvailable');
    //       requestAndHandleBiometricPermission()
    //         .then(res => {
    //           console.log('res', res);
    //         })
    //         .catch(err => {
    //           console.log('err', err);
    //         });
    //     }
    //   });
  };
  const onShare = async () => {
    let appLink =
      Platform.OS === 'ios'
        ? 'https://testflight.apple.com/join/ldWlg3fY'
        : 'https://play.google.com';
    try {
      const optionMessage =
        Platform.OS === 'ios'
          ? 'Please install 360 Patient Engagement application for your care'
          : 'Please install 360 Patient Engagement application for your care ' +
            '\n' +
            appLink;
      const result = await Share.share({
        title: 'App link',
        message: optionMessage,
        url: appLink,
      });
      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with activity type of result.activityType
        } else {
          // shared
        }
      } else if (result.action === Share.dismissedAction) {
        // dismissed
      }
    } catch (error) {
      alert(error.message);
    }
  };

  return (
    <>
      <SafeAreaView style={{backgroundColor: colors.BgColor}} />

      <View
        style={{
          backgroundColor: colors.white,
          // marginTop: hp(3.5),
          flex: 1,
          borderTopRightRadius: 24,
          borderTopLeftRadius: 24,
          shadowOffset: {width: 0.5, height: 0.5},
          shadowOpacity: 0.1,
          shadowRadius: 24,
          elevation: 3,
          // borderWidth: 2,
          // borderColor: 'red',
        }}>
        <LinearGradient
          colors={[
            'rgba(55,68,207,0.41)',
            'rgba(38,198,249,0.41)',
            'rgba(254,88,108,0.41)',
          ]}
          start={{x: 0, y: 1}}
          end={{x: 1, y: 0}}
          locations={[0.3, 0.6, 0.8]}
          useAngle={true}
          angle={45}
          angleCenter={{x: 0.5, y: 0.5}}
          style={{
            // height: '100%',
            borderTopRightRadius: 24,
            borderTopLeftRadius: 24,
            width: '100%',
            // position: 'absolute',
            paddingBottom: hp(4),
          }}>
          <Pressable
            onPress={() =>
              props.navigation.navigate('EditProfile', {
                profileDetails: userProfileData,
                screenName: 'profile',
              })
            }>
            <Image
              style={{
                width: hp(3.5),
                height: hp(3.5),
                marginLeft: hp(2),
                marginBottom: hp(1),
                marginTop: hp(2),
              }}
              resizeMode="contain"
              source={require('../../../../../assets/images/editProfilebutton.png')}
            />
          </Pressable>

          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              justifyContent: 'center',
            }}>
            {userProfileData.imagePath !== null &&
            userProfileData.imagePath !== '' ? (
              <Image
                style={{
                  width: 100,
                  height: 100,
                  marginVertical: hp(2),
                  borderRadius: 10,
                }}
                source={{
                  // uri: baseUrl + '/' + userProfileData.imagePath,
                  uri: userProfileData.imagePath,
                  //priority: Image.priority.high,
                }}
                // source={require('../../../../../assets/images/DummyPerson.png')}
              />
            ) : (
              <Image
                style={{
                  width: hp(12),
                  height: hp(12),
                  borderRadius: 30,
                  marginVertical: hp(1),
                }}
                resizeMode="contain"
                source={require('../../../../../assets/images/user_logo.png')}
              />
            )}
          </View>
        </LinearGradient>
        <ScrollView
          contentContainerStyle={{
            // flex: 1,
            alignItems: 'center',
            paddingBottom: hp(4),
            // borderWidth: 1,
          }}>
          <View
            style={{
              // borderWidth: 1,
              width: '100%',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'flex-end',
            }}>
            {/* container with left margin */}
            <View
              style={{
                // borderWidth: 1,
                width: '95.5%',
                marginTop: hp(3),
              }}>
              {/* heading */}
              <Text
                style={{
                  fontFamily: Fonts.SourceSansSemibold,
                  fontWeight: '600',
                  fontSize: hp(2),
                  color: Colors.black4,
                }}>
                Demographics
              </Text>
              {/* single row */}
              {/* fname */}
              <View
                style={{
                  display: 'flex',
                  // borderWidth: 1,
                  flexDirection: 'row',
                  marginTop: hp(3),
                }}>
                <Image
                  style={{
                    width: hp(2),
                    height: hp(2),
                  }}
                  source={Images.personIconPlaceHolder}
                />
                <View style={{marginLeft: hp(1.8)}}>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontWeight: '400',
                      color: Colors.darkGrey,
                      fontSize: hp(1.7),
                    }}>
                    First Name
                  </Text>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontWeight: '400',
                      color: Colors.black,
                      fontSize: hp(2),
                      marginTop: hp(0.5),
                    }}>
                    {userProfileData?.firstName}
                  </Text>
                </View>
              </View>
              {/* lname */}
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  marginTop: hp(3),
                }}>
                <Image
                  style={{
                    width: hp(2),
                    height: hp(2),
                  }}
                  source={Images.personIconPlaceHolder}
                />
                <View style={{marginLeft: hp(1.8)}}>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontWeight: '400',
                      color: Colors.darkGrey,
                      fontSize: hp(1.7),
                    }}>
                    Last Name
                  </Text>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontWeight: '400',
                      color: Colors.black,
                      fontSize: hp(2),
                      marginTop: hp(0.5),
                    }}>
                    {userProfileData?.lastName}
                  </Text>
                </View>
              </View>
              {/* mail */}
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  marginTop: hp(3),
                }}>
                <Image
                  style={{
                    width: hp(2),
                    height: hp(2),
                  }}
                  source={Images.EmailIconBlack}
                />
                <View style={{marginLeft: hp(1.8)}}>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontWeight: '400',
                      color: Colors.darkGrey,
                      fontSize: hp(1.7),
                    }}>
                    Email
                  </Text>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontWeight: '400',
                      color: Colors.black,
                      fontSize: hp(2),
                      marginTop: hp(0.5),
                    }}>
                    {userProfileData?.email}
                  </Text>
                </View>
              </View>
              {/* phone */}
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  marginTop: hp(3),
                }}>
                <Image
                  style={{
                    width: hp(2),
                    height: hp(2),
                  }}
                  source={Images.call_Icon_Black}
                />
                <View style={{marginLeft: hp(1.8)}}>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontWeight: '400',
                      color: Colors.darkGrey,
                      fontSize: hp(1.7),
                    }}>
                    Phone
                  </Text>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontWeight: '400',
                      color: Colors.black,
                      fontSize: hp(2),
                      marginTop: hp(0.5),
                    }}>
                    {userProfileData?.phone}
                  </Text>
                </View>
              </View>
              {/* date of birth */}
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  marginTop: hp(3),
                }}>
                <Image
                  style={{
                    width: hp(2),
                    height: hp(2),
                  }}
                  source={Images.calenderBlack}
                />
                <View style={{marginLeft: hp(1.8)}}>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontWeight: '400',
                      color: Colors.darkGrey,
                      fontSize: hp(1.7),
                    }}>
                    Dob
                  </Text>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontWeight: '400',
                      color: Colors.black,
                      fontSize: hp(2),
                      marginTop: hp(0.5),
                    }}>
                    {console.log(
                      'profile ',
                      /^\d{2}\/\d{2}\/\d{4}$/.test(
                        userProfileData?.dateOfBirth,
                      ),
                    )}
                    {/^\d{2}\/\d{2}\/\d{4}$/.test(userProfileData?.dateOfBirth)
                      ? moment(
                          userProfileData?.dateOfBirth,
                          'MM/DD/YYYY HH:mm:ss',
                        ).format('MM/DD/YYYY')
                      : moment(userProfileData?.dateOfBirth).format(
                          'MM/DD/YYYY',
                        )}
                  </Text>
                </View>
              </View>
              {/* address */}
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  marginTop: hp(3),
                }}>
                <Image
                  style={{
                    width: hp(2),
                    height: hp(2),
                  }}
                  source={Images.homeIconProfileSignUp}
                />
                <View style={{marginLeft: hp(1.8)}}>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontWeight: '400',
                      color: Colors.darkGrey,
                      fontSize: hp(1.7),
                    }}>
                    Address
                  </Text>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontWeight: '400',
                      color: Colors.black,
                      fontSize: hp(2),
                      marginTop: hp(0.5),
                    }}>
                    {userProfileData?.address}
                  </Text>
                </View>
              </View>
              {/* gender */}
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  marginTop: hp(3),
                }}>
                <Image
                  style={{
                    width: hp(2.5),
                    height: hp(2.5),
                  }}
                  source={Images.genderIcon}
                  resizeMode="contain"
                />
                <View style={{marginLeft: hp(1.8)}}>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontWeight: '400',
                      color: Colors.darkGrey,
                      fontSize: hp(1.7),
                    }}>
                    Gender
                  </Text>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontWeight: '400',
                      color: Colors.black,
                      fontSize: hp(2),
                      marginTop: hp(0.5),
                    }}>
                    {userProfileData?.gender === '1'
                      ? 'Male'
                      : userProfileData?.gender === '2'
                      ? 'Female'
                      : ''}
                  </Text>
                </View>
              </View>

              {/* seperator */}
              <View
                style={{
                  borderTopWidth: 1,
                  borderColor: Colors.line,
                  width: '94%',
                  marginTop: hp(3),
                }}
              />
              {userProfileData?.isAcoPatient === true ? (
                <View>
                  {/* second heading */}
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansSemibold,
                      fontWeight: '600',
                      fontSize: hp(2),
                      color: Colors.black4,
                      marginTop: hp(2),
                    }}>
                    Clinical Information
                  </Text>
                  {/* mrn */}
                  <View
                    style={{
                      display: 'flex',
                      flexDirection: 'row',
                      marginTop: hp(3),
                    }}>
                    <Image
                      style={{
                        width: hp(2.3),
                        height: hp(2.3),
                      }}
                      source={Images.mrnIconProfileSignUp}
                      resizeMode="contain"
                    />
                    <View style={{marginLeft: hp(1.8)}}>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansRegular,
                          fontWeight: '400',
                          color: Colors.darkGrey,
                          fontSize: hp(1.7),
                        }}>
                        MRN Number
                      </Text>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansRegular,
                          fontWeight: '400',
                          color: Colors.black,
                          fontSize: hp(2),
                          marginTop: hp(0.5),
                        }}>
                        {userProfileData?.referenceNumber}
                      </Text>
                    </View>
                  </View>
                  {/* insurance */}
                  <View
                    style={{
                      display: 'flex',
                      flexDirection: 'row',
                      marginTop: hp(3),
                    }}>
                    <Image
                      style={{
                        width: hp(1.9),
                        height: hp(1.9),
                      }}
                      source={Images.insurance}
                      resizeMode="contain"
                    />
                    <View style={{marginLeft: hp(1.8)}}>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansRegular,
                          fontWeight: '400',
                          color: Colors.darkGrey,
                          fontSize: hp(1.7),
                        }}>
                        Insurance Name
                      </Text>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansRegular,
                          fontWeight: '400',
                          color: Colors.black,
                          fontSize: hp(2),
                          marginTop: hp(0.5),
                        }}>
                        {userProfileData?.insuranceName}
                      </Text>
                    </View>
                  </View>
                  {/* insurance benifit */}
                  <View
                    style={{
                      display: 'flex',
                      flexDirection: 'row',
                      marginTop: hp(3),
                    }}>
                    <Image
                      style={{
                        width: hp(1.9),
                        height: hp(1.9),
                      }}
                      source={Images.insuranceBenifit}
                      resizeMode="contain"
                    />
                    <View style={{marginLeft: hp(1.8)}}>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansRegular,
                          fontWeight: '400',
                          color: Colors.darkGrey,
                          fontSize: hp(1.7),
                        }}>
                        Insurance Benefits
                      </Text>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansRegular,
                          fontWeight: '400',
                          color: Colors.black,
                          fontSize: hp(2),
                          marginTop: hp(0.5),
                        }}></Text>
                    </View>
                  </View>
                </View>
              ) : (
                <View
                  style={{
                    marginTop: hp(4),
                  }}></View>
              )}
            </View>
          </View>
        </ScrollView>
      </View>
    </>
  );
};

const mapStateToProps = ({userProfileData}) => ({
  userProfileData,
});
export default connect(mapStateToProps)(ProfileScreen);
