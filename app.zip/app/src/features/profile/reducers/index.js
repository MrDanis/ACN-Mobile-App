export const userProfileData = (state = {}, action) => {
  switch (action.type) {
    case 'GET_USER_PROFILE':
      return action.userDetail;
    default:
      return state;
  }
};
export const getUserSiganture = (state = {}, action) =>{
  switch (action.type) {
    case 'GET_USER-SIGNATURE':
       return action.signature;
    default:
      return state;
  }
}
