export const getUserProfile = userDetail => ({
  type: 'GET_USER_PROFILE',
  userDetail,
});
export const getSignature = signature => ({
  type:'GET_USER-SIGNATURE',
  signature
})