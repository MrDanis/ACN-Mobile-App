/* istanbul ignore file */
import React, {Fragment} from 'react';
import {View} from 'react-native';
import {heightPercentageToDP} from 'react-native-responsive-screen';
import {Colors} from '../../../../config';

export class MedicationIndicator extends React.PureComponent {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <Fragment>
        <View style={{flexDirection: 'row'}}>
          <View
            style={{
              width: heightPercentageToDP(7),
              height: 5,
              marginRight: heightPercentageToDP(5),
              borderRadius: 5,
              backgroundColor:
                this.props.index >= 1
                  ? Colors.blueTextColor
                  : Colors.lightGrey1,
            }}
          />
          <View
            style={{
              width: heightPercentageToDP(7),
              height: 5,
              marginRight: heightPercentageToDP(5),
              borderRadius: 5,
              backgroundColor:
                this.props.index >= 2
                  ? Colors.blueTextColor
                  : Colors.lightGrey1,
            }}
          />
          <View
            style={{
              width: heightPercentageToDP(7),
              height: 5,
              borderRadius: 5,
              backgroundColor:
                this.props.index >= 3
                  ? Colors.blueTextColor
                  : Colors.lightGrey1,
            }}
          />
        </View>
      </Fragment>
    );
  }
}
