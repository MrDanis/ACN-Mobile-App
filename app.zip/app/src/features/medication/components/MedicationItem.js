/* istanbul ignore file */
import React, {Fragment, useState} from 'react';
import {Image, StyleSheet, Text, View} from 'react-native';
import {
  heightPercentageToDP,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {Fonts} from '../../../../config/AppConfig';
import Colors from '../../../../config/Colors';

import Images from '../../../../config/Images';

var myProps = null;
const MedicationItem = props => {
  console.log('Props at the medication item is : ',props,' and dose timings are : ',props.item.doseTimings[0]);
  const [image, setimage] = useState({uri: props.item.fdaMedicine.imagePath});

  onError = error => {
    console.log(error);
    this.setState({image: Images.noImageFound});
  };
  /* istanbul ignore next */

  let doseTime = props.item.doseTimings[0];
  return (
    <Fragment>
      <View
        style={{
          borderRadius: 10,
          width: '95%',
          marginLeft: hp(1),
          marginBottom: hp(2),
          shadowOffset: {width: 0.5, height: 0.5},
          shadowOpacity: 0.1,
          shadowRadius: 8,
          elevation: 3,
          backgroundColor: Colors.white,
          flexDirection: 'row',
          alignItems: 'center',
          padding: hp(2),
          borderWidth:0,
          borderColor:'red'
        }}>
        <Image
          style={{
            width: 50,
            height: 50,
            borderRadius: 10,
            alignSelf: 'center',
            marginRight: hp(1),
          }}
          source={Images.medIcon4x}
        />

        <View style={{flexDirection: 'column', flex: 1}}>
          <View style={{flexDirection: 'row'}}>
            <Text
              numberOfLines={1}
              style={{
                fontFamily: Fonts.SourceSansRegular,
                marginLeft: heightPercentageToDP(2),
                fontSize: hp(2.2),
                flex: 1,
                color: Colors.black4,
                textTransform: 'capitalize',
                maxWidth: '85%',
                height: 'auto',
              }}>
              {props.item.fdaMedicine.proprietaryname}
            </Text>
          </View>

          <View
            style={{
              flexDirection: 'row',
              marginLeft: heightPercentageToDP(2),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2),
                marginRight: hp(0.5),
                color: Colors.noRecordFound,
              }}>
              {props.item.frequencyInDays}
            </Text>
            <View
              style={{
                height: 8,
                width: 8,
                alignSelf: 'center',
                marginHorizontal: hp(0.5),
                backgroundColor: Colors.textFieldGrey,
                borderRadius: 4,
              }}
            />
            <Text
              style={{
                marginLeft: hp(0.5),
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2),
                color: Colors.noRecordFound,
              }}>
              {props.item.mealStatus === false ? 'Before Meal' : 'After Meal'}
            </Text>
          </View>
        </View>

        {props.item.doseTimings[0] &&
        props.item.statusLogs[doseTime].length === 0 ? (
          <View
            style={{
              backgroundColor: Colors.pilered,
              borderRadius: 20,
              marginTop: hp(-2),
            }}>
            <Text
              style={{
                color: Colors.white,
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(1.5),
                paddingVertical: hp(0.5),
                paddingHorizontal: hp(0.8),
              }}>
              Not Taken
            </Text>
          </View>
        ) : null}
        {props.item.statusLogs === null ? null : props.item.doseTimings[0] &&
          props.item.statusLogs[doseTime].length > 0 &&
          props.item.statusLogs[doseTime][0].taken === true ? (
          <View
            style={{
              backgroundColor: Colors.badgeGreen,
              borderRadius: 20,
            }}>
            <Text
              style={{
                color: Colors.white,
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(1.5),
                paddingVertical: hp(0.3),
                paddingHorizontal: hp(0.8),
              }}>
              Taken
            </Text>
          </View>
        ) : null}
      </View>
    </Fragment>
  );
};

export default MedicationItem;

const styles = StyleSheet.create({
  leftAction: {
    flex: 1,
    backgroundColor: '#497AFC',
    justifyContent: 'center',
  },
  actionText: {
    color: Colors.black,
    fontSize: 16,
    backgroundColor: 'transparent',
    padding: 10,
  },
  rightAction: {
    alignItems: 'center',
    flex: 1,
    justifyContent: 'center',
    borderRadius: 10,
    backgroundColor: Colors.bleLayer4,
  },
});
