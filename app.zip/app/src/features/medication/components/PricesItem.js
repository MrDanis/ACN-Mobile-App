/* istanbul ignore file */
import React, {Fragment} from 'react';
import {
  Image,
  Linking,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import RNAndroidLocationEnabler from 'react-native-android-location-enabler';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {Fonts} from '../../../../config/AppConfig';
import Colors from '../../../../config/Colors';
import images from '../../../../config/Images';

export default class PricesItem extends React.PureComponent {
  constructor(props) {
    super(props);
  }

  getUserLocation() {
    if (Platform.OS === 'android' && RNAndroidLocationEnabler) {
      RNAndroidLocationEnabler.promptForEnableLocationIfNeeded({
        interval: 10000,
        fastInterval: 5000,
      })
        .then(data => {
          console.log('====================================');
          console.log('data location', data);
          console.log('====================================');
          let url = `https://www.google.com/maps/search/?api=1&query=${this.props.item.pharmacy}, ${this.props.locationData.principalSubdivision} ${this.props.locationData.postcode}, ${this.props.locationData.countryCode}`;
          Linking.openURL(url);

          // The user has accepted to enable the location services
          // data can be :
          //  - "already-enabled" if the location services has been already enabled
          //  - "enabled" if user has clicked on OK button in the popup
        })
        .catch(err => {
          console.log('====================================');
          console.log('err in loc', err);
          console.log('====================================');
          // The user has not accepted to enable the location services or something went wrong during the process
          // "err" : { "code" : "ERR00|ERR01|ERR02|ERR03", "message" : "message"}
          // codes :
          //  - ERR00 : The user has clicked on Cancel button in the popup
          //  - ERR01 : If the Settings change are unavailable
          //  - ERR02 : If the popup has failed to open
          //  - ERR03 : Internal error
        });
    }
  }

  render() {
    return (
      <Fragment>
        <View style={styles.container}>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'center',
              flex: 1,
            }}>
            <Image
              source={images.pharmacyIcon}
              style={{width: hp(5), height: hp(5)}}
            />
            <View
              style={{
                flexDirection: 'column',
                flex: 1,
                width: '90%',
              }}>
              <View style={{flexDirection: 'row'}}>
                <Text
                  style={{
                    fontSize: hp(2),
                    marginLeft: hp(1),
                    fontFamily: Fonts.SourceSansSemibold,
                    color: Colors.black,
                  }}>
                  {this.props.item.pharmacy}
                </Text>
                <Text
                  style={{
                    fontSize: hp(1.7),
                    alignSelf: 'center',
                    paddingLeft: hp(1),
                    flex: 1,
                    fontFamily: Fonts.SourceSansSemibold,
                    color: Colors.blueRxColor,
                  }}>
                  {this.props.item.savings} OFF
                </Text>
              </View>

              <View style={{flexDirection: 'row', marginTop: hp(0)}}>
                <Text
                  style={{
                    fontSize: hp(2.2),
                    paddingLeft: hp(1),
                    fontFamily: Fonts.SourceSansSemibold,
                    color: Colors.red2,
                  }}>
                  ${this.props.item.price}
                </Text>
                {this.props.item.retail_price !== null ? (
                  <Text
                    style={{
                      fontSize: hp(2),
                      fontFamily: Fonts.SourceSansSemibold,
                      color: Colors.black3,
                      alignSelf: 'center',
                      textDecorationLine: 'line-through',
                      textDecorationStyle: 'solid',
                      marginLeft: hp(1),
                      marginRight: hp(1),
                    }}>
                    ${this.props.item.retail_price}
                  </Text>
                ) : (
                  <Text style={{flex: 1}} />
                )}
              </View>
            </View>
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.navigate('Coupon', {
                  item: this.props.item,
                });
              }}>
              <Image source={images.couponIcon} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => {
                this.getUserLocation();
              }}>
              <Image
                source={images.navigationIcon}
                style={{marginLeft: hp(1)}}
              />
            </TouchableOpacity>
          </View>
        </View>
      </Fragment>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    width: '95%',
    marginTop: hp(2.5),
    marginLeft: hp(1),
    backgroundColor: Colors.white,
    borderRadius: 10,
    padding: hp(2),
    shadowOffset: {width: 0.05, height: 0.05},
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 3,
    flexDirection: 'row',
  },
  image: {
    width: 50,
    height: 50,
    borderRadius: 50 / 2,
    alignSelf: 'center',
    marginRight: hp(1),
  },
  circleShape: {
    width: hp(4),
    height: hp(4),
    borderRadius: hp(4) / 2,
    backgroundColor: Colors.lightGrey,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modal: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.white,
    padding: hp(2),
    width: '90%',
    borderRadius: 3,
  },
});
