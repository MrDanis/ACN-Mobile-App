import { View, Text, Pressable, SafeAreaView,ScrollView ,Image} from 'react-native'
import React,{useEffect,useState} from 'react'
import {heightPercentageToDP,  heightPercentageToDP as hp} from 'react-native-responsive-screen';
import MainHeader from '../../mycare/components/MainHeader'
import colors from '../../../../config/Colors'
import { Fonts } from '../../../../config/AppConfig';
import images from '../../../../config/Images';
const MedicationReminders = ({navigation,route}) => {
    const [isReminderActiveList,setisReminderActiveList] = useState({data:route?.params?.MedicationList ,selectedTab:'Add'});
    const handleAddMedicationForReminder = () =>{

    }
    useEffect(()=>{
        let ListSeprator = isReminderActiveList.data.map((item,index)=> { return{...item,isReminderActive:index%2===0?true:false}});
        console.log('Reminder Seprated list is : ',ListSeprator);
    },[])
    console.log('Medicines list for the reminder is  ',route?.params?.MedicationList)
    return (
        <SafeAreaView style={{flex:1,backgroundColor: colors.BgColor}}>
             <MainHeader
             name="Reminders" navigation={navigation}
             >
                <View style={{width:'100%',padding:hp(1.5),display:'flex',alignItems:'center',justifyContent:'space-between',flexDirection:'row',gap:hp(1),borderColor:'red',borderWidth:0}}>
                       <Pressable 
                           onPress={()=>{setisReminderActiveList({...isReminderActiveList,selectedTab:'Add'})}}
                           style={{flex:1,padding:hp(1.25),borderRadius:4,backgroundColor:isReminderActiveList.selectedTab === 'Add'?colors.TextColor:'transparent',borderWidth:1,borderColor:isReminderActiveList.selectedTab !== 'Add'?colors.TextColor:'transparent'}}>
                              <Text style={{color:isReminderActiveList.selectedTab !== 'Add'?colors.TextColor:colors.white,fontSize:hp(2),textAlign:'center'}}>
                                Add Reminder
                              </Text>
                       </Pressable>
                       <Pressable 
                         onPress={()=>{setisReminderActiveList({...isReminderActiveList,selectedTab:'Remove'})}}
                         style={{flex:1,padding:hp(1.25),borderRadius:4,backgroundColor:isReminderActiveList.selectedTab === 'Remove'?colors.TextColor:'transparent',borderWidth:1,borderColor:isReminderActiveList.selectedTab !== 'Remove'?colors.TextColor:'transparent'}}>
                              <Text style={{color:isReminderActiveList.selectedTab !== 'Remove'?colors.TextColor:colors.white,fontSize:hp(2),textAlign:'center'}}>
                                Remove Reminder
                              </Text>
                       </Pressable>
                     
                </View>
             <ScrollView style={{flex:1,borderColor:'green',borderWidth:1}}>
           {
        isReminderActiveList?.data.map((item,index)=>{
            return(
              <View
              key={index}
              style={{
                borderRadius: 10,
                width: '95%',
                marginLeft: hp(1),
                marginBottom: hp(2),
                shadowOffset: {width: 0.5, height: 0.5},
                shadowOpacity: 0.1,
                shadowRadius: 8,
                elevation: 3,
                backgroundColor: colors.white,
                flexDirection: 'row',
                alignItems: 'center',
                padding: hp(2),
                borderWidth:1,
                borderColor:'red'
              }}>
            {
                console.log('Item in the list is : ',JSON.stringify(item))
            }
        <Image
          style={{
            width: 50,
            height: 50,
            borderRadius: 10,
            alignSelf: 'center',
            marginRight: hp(1),
          }}
          source={images.medIcon4x}
        />

        <View style={{flexDirection: 'column', flex: 1}}>
          <View style={{flexDirection: 'row'}}>
            <Text
              numberOfLines={1}
              style={{
                fontFamily: Fonts.SourceSansRegular,
                marginLeft: heightPercentageToDP(2),
                fontSize: hp(2.2),
                flex: 1,
                color: colors.black4,
                textTransform: 'capitalize',
                maxWidth: '85%',
                height: 'auto',
              }}>
              {item?.fdaMedicine?.proprietaryname}
            </Text>
          </View>

          <View
            style={{
              flexDirection: 'row',
              marginLeft: heightPercentageToDP(2),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2),
                marginRight: hp(0.5),
                color: colors.noRecordFound,
              }}>
              {item?.frequencyInDays}
            </Text>
           
        </View>

        </View>

      
        
              </View>
              )
            })
           }
             </ScrollView>
             </MainHeader>
           {/* <View>
           <Pressable 
           onPress={()=>{
           navigation.pop()
           }}>
            <Text>
                Go Back
            </Text>
           </Pressable>
           <Text>MedicationReminders</Text>
           </View> */}

        </SafeAreaView>
  )
}

export default MedicationReminders