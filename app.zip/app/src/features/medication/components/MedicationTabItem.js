import React from 'react';
import {Image, Platform, Text, View} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {connect} from 'react-redux';
import {Fonts} from '../../../../config/AppConfig';
import Colors from '../../../../config/Colors';

import {TouchableOpacity} from 'react-native-gesture-handler';

const MedicationTabItem = props => {
  return (
    <TouchableOpacity onPress={props.navigation}>
      <View
        style={{
          backgroundColor: Colors.white,
          borderRadius: 8,
          height: hp(8),
          shadowOffset: {width: 0.5, height: 0.5},
          shadowOpacity: 0.1,
          shadowRadius: 8,
          elevation: Platform.OS === 'ios' ? 10 : 0,
          justifyContent: 'flex-start',
          marginHorizontal: hp(1),
          marginVertical: hp(2),
          flexDirection: 'row',
          alignItems: 'center',
        }}>
        <View style={{}}>
          <Image
            style={{
              width: 40,
              height: 40,
              marginLeft: hp(1.5),
              marginRight: hp(1.5),
            }}
            source={props.iconimage}
          />
        </View>
        <Text
          style={{
            marginRight: hp(2.5),
            marginTop: hp(1),
            fontFamily: Fonts.SourceSansRegular,
            color: Colors.black,
            fontSize: 14,
          }}>
          {props.name}
        </Text>
      </View>
    </TouchableOpacity>
  );
};
export default connect()(MedicationTabItem);
