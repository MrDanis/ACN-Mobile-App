/* istanbul ignore file */
import moment from 'moment';
import React, {Fragment} from 'react';
import {Text, TouchableOpacity, View} from 'react-native';
import {
  heightPercentageToDP,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {Fonts} from '../../../../config/AppConfig';
import Colors from '../../../../config/Colors';

export class MedicationTargetCompleted extends React.PureComponent {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <Fragment>
        <View style={{flex: 1}}>
          <TouchableOpacity
            onPress={() => {
              this.props.myProps.navigation.navigate('AllMedication');
            }}
            style={{flexDirection: 'row', marginTop: hp(2)}}>
            <Text
              style={{
                fontFamily: Fonts.NunitoBold,
                fontSize: hp(2.2),
                marginLeft: hp(2),
                flex: 1,
                color: Colors.black1,
              }}
            />
            <Text
              style={{
                textAlign: 'center',
                fontFamily: Fonts.NunitoSemiBold,
                marginLeft: heightPercentageToDP(2),
                fontSize: hp(2),
                color: Colors.blueHeadingColor,
              }}>
              View All
            </Text>
            <Text
              style={{
                fontFamily: 'WisemanPTSymbols',
                marginLeft: hp(1),
                marginRight: heightPercentageToDP(2),
                fontSize: hp(3),
                color: Colors.black3,
                alignSelf: 'center',
              }}>
              X
            </Text>
          </TouchableOpacity>

          <View
            style={{
              marginTop: hp(7),
              alignSelf: 'center',
              height: 400,
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <Text
              style={{
                textAlign: 'center',
                fontFamily: Fonts.SourceSansBold,
                marginLeft: heightPercentageToDP(5),
                marginRight: heightPercentageToDP(5),
                fontSize: 24,
                color: Colors.blueHeadingColor,
              }}>
              No More Medication for Today
            </Text>
            <Text
              style={{
                textAlign: 'center',
                fontFamily: Fonts.NunitoRegular,
                marginTop: heightPercentageToDP(3.5),
                marginLeft: heightPercentageToDP(5),
                marginRight: heightPercentageToDP(5),
                fontSize: 14,
                color: '#BDBDBD',
              }}>
              {moment(new Date()).format('LLLL')}
            </Text>
          </View>
        </View>
      </Fragment>
    );
  }
}
