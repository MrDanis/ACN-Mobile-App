/* istanbul ignore file */
import Moment from 'moment';
import React, {Fragment} from 'react';
import {
  FlatList,
  Image,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {
  heightPercentageToDP,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import images from '../../../../../app/config/Images';

import {BlurView} from '@react-native-community/blur';

import {showMessage} from 'react-native-flash-message';
import {Swipeable} from 'react-native-gesture-handler';
import Modal from 'react-native-modal';
import {Modalize} from 'react-native-modalize';
import {connect} from 'react-redux';
import AddMed from '../../../../../assets/svg/AddMed.svg';
import {Images} from '../../../../config';
import {Fonts} from '../../../../config/AppConfig';
import Colors from '../../../../config/Colors';
import MedicationService from '../../../api/medication';
import {convertUTCDateToLocalDate, getDayTime} from '../../../helpers/Common';
import {
  cancelReminder,
  isReminderSet,
  scheduleNotificationx,
} from '../../../helpers/NotificationHandler';
import MedicationItem from '../../medication/components/MedicationItem';
import {modalHanlder} from '../actions';
import {DayTime} from '../constants';
import MedicationTabItem from './MedicationTabItem';
import AsyncStorage from '@react-native-async-storage/async-storage';
import svgs from '../../../../config/Svgs';
import {SvgXml} from 'react-native-svg';
import {scheduleDailyNotification} from '../../../helpers/notifee';
import ToggleSwitch from 'toggle-switch-react-native';
import colors from '../../../../config/Colors';
class MedicationDashboard extends React.PureComponent {
  swipeableRef = React.createRef();
  constructor(props) {
    super(props);
    this.swipeableRef1 = [];
    this.swipeableRef2 = [];
    this.swipeableRef3 = [];
    this.state = {
      morning: true,
      noon: false,
      EVENING: false,
      modalVisible: false,
      morningArray: [],
      noonArray: [],
      eveningArray: [],
      nightArray: [],
      dayTime: DayTime.MORNING,
      dataArrayLength: 0,
      morningPlateCount: [],
      noonPlateCount: [],
      eveningPlateCount: [],
      nightPlateCount: [],
      todayHeading: 'Medicine to take',
      currentTime: new Date(),
      currentItem: {},
      refreshing: false,
      date: new Date(),
      isOpen: false,
      timeSelected: {},
      medSelected: {},
      timeToSchedule: 0,
      storedTimeToTest: {},
      selectedItem: null,
      morningReminders: {},
      noonReminders: {},
      nightReminders: {},
      reminderTyp: '',
      currentIndexSwipable: 0,
      reminderMorning: false,
      reminderNoon: false,
      reminderEvening: false,
    };
  }
  timeArray = [
    {id: 9, time: '08:00'},
    {id: 10, time: '09:00'},
    {id: 11, time: '10:00'},
    {id: 12, time: '11:00'},
    {id: 13, time: '12:00'},
    {id: 14, time: '13:00'},
    {id: 15, time: '14:00'},
    {id: 16, time: '15:00'},
    {id: 17, time: '16:00'},
    {id: 18, time: '17:00'},
    {id: 19, time: '18:00'},
    {id: 20, time: '19:00'},
    {id: 21, time: '20:00'},
    {id: 22, time: '21:00'},
    {id: 23, time: '22:00'},
    {id: 24, time: '23:00'},
  ];
  /* istanbul ignore next */

  componentDidMount(): void {
    this.getTodayMedicationData(this.props.allTodayMedicationData);
    this.setState({dataArrayLength: this.props.allTodayMedicationData.length});
  }
  componentWillReceiveProps(nextProps: Readonly<P>, nextContext: any): void {
    this.getTodayMedicationData(this.props.allTodayMedicationData);
  }

  componentDidUpdate(
    prevProps: Readonly<P>,
    prevState: Readonly<S>,
    snapshot: SS,
  ): void {
    if (
      prevProps.allTodayMedicationData.length !==
      this.props.allTodayMedicationData.length
    ) {
      this.getTodayMedicationData(this.props.allTodayMedicationData);
    }
  }
  // checkReminders = async (dataArray, reminderKey) => {
  //   console.log('inside checkReminders', dataArray, reminderKey);
  //   dataArray.forEach(async item => {
  //     const isSet = await isReminderSet(item.fdaMedicine?.productid);
  //     this.setState(prevState => ({
  //       [reminderKey]: {
  //         ...prevState[reminderKey],
  //         [item.fdaMedicine?.productid]: isSet,
  //       },
  //     }));
  //   });
  // };
  checkReminders = async (dataArray, reminderKey) => {
    console.log('inside checkReminders', dataArray, reminderKey);

    // Map through the data and check if a reminder is set for each item
    const reminderChecks = await Promise.all(
      dataArray.map(async item => {
        const isSet = await isReminderSet(item.fdaMedicine?.productid);
        return {id: item.fdaMedicine?.productid, isSet};
      }),
    );

    // Update state in one go after all reminders are checked
    this.setState(prevState => ({
      [reminderKey]: reminderChecks.reduce((acc, reminder) => {
        acc[reminder.id] = reminder.isSet;
        return acc;
      }, {}),
    }));

    console.log('Reminders after update:', this.state[reminderKey]);
  };
  handleBackButtonClick() {
    this.props.navigation.goBack(null);
    return true;
  }

  async getTodayMedicationData(data) {
    try {
      var date = convertUTCDateToLocalDate(new Date());
      console.log('time local********');
      console.log(date.getUTCHours(), date.getUTCMinutes());
      console.log(getDayTime(date.getUTCHours() + ':' + date.getUTCMinutes()));
      this.setState({
        dayTime: getDayTime(date.getUTCHours() + ':' + date.getUTCMinutes()),
      });
      let reminderIds = await AsyncStorage.getItem('reminderIds');
      reminderIds = reminderIds ? JSON.parse(reminderIds) : [];
      console.log('Reminder IDs:', reminderIds);
      var morningData = [];
      var noonData = [];
      var eveningData = [];
      this.setState({showLoader: false});
      console.log('dashboardGetTodayMedication');
      console.log(data);
      let tempData = [...data];
      let morningTempArray = [];
      let eveningTempArray = [];
      let nonTempArray = [];
      console.log('Temp data is ');
      tempData.forEach(item => {
        // Check each slot in medicationSlot array
        item.medicationSlot.forEach(slot => {
          // Append the slot value to the productid before categorizing
          // item.fdaMedicine.productid = item.fdaMedicine.productid + "_" + slot;
          const itemCopy = JSON.parse(JSON.stringify(item));
          if (slot === 0) {
            morningTempArray.push(itemCopy);
          } else if (slot === 1) {
            nonTempArray.push(itemCopy);
          } else if (slot === 2) {
            eveningTempArray.push(itemCopy);
          }
        });
      });
      // console.log('Before====================================');
      // console.log('morningTempArray', morningTempArray);
      // console.log('morningTempArray', eveningTempArray);
      // console.log('morningTempArray', nonTempArray);
      const morningTempArrayCopy = JSON.parse(JSON.stringify(morningTempArray)); //morningTempArray.map(item => ({ ...item }));
      const noonTempArrayCopy = JSON.parse(JSON.stringify(nonTempArray)); //nonTempArray.map(item => ({ ...item }));
      const eveningTempArrayCopy = JSON.parse(JSON.stringify(eveningTempArray)); //nonTempArray.map(item => ({ ...item }));
      console.log('====================================');
      // console.log(morningTempArrayCopy[i].fdaMedicine.productid.split('_'),'reminders of morning :',morningTempArrayCopy[i].fdaMedicine.productid)
      for (let i = 0; i < morningTempArrayCopy.length; i++) {
        console.log(morningTempArrayCopy[i].fdaMedicine.productid);
        if (
          morningTempArrayCopy[i].fdaMedicine.productid?.split('_').length > 0
        ) {
          morningTempArrayCopy[i].fdaMedicine.productid = `${
            morningTempArrayCopy[i].fdaMedicine.productid.split('_')[0]
          }_0`;
          // console.log(morningTempArrayCopy[i].fdaMedicine.productid,'M',`${morningTempArrayCopy[i].fdaMedicine.productid.split('_')[0]}_0`);
        } else {
          morningTempArrayCopy[
            i
          ].fdaMedicine.productid = `${morningTempArrayCopy[i].fdaMedicine.productid}_0`;
        }
      }
      for (let i = 0; i < noonTempArrayCopy.length; i++) {
        // console.log(noonTempArrayCopy[i].fdaMedicine.productid.split('_'),'reminders of morning :',noonTempArrayCopy[i].fdaMedicine.productid);
        if (noonTempArrayCopy[i].fdaMedicine.productid?.split('_').length > 0) {
          noonTempArrayCopy[i].fdaMedicine.productid = `${
            noonTempArrayCopy[i].fdaMedicine.productid.split('_')[0]
          }_1`;
          // console.log(noonTempArrayCopy[i].fdaMedicine.productid,'M',`${noonTempArrayCopy[i].fdaMedicine.productid.split('_')[0]}_1`);
        } else {
          noonTempArrayCopy[
            i
          ].fdaMedicine.productid = `${noonTempArrayCopy[i].fdaMedicine.productid}_1`;
        }
      }
      for (let i = 0; i < eveningTempArrayCopy.length; i++) {
        // console.log(eveningTempArrayCopy[i].fdaMedicine.productid.split('_'),'reminders of morning :',eveningTempArrayCopy[i].fdaMedicine.productid);
        if (
          eveningTempArrayCopy[i].fdaMedicine.productid?.split('_').length > 0
        ) {
          eveningTempArrayCopy[i].fdaMedicine.productid = `${
            eveningTempArrayCopy[i].fdaMedicine.productid.split('_')[0]
          }_2`;
          // console.log(eveningTempArrayCopy[i].fdaMedicine.productid,'M',`${eveningTempArrayCopy[i].fdaMedicine.productid.split('_')[0]}_2`);
        } else {
          eveningTempArrayCopy[
            i
          ].fdaMedicine.productid = `${eveningTempArrayCopy[i].fdaMedicine.productid}_2`;
        }
      }
      for (let i = 0; i < morningTempArrayCopy.length; i++) {
        let isSet = reminderIds.includes(
          morningTempArrayCopy[i].fdaMedicine?.productid,
        );
        let tempMorObj = {...morningTempArrayCopy[i], isSet};
        morningData.push(tempMorObj);
      }
      for (let i = 0; i < noonTempArrayCopy.length; i++) {
        let isSet = reminderIds.includes(
          noonTempArrayCopy[i].fdaMedicine?.productid,
        );
        let tempNonObj = {...noonTempArrayCopy[i], isSet};
        noonData.push(tempNonObj);
      }
      for (let i = 0; i < eveningTempArrayCopy.length; i++) {
        let isSet = reminderIds.includes(
          eveningTempArrayCopy[i].fdaMedicine?.productid,
        );
        let tempEvnObj = {...eveningTempArrayCopy[i], isSet};
        eveningData.push(tempEvnObj);
      }
      console.log('morningTempArray', morningTempArrayCopy);
      console.log('noonTempArray', noonTempArrayCopy);
      console.log('eveningTempArray', eveningTempArrayCopy);
      // morningTempArray = [...morningTempArray];
      // for(let i =0; i<eveningTempArray.length; i++) {
      //   eveningTempArray[i].fdaMedicine.productid = `${eveningTempArray[i].fdaMedicine.productid}_2`;
      //   console.log('reminders of evening :',eveningTempArray[i].fdaMedicine.productid)
      // }
      // console.log('morningTempArray', eveningTempArray);
      // for(let i =0; i<nonTempArray.length; i++) {
      //   console.log('reminders of noon :',nonTempArray[i].fdaMedicine.productid)
      //   nonTempArray[i].fdaMedicine.productid = `${nonTempArray[i].fdaMedicine.productid}_3`;
      // }
      // console.log('====================================');
      // console.log('morningTempArray', nonTempArray);
      // console.log('====================================');
      // data.forEach(x => {
      //   x.medicationSlot.forEach(slot => {
      //     // Check if the reminder is set
      //     console.log('Slot in the medication is : ', slot);
      //     const isSet = reminderIds.includes(x.fdaMedicine?.productid);

      //     // Add isSet property to the medication object
      //     const medicationWithReminder = { ...x, isSet };

      //     // Sort the medication based on slot
      //     if (slot === 0) {
      //       morningData.push(medicationWithReminder);
      //     }
      //     if (slot === 1) {
      //       noonData.push(medicationWithReminder);
      //     }
      //     if (slot === 2) {
      //       eveningData.push(medicationWithReminder);
      //     }
      //   });
      // });
      // console.log('====================================');
      // console.log('morningData', morningData);
      // console.log('====================================');
      // console.log('====================================');
      // console.log('noonData', noonData);
      // console.log('====================================');
      // console.log('====================================');
      // console.log('eveningData', eveningData);
      // console.log('====================================');
      this.setState({
        morningArray: morningData,
        noonArray: noonData,
        eveningArray: eveningData,
      });
    } catch (error) {
      console.error('Error in getTodayMedicationData:', error);
    }
  }
  /* istanbul ignore next */

  _onRefresh = () => {
    console.log('refresh ran onrefresh');
    this.props.todayMedication();
  };
  setDate() {
    this.props.date = Moment(new Date()).format('yyyy-MM-DDThh:mm:ss');
  }

  showFrequencyDays(Days) {
    const Frequency = Days;

    if (Frequency === 1) {
      return 'Daily';
    } else if (Frequency === 7) {
      return 'Weekly';
    } else if (Frequency === 30) {
      return 'Monthly';
    } else {
      return 'Every ' + Frequency + ' Days';
    }
  }
  onOpen() {
    this.refs.modalize.open();
    this.props.dispatch(modalHanlder(false));
  }

  onClose() {
    this.refs.modalize.close();
    this.setState({autoHeight: true});
  }
  clearData = () => {
    this.setState({
      timeSelected: {},
      timeToSchedule: 0,
    });
    console.log(
      'data dumped',
      this.state.reminderTyp,
      this.state.currentIndexSwipable,
    );
    if (this.state.reminderTyp === 'morningReminders') {
      this.swipeableRef1[this.state.currentIndexSwipable]?.close();
    } else if (this.state.reminderTyp === 'noonReminders') {
      this.swipeableRef2[this.state.currentIndexSwipable]?.close();
    } else if (this.state.reminderTyp === 'nightReminders') {
      this.swipeableRef3[this.state.currentIndexSwipable]?.close();
    }
  };
  async setReminder() {
    console.log(
      this.state.timeSelected.time,
      'Time to take the medication is : ',
      this.state.timeToSchedule,
    );

    scheduleNotificationx(
      this.state.timeToSchedule,
      this.state.medSelected,
      this.state.timeSelected.time,
      () => this.clearData(),
      () => this._onRefresh(),
    );
  }
  calculateTimeDifference(givenTime, btnclick) {
    //Implemented by danish as per requirement from asad (START)
    const currentTime = new Date();
    const currentHours = currentTime.getHours();
    const currentMinutes = currentTime.getMinutes();
    // Extract hours and minutes from the given time
    const givenHours = parseInt(givenTime.time.split(':')[0], 10);
    const givenMinutes = parseInt(givenTime.time.split(':')[1], 10);
    // Convert both times to minutes for easier comparison
    const currentTotalMinutes = currentHours * 60 + currentMinutes;
    const givenTotalMinutes = givenHours * 60 + givenMinutes;
    // Calculate the time difference in minutes
    let timeDifference = givenTotalMinutes - currentTotalMinutes;
    // If the given time has already passed, add 24 hours (in minutes)
    console.log('now the value is setting to before ', timeDifference);

    if (timeDifference < 0) {
      timeDifference += 24 * 60; // 24 hours in minutes
    }
    if (btnclick) {
      this.setState({
        timeToSchedule: timeDifference,
        storedTimeToTest: givenTime,
      });
      return false;
    }
    return false;
  }
  setModalVisible() {
    this.setState({modalVisible: !this.state.modalVisible});
  }
  renderRightAction = (x, progress, item, time, reminderType, index) => {
    const trans = progress.interpolate({
      inputRange: [0, 1],
      outputRange: [x, 0],
    });
    const reminders = this.state[reminderType] || {};
    const isSet = reminders[item.fdaMedicine?.productid] || false;
    // console.log(
    //   'hitu',
    //   item,
    //   isSet,
    //   'reminder type',
    //   reminderType,
    //   'index is',
    //   index,
    // );
    return (
      <View
        style={{
          flex: 1,
          transform: [{translateX: 0}],
          flexDirection: 'row',
          borderColor: 'red',
          borderWidth: 0,
        }}>
        {item.source === '2' && item.souce !== null ? (
          <Pressable
            style={styles.rightAction}
            onPress={() => {
              this.props.myProps.navigation.navigate('EditMedication', {
                medId: item.id,
              });
              this.setState({isOpen: true});
            }}>
            <Image
              style={{width: hp(3), height: hp(3)}}
              source={images.edit_image_colored}
            />
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(1.5),
                marginTop: hp(0.5),
                color: Colors.noRecordFound,
              }}>
              Edit
            </Text>
          </Pressable>
        ) : (
          <View></View>
        )}
        <Pressable
          style={styles.rightAction}
          onPress={() => {
            if (item.isSet) {
              cancelReminder(item.fdaMedicine.productid, this._onRefresh);
              if (reminderType === 'morningReminders') {
                this.swipeableRef1[index]?.close();
              } else if (reminderType === 'noonReminders') {
                this.swipeableRef2[index]?.close();
              } else if (reminderType === 'nightReminders') {
                this.swipeableRef3[index]?.close();
              }
            } else {
              this.setState({
                medSelected: item,
              });
              this.onOpen();
              this.setState({
                currentIndexSwipable: index,
              });
            }
          }}>
          <Image
            style={{width: hp(3), height: hp(3)}}
            source={item.isSet ? images.clockCancelIcon : images.clockIcon}
          />
          <Text
            style={{
              fontFamily: Fonts.SourceSansRegular,
              fontSize: hp(1.5),
              marginTop: hp(0.5),
              color: Colors.noRecordFound,
            }}>
            {item.isSet ? 'Cancel' : 'Set Time'}
          </Text>
        </Pressable>
        {item.source === '2' && (
          <Pressable
            style={[styles.rightAction, {backgroundColor: Colors.bleLayer4}]}
            onPress={() => {
              console.log('Item before sending to the backend is : ', item);
              var data = {};
              data.id = item.id;
              data.taken = true;
              data.mealStatus = item.mealStatus;
              data.doseTime = item.doseTimings[0]; //time;
              console.log(
                'here is the data before medication taken api call ',
                data,
              );
              MedicationService.UpdateTakenMedication(data)
                .then(response => {
                  console.log('UpdateTakenMedication');
                  console.log('UpdateTakenMedication respondo', response);

                  this.props.todayMedication();
                  console.log(response);
                  this.swipeableRef.current.close();
                })
                .catch(error => {
                  console.log(error);
                });
            }}>
            <Image source={images.TakenIcon} />
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(1.5),
                marginTop: hp(0.5),
                color: Colors.noRecordFound,
              }}>
              Taken
            </Text>
          </Pressable>
        )}
      </View>
    );
  };

  openSwipeableMorning = index => {
    if (this.swipeableRef1[index]) {
      this.swipeableRef1[index].openRight();
    }
  };
  openSwipeableNoon = index => {
    if (this.swipeableRef2[index]) {
      this.swipeableRef2[index].openRight();
    }
  };
  openSwipeableEvening = index => {
    if (this.swipeableRef3[index]) {
      this.swipeableRef3[index].openRight();
    }
  };

  renderRightActions = (progress, item, time, reminderType, index) => {
    this.setState({
      reminderTyp: reminderType,
    });

    return (
      <View
        style={{
          width: '50%',
          height: hp(10),
          marginRight: hp(2),
          marginLeft: -hp(1.5),
          backgroundColor: Colors.bleLayer4,
          borderRadius: 10,
        }}>
        {this.renderRightAction(160, progress, item, time, reminderType, index)}
      </View>
    );
  };

  render() {
    return (
      <Fragment>
        <Modalize
          ref="modalize"
          visible={this.state.modalVisible}
          backgroundColor={Colors.black2}
          // modalHeight={hp(40)}
          adjustToContentHeight
          withHandle={false}
          onClose={() => {
            this.props.dispatch(modalHanlder(true));
            this.setState({
              timeSelected: {},
              timeToSchedule: 0,
            });
          }}
          modalStyle={{
            borderTopRightRadius: 25,
            borderTopLeftRadius: 25,
          }}>
          {/* main container */}

          <View
            style={{
              backgroundColor: Colors.transparent,
              flex: 1,
              width: '100%',
              alignSelf: 'center',
              borderRadius: 10,
              alignItems: 'center',
              paddingBottom: hp(4),
              marginTop: hp(2.5),
            }}>
            {/* first container ahead */}
            <View style={{width: '100%'}}>
              <ScrollView>
                <Text
                  style={{
                    color: Colors.black4,
                    fontFamily: Fonts.SourceSansBold,
                    fontSize: hp(2.2),
                    marginLeft: hp(1.8),
                  }}>
                  Medicine
                </Text>
                <View
                  style={{
                    marginTop: hp(1.5),
                  }}>
                  <View
                    style={{
                      borderRadius: 10,
                      width: '92%',
                      marginLeft: hp(1.8),
                      marginBottom: hp(2),
                      shadowOffset: {width: 0.5, height: 0.5},
                      shadowOpacity: 0.1,
                      shadowRadius: 8,
                      elevation: 3,
                      backgroundColor: Colors.white,
                      flexDirection: 'row',
                      alignItems: 'center',
                      padding: hp(2),
                    }}>
                    <Image
                      style={{
                        width: 50,
                        height: 50,
                        borderRadius: 10,
                        alignSelf: 'center',
                        marginRight: hp(1),
                      }}
                      source={Images.medIcon4x}
                    />

                    <View style={{flexDirection: 'column', flex: 1}}>
                      <View style={{flexDirection: 'row'}}>
                        <Text
                          numberOfLines={1}
                          style={{
                            fontFamily: Fonts.SourceSansRegular,
                            marginLeft: heightPercentageToDP(2),
                            fontSize: hp(2.2),
                            flex: 1,
                            color: Colors.black4,
                            textTransform: 'capitalize',
                            maxWidth: '85%',
                            height: 'auto',
                          }}>
                          {this.state.medSelected?.fdaMedicine?.proprietaryname}
                        </Text>
                      </View>

                      <View
                        style={{
                          flexDirection: 'row',
                          marginLeft: heightPercentageToDP(2),
                        }}>
                        <Text
                          style={{
                            fontFamily: Fonts.SourceSansRegular,
                            fontSize: hp(2),
                            marginRight: hp(0.5),
                            color: Colors.noRecordFound,
                          }}>
                          {this.state.medSelected?.frequencyInDays}
                        </Text>
                        <View
                          style={{
                            height: 8,
                            width: 8,
                            alignSelf: 'center',
                            marginHorizontal: hp(0.5),
                            backgroundColor: Colors.textFieldGrey,
                            borderRadius: 4,
                          }}
                        />
                        <Text
                          style={{
                            marginLeft: hp(0.5),
                            fontFamily: Fonts.SourceSansRegular,
                            fontSize: hp(2),
                            color: Colors.noRecordFound,
                          }}>
                          {this.state.medSelected?.mealStatus === false
                            ? 'Before Meal'
                            : 'After Meal'}
                        </Text>
                      </View>
                    </View>
                  </View>
                </View>

                {/* seperator*/}

                <View style={{borderTopWidth: 1, borderColor: Colors.line}} />
                {/* <Text
                  style={{
                    color: Colors.black4,
                    fontFamily: Fonts.SourceSansSemibold,
                    fontSize: hp(2.2),
                    marginTop: hp(1.8),
                    marginLeft: hp(1.8),
                  }}>
                  Select your Time
                </Text> */}
                {/* <View
                  style={{
                    display: 'flex',
                    flexDirection: 'row',
                    flexWrap: 'wrap',
                    marginTop: hp(1.5),
                    marginHorizontal: hp(1),
                    justifyContent:
                      Platform.OS === 'ios' ? 'flex-start' : 'space-between',
                  }}>
                  {this.timeArray?.map(item => {
                    return (
                      <Pressable
                        onPress={() => {
                          console.log('selected time is', item);
                          // the button is pressed to passing true flag so the value is saved in state
                          this.calculateTimeDifference(item, true);
                          this.setState({
                            timeSelected: item,
                          });
                        }}>
                        <View
                          style={{
                            borderWidth: 1,
                            backgroundColor:
                              item.id === this.state.timeSelected?.id
                                ? Colors.blueTextColor
                                : Colors.bleLayer4,
                            // padding: hp(1.2),
                            width: hp(9),
                            height: hp(6),
                            borderColor: Colors.bleLayer3,
                            margin: hp(1),
                            display: 'flex',
                            flexDirection: 'row',
                            justifyContent: 'center',
                            alignItems: 'center',
                            borderRadius: hp(1.2),
                          }}>
                          <Text
                            style={{
                              textAlign: 'center',

                              color:
                                item.id === this.state.timeSelected?.id
                                  ? Colors.white
                                  : Colors.blueTextColor,
                              fontFamily: Fonts.SourceSansRegular,
                              fontSize: hp(2.2),
                            }}>
                            {item.time}
                          </Text>
                        </View>
                      </Pressable>
                    );
                  })}
                </View> */}
                <View
                  style={{
                    display: 'flex',
                    flexDirection: 'row',
                    flexWrap: 'wrap',
                    marginTop: hp(1.5),
                    marginHorizontal: hp(1),
                    justifyContent:
                      Platform.OS === 'ios' ? 'flex-start' : 'space-between',
                  }}>
                  {this.timeArray
                    ?.filter(item => {
                      const time = item.time;
                      if (this.state.morning) {
                        return time >= '08:00' && time <= '11:59'; // Morning: 00:00 to 11:59
                      } else if (this.state.noon) {
                        return time >= '12:00' && time <= '15:59'; // Noon: 12:00 to 16:59
                      } else if (this.state.EVENING) {
                        return time >= '16:00' && time <= '23:59'; // Evening: 17:00 to 23:59
                      }
                      return false; // Default case
                    })
                    .map(item => (
                      <Pressable
                        key={item.id}
                        onPress={() => {
                          console.log('selected time is', item);
                          this.calculateTimeDifference(item, true);
                          this.setState({
                            timeSelected: item,
                          });
                        }}>
                        <View
                          style={{
                            borderWidth: 1,
                            backgroundColor:
                              item.id === this.state.timeSelected?.id
                                ? Colors.blueTextColor
                                : Colors.bleLayer4,
                            width: hp(9),
                            height: hp(6),
                            borderColor: Colors.bleLayer3,
                            margin: hp(1),
                            display: 'flex',
                            flexDirection: 'row',
                            justifyContent: 'center',
                            alignItems: 'center',
                            borderRadius: hp(1.2),
                          }}>
                          <Text
                            style={{
                              textAlign: 'center',
                              color:
                                item.id === this.state.timeSelected?.id
                                  ? Colors.white
                                  : Colors.blueTextColor,
                              fontFamily: Fonts.SourceSansRegular,
                              fontSize: hp(2.2),
                            }}>
                            {item.time}
                          </Text>
                        </View>
                      </Pressable>
                    ))}
                </View>
                <View
                  style={{
                    borderRadius: hp(1),
                    marginTop: hp(4),
                    marginHorizontal: hp(2),
                    marginBottom: hp(1),
                  }}>
                  <TouchableOpacity
                    onPress={() => {
                      console.log('reminder presz');
                      if (
                        Object.keys(this.state.storedTimeToTest).length === 0 ||
                        this.state.timeToSchedule === 0
                      ) {
                        showMessage({
                          message: 'Error',
                          description: 'Select Time Slot First !',
                          type: 'default',
                          icon: {icon: 'info', position: 'left'},
                          backgroundColor: Colors.red,
                        });
                      } else if (
                        this.calculateTimeDifference(
                          this.state.storedTimeToTest,
                          true,
                        ) === false
                      ) {
                        this.setReminder();
                        this.setState({isOpen: false});
                        this.onClose();
                        showMessage({
                          message: 'Success',
                          description:
                            'Reminder has been set for requested medicine.',
                          type: 'default',
                          icon: {icon: 'info', position: 'left'},
                          backgroundColor: Colors.green,
                        });
                      }
                    }}
                    // onPress={() => {
                    //   scheduleDailyNotification();
                    //   this.setState({isOpen: false});
                    //   this.onClose();
                    // }}
                    style={{
                      borderRadius: hp(1),
                      height: hp(6.5),
                      display: 'flex',
                      flexDirection: 'row',
                      justifyContent: 'center',
                      alignItems: 'center',
                      backgroundColor: Colors.blueTextColor,
                    }}>
                    <Text
                      style={{
                        color: Colors.white,
                        fontFamily: Fonts.SourceSansSemibold,
                        fontSize: hp(2.2),
                      }}>
                      Set Reminder
                    </Text>
                  </TouchableOpacity>
                </View>
              </ScrollView>
            </View>
          </View>
        </Modalize>
        <Modal
          animationType="fade"
          transparent={true}
          visible={this.state.modalVisible}>
          <BlurView
            blurType="light"
            blurAmount={10}
            style={{
              flex: 1,
              justifyContent: 'center',
              alignItems: 'center',
              width: '100%',
            }}>
            <View style={styles.modalContainer}>
              <Text
                style={{
                  fontFamily: Fonts.SourceSansRegular,
                  marginLeft: heightPercentageToDP(2),
                  fontSize: hp(2.2),
                  flex: 1,
                  color: Colors.black4,
                  textTransform: 'capitalize',
                }}>
                {this.state.selectedItem?.fdaMedicine?.dosageformname}
              </Text>
              {/* Add your modal content here */}
            </View>
          </BlurView>
        </Modal>
        <View
          style={{
            flex: 1,
            backgroundColor: Colors.BgColor,
          }}>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              width: '95%',
              alignItems: 'center',
              alignSelf: 'center',
            }}>
            <View style={{flex: 1}}>
              <MedicationTabItem
                iconimage={images.prescriptionIcon}
                name={'Med List'}
                navigation={() => {
                  this.props.myProps.navigation.navigate('Prescriptions');
                }}
              />
            </View>
          </View>
          <View
            style={{
              height: '14%',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <View
              style={{
                width: '95%',
                height: '60%',
                flexDirection: 'row',
                justifyContent: 'space-between',
              }}>
              <TouchableOpacity
                onPress={() => {
                  this.setState({
                    EVENING: false,
                    morning: true,
                    noon: false,
                  });
                }}>
                <View
                  style={{
                    height: hp(7),
                    width: hp(13),
                    borderBottomWidth: 2,
                    borderBottomColor:
                      this.state.morning === true
                        ? Colors.blueTextColor
                        : Colors.transparent,
                    justifyContent: 'space-around',
                    alignItems: 'center',
                    justifyContent: 'center',
                    //
                  }}>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                    <Image
                      style={{
                        width: 17,
                        height: 17,
                      }}
                      source={images.sunIcon_dashboard}
                    />

                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansBold,
                        fontSize: hp(2),
                        color:
                          this.state.morning === true
                            ? Colors.blueTextColor
                            : Colors.black,
                        marginHorizontal: hp(0.5),
                        marginBottom: hp(0),
                      }}>
                      Morning
                    </Text>
                  </View>

                  <Text
                    style={{
                      color: Colors.label,
                      paddingTop: hp(0.5),
                      paddingBottom: hp(0.5),
                      fontSize: Platform.OS === 'android' ? hp(1.5) : hp(1.5),
                    }}>
                    {this.state.morningArray.length} Medication
                  </Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  this.setState({
                    EVENING: false,
                    morning: false,
                    noon: true,
                  });
                }}>
                <View
                  style={{
                    height: hp(7),
                    marginLeft: hp(2),
                    width: hp(14),
                    borderBottomWidth: 2,
                    borderBottomColor:
                      this.state.noon === true
                        ? Colors.blueTextColor
                        : Colors.transparent,
                    justifyContent: 'space-around',
                    alignItems: 'center',
                    justifyContent: 'center',
                    //
                  }}>
                  <View style={{flexDirection: 'row'}}>
                    <Image
                      style={{
                        width: 19,
                        height: 17,
                      }}
                      source={images.noon_icon}
                    />

                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansBold,
                        fontSize: hp(2),
                        color:
                          this.state.noon === true
                            ? Colors.blueTextColor
                            : Colors.black,
                        marginHorizontal: hp(0.5),
                        marginBottom: hp(0),
                      }}>
                      Noon
                    </Text>
                  </View>

                  <Text
                    style={{
                      color: Colors.label,
                      paddingTop: hp(0.5),
                      paddingBottom: hp(0.5),
                      fontSize: Platform.OS === 'android' ? hp(1.5) : hp(1.5),
                    }}>
                    {this.state.noonArray.length} Medication
                  </Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  this.setState({
                    EVENING: true,
                    morning: false,
                    noon: false,
                  });
                }}>
                <View
                  style={{
                    height: hp(7),

                    width: hp(14),
                    justifyContent: 'space-around',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderBottomWidth: 2,
                    borderBottomColor:
                      this.state.EVENING === true
                        ? Colors.blueTextColor
                        : Colors.transparent,
                  }}>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                    <Image
                      style={{
                        width: 15,
                        height: 17,
                      }}
                      source={images.evening_icon}
                    />
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansBold,
                        fontSize: hp(2),

                        color:
                          this.state.EVENING === true
                            ? Colors.blueTextColor
                            : Colors.black,
                        marginLeft: hp(1),
                      }}>
                      Evening
                    </Text>
                  </View>

                  <Text
                    style={{
                      color: Colors.label,
                      paddingTop: hp(0.5),
                      paddingBottom: hp(0.5),
                      fontSize: Platform.OS === 'android' ? hp(1.5) : hp(1.55),
                    }}>
                    {this.state.eveningArray.length} Medication
                  </Text>
                </View>
              </TouchableOpacity>
            </View>
          </View>

          {
            // this.state.dayTime === DayTime.MORNING &&
            this.state.morning === true ? (
              this.state.morningArray.length ? (
                <View
                  style={{
                    flex: 1,
                    marginLeft: hp(1),
                    marginRight: hp(1),
                    // marginTop: hp(2),
                    alignItems: 'center',
                  }}>
                  <View
                    style={{width: '100%', borderColor: 'red', borderWidth: 0}}>
                    <FlatList
                      data={this.state.morningArray}
                      //  ItemSeparatorComponent={this.FlatListItemSeparator}
                      renderItem={({item, index}) => {
                        console.log('====================================');
                        console.log('item in dashboard', item);
                        console.log('====================================');
                        return (
                          <>
                            <Pressable
                              onPress={() => {
                                this.openSwipeableMorning(index);
                              }}
                              onPressOut={() => {
                                console.log(
                                  '====================================',
                                );
                                console.log('cance press swipeable');
                                console.log(
                                  '====================================',
                                );
                                this.setState({modalVisible: false});
                              }}>
                              <Swipeable
                                onSwipeableWillOpen={() =>
                                  this.setState({isOpen: true})
                                }
                                onSwipeableWillClose={() =>
                                  this.setState({isOpen: false})
                                }
                                ref={ref => {
                                  this.swipeableRef1[index] = ref;
                                }}
                                renderRightActions={progress =>
                                  this.renderRightActions(
                                    progress,
                                    item,
                                    '08:05 AM',
                                    'morningReminders',
                                    index,
                                  )
                                }>
                                <MedicationItem
                                  item={item}
                                  index={index}
                                  myProps={this.props}
                                  navigation={this.props.myProps.navigation}
                                  onClick={() => this.onOpen(item)}
                                  onStatusChange={() =>
                                    this.props.todayMedication()
                                  }
                                />
                              </Swipeable>
                            </Pressable>
                          </>
                        );
                      }}
                      refreshControl={
                        <RefreshControl
                          refreshing={this.state.refreshing}
                          onRefresh={this._onRefresh}
                        />
                      }
                      keyExtractor={item => item.id}
                      style={{marginBottom: hp(5), height: '100%'}}
                    />
                  </View>
                </View>
              ) : (
                <View
                  style={{
                    flex: 1,
                    alignItems: 'center',
                  }}>
                  <Image
                    source={images.no_result_found}
                    style={{width: hp(18), height: hp(17)}}
                  />
                  <Text
                    style={{
                      marginTop: hp(4),
                      fontFamily: Fonts.SourceSansBold,
                      fontSize: hp(2),
                    }}>
                    No Result Found
                  </Text>
                  <Text
                    style={{
                      marginTop: hp(1),
                      fontFamily: Fonts.SourceSansRegular,
                      fontSize: hp(2),
                      color: Colors.noRecordFound,
                      width: '90%',
                      textAlign: 'center',
                    }}>
                    Sorry, there are no results for this search.
                  </Text>
                </View>
              )
            ) : null
          }
          {
            // this.state.dayTime === DayTime.MORNING &&
            this.state.noon === true ? (
              this.state.noonArray.length ? (
                <View
                  style={{
                    flex: 1,
                    marginLeft: hp(1),
                    marginRight: hp(1),
                    // marginTop: hp(2),
                    alignItems: 'center',
                  }}>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      width: '95%',
                      marginBottom: hp(2),
                      display: 'none',
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansBold,
                        fontSize: hp(2),
                      }}>
                      Medicine Reminder
                    </Text>
                    <ToggleSwitch
                      isOn={this.state.reminderNoon}
                      onColor={Colors.blueTextColor}
                      offColor={Colors.sliderGrey}
                      onToggle={newValue => {
                        this.setState({reminderNoon: newValue});
                        console.log('====================================');
                        console.log('new', newValue);
                        console.log('====================================');
                      }}
                      size="small"
                    />
                  </View>
                  <View style={{width: '100%'}}>
                    <FlatList
                      data={this.state.noonArray}
                      //  ItemSeparatorComponent={this.FlatListItemSeparator}
                      renderItem={({item, index}) => (
                        // <Pressable
                        //   onPress={() => {
                        //     this.openSwipeableMorning(index);
                        //   }}
                        //   onPressOut={() => {
                        //     this.setState({modalVisible: false});
                        //   }}>
                        //   <Swipeable
                        //     onSwipeableWillOpen={() =>
                        //       this.setState({isOpen: true})
                        //     }
                        //     onSwipeableWillClose={() =>
                        //       this.setState({isOpen: false})
                        //     }
                        //     ref={ref => {
                        //       this.swipeableRef1[index] = ref;
                        //     }}
                        //     renderRightActions={progress =>
                        //       this.renderRightActions(
                        //         progress,
                        //         item,
                        //         '12:05 PM',
                        //         'noonReminders',
                        //         index,
                        //       )
                        //     }>
                        //     <MedicationItem
                        //       item={item}
                        //       index={index}
                        //       myProps={this.props}
                        //       navigation={this.props.myProps.navigation}
                        //       onClick={() => this.onOpen(item)}
                        //       onStatusChange={() =>
                        //         this.props.todayMedication()
                        //       }
                        //     />
                        //   </Swipeable>
                        // </Pressable>
                        <>
                          {item.source === '2' ? (
                            <Pressable
                              onPress={() => {
                                this.openSwipeableMorning(index);
                              }}
                              onPressOut={() => {
                                this.setState({modalVisible: false});
                              }}>
                              <Swipeable
                                onSwipeableWillOpen={() =>
                                  this.setState({isOpen: true})
                                }
                                onSwipeableWillClose={() =>
                                  this.setState({isOpen: false})
                                }
                                ref={ref => {
                                  this.swipeableRef1[index] = ref;
                                }}
                                renderRightActions={progress =>
                                  this.renderRightActions(
                                    progress,
                                    item,
                                    '12:05 PM',
                                    'noonReminders',
                                    index,
                                  )
                                }>
                                <MedicationItem
                                  item={item}
                                  index={index}
                                  myProps={this.props}
                                  navigation={this.props.myProps.navigation}
                                  onClick={() => this.onOpen(item)}
                                  onStatusChange={() =>
                                    this.props.todayMedication()
                                  }
                                />
                              </Swipeable>
                            </Pressable>
                          ) : (
                            <Pressable
                              onPressOut={() => {
                                console.log(
                                  '====================================',
                                );
                                console.log('cance press');
                                console.log(
                                  '====================================',
                                );
                                this.setState({modalVisible: false});
                              }}>
                              <MedicationItem
                                item={item}
                                index={index}
                                myProps={this.props}
                                navigation={this.props.myProps.navigation}
                                onClick={() => this.onOpen(item)}
                                onStatusChange={() =>
                                  this.props.todayMedication()
                                }
                              />
                            </Pressable>
                          )}
                        </>
                      )}
                      refreshControl={
                        <RefreshControl
                          refreshing={this.state.refreshing}
                          onRefresh={this._onRefresh}
                        />
                      }
                      keyExtractor={item => item.id}
                      style={{marginBottom: hp(5), height: '100%'}}
                    />
                  </View>
                </View>
              ) : (
                <View
                  style={{
                    flex: 1,
                    alignItems: 'center',
                  }}>
                  <Image
                    source={images.no_result_found}
                    style={{width: hp(18), height: hp(17)}}
                  />
                  <Text
                    style={{
                      marginTop: hp(4),
                      fontFamily: Fonts.SourceSansBold,
                      fontSize: hp(2),
                    }}>
                    No Result Found
                  </Text>
                  <Text
                    style={{
                      marginTop: hp(1),
                      fontFamily: Fonts.SourceSansRegular,
                      fontSize: hp(2),
                      color: Colors.noRecordFound,
                      width: '90%',
                      textAlign: 'center',
                    }}>
                    Sorry, there are no results for this search.
                  </Text>
                </View>
              )
            ) : null
          }

          {
            // this.state.dayTime === DayTime.MORNING &&
            this.state.EVENING === true ? (
              this.state.eveningArray.length ? (
                <View
                  style={{
                    flex: 1,
                    marginLeft: hp(1),
                    marginRight: hp(1),
                    // marginTop: hp(2),
                    alignItems: 'center',
                  }}>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      width: '95%',
                      marginBottom: hp(2),
                      display: 'none',
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansBold,
                        fontSize: hp(2),
                      }}>
                      Medicine Reminder
                    </Text>
                    <ToggleSwitch
                      isOn={this.state.reminderEvening}
                      onColor={Colors.blueTextColor}
                      offColor={Colors.sliderGrey}
                      onToggle={newValue => {
                        this.setState({reminderEvening: newValue});
                        console.log('====================================');
                        console.log('new', newValue);
                        console.log('====================================');
                      }}
                      size="small"
                    />
                  </View>
                  <View style={{width: '100%'}}>
                    <FlatList
                      data={this.state.eveningArray}
                      //  ItemSeparatorComponent={this.FlatListItemSeparator}
                      renderItem={({item, index}) => (
                        <>
                          {item.source === '2' ? (
                            <Pressable
                              onPress={() => {
                                this.openSwipeableMorning(index);
                              }}
                              onPressOut={() => {
                                this.setState({modalVisible: false});
                              }}>
                              <Swipeable
                                onSwipeableWillOpen={() =>
                                  this.setState({isOpen: true})
                                }
                                onSwipeableWillClose={() =>
                                  this.setState({isOpen: false})
                                }
                                ref={ref => {
                                  this.swipeableRef1[index] = ref;
                                }}
                                renderRightActions={progress =>
                                  this.renderRightActions(
                                    progress,
                                    item,
                                    '12:05 PM',
                                    'noonReminders',
                                    index,
                                  )
                                }>
                                <MedicationItem
                                  item={item}
                                  index={index}
                                  myProps={this.props}
                                  navigation={this.props.myProps.navigation}
                                  onClick={() => this.onOpen(item)}
                                  onStatusChange={() =>
                                    this.props.todayMedication()
                                  }
                                />
                              </Swipeable>
                            </Pressable>
                          ) : (
                            <Pressable
                              onPressOut={() => {
                                console.log(
                                  '====================================',
                                );
                                console.log('cance press');
                                console.log(
                                  '====================================',
                                );
                                this.setState({modalVisible: false});
                              }}>
                              <MedicationItem
                                item={item}
                                index={index}
                                myProps={this.props}
                                navigation={this.props.myProps.navigation}
                                onClick={() => this.onOpen(item)}
                                onStatusChange={() =>
                                  this.props.todayMedication()
                                }
                              />
                            </Pressable>
                          )}
                        </>
                      )}
                      refreshControl={
                        <RefreshControl
                          refreshing={this.state.refreshing}
                          onRefresh={this._onRefresh}
                        />
                      }
                      keyExtractor={item => item.id}
                      style={{marginBottom: hp(5), height: '100%'}}
                    />
                  </View>
                </View>
              ) : (
                <View
                  style={{
                    flex: 1,
                    alignItems: 'center',
                  }}>
                  <Image
                    source={images.no_result_found}
                    style={{width: hp(18), height: hp(17)}}
                  />
                  <Text
                    style={{
                      marginTop: hp(4),
                      fontFamily: Fonts.SourceSansBold,
                      fontSize: hp(2),
                    }}>
                    No Result Found
                  </Text>
                  <Text
                    style={{
                      marginTop: hp(1),
                      fontFamily: Fonts.SourceSansRegular,
                      fontSize: hp(2),
                      color: Colors.noRecordFound,
                      width: '90%',
                      textAlign: 'center',
                    }}>
                    Sorry, there are no results for this search.
                  </Text>
                </View>
              )
            ) : null
          }

          <Pressable
            onPress={() => {
              this.props.myProps.navigation.navigate('AddNewMedication');
            }}
            style={{
              position: 'absolute',
              bottom:
                this.state.morningArray.length &&
                this.state.noonArray.length &&
                this.state.eveningArray.length
                  ? '13%'
                  : '5%',
              right: '5%',
              zIndex: 111,
            }}>
            <SvgXml xml={svgs.AddMed} height="75" width="75" style={{}} />
            {/* <AddMed height="75" width="75" style={{}} /> */}
          </Pressable>
        </View>
      </Fragment>
    );
  }
}
/* istanbul ignore next */
const mapStateToProps = ({allTodayMedicationData, modalHandler}) => ({
  allTodayMedicationData,
  modalHandler,
});
export default connect(mapStateToProps)(MedicationDashboard);

const styles = StyleSheet.create({
  leftAction: {
    flex: 1,
    backgroundColor: '#497AFC',
    justifyContent: 'center',
  },
  actionText: {
    color: Colors.black,
    fontSize: 16,
    backgroundColor: 'transparent',
    padding: 10,
  },
  rightAction: {
    alignItems: 'center',
    flex: 1,
    justifyContent: 'center',
    borderRadius: 10,
    backgroundColor: Colors.bleLayer4,
    borderColor: 'red',
    borderWidth: 0,
  },
  modalContainer: {
    // flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.white,
    width: '100%',
    height: hp(10),
    borderRadius: hp(0.5),
  },
});
