/* istanbul ignore file */
import React, {Fragment} from 'react';
import {
  Image,
  Platform,
  SafeAreaView,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import DatePicker from 'react-native-date-picker';
import {showMessage} from 'react-native-flash-message';
import Spinner from 'react-native-loading-spinner-overlay';
import DateTimePicker from 'react-native-modal-datetime-picker';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {Colors, Images} from '../../../../config';
import {Fonts} from '../../../../config/AppConfig';
import MedicationService from '../../../api/medication';
import {MedicationType} from '../constants';
import {SvgCss} from 'react-native-svg';
import svgs from '../../../../config/Svgs';
import moment from 'moment';
export default class EditMedicationScreen extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      cardIndex: 1,
      selectedIndex: 0,
      time: '',
      date: new Date(),
      selectedDate: new Date(),
      showTimePicker: false,
      startDate: '',
      timeArray: [],
      selectedTimeIndex: 0,
      selectedTimeArray: [],
      timeSelectedArray: [new Date()],
      tabletQuantity: ['0.5', '1', '2', '3'],
      injectionQuantity: ['1', '5', '10', '20', '50'],
      syrupQuantity: ['5', '10', '15'],
      capsuleQuantity: ['1', '2', '3'],
      quantityIndex: 0,
      selectedDose: '',
      quantity: ['0.5', '1', '2', '3'],
      selectedQuantity: [],
      replaceIndex: -1,
      quantityText: '',
      quantityUnit: '',
      dateSelectedIndex: 0,
      incommingSelectedStopDate: null,
      stopDate: null,
      count: 2,
      selectButtonOnIncrementDecrement: false,
      frequSelectedIndex: 0,
      morning: false,
      noon: false,
      evening: false,
      timeArrNew: [],
      medId: this.props.route.params.medId,
      doseField: '',
      stripSize: null,
    };
    var d1 = new Date(),
      d2 = new Date(d1);
    d2.setMinutes(d1.getMinutes() + 30);
    this.setTime(d1);
  }
  componentDidMount(): void {
    var dummyTimeArr = [];
    var data = {};
    this.state.timeArray.map((time, index) => {
      data = {time: time, selected: true};
      dummyTimeArr.push(data);
    });
    this.getMedicationById();
    // this.selectDoseQuantity();
  }

  getMedicationById() {
    this.setState({showLoader: true});
    MedicationService.getMedicationById(this.state.medId).then(response => {
      console.log('====================================');
      console.log('res of med by id', response);
      console.log('====================================');
      if (response && response.statusCode === 200) {
        this.setState({showLoader: false});
        global.selectedData = response.data;
        let tempStopDate = null;
        console.log('Medication end date is : ', response.data.endDate);
        if (response.data.endDate === null) {
          tempStopDate = new Date().toLocaleDateString('en-US', {
            month: '2-digit',
            day: '2-digit',
            year: 'numeric',
          });
          this.setState({
            dateSelectedIndex: 1,
            incommingSelectedStopDate: tempStopDate,
          });
          console.log(
            'if Test end date is : ',
            response.data.endDate,
            tempStopDate,
          );
        } else {
          tempStopDate = new Date(response.data.endDate).toLocaleDateString(
            'en-US',
            {
              month: '2-digit',
              day: '2-digit',
              year: 'numeric',
            },
          );
          //to handle the selected stop filter
          let providedDate = new Date(response.data.endDate);
          let currentDate = new Date();
          providedDate.setHours(0, 0, 0, 0);
          currentDate.setHours(0, 0, 0, 0);
          let timeDifference = providedDate.getTime() - currentDate.getTime();
          let daysInDifference = Math.floor(
            timeDifference / (1000 * 60 * 60 * 24),
          );

          console.log('Else date is : ', tempStopDate, response.data.endDate);
          if (daysInDifference === 7) {
            this.setState({
              dateSelectedIndex: 2,
              incommingSelectedStopDate: tempStopDate,
            });
          }
          if (daysInDifference === 30) {
            this.setState({
              dateSelectedIndex: 3,
              incommingSelectedStopDate: tempStopDate,
            });
          }
          if (daysInDifference !== 30 && daysInDifference !== 7) {
            this.setState({
              dateSelectedIndex: 0,
              incommingSelectedStopDate: tempStopDate,
            });
          }
        }
        // console.log('Else Test end date is : ',response.data.endDate,response.data.frequencyInDays);
        if (
          response.data.frequencyInDays !== '30' &&
          response.data.frequencyInDays !== '7' &&
          response.data.frequencyInDays !== '1'
        ) {
          this.setState({
            count: response.data.frequencyInDays,
          });
        }

        if (
          response.data.frequencyInDays === 'Monthly' ||
          response.data.frequencyInDays === '30'
        ) {
          global.frequencyIndex = 4;
          this.setState({
            frequSelectedIndex: 4,
            selectButtonOnIncrementDecrement: false,
          });
          global.selectedData.frequencyLabel = 'Monthly';

          global.selectedData.frequencyInDays = 30;
        } else if (
          response.data.frequencyInDays === 'Daily' ||
          response.data.frequencyInDays === '1'
        ) {
          global.frequencyIndex = 1;
          this.setState({
            frequSelectedIndex: 1,
            selectButtonOnIncrementDecrement: false,
          });
          global.selectedData.frequencyLabel = 'Daily';
          global.selectedData.frequencyInDays = 1;
        } else if (
          response.data.frequencyInDays === 'Weekly' ||
          response.data.frequencyInDays === '7'
        ) {
          global.frequencyIndex = 3;
          this.setState({
            frequSelectedIndex: 3,
            selectButtonOnIncrementDecrement: false,
          });
          global.selectedData.frequencyLabel = 'Weekly';
          global.selectedData.frequencyInDays = 7;
        } else {
          global.frequencyIndex = 2;
          this.setState({
            frequSelectedIndex: 2,
            selectButtonOnIncrementDecrement: true,
          });
          global.selectedData.frequencyLabel =
            response.data.frequencyInDays + ' Day';
          global.selectedData.frequencyInDays = response.data.frequencyInDays;
        }
        response.data.medicationSlot.map(slot => {
          if (slot === 0) {
            this.setState({morning: true});
            this.state.timeArrNew.push('8:05 AM');
          }
          if (slot === 1) {
            this.setState({noon: true});
            this.state.timeArrNew.push('05:05 PM');
          }
          if (slot === 2) {
            this.setState({evening: true});
            this.state.timeArrNew.push('12:05 PM');
          }
          global.selectedData.doseTimings = this.state.timeArrNew;
        });

        if (response.data.mealStatus === false) {
          global.selectedIndex = 0;
          this.setState({selectedIndex: 0});
          global.selectedData.mealStatus = false;
        }
        if (response.data.mealStatus === true) {
          global.selectedIndex = 1;
          this.setState({selectedIndex: 1});
          global.selectedData.mealStatus = true;
        }

        this.geSelectedDoseQuantityIndex(response.data);
        this.selectDoseQuantity(response.data);
      } else {
        this.setState({showLoader: false});
      }
    });
  }
  geSelectedDoseQuantityIndex(data) {
    if (data.fdaMedicine.dosageformname.includes(MedicationType.TABLET)) {
      this.state.tabletQuantity.map((dose, index) => {
        if (dose === JSON.stringify(data.quantity)) {
          this.setState({
            quantityIndex: index,
          });
        }
        if (data.quantity > 5) {
          this.setState({
            doseField: JSON.stringify(data.quantity),
            quantityIndex: 77,
          });
        }
        global.selectedData.quantity = parseFloat(data.quantity);

        global.quantity = parseFloat(data.quantity);
      });
    } else if (
      data.fdaMedicine.dosageformname.includes(MedicationType.CAPSULE)
    ) {
      this.state.capsuleQuantity.map((dose, index) => {
        if (dose === JSON.stringify(data.quantity)) {
          this.setState({
            quantityIndex: index,
          });
        }
        if (data.quantity > 5) {
          this.setState({
            doseField: JSON.stringify(data.quantity),
            quantityIndex: 77,
          });
        }
        global.selectedData.quantity = parseFloat(data.quantity);

        global.quantity = parseFloat(data.quantity);
      });
    } else if (
      data.fdaMedicine.dosageformname.includes(MedicationType.INJECTION1)
    ) {
      this.state.injectionQuantity.map((dose, index) => {
        if (dose === JSON.stringify(data.quantity)) {
          this.setState({
            quantityIndex: index,
          });
        }
        if (data.quantity > 50) {
          this.setState({
            doseField: JSON.stringify(data.quantity),
            quantityIndex: 77,
          });
        }
        global.selectedData.quantity = parseFloat(data.quantity);

        global.quantity = parseFloat(data.quantity);
      });
    } else if (
      data.fdaMedicine.dosageformname.includes(MedicationType.INJECTION2)
    ) {
      this.state.injectionQuantity.map((dose, index) => {
        if (dose === JSON.stringify(data.quantity)) {
          this.setState({
            quantityIndex: index,
          });
        }
        if (data.quantity > 50) {
          this.setState({
            doseField: JSON.stringify(data.quantity),
            quantityIndex: 77,
          });
        }
        global.selectedData.quantity = parseFloat(data.quantity);

        global.quantity = parseFloat(data.quantity);
      });
    } else if (
      data.fdaMedicine.dosageformname.includes(MedicationType.SYRUP1)
    ) {
      this.state.syrupQuantity.map((dose, index) => {
        if (dose === JSON.stringify(data.quantity)) {
          this.setState({
            quantityIndex: index,
          });
        }
        if (data.quantity > 15) {
          this.setState({
            doseField: JSON.stringify(data.quantity),
            quantityIndex: 77,
          });
        }
        global.selectedData.quantity = parseFloat(data.quantity);

        global.quantity = parseFloat(data.quantity);
      });
    } else if (
      data.fdaMedicine.dosageformname.includes(MedicationType.SYRUP2)
    ) {
      this.state.syrupQuantity.map((dose, index) => {
        if (dose === JSON.stringify(data.quantity)) {
          this.setState({
            quantityIndex: index,
          });
        }
        if (data.quantity > 15) {
          this.setState({
            doseField: JSON.stringify(data.quantity),
            quantityIndex: 77,
          });
        }
        global.selectedData.quantity = parseFloat(data.quantity);

        global.quantity = parseFloat(data.quantity);
      });
    } else if (
      data.fdaMedicine.dosageformname.includes(MedicationType.EYEDROPS)
    ) {
      this.state.capsuleQuantity.map((dose, index) => {
        if (dose === JSON.stringify(data.quantity)) {
          this.setState({
            quantityIndex: index,
          });
        }
        if (data.quantity > 5) {
          this.setState({
            doseField: JSON.stringify(data.quantity),
            quantityIndex: 77,
          });
        }
        global.selectedData.quantity = parseFloat(data.quantity);

        global.quantity = parseFloat(data.quantity);
      });
    } else {
      this.state.quantity.map((dose, index) => {
        if (dose === JSON.stringify(data.quantity)) {
          this.setState({
            quantityIndex: index,
          });
        }
        if (data.quantity > 5) {
          this.setState({
            doseField: JSON.stringify(data.quantity),
            quantityIndex: 77,
          });
        }
        global.selectedData.quantity = parseFloat(data.quantity);

        global.quantity = parseFloat(data.quantity);
      });
    }
  }
  selectDoseQuantity(data) {
    if (data.fdaMedicine.dosageformname.includes(MedicationType.TABLET)) {
      this.setState({
        selectedQuantity: this.state.tabletQuantity,
        quantityText: 'Tablet Quantity',
        quantityUnit: '',
        stripSize: `${data.fdaMedicine.packageSize} tablets`,
      });
    } else if (
      data.fdaMedicine.dosageformname.includes(MedicationType.CAPSULE)
    ) {
      this.setState({
        selectedQuantity: this.state.capsuleQuantity,
        quantityText: 'Capsule Quantity',
        quantityUnit: '',
        stripSize: `${data.fdaMedicine.packageSize} capsules`,
      });
    } else if (
      data.fdaMedicine.dosageformname.includes(MedicationType.INJECTION1)
    ) {
      this.setState({
        selectedQuantity: this.state.injectionQuantity,
        quantityText: 'Injection Quantity',
        quantityUnit: 'mL',
        stripSize: `${data.fdaMedicine.packageSize} mL`,
      });
    } else if (
      data.fdaMedicine.dosageformname.includes(MedicationType.INJECTION2)
    ) {
      this.setState({
        selectedQuantity: this.state.injectionQuantity,
        quantityText: 'Injection Quantity',
        quantityUnit: 'mL',
        stripSize: `${data.fdaMedicine.packageSize} mL`,
      });
    } else if (
      data.fdaMedicine.dosageformname.includes(MedicationType.SYRUP1)
    ) {
      this.setState({
        selectedQuantity: this.state.syrupQuantity,
        quantityText: 'Syrup Quantity',
        quantityUnit: 'mL',
        stripSize: `${data.fdaMedicine.packageSize} mL`,
      });
    } else if (
      data.fdaMedicine.dosageformname.includes(MedicationType.SYRUP2)
    ) {
      this.setState({
        selectedQuantity: this.state.syrupQuantity,
        quantityText: 'Syrup Quantity',
        quantityUnit: 'mL',
        stripSize: `${data.fdaMedicine.packageSize} mL`,
      });
    } else if (
      data.fdaMedicine.dosageformname.includes(MedicationType.EYEDROPS)
    ) {
      this.setState({
        selectedQuantity: this.state.capsuleQuantity,
        quantityText: 'Drops Quantity',
        quantityUnit: '',
        stripSize: `${data.fdaMedicine.packageSize} mL`,
      });
    } else {
      this.setState({
        selectedQuantity: this.state.quantity,
        quantityText: 'Quantity',
        quantityUnit: '',
        stripSize: `${data.fdaMedicine.packageSize} tablets`,
      });
    }
  }

  //step 4 function

  /* istanbul ignore next */
  setDate(date) {
    this.setState({stopDate: date, dateSelectedIndex: 4}, () => {
      this.hideDatePicker();
      global.selectedData.endDate = date;
      global.stopIndex = 4;
      global.date = date;
    });
  }
  /* istanbul ignore next */
  startDatePicker() {
    this.setState({
      isDatePickerVisible: true,
    });
  }
  /* istanbul ignore next */
  hideDatePicker() {
    this.setState({isDatePickerVisible: false});
  }

  /* istanbul ignore next */
  hideDateTimePicker() {
    this.setState({
      isDateTimePickerVisible: false,
      replaceIndex: -1,
      selectedTimeIndex: this.state.timeArray.length - 1,
    });
  }
  /* istanbul ignore next */
  startTimePicker() {
    this.setState({
      date:
        this.state.replaceIndex !== -1
          ? this.state.timeSelectedArray[this.state.replaceIndex]
          : new Date(),
      isDateTimePickerVisible: true,
      mode: 'time',
      modeName: 'startTime',
      selectedTimeIndex: this.state.replaceIndex, //while adding new time
    });
  }
  timeConvert24(time24) {
    var ts = time24;
    var H = +ts.substr(0, 2);
    var h = H % 12 || 12;
    h = h < 10 ? '0' + h : h; // leading 0 at the left for 1 digit hours
    var ampm = H < 12 ? ' AM' : ' PM';
    ts = h + ts.substr(2, 3) + ampm;
    return ts;
  }
  /* istanbul ignore next */
  setTime(date) {
    let myDate = new Date(date);
    console.log(myDate);
    var time =
      ('0' + myDate.getHours()).slice(-2) +
      ':' +
      ('0' + myDate.getMinutes()).slice(-2);

    var convertedTime = this.timeConvert24(time);

    var preArray = this.state.timeArray;
    var selectedArray = this.state.timeSelectedArray;
    let data = this.state.selectedTimeArray;
    if (this.state.replaceIndex === -1) {
      preArray.push(convertedTime.toString());
      // data ={myDate,selected:true}
      selectedArray.push(myDate);
      data.push({time: convertedTime.toString(), selected: true});
    } else {
      preArray[this.state.replaceIndex] = convertedTime.toString();
      selectedArray[this.state.replaceIndex] = myDate;
      data.push({time: convertedTime.toString(), selected: true});
    }
    var dummyTimeArr = [];
    var newTimeArr = [];
    var dataTime = {};
    preArray.map((time, index) => {
      dataTime = {time: time, selected: true};
      dummyTimeArr.push(dataTime);
      newTimeArr.push(time);
    });

    this.setState(
      {
        timeArray: preArray,
        replaceIndex: -1,
        selectedTimeIndex: this.state.timeArray.length - 1,
        selectedTimeArray: dummyTimeArr,
      },
      () => {
        this.hideDateTimePicker();
        global.selectedData.doseTimings = this.state.timeArray;
        // global.timeArray = this.state.timeArray;
        global.timeArray = newTimeArr;
      },
    );
  }

  rerenderGlobalTimeArray(dummyTime) {
    var newTimeArr = [];
    dummyTime.map((time, index) => {
      if (time.selected === true) {
        newTimeArr.push(time.time);
      }
    });
    global.timeArray = newTimeArr;
    // global.selectedData.doseTimings = newTimeArr;
  }

  renderTimeArray() {
    var dummyTimeArr = this.state.selectedTimeArray;

    return this.state.selectedTimeArray.map((timeofIndex, indexOftime) => {
      return (
        <TouchableOpacity
          onPress={() => {
            var dummyTime = this.state.selectedTimeArray;
            this.state.selectedTimeArray.map((time, index) => {
              if (time.time === timeofIndex.time) {
                dummyTime[indexOftime].selected =
                  !dummyTime[indexOftime].selected;
              }
            });
            this.setState(
              {
                replaceIndex: timeofIndex.selected
                  ? indexOftime
                  : indexOftime - 1,
                selectedTimeIndex: indexOftime,
                selectedTimeArray: dummyTime,
              },
              () => {
                this.rerenderGlobalTimeArray(dummyTime);
              },
            );
          }}
          key={Math.random().toString(36).substr(2, 9)}
          style={{
            width: 80,
            height: 40,
            marginTop: hp(1),
            paddingHorizontal: 5,
            marginRight: hp(1),
            borderWidth: 1,
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: 5,
            backgroundColor: timeofIndex.selected
              ? Colors.blueTextColor
              : Colors.medicalHistoryBg,
            borderColor: timeofIndex.selected
              ? Colors.blueTextColor
              : Colors.border,
          }}>
          <Text
            style={{
              fontFamily: Fonts.SourceSansBold,
              color: timeofIndex.selected ? Colors.white : Colors.black1,
            }}>
            {timeofIndex.time}
          </Text>
        </TouchableOpacity>
      );
    });
  }
  renderDoseArray() {
    // if (this.state.selectedQuantity.length) {
    //   global.selectedData.Quantity = parseFloat(this.state.selectedQuantity[0]);
    // }
    console.log(
      'this is the doseage coming to us ',
      this.state.selectedQuantity,
    );
    return this.state.selectedQuantity.map((dose, index) => {
      // below check is added because user can't edit the medicine quantity
      return (
        <>
          {index < 0 ? null : (
            <TouchableOpacity
              onPress={() => {
                console.log('selectedQuantity');
                console.log(dose);
                this.setState({
                  quantityIndex: index,
                });
                global.selectedData.quantity = parseFloat(dose);
                global.quantityIndex = index;
                global.quantity = parseFloat(dose);
              }}
              style={{
                width: 72,
                height: 42,
                marginTop: hp(1.5),
                marginRight: hp(1.5),
                borderWidth: 1,
                alignItems: 'center',
                justifyContent: 'center',
                borderRadius: 5,
                backgroundColor:
                  this.state.quantityIndex === index
                    ? Colors.blueTextColor
                    : Colors.bleLayer4,
                borderColor:
                  this.state.quantityIndex === index
                    ? Colors.blueTextColor
                    : Colors.bleLayer3,
              }}>
              <Text
                style={{
                  fontFamily: Fonts.SourceSansRegular,
                  color:
                    this.state.quantityIndex === index
                      ? Colors.white
                      : Colors.TextColor,
                  fontSize: hp(2),
                }}>
                {dose + this.state.quantityUnit}
              </Text>
            </TouchableOpacity>
          )}
        </>
      );
    });
  }

  render() {
    var minDate = new Date();
    minDate.setDate(minDate.getDate());
    var minimumDate = minDate.setHours(0, 0, 0, 0);

    return (
      <Fragment>
        <SafeAreaView
          style={{
            flex: 1,
            backgroundColor: Colors.BgColor,
          }}>
          <Spinner
            visible={this.state.showLoader}
            textContent={'Loading...'}
            textStyle={{color: '#FFF'}}
          />
          <View style={{flex: 1, backgroundColor: Colors.BgColor}}>
            {this.state.isDatePickerVisible ? (
              <DatePicker
                modal
                open={true}
                date={minDate}
                // maximumDate={minDate}
                minimumDate={new Date()}
                mode="date"
                onCancel={() => this.hideDatePicker()}
                onConfirm={date => {
                  this.setDate(date);
                }}
              />
            ) : null}

            <DateTimePicker
              isVisible={this.state.isDateTimePickerVisible}
              onCancel={() => this.hideDateTimePicker()}
              mode={'time'}
              date={this.state.date}
              titleIOS={'Pick a Time'}
              titleStyle={{fontSize: hp(3)}}
              is24Hour={false}
              onConfirm={date => {
                this.setTime(date);
              }}
            />
            <View
              style={{
                flexDirection: 'row',
                width: '100%',
                alignItems: 'center',
                height: hp(7.5),
                borderBottomWidth: 1,
                borderColor: Colors.BgColor,
                backgroundColor: Colors.BgColor,
              }}>
              <SvgCss
                style={{marginLeft: hp(2)}}
                xml={svgs.arrowHeadLeft}
                width={hp(4)}
                height={hp(4)}
                fill={Colors.black}
                onPress={() => {
                  this.props.navigation.goBack();
                }}
              />
              {/* <TouchableOpacity
                onPress={() => {
                  this.props.navigation.goBack();
                }}>
                <Text
                  style={{
                    fontFamily: 'WisemanPTSymbols',
                    marginLeft: hp(2),
                    marginRight: hp(1),
                    fontSize: hp(5),
                    color: Colors.black1,
                  }}>
                  W
                </Text>
              </TouchableOpacity> */}
              <Text
                style={{
                  fontFamily: Fonts.SourceSansSemibold,
                  fontSize: hp(2.5),
                  color: Colors.black1,
                  flex: 1,
                  textTransform: 'capitalize',
                  textAlign: 'center',
                }}>
                Edit Medication
              </Text>
              <View style={{marginRight: hp(2)}}></View>
            </View>
            <View
              style={{
                flexDirection: 'column',
                alignItems: 'center',
                alignSelf: 'center',
                marginTop: hp(2),
                height: '30%',
                minHeight: '40%',
                maxHeight: '40%',
                backgroundColor: Colors.BgColor,
              }}>
              <View
                style={{
                  backgroundColor: Colors.white,
                  borderRadius: 10,
                  shadowOffset: {width: 0.5, height: 0.5},
                  shadowOpacity: 0.1,
                  shadowRadius: 8,
                  elevation: 5,
                  height: '100%',
                  alignItems: 'center',
                  alignSelf: 'center',
                  paddingBottom: Platform.OS === 'ios' ? hp(19) : hp(19),
                  paddingTop: hp(1),
                  minWidth: '90%',
                  display: 'flex',
                }}>
                <View style={{paddingTop: hp(3)}}>
                  <Image
                    style={{
                      width: 80,
                      height: 80,
                      borderRadius: 20,
                      alignSelf: 'center',
                      marginRight: hp(1),
                    }}
                    source={Images.medIcon4x}
                  />
                </View>
                <Text
                  style={{
                    paddingTop: hp(1),
                    fontFamily: Fonts.SourceSansRegular,
                    fontSize: hp(2.5),
                    color: Colors.black,
                    textTransform: 'capitalize',
                    marginTop: hp(2),
                  }}>
                  {global.selectedData.fdaMedicine?.proprietaryname}
                </Text>
                <View style={{marginTop: hp(1.5)}}>
                  {global.selectedData.fdaMedicine?.strength !== '' && (
                    <View
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        alignSelf: 'center',
                      }}>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansRegular,
                          fontSize: hp(1.7),
                          marginLeft: hp(2),
                          color: Colors.noRecordFound,
                          lineHeight: hp(3),
                        }}>
                        {'Strength - ' +
                          global.selectedData.fdaMedicine?.strength}
                      </Text>
                    </View>
                  )}
                  <View
                    style={{
                      flexDirection: 'row',
                      marginVertical: hp(0.5),
                      alignItems: 'center',
                      alignSelf: 'center',
                    }}>
                    <View
                      style={{
                        height: 8,
                        width: 8,
                        alignSelf: 'center',
                        marginLeft: hp(0.5),
                        backgroundColor: Colors.border,
                        borderRadius: 4,
                      }}
                    />
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansRegular,
                        fontSize: hp(1.7),
                        marginLeft: hp(0.5),
                        color: Colors.noRecordFound,
                      }}>
                      {'Strip Size - '}
                    </Text>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansRegular,
                        fontSize: hp(1.7),
                        marginLeft: hp(0.5),
                        color: Colors.noRecordFound,
                      }}>
                      {this.state.stripSize}
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: 'row',
                      marginVertical: hp(0.5),
                      alignItems: 'center',
                      alignSelf: 'center',
                    }}>
                    <View
                      style={{
                        height: 8,
                        width: 8,
                        alignSelf: 'center',
                        backgroundColor: Colors.border,
                        borderRadius: 4,
                      }}
                    />

                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansRegular,
                        fontSize: hp(1.7),
                        color: Colors.noRecordFound,
                        textTransform: 'capitalize',
                      }}>
                      {'  Mfr. by: ' +
                        global.selectedData.fdaMedicine?.manufacturer?.toLowerCase()}
                    </Text>
                  </View>
                </View>
              </View>
            </View>

            {this.state.cardIndex === 1 ? (
              <View
                style={{
                  margin: hp(2),
                  backgroundColor: Colors.white,
                  borderRadius: 10,
                  shadowOffset: {width: 0.5, height: 0.5},
                  shadowOpacity: 0.1,
                  shadowRadius: 8,
                  elevation: 5,
                  flexDirection: 'column',
                  alignSelf: 'center',
                  width: '90%',
                  paddingBottom: hp(1.5),
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansRegular,
                    fontSize: hp(2),
                    color: Colors.black,
                    marginTop: hp(3),
                    marginLeft: hp(2),
                  }}>
                  How will you take it?
                </Text>
                <View
                  style={{
                    flexDirection: 'row',
                    flexWrap: 'wrap',
                    alignItems: 'center',
                    padding: hp(2),
                  }}>
                  <TouchableOpacity
                    onPress={() => {
                      global.frequencyIndex = 1;
                      this.setState({
                        frequSelectedIndex: 1,
                        selectButtonOnIncrementDecrement: false,
                      });
                      global.selectedData.frequencyLabel = 'Daily';
                      global.selectedData.frequencyInDays = 1;
                    }}
                    style={{
                      width: 80,
                      height: 42,
                      borderWidth: 1,
                      marginRight: hp(2),
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderRadius: 5,
                      backgroundColor:
                        this.state.frequSelectedIndex === 1
                          ? Colors.blueTextColor
                          : Colors.bleLayer4,
                      borderColor:
                        this.state.frequSelectedIndex === 1
                          ? Colors.blueTextColor
                          : Colors.bleLayer3,
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansRegular,
                        color:
                          this.state.frequSelectedIndex === 1
                            ? Colors.white
                            : Colors.TextColor,
                        fontSize: hp(2),
                      }}>
                      Daily
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      global.frequencyIndex = 3;
                      this.setState({
                        frequSelectedIndex: 3,
                        selectButtonOnIncrementDecrement: false,
                      });
                      global.selectedData.frequencyLabel = 'Weekly';
                      global.selectedData.frequencyInDays = 7;
                    }}
                    style={{
                      width: 80,
                      height: 42,
                      borderWidth: 1,
                      marginTop: hp(1.5),
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderRadius: 5,
                      marginRight: hp(2),
                      backgroundColor:
                        this.state.frequSelectedIndex === 3
                          ? Colors.blueTextColor
                          : Colors.bleLayer4,
                      borderColor:
                        this.state.frequSelectedIndex === 3
                          ? Colors.blueTextColor
                          : Colors.bleLayer3,
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansRegular,
                        color:
                          this.state.frequSelectedIndex === 3
                            ? Colors.white
                            : Colors.TextColor,
                        fontSize: hp(2),
                      }}>
                      Weekly
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      global.frequencyIndex = 4;
                      this.setState({frequSelectedIndex: 4});
                      global.selectedData.frequencyLabel = 'Monthly';
                      global.selectedData.frequencyInDays = 30;
                    }}
                    style={{
                      width: 80,
                      height: 42,
                      borderWidth: 1,
                      marginTop: hp(1.5),
                      alignItems: 'center',
                      justifyContent: 'center',
                      marginRight: hp(2),
                      borderRadius: 5,
                      backgroundColor:
                        this.state.frequSelectedIndex === 4
                          ? Colors.blueTextColor
                          : Colors.bleLayer4,
                      borderColor:
                        this.state.frequSelectedIndex === 4
                          ? Colors.blueTextColor
                          : Colors.bleLayer3,
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansRegular,
                        color:
                          this.state.frequSelectedIndex === 4
                            ? Colors.white
                            : Colors.TextColor,
                        fontSize: hp(2.2),
                      }}>
                      Monthly
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      global.frequencyIndex = 2;
                      this.setState({
                        frequSelectedIndex: 2,
                        selectButtonOnIncrementDecrement: true,
                      });
                      global.selectedData.frequencyLabel =
                        this.state.count + ' Day';
                      global.selectedData.frequencyInDays = this.state.count;
                    }}
                    style={{
                      width: 150,
                      height: 42,
                      borderWidth: 1,
                      marginTop: hp(3),
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      flexDirection: 'row',
                      borderRadius: 5,
                      backgroundColor:
                        this.state.frequSelectedIndex === 2
                          ? Colors.blueTextColor
                          : Colors.bleLayer4,
                      borderColor:
                        this.state.frequSelectedIndex === 2
                          ? Colors.blueTextColor
                          : Colors.bleLayer3,
                    }}>
                    <TouchableOpacity
                      onPress={() => {
                        if (this.state.count > 2) {
                          let incrementer = parseInt(this.state.count) - 1;
                          console.log('Incrementer is : ', incrementer);
                          this.setState({
                            count: incrementer,
                            selectButtonOnIncrementDecrement: true,
                            frequSelectedIndex: 2,
                          });
                          global.selectedData.frequencyLabel =
                            incrementer + ' Day';
                          global.selectedData.frequencyInDays = incrementer;

                          // this.setState({
                          //   count: this.state.count - 1,
                          //   selectButtonOnIncrementDecrement: true,
                          //   frequSelectedIndex: 2,
                          // });
                          // global.selectedData.frequencyLabel =
                          //   this.state.count - 1 + ' Day';
                          // global.selectedData.frequencyInDays =
                          //   this.state.count;
                        }
                      }}>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansRegular,
                          color:
                            this.state.frequSelectedIndex === 2
                              ? Colors.white
                              : Colors.TextColor,
                          fontSize: hp(5),
                          marginTop: hp(-1.5),
                          marginLeft: hp(3),
                        }}>
                        -
                      </Text>
                    </TouchableOpacity>

                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansRegular,
                        color:
                          this.state.frequSelectedIndex === 2
                            ? Colors.white
                            : Colors.TextColor,
                        fontSize: hp(2),
                      }}>
                      {this.state.count} Days
                      {console.log(
                        'State of the date counts are : ',
                        this.state.count,
                      )}
                    </Text>
                    <TouchableOpacity
                      disabled={this.state.count <= 29 ? false : true}
                      onPress={() => {
                        console.log(
                          'count state is : ',
                          parseInt(this.state.count),
                        );
                        if (this.state.count < 29) {
                          let incrementer = parseInt(this.state.count) + 1;
                          console.log('Incrementer is : ', incrementer);
                          this.setState({
                            count: incrementer,
                            selectButtonOnIncrementDecrement: true,
                            frequSelectedIndex: 2,
                          });
                          global.selectedData.frequencyLabel =
                            incrementer + ' Day';
                          global.selectedData.frequencyInDays = incrementer;
                        }
                        // if (this.state.count < 29) {
                        //   this.setState({
                        //     count: this.state.count + 1,
                        //     selectButtonOnIncrementDecrement: true,
                        //     frequSelectedIndex: 2,
                        //   });
                        //   global.selectedData.frequencyLabel =
                        //     this.state.count + 1 + ' Day';
                        //   global.selectedData.frequencyInDays =
                        //     this.state.count + 1;
                        // }
                      }}>
                      <Text
                        style={{
                          // fontFamily: 'WisemanPTSymbols',
                          marginRight: hp(3),
                          color:
                            this.state.frequSelectedIndex === 2
                              ? Colors.white
                              : Colors.TextColor,
                          fontSize: hp(3),
                        }}>
                        +
                      </Text>
                    </TouchableOpacity>
                  </TouchableOpacity>
                </View>
              </View>
            ) : null}
            {this.state.cardIndex === 2 ? (
              <View
                style={{
                  margin: hp(2),
                  backgroundColor: Colors.white,
                  borderRadius: 10,
                  shadowOffset: {width: 0.5, height: 0.5},
                  shadowOpacity: 0.1,
                  shadowRadius: 8,
                  elevation: 5,
                  flexDirection: 'column',

                  alignSelf: 'center',

                  width: '90%',

                  paddingBottom: hp(1.5),
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansRegular,
                    marginTop: hp(3),
                    marginLeft: hp(2),
                    fontSize: hp(2),
                    color: Colors.black,
                  }}>
                  When and How many time will you take in a day?
                </Text>

                <View
                  style={{
                    flexDirection: 'row',
                    flexWrap: 'wrap',
                    alignItems: 'center',
                    padding: hp(2),
                  }}>
                  <TouchableOpacity
                    onPress={() => {
                      this.setState({
                        morning: !this.state.morning,
                      });
                    }}
                    style={{
                      width: 80,
                      height: 42,
                      borderWidth: 1,
                      marginRight: hp(2),
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderRadius: 5,
                      backgroundColor:
                        this.state.morning === true
                          ? Colors.blueTextColor
                          : Colors.bleLayer4,
                      borderColor:
                        this.state.morning === true
                          ? Colors.blueTextColor
                          : Colors.bleLayer3,
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansRegular,
                        color:
                          this.state.morning === true
                            ? Colors.white
                            : Colors.TextColor,
                        fontSize: hp(2),
                      }}>
                      Morning
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      this.setState({
                        noon: !this.state.noon,
                      });
                    }}
                    style={{
                      width: 80,
                      height: 42,
                      borderWidth: 1,
                      marginTop: hp(1.5),
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderRadius: 5,
                      marginRight: hp(2),
                      backgroundColor:
                        this.state.noon === true
                          ? Colors.blueTextColor
                          : Colors.bleLayer4,
                      borderColor:
                        this.state.noon === true
                          ? Colors.blueTextColor
                          : Colors.bleLayer3,
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansRegular,
                        color:
                          this.state.noon === true
                            ? Colors.white
                            : Colors.TextColor,
                        fontSize: hp(2),
                      }}>
                      Noon
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      this.setState({
                        evening: !this.state.evening,
                      });
                    }}
                    style={{
                      width: 80,
                      height: 42,
                      borderWidth: 1,
                      marginTop: hp(1.5),
                      alignItems: 'center',
                      justifyContent: 'center',
                      marginRight: hp(2),
                      borderRadius: 5,
                      backgroundColor:
                        this.state.evening === true
                          ? Colors.blueTextColor
                          : Colors.bleLayer4,
                      borderColor:
                        this.state.evening === true
                          ? Colors.blueTextColor
                          : Colors.bleLayer3,
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansRegular,
                        color:
                          this.state.evening === true
                            ? Colors.white
                            : Colors.TextColor,
                        fontSize: hp(2.2),
                      }}>
                      Evening
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            ) : null}
            {this.state.cardIndex === 3 ? (
              <View
                style={{
                  margin: hp(2),
                  backgroundColor: Colors.white,
                  borderRadius: 10,
                  shadowOffset: {width: 0.5, height: 0.5},
                  shadowOpacity: 0.1,
                  shadowRadius: 8,
                  elevation: 5,
                  flexDirection: 'column',
                  alignSelf: 'center',
                  width: '90%',
                  padding: hp(2),
                  paddingBottom: hp(2.5),
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansRegular,
                    fontSize: hp(2),
                    color: Colors.black,
                    marginTop: hp(1),
                  }}>
                  Have you got any intake advice?
                </Text>
                <View
                  style={{
                    flexDirection: 'row',
                    marginTop: hp(3),
                    justifyContent: 'space-between',
                  }}>
                  <TouchableOpacity
                    onPress={() => {
                      global.selectedIndex = 0;
                      this.setState({selectedIndex: 0});
                      global.selectedData.mealStatus = false;
                    }}
                    style={{
                      flex: 1,
                      height: 42,
                      borderWidth: 1,
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderRadius: 5,
                      backgroundColor:
                        this.state.selectedIndex === 0
                          ? Colors.blueTextColor
                          : Colors.bleLayer4,
                      borderColor:
                        this.state.selectedIndex === 0
                          ? Colors.blueTextColor
                          : Colors.bleLayer3,
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.NunitoBold,
                        color:
                          this.state.selectedIndex === 0
                            ? Colors.white
                            : Colors.TextColor,
                        fontSize: hp(2),
                      }}>
                      Before Meal
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      global.selectedIndex = 1;
                      this.setState({selectedIndex: 1});
                      global.selectedData.mealStatus = true;
                    }}
                    style={{
                      flex: 1,
                      height: 42,
                      borderWidth: 1,
                      marginLeft: hp(1),
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderRadius: 5,
                      backgroundColor:
                        this.state.selectedIndex === 1
                          ? Colors.blueTextColor
                          : Colors.bleLayer4,
                      borderColor:
                        this.state.selectedIndex === 1
                          ? Colors.blueTextColor
                          : Colors.bleLayer3,
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.NunitoBold,
                        color:
                          this.state.selectedIndex === 1
                            ? Colors.white
                            : Colors.TextColor,
                        fontSize: hp(2),
                      }}>
                      After Meal
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            ) : null}
            {this.state.cardIndex === 4 ? (
              <View
                style={{
                  margin: hp(2),
                  backgroundColor: Colors.white,
                  borderRadius: 10,
                  shadowOffset: {width: 0.5, height: 0.5},
                  shadowOpacity: 0.1,
                  shadowRadius: 8,
                  elevation: 5,
                  flexDirection: 'column',
                  alignSelf: 'center',
                  width: '90%',
                  padding: hp(2),
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansRegular,
                    fontSize: hp(2),
                    color: Colors.black,
                  }}>
                  Quantity?
                </Text>
                <View
                  style={{
                    flexDirection: 'row',
                    flexWrap: 'wrap',
                    padding: hp(1),
                  }}>
                  {this.renderDoseArray()}
                </View>
              </View>
            ) : null}
            {this.state.cardIndex >= 5 ? (
              <View
                style={{
                  margin: hp(2),
                  backgroundColor: Colors.white,
                  borderRadius: 10,
                  shadowOffset: {width: 0.5, height: 0.5},
                  shadowOpacity: 0.1,
                  shadowRadius: 8,
                  elevation: 5,
                  flexDirection: 'column',
                  alignSelf: 'center',
                  height: hp(25),
                  width: '90%',
                  padding: hp(2),
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansRegular,

                    fontSize: hp(2),
                    color: Colors.black,
                  }}>
                  When should it stop?
                </Text>
                <View
                  style={{
                    flexDirection: 'row',
                    flexWrap: 'wrap',
                    marginTop: hp(2),
                    alignItems: 'center',
                  }}>
                  <TouchableOpacity
                    onPress={() => {
                      global.stopIndex = 1;
                      let tempDate = new Date().toLocaleDateString('en-US', {
                        month: '2-digit',
                        day: '2-digit',
                        year: 'numeric',
                      });
                      console.log(
                        'Formated date after the week is : ',
                        tempDate,
                      );
                      this.setState({
                        dateSelectedIndex: 1,
                        incommingSelectedStopDate: tempDate,
                      });
                      global.selectedData.endDate = null;
                    }}
                    style={{
                      height: 42,
                      borderWidth: 1,
                      paddingHorizontal: hp(3.5),
                      alignItems: 'center',
                      justifyContent: 'center',
                      marginRight: hp(1),
                      borderRadius: 5,
                      backgroundColor:
                        this.state.dateSelectedIndex === 1
                          ? Colors.blueTextColor
                          : Colors.bleLayer4,
                      borderColor:
                        this.state.dateSelectedIndex === 1
                          ? Colors.blueTextColor
                          : Colors.bleLayer3,
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansRegular,
                        color:
                          this.state.dateSelectedIndex === 1
                            ? Colors.white
                            : Colors.TextColor,
                        fontSize: hp(2),
                      }}>
                      On Going
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      global.stopIndex = 2;
                      let tempDate = new Date();
                      tempDate.setDate(tempDate.getDate() + 7);
                      let formatedTempDate = tempDate.toLocaleDateString(
                        'en-US',
                        {
                          month: '2-digit',
                          day: '2-digit',
                          year: 'numeric',
                        },
                      );
                      var todayDate = new Date();
                      var numberOfDaysToAdd = 7;
                      todayDate.setDate(
                        todayDate.getDate() + numberOfDaysToAdd,
                      );
                      this.setState({
                        dateSelectedIndex: 2,
                        incommingSelectedStopDate: formatedTempDate,
                      });
                      // console.log('todayDate for the week : ',todayDate);
                      // console.log(todayDate);
                      // this.setState({incommingSelectedStopDate : todayDate});
                      global.selectedData.endDate = todayDate;
                    }}
                    style={{
                      height: 42,
                      borderWidth: 1,
                      paddingHorizontal: hp(1.5),
                      marginLeft: hp(1),
                      alignItems: 'center',
                      justifyContent: 'center',
                      marginRight: hp(2),
                      borderRadius: 5,
                      backgroundColor:
                        this.state.dateSelectedIndex === 2
                          ? Colors.blueTextColor
                          : Colors.bleLayer4,
                      borderColor:
                        this.state.dateSelectedIndex === 2
                          ? Colors.blueTextColor
                          : Colors.bleLayer3,
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansRegular,
                        color:
                          this.state.dateSelectedIndex === 2
                            ? Colors.white
                            : Colors.TextColor,
                        fontSize: hp(2),
                      }}>
                      After a Week
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      global.stopIndex = 3;
                      let tempDate = new Date();
                      tempDate.setDate(tempDate.getDate() + 30);
                      let formatedTempDate = tempDate.toLocaleDateString(
                        'en-US',
                        {
                          month: '2-digit',
                          day: '2-digit',
                          year: 'numeric',
                        },
                      );
                      var todayDate = new Date();
                      var numberOfDaysToAdd = 30;
                      todayDate.setDate(
                        todayDate.getDate() + numberOfDaysToAdd,
                      );
                      console.log('aftermonthDate : ', todayDate);
                      console.log(todayDate);
                      this.setState({
                        dateSelectedIndex: 3,
                        incommingSelectedStopDate: formatedTempDate,
                      });
                      global.selectedData.endDate = todayDate;
                    }}
                    style={{
                      height: 42,
                      borderWidth: 1,
                      marginTop: hp(2),
                      paddingHorizontal: hp(1.5),
                      marginRight: hp(1),
                      alignItems: 'center',
                      justifyContent: 'center',
                      marginRight: hp(2),
                      borderRadius: 5,
                      backgroundColor:
                        this.state.dateSelectedIndex === 3
                          ? Colors.blueTextColor
                          : Colors.bleLayer4,
                      borderColor:
                        this.state.dateSelectedIndex === 3
                          ? Colors.blueTextColor
                          : Colors.bleLayer3,
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansRegular,
                        color:
                          this.state.dateSelectedIndex === 3
                            ? Colors.white
                            : Colors.TextColor,
                        fontSize: hp(2),
                      }}>
                      After a Month
                    </Text>
                  </TouchableOpacity>
                  {this.state.stopDate !== null ? (
                    <TouchableOpacity
                      onPress={() => {
                        global.stopIndex = 4;
                        this.setState({dateSelectedIndex: 4});
                        var todayDate = new Date();
                        var numberOfDaysToAdd = 30;
                        todayDate.setDate(
                          todayDate.getDate() + numberOfDaysToAdd,
                        );
                        console.log('aftermonthDate');
                        console.log(todayDate);
                        global.selectedData.endDate = todayDate;
                      }}
                      style={{
                        height: 40,
                        borderWidth: 1,
                        marginTop: hp(1.5),
                        marginRight: hp(1),
                        paddingHorizontal: hp(2),
                        alignItems: 'center',
                        justifyContent: 'center',
                        borderRadius: 5,
                        backgroundColor:
                          this.state.dateSelectedIndex === 4
                            ? Colors.blueTextColor
                            : Colors.medicalHistoryBg,
                        borderColor:
                          this.state.dateSelectedIndex === 4
                            ? Colors.blueTextColor
                            : Colors.border,
                      }}>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansBold,
                          color:
                            this.state.dateSelectedIndex === 4
                              ? Colors.white
                              : Colors.buttonLabel,
                          fontSize: hp(2.2),
                        }}>
                        {new Date(this.state.stopDate).toLocaleDateString()}
                      </Text>
                    </TouchableOpacity>
                  ) : (
                    // changin it because of hanan request (START)
                    <TouchableOpacity
                      onPress={() => {
                        this.startDatePicker();
                      }}
                      style={{
                        width: 150,
                        height: 42,
                        marginTop: hp(1),

                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        paddingTop: hp(1.3),
                        paddingLeft: hp(1),
                        paddingRight: hp(1),
                        borderColor: Colors.headingColor,
                        opacity: 0.3,
                        borderRadius: 5,
                        borderWidth: 2,
                        backgroundColor: Colors.white,
                      }}>
                      <Text
                        style={{
                          fontSize: hp(2),
                          color: Colors.headingColor,

                          ...Platform.select({
                            android: {},
                          }),
                        }}>
                        {this.state.incommingSelectedStopDate}
                        {console.log(
                          'Date in case of never',
                          this.state.incommingSelectedStopDate,
                        )}
                      </Text>
                      <Image
                        source={Images.calenderIcon}
                        style={{justifyContent: 'flex-end'}}
                      />
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            ) : null}
            {/* </View> */}
            <View
              style={{
                height: hp(25),
                backgroundColor: Colors.BgColor,
                paddingTop: hp(0),
                paddingHorizontal: hp(2),
                flexDirection: 'row',
                justifyContent: 'space-around',
              }}>
              {this.state.cardIndex === 1 ? null : (
                <TouchableOpacity
                  onPress={() => {
                    global.frequencyIndex = 1;
                    global.timeArray = [];
                    this.state.timeArrNew = [];

                    global.selectedIndex = 0;
                    global.quantityIndex = 0;
                    global.stopIndex = 1;
                    global.date = null;
                    console.log(global.selectedData);

                    this.setState({cardIndex: this.state.cardIndex - 1});
                    console.log(this.state.cardIndex);
                    console.log('checking global card index value');
                    if (this.state.index > 1) {
                      this.setState({index: this.state.index - 1});
                    }
                  }}
                  style={{
                    height: 57,
                    width: '45%',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderWidth: 2,
                    borderRadius: 10,
                    backgroundColor: Colors.bleLayer3,
                    borderColor: Colors.bleLayer3,
                  }}>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansSemibold,
                      color: Colors.blueTextColor,
                      fontSize: hp(2.6),
                    }}>
                    Back
                  </Text>
                </TouchableOpacity>
              )}
              <TouchableOpacity
                onPress={() => {
                  if (this.state.cardIndex <= 4) {
                    this.setState({cardIndex: this.state.cardIndex + 1});
                  }

                  if (this.state.index < 2) {
                    this.setState({index: this.state.index + 1});
                  } else {
                    if (this.state.cardIndex >= 5) {
                      let slot = [];
                      this.setState({showLoader: true});
                      this.state.timeArrNew = [];
                      if (this.state.morning === true) {
                        this.state.timeArrNew.push('08:05 AM');
                        slot.push(0);
                      }
                      if (this.state.evening === true) {
                        this.state.timeArrNew.push('05:05 PM');
                        slot.push(2);
                      }
                      if (this.state.noon === true) {
                        this.state.timeArrNew.push('12:05 PM');
                        slot.push(1);
                      }

                      if (global.selectedData.doseTimings.length === 0) {
                        alert('Please add Time');
                      }
                      global.selectedData.doseTimings = this.state.timeArrNew;
                      global.selectedData.medicationSlot = slot;
                      global.selectedData.utcOffsetInMinutes =
                        this.state.timeOffest;
                      if (global.selectedData.endDate !== null) {
                        global.selectedData.endDate = moment(
                          global.selectedData.endDate,
                        ).format('YYYY-MM-DDTHH:mm:ss.SSS');
                      }
                      console.log(
                        'data before edit to server is ',
                        global.selectedData,
                      );

                      MedicationService.updateMedication(global.selectedData)
                        .then(response => {
                          this.setState({showLoader: false});
                          if (response.statusCode === 200) {
                            global.frequencyIndex = 1;
                            global.timeArray = [];
                            this.state.timeArrNew = [];
                            global.selectedIndex = 0;
                            global.quantityIndex = 0;
                            global.stopIndex = 1;
                            global.date = null;

                            this.props.navigation.goBack();
                          }
                        })
                        .catch(err => {
                          this.setState({showLoader: false});

                          console.log('error');
                          console.log(err);
                          showMessage({
                            message: 'Unable to add requested medicine',
                            description: err.detail,
                            type: 'default',
                            icon: {icon: 'info', position: 'left'},
                            backgroundColor: Colors.homeYellow,
                          });
                        });
                    }
                  }
                }}
                style={{
                  height: 57,
                  width: this.state.cardIndex === 1 ? '95%' : '45%',
                  marginLeft: hp(1),
                  alignItems: 'center',
                  justifyContent: 'center',
                  borderRadius: 10,
                  backgroundColor: Colors.blueTextColor,
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansBold,
                    color: Colors.white,
                    fontSize: hp(2.6),
                  }}>
                  {this.state.cardIndex >= 2 && this.state.cardIndex >= 5
                    ? 'Edit Medicine'
                    : 'Next'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </SafeAreaView>
      </Fragment>
    );
  }
}
