/* istanbul ignore file */
import {BlurView} from '@react-native-community/blur';
import moment from 'moment';
import React, {Fragment} from 'react';
import {
  Image,
  Modal,
  Platform,
  SafeAreaView,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import Spinner from 'react-native-loading-spinner-overlay';
import {ActivityIndicator} from 'react-native-paper';
import {
  heightPercentageToDP,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import images from '../../../../../app/config/Images';
import {Colors} from '../../../../config';
import {Fonts} from '../../../../config/AppConfig';
import Images from '../../../../config/Images';
import MedicationService from '../../../api/medication';
import {getAllMedication, getTodayMedication} from '../actions';
import {SvgCss} from 'react-native-svg';
import Svgs from '../../../../config/Svgs';
class MedicationDetailScreen extends React.PureComponent {
  constructor(props) {
    super(props);
    const {data} = this.props.route.params;
    this.state = {
      item: data,
      image: {uri: data.fdaMedicine.imagePath},
      isEnabled: data.isActive,
      modalVisible: false,
      showLoader: false,
    };
  }
  onError(error) {
    console.log(error);
    this.setState({image: Images.noImageFound});
  }

  setIsEnable(enable) {
    this.setState({isEnabled: enable});
    MedicationService.updateActiveStatus(this.state.item.id, enable)
      .then(res => {})
      .catch(error => {
        console.log('updateActiveStatus');
        console.log(error);
      });
  }
  getAllMedicationData() {
    this.setState({showLoader: true});
    MedicationService.getAllMedication()
      .then(response => {
        this.setState({showLoader: false});

        if (response && response.statusCode === 200) {
          this.props.dispatch(getAllMedication(response.data));
        }
      })
      .catch(error => {
        console.log(error);
        this.setState({showLoader: false});
      });
  }
  getTodayMedicationData() {
    MedicationService.getTodayMedication()
      .then(response => {
        if (
          response &&
          response.statusCode === 200 &&
          response.data.length > 0
        ) {
          this.props.dispatch(getTodayMedication(response.data));
        } else {
          this.props.dispatch(getTodayMedication([]));
        }
      })
      .catch(error => {
        console.log(error);
        this.setState({showLoader: false});
      });
  }

  showFrequencyDays(Days) {
    const Frequency = Days;

    if (Frequency === 1) {
      return 'Daily';
    } else if (Frequency === 7) {
      return 'Weekly';
    } else if (Frequency === 30) {
      return 'Monthly';
    } else {
      return 'Every ' + Frequency + ' Days';
    }
  }
  setModalVisible() {
    this.setState({modalVisible: !this.state.modalVisible});
  }
  render() {
    return (
      <Fragment>
        <SafeAreaView
          style={{
            flex: 1,
            backgroundColor: Colors.BgColor,
          }}>
          <Spinner
            visible={this.state.showLoader}
            textContent={'Please Wait....'}
            textStyle={{color: '#000'}}
          />
          <Modal
            animationType="fade"
            transparent={true}
            visible={this.state.modalVisible}
            backdropOpacity={0.3}>
            <BlurView
              blurType="prominent"
              style={{
                flex: 1,
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <View
                style={{
                  alignSelf: 'center',
                  justifyContent: 'space-around',
                  backgroundColor: Colors.transparent,
                  flex: 1,
                  width: '100%',
                  borderWidth: 1,
                  borderColor: Colors.lightGrey1,
                  alignItems: 'center',
                }}>
                <View
                  style={{
                    backgroundColor: Colors.white,
                    width: '80%',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    borderRadius: 10,
                  }}>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansBold,
                      fontSize: hp(2.6),
                      color: Colors.black,

                      marginVertical: hp(1),
                      marginLeft: hp(1),
                      alignSelf: 'flex-start',
                      paddingHorizontal: hp(1),
                    }}>
                    Confirmation
                  </Text>

                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontSize: hp(2),
                      color: Colors.black,
                      paddingHorizontal: hp(1),
                    }}>
                    Are you sure you want to delete this Medication
                  </Text>
                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'flex-end',
                      alignItems: 'center',
                      alignSelf: 'flex-end',
                    }}>
                    {!this.state.showLoader ? (
                      <TouchableOpacity
                        style={{
                          width: '25%',
                          height: hp(4),
                          marginTop: hp(1),
                          marginBottom: hp(1),
                          alignSelf: 'center',
                          borderRadius: 5,
                          borderColor: Colors.cyan,
                          justifyContent: 'center',
                          alignItems: 'center',
                        }}
                        onPress={() => {
                          this.setState({showLoader: true});
                          MedicationService.deleteMedication(this.state.item.id)
                            .then(res => {
                              this.props.navigation.goBack();
                              this.setState({showLoader: false});
                              if (res && res.Status === true) {
                                this.getTodayMedicationData();
                                this.getAllMedicationData();
                              }
                            })
                            .catch(err => {
                              this.setState({showLoader: false});
                              console.log('deleteMedicationerror');
                              console.log(err);
                            });
                        }}>
                        <Text
                          style={{
                            fontFamily: Fonts.SourceSansBold,
                            fontSize: hp(2.2),
                            color: Colors.black,
                          }}>
                          Yes
                        </Text>
                      </TouchableOpacity>
                    ) : Platform.OS === 'ios' ? (
                      <ActivityIndicator size={'small'} color={Colors.black} />
                    ) : (
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansBold,
                          fontSize: hp(2.2),
                          color: Colors.black,
                        }}>
                        Yes
                      </Text>
                    )}
                    <TouchableOpacity
                      style={{
                        width: '25%',
                        marginTop: hp(1),
                        marginBottom: hp(1),
                        height: hp(4),
                        alignSelf: 'center',
                        borderRadius: 5,
                        borderColor: Colors.cyan,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}
                      onPress={() => this.setModalVisible()}>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansBold,
                          fontSize: hp(2.2),
                          color: Colors.black,
                        }}>
                        No
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            </BlurView>
          </Modal>
          <ScrollView>
            <View
              style={{
                flex: 1,
                backgroundColor: Colors.BgColor,
              }}>
              <View
                style={{
                  // paddingTop: hp(7),
                  flexDirection: 'row',
                  width: '100%',
                  alignItems: 'center',
                  height: hp(8),
                  borderBottomWidth: 0.5,
                  borderColor: Colors.BgColor,
                  backgroundColor: Colors.BgColor,
                }}>
                <SvgCss
                  style={{marginLeft: hp(2)}}
                  xml={Svgs.arrowHeadLeft}
                  width={hp(4)}
                  height={hp(4)}
                  fill={Colors.black}
                  onPress={() => {
                    this.props.navigation.pop();
                  }}
                />
                {/* <TouchableOpacity
                  onPress={() => {
                    this.props.navigation.pop();
                  }}>
                  <Text
                    style={{
                      fontFamily: 'WisemanPTSymbols',
                      marginLeft: heightPercentageToDP(1),
                      marginRight: heightPercentageToDP(1),
                      fontSize: hp(5),
                      color: Colors.black1,
                    }}>
                    W
                  </Text>
                </TouchableOpacity> */}
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansBold,
                    marginLeft: hp(10),
                    fontSize: hp(2.5),
                    color: Colors.black1,
                    flex: 1,
                  }}>
                  Prescriptions
                </Text>
                <TouchableOpacity
                  onPress={() =>
                    this.props.navigation.navigate('NotificationStack')
                  }>
                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'flex-start',
                      marginRight: hp(2),
                    }}>
                    <Image
                      style={{
                        width: hp(2),
                        height: hp(2.5),
                      }}
                      source={Images.notification_dashboard}
                    />
                  </View>
                </TouchableOpacity>
              </View>
              <View
                style={{
                  backgroundColor: Colors.BgColor,
                }}>
                <View style={{backgroundColor: Colors.BgColor}}>
                  <View
                    style={{
                      marginLeft: hp(2),
                      marginTop: hp(6),
                      backgroundColor: Colors.white,
                      width: '90%',
                      borderRadius: 10,
                      paddingTop: hp(2),
                      shadowOffset: {width: 0.05, height: 0.05},
                      shadowOpacity: 0.2,
                      shadowRadius: 8,
                      elevation: 3,
                    }}>
                    {this.state.item.source !== null &&
                      this.state.item.source === '2' && (
                        <View
                          style={{
                            flexDirection: 'row',
                            marginBottom: hp(3),
                            marginLeft: hp(3),
                            marginRight: hp(3),
                          }}>
                          <TouchableOpacity
                            onPress={() => {
                              this.props.navigation.navigate('EditMedication', {
                                medId: this.state.item.id,
                              });
                              global.selectedData = this.state.item;
                            }}>
                            <Image
                              source={images.editIcon}
                              style={{width: hp(3), height: hp(3)}}
                            />
                          </TouchableOpacity>

                          <View
                            style={{
                              flex: 1,
                              alignItems: 'flex-end',
                            }}>
                            <TouchableOpacity
                              onPress={() => {
                                this.setModalVisible();
                              }}>
                              <Image
                                source={images.deleteIcon}
                                style={{width: hp(3), height: hp(3)}}
                              />
                            </TouchableOpacity>
                          </View>
                        </View>
                      )}
                    <View
                      style={{
                        paddingTop:
                          this.state.item.source !== null &&
                          this.state.item.source === '2'
                            ? hp(2)
                            : hp(5),
                        alignItems: 'center',
                      }}>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansBold,
                          fontSize: hp(2.2),
                          color: Colors.black,
                        }}>
                        {this.state.item.fdaMedicine.proprietaryname}
                      </Text>
                    </View>
                    <View
                      style={{
                        flexDirection: 'row',
                        marginTop: hp(3),
                        marginBottom: hp(2),
                        marginLeft: hp(3),
                        marginRight: hp(3),
                        alignItems: 'center',
                      }}>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansSemibold,
                          fontSize: hp(2),
                          color: Colors.black1,
                          flex: 0.3,
                        }}>
                        Name
                      </Text>
                      <View
                        style={{
                          flex: 1,
                          alignItems: 'flex-end',
                        }}>
                        <Text
                          style={{
                            fontFamily: Fonts.SourceSansRegular,
                            fontSize: hp(2),
                            color: Colors.black2,
                          }}>
                          {this.state.item.fdaMedicine.proprietaryname}
                        </Text>
                      </View>
                    </View>

                    <View
                      style={{
                        flexDirection: 'row',
                        marginLeft: hp(3),
                        marginBottom: hp(3),
                        marginRight: hp(3),
                      }}>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansSemibold,
                          fontSize: hp(2),
                          flex: 1,
                          color: Colors.black1,
                        }}>
                        Frequency
                      </Text>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansRegular,
                          marginLeft: heightPercentageToDP(5),
                          fontSize: hp(2),
                          color: Colors.black2,
                        }}>
                        {this.state.item.frequencyInDays}
                      </Text>
                    </View>

                    <View
                      style={{
                        flexDirection: 'row',

                        marginBottom: hp(3),
                        marginLeft: hp(3),
                        marginRight: hp(3),
                      }}>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansSemibold,
                          fontSize: hp(2),
                          flex: 1,
                          color: Colors.black1,
                        }}>
                        Advice
                      </Text>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansRegular,
                          marginLeft: heightPercentageToDP(5),
                          fontSize: hp(2),
                          color: Colors.black2,
                        }}>
                        {this.state.item.mealStatus === false
                          ? 'Before Meal'
                          : 'After Meal'}
                      </Text>
                    </View>

                    <View
                      style={{
                        flexDirection: 'row',

                        marginBottom: hp(3),
                        marginLeft: hp(3),
                        marginRight: hp(3),
                      }}>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansSemibold,
                          fontSize: hp(2),
                          flex: 1,
                          color: Colors.black1,
                        }}>
                        End Date
                      </Text>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansRegular,
                          marginLeft: heightPercentageToDP(5),
                          fontSize: hp(2),
                          color: Colors.black2,
                        }}>
                        {this.state.item.endDate !== null
                          ? moment(this.state.item.endDate).format('MMM Do YY')
                          : 'On Going'}
                      </Text>
                    </View>
                  </View>
                </View>
                <TouchableOpacity
                  onPress={() => {
                    this.props.navigation.navigate('Pharmacies', {
                      image: this.state.item.fdaMedicine.imagePath,
                      name: this.state.item.fdaMedicine.proprietaryname,
                      ndc: this.state.item.fdaMedicine.ndc,
                      quantity: this.state.item.quantity,
                      dosage: this.state.item.fdaMedicine.dosageformname,
                    });
                  }}
                  style={{
                    width: '90%',
                    marginBottom: hp(2),
                    marginTop: hp(3),
                    height: hp(7),
                    alignSelf: 'center',
                    borderRadius: 5,
                    backgroundColor: Colors.blueTextColor,
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansBold,
                      fontSize: hp(2.2),
                      color: Colors.white,
                    }}>
                    Search Low Cost Medication
                  </Text>
                </TouchableOpacity>

                <View
                  style={{
                    // height: '100%',
                    marginLeft: hp(17),
                    width: hp(12),

                    flexDirection: 'row',
                    alignItems: 'center',
                    position: 'absolute',
                  }}>
                  <Image
                    style={{
                      width: '100%',
                      height: hp(12),
                      resizeMode: 'contain',
                      alignSelf: 'center',
                    }}
                    source={Images.medIcon4x}
                  />
                </View>
              </View>
            </View>
          </ScrollView>
        </SafeAreaView>
      </Fragment>
    );
  }
}
export default MedicationDetailScreen;
