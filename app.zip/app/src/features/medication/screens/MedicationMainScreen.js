/* istanbul ignore file */
import React, {Fragment} from 'react';
import {SafeAreaView} from 'react-native';
import Spinner from 'react-native-loading-spinner-overlay';
import {connect} from 'react-redux';
import Colors from '../../../../config/Colors';
import MedicationService from '../../../api/medication';
import MainHeader from '../../mycare/components/MainHeader';
import {getTodayMedication} from '../actions';
import MedicationDashboard from '../components/MedicationDashboard';
var instance = null;
class MedicationMainScreen extends React.PureComponent {
  constructor(props) {
    super(props);
    // this.handleBackButtonClick = this.handleBackButtonClick.bind(this);
    this.state = {dataArray: [], refreshing: false};
  }

  componentDidMount(): void {
    instance = this;
    instance.onAddNewButtonPress.bind(this);
    this.willFocusSubscription = this.props.navigation.addListener(
      'focus',
      () => {
        console.log('come here to foucs');
        this.getTodayMedicationData();
      },
    );
  }

  componentDidUpdate(
    prevProps: Readonly<P>,
    prevState: Readonly<S>,
    snapshot: SS,
  ): void {
    if (
      prevProps.allTodayMedicationData.length !==
      this.props.allTodayMedicationData.length
    ) {
      this.props.dispatch(
        getTodayMedication(this.props.allTodayMedicationData),
      );
      this.setState({
        dataArray: this.props.allTodayMedicationData,
      });
    }
  }

  getTodayMedicationData() {
    this.setState({showLoader: true});
    MedicationService.getTodayMedication()
      .then(response => {
        this.setState({showLoader: false});
        if (
          response &&
          response.statusCode === 200 &&
          response.data.length > 0
        ) {
          console.log('condition passed successfully medication put');
          this.setState({showLoader: false});
          this.props.dispatch(getTodayMedication(response.data));
          this.setState({
            dataArray: response.data,
          });
        } else {
          this.setState({showLoader: false});
          this.props.dispatch(getTodayMedication([]));
        }
      })
      .catch(error => {
        console.log(error);
        this.setState({showLoader: false});
      });
  }

  /* istanbul ignore next */
  onAddNewButtonPress() {
    global.selectedData = null;
    this.props.navigation.navigate('AddNewMedication');
  }
  _onRefresh = () => {
    this.getTodayMedicationData();
  };
  render() {
    return (
      <Fragment>
        <Spinner
          visible={this.state.showLoader}
          textContent={'Loading....'}
          textStyle={{color: '#FFF'}}
        />
        <SafeAreaView style={{flex: 1, backgroundColor: Colors.BgColor}}>
          <MainHeader name={'Medication'} navigation={this.props.navigation}>
            <MedicationDashboard
              myProps={this.props}
              data={this.state.dataArray}
              todayMedication={() => this.getTodayMedicationData()}
            />
          </MainHeader>
        </SafeAreaView>
      </Fragment>
    );
  }
}
/* istanbul ignore next */
const mapStateToProps = ({
  allTodayMedicationData,
  homeApiData,
  modalHandler,
}) => ({
  allTodayMedicationData,
  homeApiData,
  modalHandler,
});
export default connect(mapStateToProps)(MedicationMainScreen);
