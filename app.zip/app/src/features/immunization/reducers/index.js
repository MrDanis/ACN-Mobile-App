/* istanbul ignore file */
export const immunizationData = (state = false, action) => {
  switch (action.type) {
    case 'GET_IMMUNIZATION_DATA':
      return action.data;
    default:
      return state;
  }
};
