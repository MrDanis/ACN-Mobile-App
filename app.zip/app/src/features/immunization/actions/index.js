/* istanbul ignore file */
export const getImmunizationData = data => ({
  type: 'GET_IMMUNIZATION_DATA',
  data,
});
