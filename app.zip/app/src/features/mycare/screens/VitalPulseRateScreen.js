import {useEffect, useRef, useState} from 'react';

import moment from 'moment';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';

import AsyncStorage from '@react-native-async-storage/async-storage';
import {useFocusEffect} from '@react-navigation/native';
import Moment from 'moment';
import React from 'react';
import {
  Image,
  Platform,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {AnimatedCircularProgress} from 'react-native-circular-progress';

import {showMessage} from 'react-native-flash-message';
import Spinner from 'react-native-loading-spinner-overlay';
import {Modalize} from 'react-native-modalize';
import {SafeAreaView} from 'react-native-safe-area-context';
import {SvgCss} from 'react-native-svg';
import {useDispatch, useSelector} from 'react-redux';
import {Colors, Images, Svgs} from '../../../../config';
import {Fonts, OSSource} from '../../../../config/AppConfig';
import images from '../../../../config/Images';
import VitalsService from '../../../api/vitals';
import {getHeartRateFromGoogleFit} from '../../../helpers/GoogleFit/GoogleFitHandler';
import {getHeartRateHK} from '../../../helpers/HealthKit/HealthKitHandler';
import CustomTestChart from '../../home/screens/custom_chart';
import {modalHanlder} from '../../medication/actions';
import {getVitalSubTypesData} from '../action';
import MainHeader from '../components/MainHeader';

const VitalPulseRateScreen = ({navigation, route}) => {
  let dateType = 0;
  const dispatch = useDispatch();
  const {vitalsData} = route.params;
  const userProfileData = useSelector(state => state.userProfileData);
  const [vitalData, setvitalData] = useState(vitalsData);
  const [historyData, setHistoryData] = useState();
  const [refreshing, setRefreshing] = useState(false);
  const [date, setDate] = useState(
    moment(new Date()).format('yyyy-MM-DDThh:mm:ss'),
  );
  const [pulseRate, setPulseRate] = useState(0);
  const [pulsePercentValue, setPulsePercentValue] = useState(0);
  const [vitalSubType, setVitalSubType] = useState(null);
  const [isEditable, setIsEditable] = useState(false);
  const [barData, setbarData] = useState([]);
  const [loader, setLoader] = useState(false);
  const modalizeRef = useRef(Modalize);
  const [isHealthkit, setIsHealthKit] = useState(false);
  const [isGoogleFit, setIsGoogleFit] = useState(false);
  const [isSelectedDay, setisSelectedDay] = useState('Day');
  const [heartRateFromHealth, setHeartRateFromHealth] = useState();
  const [heartRateFromGoogleFit, setHeartRateFromGoogleFit] = useState();

  let percentValue = 0;

  useFocusEffect(
    React.useCallback(() => {
      getVitalSubType();
      getVitalHistory(date);
    }, []),
  );
  useEffect(() => {
    if (Platform.OS === 'ios') {
      getHeartRateHK()
        .then(results => {
          setHeartRateFromHealth(results);
          checkForVitalDataUpdates();
        })
        .catch(error => {
          // Handle any errors that occurred during the execution of x() here
          console.error('Error calling x:', error);
        });
    } else {
      getHeartRateFromGoogleFit()
        .then(res => {
          setHeartRateFromGoogleFit(res);
          checkForVitalDataUpdates();
        })
        .catch(err => {
          console.log('User have denied the access', err);
        });
    }
    getVitalSubType();
  }, [historyData]);
  const getVitalSubType = () => {
    setLoader(true);
    // setLoaderSlider(true);
    VitalsService.getVitalSubTypeData(vitalsData.loinc)
      .then(res => {
        console.log('Vitals SubType Data', vitalsData.id, vitalsData.loinc);
        console.log(res);
        //Adding the else part for the if in case of no data is comming from the api

        if (res.statusCode === 200 && res.data.length > 0) {
          let val = null;
          setLoader(false);
          setVitalSubType(res?.data[0]);
          // Below check is added because we have null value when the user is first time comming to PulseRate Screen wich cause issue in the Circular Progress bar
          if (Object.is(res.data[0].value, null)) {
            percentValue =
              (parseInt(res?.data[0]?.defaultValue) / res?.data[0]?.maxRange) *
              100;
            percentValue = parseInt(percentValue.toFixed(0));
          } else {
            percentValue =
              (parseInt(res?.data[0]?.value) / res?.data[0]?.maxRange) * 100;
            percentValue = parseInt(percentValue.toFixed(0));
          }

          setPulsePercentValue(percentValue);
          setPulseRate(res.data[0].value);
          dispatch(getVitalSubTypesData(res.data));
        } else {
          setLoader(false);
        }
      })
      .catch(err => {
        setLoader(false);
        console.log('Vitals Error', err);
        showMessage({
          message: 'Information',
          description: err.message,
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  };

  const getVitalHistory = date => {
    setLoader(true);

    VitalsService.getVitalCategoryHistory(
      vitalsData.id,
      Moment(new Date(date)).format('YYYY-MM-DD'),
      dateType,
      vitalData.loinc,
    )
      .then(response => {
        setLoader(false);
        if (response && response.statusCode === 200) {
          setHistoryData(response.data);
          getvitalDataForChart(response.data);
          setRefreshing(false);
        } else {
          showMessage({
            message: 'Information',
            description:
              'Authentication Failed. Provided information is not verified.',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        }
      })
      .catch(err => {
        setLoader(false);
        console.log('error');
        console.log(err);
        showMessage({
          message: 'Info',
          description: 'Internal Server Error',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  };
  function getvitalDataForChart(listData) {
    let newVitallist = [];
    let tempdata = [];
    if (dateType === 1) {
      let newDate = moment(date).subtract(7, 'days');
      const days = [];
      for (let i = 1; i <= 7; i++) {
        newDate = newDate.add(1, 'days');
        const dayName = newDate.format('dddd');

        days.push(dayName);
      }

      let objData = null;
      days.map((day, index) => {
        objData = listData.filter((data, index) => {
          if (day === moment(new Date(data.createdDate)).format('dddd')) {
            return data;
          }
        });
        tempdata.push(objData.length !== 0 ? objData[0] : {});

        if (
          objData.length !== 0 &&
          tempdata[index] !== null &&
          tempdata[index] !== {}
        ) {
          newVitallist.push({
            value: objData[0]?.vitalData[0]?.value,
            label: day.slice(0, 3),
            labelWidth: 20,
            labelTextStyle: {color: 'gray', fontSize: 10},
            frontColor: objData[0]?.isCritical ? '#F44336' : '#00D685',
            topLabelComponent: () => (
              <Text
                style={{
                  color: 'black',
                  fontSize: 8,
                  // width: 20,
                  // marginLeft: 5,
                  marginBottom: 5,
                  height: 10,
                }}>
                {tempdata[index]?.vitalData[0]?.value}
              </Text>
            ),
            spacing: 18,
          });
        } else {
          newVitallist.push({
            value: 0,
            label: day.slice(0, 3),
            labelWidth: 20,
            labelTextStyle: {color: 'grey', fontSize: 9},
            frontColor: '#2962FF',
            spacing: 18,
          });
        }
      });
    } else if (dateType === 2) {
      let newDate = moment(date).subtract(30, 'days');
      const days = [];
      for (let i = 1; i <= 30; i++) {
        newDate = newDate.add(1, 'days');

        const dayString = newDate.format('YYYY-MM-DD');
        days.push(dayString);
      }

      let objData = null;
      days.map((day, index) => {
        objData = listData.filter((data, index) => {
          if (day === moment(new Date(data.createdDate)).format('YYYY-MM-DD')) {
            return data;
          }
        });
        tempdata.push(objData.length !== 0 ? objData[0] : {});

        if (objData.length !== 0) {
          newVitallist.push({
            value: objData[0]?.vitalData[0]?.value,
            label: day.slice(8, 10),
            labelWidth: 20,
            labelTextStyle: {color: 'gray', fontSize: 10},
            frontColor: objData[0]?.isCritical ? '#F44336' : '#00D685',
            topLabelComponent: () => (
              <Text
                style={{
                  color: 'black',
                  fontSize: 8,

                  marginBottom: 5,
                  height: 10,
                }}>
                {tempdata[index]?.vitalData[0]?.value}
              </Text>
            ),
            spacing: 18,
          });
        } else {
          newVitallist.push({
            value: 0,
            label: day.slice(8, 10),
            labelWidth: 20,
            labelTextStyle: {color: 'gray', fontSize: 10},
            frontColor: '#2962FF',
            spacing: 18,
          });
        }
      });
    } else {
      // Same logic but it is not working like it is working in activities for the day data
      let dayFormatSample = [
        '12:00 AM',
        '01:00 AM',
        '02:00 AM',
        '03:00 AM',
        '04:00 AM',
        '05:00 AM',
        '06:00 AM',
        '07:00 AM',
        '08:00 AM',
        '09:00 AM',
        '10:00 AM',
        '11:00 AM',
        '12:00 PM',
        '01:00 PM',
        '02:00 PM',
        '03:00 PM',
        '04:00 PM',
        '05:00 PM',
        '06:00 PM',
        '07:00 PM',
        '08:00 PM',
        '09:00 PM',
        '10:00 PM',
        '11:00 PM',
        '12:00 AM',
      ];
      let stackData = [];
      for (let j = 0; j < dayFormatSample.length; j++) {
        let groupedDayData = [];
        for (let k = 0; k < listData?.length; k++) {
          let recordSubmitTime = moment
            .utc(moment.utc(listData[k]?.createdDate).format())
            .local()
            .format('hh:mm A');
          let currentTime = moment(recordSubmitTime, 'hh:mm A');
          let afterTime = moment(dayFormatSample[j], 'hh:mm A');
          let beforeTime = moment(dayFormatSample[j + 1], 'hh:mm A');
          if (currentTime.isBetween(afterTime, beforeTime)) {
            groupedDayData.push({
              value: listData[k]?.value,
              label: '', //moment(moment(dataResponse?.data[i]?.createdDate)).format('hh:mm A'),
              labelWidth: 20,
              labelTextStyle: {color: 'gray'},
              frontColor: listData[k]?.isCritical ? '#F44336' : '#00D685', //Colors.purpleBar,
              spacing: 18,
              topLabelComponent: () => (
                <View>
                  <Text
                    style={{
                      color: 'black',
                      fontSize: 8,
                      width: '100%',
                      marginBottom: 5,
                      height: 10,
                      borderColor: 'red',
                      borderWidth: 0,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                    <Text
                      style={{
                        color: 'black',
                        fontSize: 8,
                        // width: 20,
                        // marginLeft: 5,
                        marginBottom: 5,
                        height: 10,
                      }}>
                      {listData[k]?.value}
                    </Text>
                  </Text>
                </View>
              ),
            });
          }
        }
        let testData = {
          value: groupedDayData?.length > 0 ? groupedDayData[0]?.value : 0,
          label:
            j === 0
              ? '12A'
              : j === 12
              ? '12P'
              : j === 24
              ? '12A'
              : j % 2 !== 0
              ? ''
              : dayFormatSample[j].split(':')[0],
          spacing: 10,
          labelWidth: 20,
          labelTextStyle: {color: 'gray', fontSize: 10},
          frontColor: groupedDayData[0]?.frontColor,
          topLabelComponent: () => (
            <Text style={{color: 'black', fontSize: 8}}>
              {groupedDayData[0]?.value}
            </Text>
          ),
        };
        stackData.push(testData);
      }
      newVitallist.push(...stackData);
    }

    setbarData(newVitallist);
  }

  const setDateTypeFunction = d => {
    dateType = d;
  };

  const handleValue = React.useCallback(
    newValue => {
      percentValue =
        (newValue / vitalsData?.criticalMaxRange.split('.')[0]) * 100;

      setPulsePercentValue(percentValue);
      setPulseRate(newValue);
    },
    [setPulseRate],
  );

  const addVitalHandler = () => {
    measureVitalCall();
  };

  function measureVitalCall() {
    const listObj = [];
    const catData = {
      vitalSubTypeId: vitalSubType.id,
      value: String(pulseRate),
    };
    listObj.push(catData);
    setLoader(true);
    const data = {
      vitalTypeId: vitalsData.id,
      source: OSSource,
      categoryData: listObj,
      createdSource: userProfileData.role === 'Patient' ? 1 : 2,
      dateCreated: moment(new Date()).utc().format('YYYY-MM-DDTHH:mm:ss.SSS'),
      loinc: vitalsData.loinc,
    };
    VitalsService.addVital(data)
      .then(response => {
        setLoader(false);
        if (response && response.statusCode === 200) {
          setIsEditable(false);

          navigation.pop();
        } else {
          showMessage({
            message: 'Information',
            description:
              'Authentication Failed. Provided information is not verified.',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        }
      })
      .catch(err => {
        setLoader(false);
        console.log('error');
        console.log(err);
        showMessage({
          message: 'Info',
          description: err.message,
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  }

  const convertUTCDateToAMPM = date => {
    var newDate = new Date(
      date.getTime() + date.getTimezoneOffset() * 60 * 1000,
    );
    const dateTimeAndroid = moment(new Date(date)).format('A');

    var offset = date.getTimezoneOffset() / 60;
    var hours = date.getHours();
    newDate.setHours(hours - offset);

    const dateTimeIos = moment(new Date(newDate)).format('A');

    return Platform.OS === 'ios' ? dateTimeIos : dateTimeAndroid;
  };
  function sendHealthKitDataToDB() {
    // Check if the heartRateFromHealthKit is comming from the healthkit or not
    // If it is comming then save it to Db otherwise ignore it
    console.log('data from parent is : ', heartRateFromHealth);
    if (
      !(
        heartRateFromHealth === undefined ||
        heartRateFromHealth === null ||
        heartRateFromHealth.length === 0
      )
    ) {
      const data = {
        vitalTypeId: vitalData.id,
        source: OSSource,
        categoryData: [
          {
            vitalSubTypeId: 3,
            value: `${heartRateFromHealth[0]?.value}`,
          },
        ],
        createdSource: 1,
        dateCreated: moment(new Date()).utc().format('YYYY-MM-DDTHH:mm:ss.SSS'),
        loinc: vitalData.loinc,
      };
      console.log(
        'payload for the api to send health kit data to DB',
        JSON.stringify(data),
      );
      VitalsService.addVital(data)
        .then(response => {
          getVitalHistory(date);
          onClose();
          console.log(
            'this is the response of api call of send healthkit data to db',
            response,
          );
        })
        .catch(err => {
          console.log('error in api call of send healthkit data to db');
          console.log(err);
        });
    } else {
      console.log(
        'Comming to the else because data is not comming from the healthkit',
      );
    }
  }
  function sendGoogleFitDataToDB() {
    // Check if the heartRateFromHealthKit is comming from the healthkit or not
    // If it is comming then save it to Db otherwise ignore it
    console.log('data from parent is : ', heartRateFromGoogleFit);
    if (
      !(
        heartRateFromGoogleFit === undefined ||
        heartRateFromGoogleFit === null ||
        heartRateFromGoogleFit.length === 0
      )
    ) {
      const data = {
        vitalTypeId: vitalData.id,
        source: OSSource,
        categoryData: [
          {
            vitalSubTypeId: 3,
            value: `${
              heartRateFromGoogleFit[heartRateFromGoogleFit?.length - 1].value
            }`,
          },
        ],
        createdSource: 1,
        dateCreated: moment(
          heartRateFromGoogleFit[heartRateFromGoogleFit.length - 1].startDate,
        )
          .utc()
          .format('YYYY-MM-DDTHH:mm:ss.SSS'),
        loinc: vitalData.loinc,
      };
      console.log(
        'payload for the api to send google fit pulse data to DB',
        JSON.stringify(data),
      );
      VitalsService.addVital(data)
        .then(response => {
          getVitalHistory(date);

          onClose();
          console.log(
            'this is the response of api call of send pulse data from google fit  to db',
            response,
          );
        })
        .catch(err => {
          console.log(
            'error in api call of send pulse data from google fit  to db',
          );
          console.log(err);
        });
    } else {
      console.log(
        'Comming to the else because data is not comming from the google fit',
      );
    }
  }
  function saveData() {
    if (isHealthkit) {
      saveToAsyncStorage(heartRateFromHealth[0]);
      sendHealthKitDataToDB();
    } else if (isGoogleFit) {
      saveToAsyncStorage(
        heartRateFromGoogleFit[heartRateFromGoogleFit.length - 1],
      );
      sendGoogleFitDataToDB();
    }
  }
  const compareWithLastSavedValue = async newValue => {
    try {
      const lastSavedValueString = await AsyncStorage.getItem(
        'lastSavedValuePulseRate',
      );
      console.log('value  recieved in comparefun', newValue);
      if (lastSavedValueString) {
        const lastSavedValue = JSON.parse(lastSavedValueString);

        // Convert date strings to Date objects
        const newDate = new Date(newValue);
        const lastSavedDate = new Date(lastSavedValue.startDate);

        // Compare based on Date objects
        if (newDate > lastSavedDate) {
          // The new value has a later startDate, prompt the user or take action
          onOpen();
        } else {
          // The new value has an equal or earlier startDate, no need to prompt
          //do nothing
        }
      } else {
        // No last saved value found, prompt the user or take action
        onOpen();

        console.log(
          'No last saved value found. Prompt the user or take action for the new value.',
        );
        onOpen();
      }
    } catch (error) {
      console.error('Error reading from AsyncStorage:', error);
      // Handle the error as needed
    }
  };
  function onOpen() {
    modalizeRef.current?.open();
    // props.dispatch(modalHanlder(false));
  }

  function onClose() {
    modalizeRef.current?.close();
  }
  const saveToAsyncStorage = async valueObject => {
    try {
      await AsyncStorage.setItem(
        'lastSavedValuePulseRate',
        JSON.stringify(valueObject),
      );
    } catch (error) {
      console.error('Error saving to AsyncStorage:', error);
    }
  };
  function checkForVitalDataUpdates() {
    if (
      !(
        heartRateFromHealth === undefined ||
        heartRateFromHealth === null ||
        heartRateFromHealth.length === 0
      )
    ) {
      setIsHealthKit(true);
      setIsGoogleFit(false);
      compareWithLastSavedValue(heartRateFromHealth[0].startDate);
    } else if (
      !(
        heartRateFromGoogleFit === undefined ||
        heartRateFromGoogleFit === null ||
        heartRateFromGoogleFit.length === 0
      )
    ) {
      setIsGoogleFit(true);
      setIsHealthKit(false);
      compareWithLastSavedValue(
        heartRateFromGoogleFit[heartRateFromGoogleFit.length - 1].startDate,
      );
    }
  }
  return (
    <SafeAreaView
      style={{flex: 1, backgroundColor: Colors.backgroundMainLogin}}>
      <MainHeader navigation={navigation} name="Pulse Rate">
        <Modalize
          ref={modalizeRef}
          adjustToContentHeight={true}
          onClosed={() => {
            dispatch(modalHanlder(true));
          }}
          modalStyle={{
            borderTopRightRadius: 25,
            borderTopLeftRadius: 25,
            minHeight: 250,
            backgroundColor: Colors.white,
          }}>
          <View
            style={{
              justifyContent: 'center',
              backgroundColor: Colors.white,
              width: '90%',
              borderRadius: 3,
              alignSelf: 'center',
              marginVertical: hp(1.5),
            }}>
            <View
              style={{
                flexDirection: 'column',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginTop: hp(1),
              }}>
              <Image
                source={Images.completeAssessment}
                style={{
                  alignSelf: 'center',
                  height: hp(10),
                  width: hp(10),
                }}
              />
              <Text
                style={{
                  fontFamily: Fonts.SourceSansBold,
                  fontSize: hp(3),
                  flex: 1,
                  color: Colors.black1,
                  marginTop: hp(1),
                  marginLeft: hp(2),
                  textAlign: 'center',
                }}>
                Do you want to save the Heart Rate value{' '}
                {isGoogleFit
                  ? heartRateFromGoogleFit[heartRateFromGoogleFit.length - 1]
                      .value
                  : isHealthkit
                  ? parseInt(heartRateFromHealth[0]?.value)
                  : ''}{' '}
                BPM ?
              </Text>
            </View>
            <View
              style={{
                flexDirection: 'column',
                justifyContent: 'space-around',
                marginTop: hp(1),
                width: '100%',
              }}>
              <TouchableOpacity
                onPress={() => {
                  saveData();
                }}
                style={{
                  flexDirection: 'row',
                  marginTop: hp(2),
                  marginBottom: hp(2),
                  marginRight: hp(3),
                  width: '100%',
                  borderWidth: 1,
                  height: 50,
                  borderColor: Colors.blueTextColor,
                  justifyContent: 'center',
                  alignItems: 'center',
                  borderRadius: 8,
                  backgroundColor: Colors.blueTextColor,
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansSemibold,
                    fontSize: hp(2.2),
                    flex: 1,
                    color: Colors.white,
                    textAlign: 'center',
                  }}>
                  Save
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  onClose();
                  dispatch(modalHanlder(true));
                  if (isHealthkit) {
                    saveToAsyncStorage(heartRateFromHealth[0]);
                  } else if (isGoogleFit) {
                    saveToAsyncStorage(
                      heartRateFromGoogleFit[heartRateFromGoogleFit.length - 1],
                    );
                  }
                }}
                style={{
                  flexDirection: 'row',
                  width: '100%',
                  height: 50,
                  backgroundColor: Colors.lightRed,
                  justifyContent: 'center',
                  alignItems: 'center',
                  borderRadius: 8,
                  marginBottom: hp(2),
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansSemibold,
                    fontSize: hp(2.2),
                    flex: 1,
                    color: Colors.red,
                    textAlign: 'center',
                  }}>
                  Cancel
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modalize>
        <View style={{flex: 1, backgroundColor: Colors.backgroundMainLogin}}>
          <ScrollView
            refreshControl={
              <RefreshControl
                refreshing={refreshing}
                onRefresh={() => {
                  setRefreshing(true);
                  getVitalHistory(date);
                }}
              />
            }
            style={{
              backgroundColor: Colors.backgroundMainLogin,
            }}>
            <Spinner
              visible={loader}
              textContent={'Loading...'}
              textStyle={{color: '#FFF'}}
            />
            {/* Calender View */}

            {/* Main Card Daily Steps, Circular Bar And Distance Speed Time, Custom Chart*/}
            <View style={{width: '100%', alignSelf: 'center'}}>
              {/* Daily Steps Row */}
              <View
                style={{
                  backgroundColor: 'white',
                  width: '90%',
                  alignSelf: 'center',
                  marginVertical: hp(2),
                  paddingVertical: hp(2),
                  alignItems: 'center',
                  borderRadius: hp(1),
                  elevation: hp(5),
                  shadowOffset: {width: 0.5, height: 0.5},
                  shadowOpacity: 0.1,
                  shadowRadius: 8,
                }}>
                <View
                  style={{
                    flexDirection: 'row',
                    alignContent: 'center',
                    alignItems: 'center',
                    alignSelf: 'flex-end',
                  }}>
                  <View
                    style={{
                      paddingRight: hp(10),
                    }}
                  />

                  <TouchableOpacity
                    onPress={() => {
                      navigation.navigate('PulseRateEditScreen', {
                        heading: 'Set Pulse Rate',
                        changeTextTitle: 'Pulse Rate',
                        onChangValue: handleValue,
                        unit: 'bpm',
                        value: pulseRate,
                        maxRange: vitalSubType.maxRange,
                        minRange: vitalSubType.minRange,
                        vitalSubType: vitalSubType,
                        vitalsData: vitalsData,
                      });
                    }}>
                    <Image
                      style={{
                        width: 20,
                        height: 20,
                        marginRight: hp(1),
                        alignSelf: 'center',
                      }}
                      source={images.edit_assessment}
                    />
                  </TouchableOpacity>
                </View>
                <AnimatedCircularProgress
                  size={hp(24)}
                  width={7.5}
                  fill={pulsePercentValue}
                  rotation={360}
                  tintColor={Colors.red3}
                  backgroundColor={Colors.bleLayer4}>
                  {fill => (
                    <View>
                      <SvgCss
                        xml={Svgs.pulse_rate}
                        width={hp(5)}
                        height={hp(5)}
                        fill={Colors.black}
                        style={{marginHorizontal: hp(1.5)}}
                      />
                      <Text
                        style={{
                          alignSelf: 'center',
                          fontSize: hp(1.4),
                          color: Colors.darkgrey,
                          paddingBottom: hp(0.5),
                        }}>
                        Heart Rate
                      </Text>
                      <Text
                        style={{
                          alignSelf: 'center',
                          fontSize: hp(2.5),
                          fontWeight: '600',
                          fontFamily: Fonts.SourceSansRegular,
                          paddingBottom: hp(0.5),
                          color: Platform.OS === 'android' ? 'black' : '',
                        }}>
                        {pulseRate === null
                          ? vitalSubType?.defaultValue
                          : pulseRate}
                      </Text>
                      <Text
                        style={{
                          alignSelf: 'center',
                          color: Colors.darkGrey,
                        }}>
                        {'BPM'}
                      </Text>
                    </View>
                  )}
                </AnimatedCircularProgress>
                <View
                  style={{
                    backgroundColor: 'white',
                    width: '90%',
                    alignSelf: 'center',
                  }}>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'space-evenly',
                      marginTop: hp(4),
                      marginBottom: hp(0.4),
                    }}>
                    {/* Pulse Rate Box View */}
                    <View
                      style={{
                        alignContent: 'center',
                        alignItems: 'center',
                      }}>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansSemibold,
                          fontSize: hp(2.6),

                          color: Colors.black,
                        }}>
                        {vitalSubType?.minRange} {''}
                        <Text
                          style={{
                            fontFamily: Fonts.SourceSansRegular,
                            fontSize: hp(2),

                            color: Colors.noRecordFound,
                          }}>
                          bpm
                        </Text>
                      </Text>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansRegular,
                          fontSize: hp(1.6),
                          fontWeight: '400',

                          color: Colors.noRecordFound,
                        }}>
                        Min
                      </Text>
                    </View>
                    {/* Max Pulse Rate Box View */}
                    <View
                      style={{
                        alignContent: 'center',
                        alignItems: 'center',
                      }}>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansSemibold,
                          fontSize: hp(2.6),

                          color: Colors.black,
                        }}>
                        {vitalSubType?.maxRange} {''}
                        <Text
                          style={{
                            fontFamily: Fonts.SourceSansRegular,
                            fontSize: hp(2),

                            color: Colors.noRecordFound,
                          }}>
                          bpm
                        </Text>
                      </Text>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansRegular,
                          fontSize: hp(1.6),
                          fontWeight: '400',

                          color: Colors.noRecordFound,
                        }}>
                        Max
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
              <CustomTestChart
                barDataRetrived={barData}
                setDateType={setDateTypeFunction}
                getVitalHistory={getVitalHistory}
                date={date}
                setisSelectedDay={setisSelectedDay}
                isSelectedDay={isSelectedDay}
                maxValue={
                  barData?.length === 0
                    ? vitalsData?.criticalMaxRange
                    : parseInt(
                        ([...barData]?.sort((a, b) => b?.value - a?.value))[0]
                          ?.value,
                      ) + 50
                }
              />
            </View>
          </ScrollView>
        </View>
      </MainHeader>
    </SafeAreaView>
  );
};

export default VitalPulseRateScreen;

const styles = StyleSheet.create({});
