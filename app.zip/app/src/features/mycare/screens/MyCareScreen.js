import React, {useEffect} from 'react';
import {FlatList, SafeAreaView, View,Image} from 'react-native';
import {connect, useDispatch, useSelector} from 'react-redux';
import {Colors} from '../../../../config';
import ProfileService from '../../../api/profile';
import {getUserProfile} from '../../profile/action';
import FooterModules from '../components/FooterModules';
import HeaderImage from '../components/HeaderImage';
import MyCareModules from '../components/MyCareModules';

const Modules = [
  {
    name: 'My Vitals',
    key: 'V',
    image: require('../../../../../assets/images/Vital_color.png'),
  },
  {
    name: 'Assessments',
    key: 'A',
    image: require('../../../../../assets/images/assessment_color.png'),
  },
];
console.log('====================================');
console.log('Modules', Modules);
console.log('====================================');

const MyCareScreen = props => {
  const userProfileData = useSelector(state => state.userProfileData);
  const dispatch = useDispatch();
  useEffect(() => {
    ProfileService.getUserProfile()
      .then(response => {
        console.log('getUserProfile');
        console.log(response);
        if (response && response.statusCode === 200) {
          dispatch(getUserProfile(response.data));
        }
      })
      .catch(error => {
        console.log(error);
      });
  }, []);

  return (
    <SafeAreaView
      style={{
        flex: 1,
        height: '100%',
        backgroundColor: Colors.backgroundMainLogin,
      }}>
      <View
        style={{
          flex: 1,
          maxWidth: '90%',
          minWidth: '90%',
          alignSelf: 'center',
        }}>
        <FlatList
          nestedScrollEnabled={true}
          columnWrapperStyle={{justifyContent: 'space-between'}}
          ListHeaderComponent={
            <HeaderImage userProfileData={userProfileData} />
          }
          ListFooterComponent={<FooterModules navigation={props.navigation} />}
          data={Modules}
          numColumns={2}
          renderItem={({item}) => {
            console.log('====================================');
            console.log('item', item);
            console.log('====================================');
            return (
              <MyCareModules
                name={item.name}
                image={item.image}
                navigation={props.navigation}
                Module={item.key}
              />
            );
          }}
        />
      </View>
    </SafeAreaView>
  );
};

export default connect()(MyCareScreen);
