import React, {Fragment} from 'react';
import {
  BackHandler,
  Image,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {SafeAreaView} from 'react-navigation';
import Colors from '../../../../../config/Colors';
import AssessmentService from '../../../../api/assesment';
import {showMessage} from 'react-native-flash-message';
import Spinner from 'react-native-loading-spinner-overlay';
import Modal from 'react-native-modal';
import {Modalize} from 'react-native-modalize';
import {connect} from 'react-redux';
import {Fonts} from '../../../../../config/AppConfig';
import Images from '../../../../../config/Images';
import {AssessmentNavigator} from '../../../../helpers/Assessment/AssessmentNavigator';
import {modalHanlder} from '../../../medication/actions';
import MainHeader from '../../components/MainHeader';
import {QuestionRenderer} from '../../components/assessmentQuestions/QuestionRenderer';
export var finalAssessmentData = null;
class AssessmentDetail extends React.PureComponent {
  /* istanbul ignore next */

  navigator: AssessmentNavigator = null;
  static navigationOptions = ({navigation}) => ({
    header: null,
  });

  /* istanbul ignore next */
  constructor(props) {
    super(props);
    this.handleBackButtonClick = this.handleBackButtonClick.bind(this);
    this.state = {
      item: {},
      rootData: [],
      showLoader: false,
      itemData: null,
      selectedIndex: 0,
      currentQuestion: null,
      surveyDetailObj: null,
      fromSummary: false,
      fromPending: false,
      isButtonColor: false,
      buttonText: 'Next',
      modalVisible: false,
      formSubId: 0,
      headerTitle: '',
    };
  }
  /* istanbul ignore next */
  setSelectedIndex(index) {
    this.setState({selectedIndex: index});
  }
  /* istanbul ignore next */
  handleBackButtonClick() {
    if (this.state.fromSummary === true) {
      this.props.navigation.navigate('AssessmentStack');
    } else {
      this.props.navigation.goBack();
    }
    return true;
  }

  /* istanbul ignore next */
  componentDidMount(): void {
    BackHandler.addEventListener(
      'hardwareBackPress',
      this.handleBackButtonClick,
    );
  }

  /* istanbul ignore next */
  componentWillUnmount(): void {
    BackHandler.addEventListener(
      'hardwareBackPress',
      this.handleBackButtonClick,
    );
  }

  /* istanbul ignore next */
  setModalVisible(visible) {
    this.setState({modalVisible: visible});
  }
  componentDidMount(): void {
    this.willFocusSubscription = this.props.navigation.addListener(
      'focus',
      async () => {
        let {route} = this.props;
        let {fromSummary, dataObj, index, fromPending, itemData, title} =
          route.params;
        console.log('====================================');
        console.log('itemData in Ass Detail', itemData);
        console.log('====================================');
        if (fromSummary) {
          this.setUpCurrentQuestion(dataObj, index);
        }

        this.setState({
          fromSummary: fromSummary,
          selectedIndex: index,
          fromPending: fromPending,
          itemData: itemData,
          formSubId: itemData.formSubId,
          headerTitle: title,
        });
        this.setState({itemData: itemData, formSubId: itemData.formSubId});
        this.getAssessmentDetailData(itemData, 0);
      },
    );
  }
  /* istanbul ignore next */
  getAssessmentDetailData(itemData, index) {
    this.setState({showLoader: true});
    AssessmentService.getAssessmentsDetails(itemData)
      .then(res => {
        this.setState({showLoader: false});
        this.setUpCurrentQuestion(res, 0);
      })
      .catch(error => {
        this.setState({showLoader: false});
        console.log('error data');
        console.log(error);
        showMessage({
          message: 'Information',
          description: error.message,
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  }
  /* istanbul ignore next */
  setUpCurrentQuestion(surveyObj, index) {
    this.navigator = new AssessmentNavigator(surveyObj.data);
    let question = this.navigator.currentQuestion(index);
    this.setState({surveyDetailObj: surveyObj.data, currentQuestion: question});
  }
  /* istanbul ignore next */
  setupNavigator(surveyObj) {
    this.navigator = new AssessmentNavigator(surveyObj);
    let question = this.navigator.start();
    this.setState({surveyDetailObj: surveyObj, currentQuestion: question});
  }
  /* istanbul ignore next */
  componentWillReceiveProps(nextProps: Readonly<P>, nextContext: any): void {
    const {assessmentDetailsObj} = nextProps;
    if (assessmentDetailsObj !== null) {
    }
  }
  /* istanbul ignore next */
  onRefresh() {
    console.log('refresh load');
  }
  /* istanbul ignore next */
  willFocusAction = payload => {
    let params = payload.state.params;
    let {fromSummary, dataObj, index, fromPending, itemData, title} = params;
    if (fromSummary) {
      this.setUpCurrentQuestion(dataObj, index);
    } else {
      // this.getAssessmentDetailData(itemData, index);
    }

    this.setState({
      fromSummary: fromSummary,
      selectedIndex: index,
      fromPending: fromPending,
      itemData: itemData,
      formSubId: itemData.formSubId,
      headerTitle: title,
    });
  };
  /* istanbul ignore next */
  saveAssessmentOnServer(filledQuestion, isLast) {
    this.onClose();
    this.props.dispatch(modalHanlder(true));
    console.log('Sate data is : ', this.state?.itemData);
    let data = {};
    let currentAssessmentId = this.state.itemData.id;
    data.id = currentAssessmentId;
    data.formSubId =
      this.state.itemData.formSubId === 0 && this.state.formSubId === 0
        ? this.state.itemData.formSubId
        : this.state.formSubId;
    data.question = filledQuestion;
    data.patientAssessmentId = this.state?.itemData.patientAssessmentId;
    data.taskId = this.state?.itemData.taskId;

    AssessmentService.saveAssessmentSingleQuestion(data)
      .then(res => {
        if (res) {
          if (
            this.state.itemData.formSubId === 0 &&
            this.state.formSubId === 0
          ) {
            this.setState({formSubId: res?.data?.formSubId});
          } else {
          }
          if (isLast) {
            let data = {};
            data.id = this.state.itemData.id;
            data.formSubId = this.state.itemData.formSubId;
            data.patientAssessmentId = this.state?.itemData.patientAssessmentId;
            data.taskId = this.state?.itemData.taskId;

            this.markCompletedAssessmentOnServer(data);
          }
        } else {
          if (isLast) {
            let data = {};
            data.id = this.state.itemData.id;
            data.formSubId = this.state.itemData.formSubId;
            data.patientAssessmentId = this.state?.itemData.patientAssessmentId;
            data.taskId = this.state?.itemData.taskId;
            console.log('markCompletedAssessmentOnServer in else');
            console.log(data);
            this.markCompletedAssessmentOnServer(data);
          } else {
            console.log('some thing went wrong');
          }
        }
      })
      .catch(error => {
        console.log('error data', error);
        showMessage({
          message: 'Error',
          description: error.message,
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  }
  /* istanbul ignore next */
  saveEditAssessmentOnServer(filledQuestion) {
    let data = {};
    data.Id = this.state.itemData.id;
    data.FormSubId = this.state.itemData.formSubId;
    data.Question = filledQuestion;

    this.setState({showLoader: true});
    AssessmentService.saveAssessmentSingleQuestion(data)
      .then(res => {
        this.setState({showLoader: false});
        if (res) {
          showMessage({
            message: 'Great!',
            description: 'Survey Saved',
            type: 'default',
            icon: {icon: 'success', position: 'left'},
            backgroundColor: 'green',
            duration: 3 * 1000,
          });
          this.props.navigation.goBack(null);
        }
      })
      .catch(error => {
        console.log('error data', error);
      });
  }
  /* istanbul ignore next */
  markCompletedAssessmentOnServer(data) {
    let palyload = {
      ...data,
      formSubId: this.state.formSubId,
    };
    this.setState({showLoader: true});
    AssessmentService.markCompletedAssessment(palyload)
      .then(res => {
        this.setState({showLoader: false});

        if (res.data === true) {
          showMessage({
            message: 'Survey Completed',
            description: 'Survey is successfully completed.',
            type: 'success',
            icon: {icon: 'success', position: 'left'},
            // backgroundColor: 'green',
            duration: 3 * 1000,
          });
          // navigateToStack.navigate('AssessmentStack')

          this.props.navigation.popToTop();
          // this.props.navigation.navigate('AssessmentStack');
        } else {
          this.setState({showLoader: false});
          showMessage({
            message: 'Survey is not saved',
            description: '',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        }
      })
      .catch(error => {
        console.log('error data', error);
        this.setState({showLoader: false});
        showMessage({
          message: 'Error',
          description: 'Server is busy now',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  }
  onOpen() {
    this.refs.modalize.open();
  }
  onClose() {
    this.refs.modalize.close();
  }
  /* istanbul ignore next */
  render() {
    return (
      <SafeAreaView
        style={{flex: 1, backgroundColor: Colors.backgroundMainLogin}}>
        <MainHeader navigation={this.props.navigation} name={'Screenings'}>
          <Fragment>
            <Modalize
              ref="modalize"
              adjustToContentHeight={true}
              onClosed={() => {
                this.props.dispatch(modalHanlder(true));
              }}
              modalStyle={{
                borderTopRightRadius: 25,
                borderTopLeftRadius: 25,
                minHeight: 250,
                backgroundColor: Colors.white,
              }}>
              <View style={styles.modal}>
                <View
                  style={{
                    flexDirection: 'column',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    marginTop: hp(1),
                  }}>
                  <Image
                    source={Images.completeAssessment}
                    style={{
                      alignSelf: 'center',
                      height: hp(10),
                      width: hp(10),
                    }}
                  />
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansBold,
                      fontSize: hp(3),
                      flex: 1,
                      color: Colors.black1,
                      marginTop: hp(1),
                      marginLeft: hp(2),
                      textAlign: 'center',
                      borderColor: 'red',
                    }}>
                    Would you like to send the survey now?
                  </Text>
                </View>
                <View
                  style={{
                    flexDirection: 'column',
                    justifyContent: 'space-around',
                    marginTop: hp(1),
                    width: '100%',
                  }}>
                  <TouchableOpacity
                    onPress={() => {
                      this.saveAssessmentOnServer(
                        this.navigator.currentQuestion,
                        true,
                      );
                    }}
                    style={{
                      flexDirection: 'row',
                      marginTop: hp(2),
                      marginBottom: hp(2),
                      marginRight: hp(3),
                      width: '100%',
                      borderWidth: 1,
                      height: 50,
                      borderColor: Colors.blueTextColor,
                      justifyContent: 'center',
                      alignItems: 'center',
                      borderRadius: 8,
                      backgroundColor: Colors.blueTextColor,
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansSemibold,
                        fontSize: hp(2.2),
                        flex: 1,
                        color: Colors.white,
                        textAlign: 'center',
                      }}>
                      Send now
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      console.log('Cancel is pressed to close the modal...');
                      this.refs.modalize.close();
                      this.onClose();
                      this.props.dispatch(modalHanlder(true));
                      this.props.navigation.popToTop();
                    }}
                    style={{
                      flexDirection: 'row',
                      width: '100%',
                      height: 50,
                      backgroundColor: Colors.lightRed,
                      justifyContent: 'center',
                      alignItems: 'center',
                      borderRadius: 8,
                      marginBottom: hp(2),
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansSemibold,
                        fontSize: hp(2.2),
                        flex: 1,
                        color: Colors.red,
                        textAlign: 'center',
                      }}>
                      Cancel
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </Modalize>
            <Modal
              isVisible={this.state.modalVisible}
              style={{alignItems: 'center', justifyContent: 'center'}}>
              <View style={styles.modal}>
                <View
                  style={{
                    height: hp(14),
                    backgroundColor: Colors.medicalHistoryBg,
                  }}
                />
                <View
                  style={{
                    alignSelf: 'center',
                    marginTop: hp(-5),
                  }}></View>
                <View style={{padding: hp(2)}}>
                  <Text
                    style={{
                      fontSize: hp(3),
                      textAlign: 'center',
                      fontFamily: Fonts.SourceSansRegular,
                      marginTop: hp(3),
                      marginBottom: hp(4),
                      color: Colors.black,
                      // borderWidth: 1,
                      borderColor: 'blue',
                    }}>
                    Would you like to send the survey now?
                  </Text>

                  <View
                    style={{
                      flexDirection: 'row',
                      width: '100%',
                      marginBottom: hp(1),
                    }}>
                    <View
                      style={{
                        flex: 1,
                        flexDirection: 'row',
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      <TouchableOpacity
                        onPress={() => {
                          this.setModalVisible(!this.state.modalVisible);
                        }}
                        style={{
                          marginRight: hp(2),
                          backgroundColor: Colors.label,
                          borderRadius: hp(1),
                          padding: hp(2),
                        }}>
                        <Text
                          style={{
                            fontSize: hp(2),
                            fontFamily: Fonts.SourceSansRegular,
                            color: Colors.white,
                          }}>
                          CANCEL
                        </Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        onPress={() => {
                          this.setModalVisible(!this.state.modalVisible);
                          this.saveAssessmentOnServer(
                            this.navigator.currentQuestion,
                            true,
                          );
                        }}
                        style={{
                          padding: hp(2),
                          backgroundColor: Colors.assessment_blue_500,
                          borderRadius: hp(1),
                        }}>
                        <Text
                          style={{
                            fontSize: hp(2),
                            fontFamily: Fonts.SourceSansRegular,
                            color: Colors.white,
                          }}>
                          Send Now
                        </Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </View>
            </Modal>
            <View
              style={{
                flex: 1,
                flexDirection: 'column',
                backgroundColor: Colors.backgroundMainLogin,
              }}>
              {this.state.surveyDetailObj !== null ? (
                <View style={{flex: 1, flexDirection: 'column'}}>
                  {this.state.currentQuestion ? (
                    <View
                      style={{
                        flex: 1,
                        paddingTop: hp(1),
                        marginLeft: hp(1.5),
                        marginRight: hp(1.5),
                        backgroundColor: Colors.backgroundMainLogin,
                        elevation: 10,
                        borderTopLeftRadius: 10,
                        borderTopRightRadius: 10,
                      }}>
                      <View
                        style={{
                          width: '99%',
                          flex: 1,
                        }}>
                        <Text
                          style={{
                            marginLeft: hp(2),
                            marginRight: hp(1),
                            fontSize: hp(2.2),
                            fontFamily: Fonts.SourceSansRegular,
                            color: Colors.blueTextColor,
                            marginVertical: hp(3),
                          }}>
                          {'Question ' +
                            (this.navigator.currentIndex + 1) +
                            '/' +
                            this.navigator.questionsToAsk.length}
                        </Text>
                        <QuestionRenderer
                          key={`${this.state.currentQuestion.id}-${this.state.currentQuestion.parentQuestionId}`}
                          question={this.state.currentQuestion}
                          onAnswer={arg => {
                            console.log(
                              'onAnswer get full object here from on answer and then make two differnet args onw with keys and one just answer ',
                              arg,
                            );
                            console.log(answers);
                            const answers = arg.map(item => {
                              console.log(
                                '====================================',
                              );
                              console.log('item in detail', item);
                              console.log(
                                '====================================',
                              );
                              if (this.state.currentQuestion.type === 5) {
                                return item.text;
                              } else if (
                                this.state.currentQuestion.type === 2 ||
                                this.state.currentQuestion.type === 6
                              ) {
                                return item.label;
                              } else if (
                                this.state.currentQuestion.type === 4
                              ) {
                                return item.label;
                              } else {
                                return item;
                              }
                            });
                            let answerId = null;
                            // this.state.currentQuestion.type === 4
                            //   ? arg.map(item => item.item.id)
                            //   : arg.map(item => item.id);
                            if (this.state.currentQuestion.type === 4) {
                              answerId = arg.map(item => item.item.id);
                            } else if (this.state.currentQuestion.type === 0) {
                              answerId = null;
                            } else {
                              answerId = arg.map(item => item.id);
                            }
                            console.log(
                              'these are the gathered data : ',
                              answerId,
                              this.state.currentQuestion,
                            );
                            this.navigator.saveAnswer(
                              this.state.currentQuestion.id,
                              this.state.currentQuestion.parentQuestionId,
                              answers,
                              answerId,
                            );
                            if (this.navigator.isLastQuestion()) {
                              this.setState({
                                isButtonColor: true,
                                buttonText: 'Complete',
                              });
                            } else {
                              this.setState({
                                isButtonColor: false,
                                buttonText: 'Next',
                              });
                            }
                          }}
                        />
                      </View>
                    </View>
                  ) : null}
                  {/*===================================== Above code will render when the user start the survey =================================*/}
                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'space-evenly',
                      alignItems: 'center',
                      width: '94%',
                      alignSelf: 'center',
                      paddingBottom: hp(1),
                      backgroundColor: Colors.backgroundMainLogin,
                      borderBottomRightRadius: 10,
                      borderBottomLeftRadius: 10,
                      marginBottom: hp(2),
                      overflow: 'hidden',
                    }}>
                    <TouchableOpacity
                      style={{
                        justifyContent: 'center',
                        backgroundColor: Colors.bleLayer3,
                        borderRadius: 8,

                        flexDirection: 'row',
                        marginRight: hp(2),
                        alignItems: 'center',
                        paddingLeft: hp(1),
                        paddingRight: hp(1),
                        borderColor: Colors.blueTextColor,
                        height: hp(7.5),
                        width: '45%',
                      }}
                      onPress={() => {
                        this.setState({isButtonColor: false});
                        if (this.navigator.canGoPrevious()) {
                          let prevQuestion =
                            this.navigator.moveToPreviousQuestion();
                          this.setState({currentQuestion: prevQuestion});
                        } else {
                          this.props.navigation.goBack();
                        }
                      }}>
                      <Text style={styles.backButtonEnable}>Previous</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                      style={{
                        justifyContent: 'center',
                        backgroundColor: Colors.blueTextColor,
                        borderRadius: 8,
                        flexDirection: 'row',
                        alignItems: 'center',
                        paddingLeft: hp(1),
                        paddingRight: hp(1),
                        height: hp(7.5),
                        width: '45%',
                      }}
                      onPress={() => {
                        console.log('this.navigator.filledSurveyToSave()');
                        console.log(this.navigator.currentQuestion);
                        this.saveAssessmentOnServer(
                          this.navigator.currentQuestion,
                          false,
                        );
                        if (this.navigator.canGoNext()) {
                          let nextQuestion =
                            this.navigator.moveToNextQuestion();
                          if (nextQuestion) {
                            this.setState({currentQuestion: nextQuestion});
                          } else {
                            this.refs.modalize.open();
                            this.onOpen();
                            this.props.dispatch(modalHanlder(false));
                          }
                        } else {
                          showMessage({
                            message: 'Message',
                            description: 'Please answer the required question',
                            type: 'warning',
                            icon: {icon: 'info', position: 'left'},
                            duration: 3 * 1000,
                          });
                        }
                      }}>
                      <Text
                        style={{
                          fontSize: hp(2.5),
                          color: Colors.white,
                          marginRight: hp(1),
                          fontFamily: Fonts.SourceSansRegular,
                        }}>
                        {this.navigator.isLastQuestion()
                          ? 'Complete'
                          : this.state.buttonText}
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              ) : (
                <ScrollView
                  contentContainerStyle={{
                    flex: 1,
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                  refreshControl={
                    <RefreshControl
                      refreshing={this.state.refreshing}
                      onRefresh={this.onRefresh.bind(this)}
                    />
                  }>
                  <Text
                    style={{
                      fontSize: hp(2),
                      color: Colors.fontGrey,
                      fontFamily: Fonts.SourceSansRegular,
                    }}>
                    No Assessment Question Data Available.
                  </Text>
                </ScrollView>
              )}
              {this.state.showLoader === true ? (
                <Spinner
                  visible={this.state.showLoader}
                  textContent={'Loading...'}
                  textStyle={{color: '#FFF'}}
                />
              ) : null}
            </View>
          </Fragment>
        </MainHeader>
      </SafeAreaView>
    );
  }
}
/* istanbul ignore next */
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.medicalHistoryBg,
  },
  slideContainer: {
    flex: 1,
    flexDirection: 'column',
    alignItems: 'center',
  },
  activeDotStyle: {
    backgroundColor: Colors.green,
    width: 11,
    height: 11,
    borderRadius: 6,
    marginLeft: 5,
    marginRight: 5,
    marginTop: 5,
    marginBottom: 5,
  },
  dotStyle: {
    backgroundColor: Colors.borderColor,
    width: 8,
    height: 8,
    borderRadius: 5,
    marginLeft: 5,
    marginRight: 5,
    marginTop: 5,
    marginBottom: 5,
  },
  backButtonDisable: {
    fontSize: hp(2.5),
    padding: 13,
    color: Colors.assessment_green_700,
    fontFamily: Fonts.SourceSansRegular,
  },
  backButtonEnable: {
    fontSize: hp(2.5),
    color: Colors.blueTextColor,
    fontFamily: Fonts.SourceSansRegular,
  },
  nextButtonLarge: {
    justifyContent: 'center',
    flexDirection: 'row',
    width: '30%',
    alignSelf: 'flex-start',
    marginLeft: '2.5%',
    backgroundColor: Colors.assessment_lightgreen_500,
    borderRadius: 4,
    alignItems: 'center',
    height: hp(7.5),
  },
  nextButtonSmall: {
    justifyContent: 'center',
    backgroundColor: Colors.assessment_lightgreen_500,
    borderRadius: 4,
    flexDirection: 'row',
    alignItems: 'center',
    height: hp(7.5),
    width: hp(22),
  },
  modal: {
    justifyContent: 'center',
    backgroundColor: Colors.white,
    width: '90%',
    borderRadius: 3,
    alignSelf: 'center',
    marginVertical: hp(1.5),
  },
});

export default connect()(AssessmentDetail);
