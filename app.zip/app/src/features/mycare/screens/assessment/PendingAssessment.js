import React, {Fragment} from 'react';
import {FlatList, RefreshControl, ScrollView, Text, View} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Colors from '../../../../../config/Colors';
import AssessmentService from '../../../../api/assesment';

import {showMessage} from 'react-native-flash-message';
import Spinner from 'react-native-loading-spinner-overlay';
import {Fonts} from '../../../../../config/AppConfig';
import AssessmentItem from '../../components/AssessmentItem';
/* istanbul ignore next */
function Item({item, navigation}) {
  console.log('item');
  console.log(item);
  const fill = item.completionPercentage;
  return (
    <AssessmentItem item={item} navigation={navigation} completed={false} />
  );
}
var Ref = null;
export class PendingAssessment extends React.PureComponent {
  /* istanbul ignore next */
  constructor(props) {
    super(props);
    this.state = {
      refreshing: false,
      showLoader: false,
      assessmentData: [],
      allAssessmentData: [],
      selectedFilter: 'All Programs',
    };
  }
  /* istanbul ignore next */
  componentDidMount(): void {
    Ref = this;
    console.log('Component did mount is called....');
    this.callGetAssessmentListApi();
  }
  componentWillMount(): void {
    this.willFocusSubscription = this.props.navigation.addListener(
      'focus',
      () => {
        console.log('This should work when we focus on someting.....');
        this.callGetAssessmentListApi();
      },
    );
  }
  /* istanbul ignore next */
  componentWillUnmount(): void {}
  /* istanbul ignore next */
  async callGetAssessmentListApi() {
    this.setState({showLoader: true});
    AssessmentService.getPendingAssessmentsList()
      .then(response => {
        console.log('res');
        console.log(response);
        this.setState({showLoader: false});
        if (response.statusCode === 200) {
          global.newAssessmentCount = response.data.length;

          this.setState({
            assessmentData: response.data,
            allAssessmentData: response.data,
          });
        }
      })
      .catch(error => {
        this.setState({showLoader: false});
        global.newAssessmentCount = 0;
        console.log('error');
        console.log(error);
        showMessage({
          message: 'Information',
          description: error.message,
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  }

  /* istanbul ignore next */
  onRefresh() {
    this.callGetAssessmentListApi();
  }
  /* istanbul ignore next */
  renderSeparator = () => {
    return (
      <View
        style={{
          height: 1,
          width: '80%',
          backgroundColor: Colors.line,
          alignSelf: 'flex-end',
        }}
      />
    );
  };
  /* istanbul ignore next */
  render() {
    return (
      <Fragment>
        <View
          style={{
            flex: 1,
            backgroundColor: Colors.BgColor,
            flexDirection: 'column',
          }}>
          {this.state.assessmentData.length ? (
            <View style={{flex: 1}}>
              <FlatList
                data={this.state.assessmentData}
                extraData={this.state.refresh}
                renderItem={({item}) => (
                  <Item item={item} navigation={this.props.navigation} />
                )}
                keyExtractor={item => item.assessmentID}
                refreshControl={
                  <RefreshControl
                    refreshing={this.state.refreshing}
                    onRefresh={this.onRefresh.bind(this)}
                  />
                }
              />
            </View>
          ) : (
            <ScrollView
              contentContainerStyle={{
                flex: 1,
                alignItems: 'center',
                justifyContent: 'center',
              }}
              refreshControl={
                <RefreshControl
                  refreshing={this.state.refreshing}
                  onRefresh={this.onRefresh.bind(this)}
                />
              }>
              <Text
                style={{
                  fontSize: hp(2),
                  color: Colors.fontGrey,
                  fontFamily: Fonts.SourceSansRegular,
                }}>
                No Screening Available.
              </Text>
            </ScrollView>
          )}
          {this.state.showLoader === true ? (
            <Spinner
              visible={this.state.showLoader}
              textContent={'Loading...'}
              textStyle={{color: '#FFF'}}
            />
          ) : null}
        </View>
      </Fragment>
    );
  }
}

export default PendingAssessment;
