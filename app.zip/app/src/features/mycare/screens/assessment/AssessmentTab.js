import React, {useState} from 'react';
import {Platform, StyleSheet, Text, View} from 'react-native';
import {TouchableOpacity} from 'react-native-gesture-handler';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Colors from '../../../../../config/Colors';
import CompletedAssessment from './CompletedAssessment';
import PendingAssessment from './PendingAssessment';
function AssessmentTab({navigation}) {
  const [index, setIndex] = useState(0);
  const [newBtn, SetNewBtn] = useState(true);
  const [completeBtn, setCompleteBtn] = useState(false);
  const [routes] = useState([
    {key: 'first', title: 'New'},
    {key: 'second', title: 'Completed'},
  ]);
  return (
    <View>
      <View
        style={{
          alignItems: 'center',
        }}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'center',
            backgroundColor: Colors.bleLayer4,
            width: Platform.OS === 'ios' ? '90%' : hp(44),
            borderRadius: hp(1),
          }}>
          <TouchableOpacity
            style={{
              minWidth: Platform.OS === 'ios' ? '50%' : hp('23%'),
              height: Platform.OS === 'android' ? hp(6) : hp(7),
              flexDirection: 'row',
              justifyContent: 'center',
              alignItems: 'center',
              backgroundColor: newBtn ? Colors.blueTextColor : Colors.bleLayer4,
              borderRadius: hp(1),
            }}
            onPress={() => {
              SetNewBtn(true);
              setCompleteBtn(false);
            }}>
            <Text style={{color: newBtn ? Colors.white : Colors.noRecordFound}}>
              New
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              minWidth: Platform.OS === 'ios' ? '50%' : hp('23%'),
              height: Platform.OS === 'android' ? hp(6) : hp(7),
              justifyContent: 'center',
              alignItems: 'center',
              backgroundColor: completeBtn
                ? Colors.blueTextColor
                : Colors.bleLayer4,
              borderRadius: hp(1),
              shadowRadius: 5,
              marginLeft: Platform.OS === 'ios' ? hp(0.1) : hp(0),
            }}
            onPress={() => {
              setCompleteBtn(true);
              SetNewBtn(false);
            }}>
            <Text
              style={{
                color: completeBtn ? Colors.white : Colors.noRecordFound,
              }}>
              Completed
            </Text>
          </TouchableOpacity>
        </View>
      </View>
      <View
        style={{
          height: Platform.OS === 'ios' ? '83.5%' : '84.5%',
          marginTop: hp(2),
        }}>
        {newBtn ? (
          <PendingAssessment navigation={navigation} />
        ) : (
          <CompletedAssessment navigation={navigation} />
        )}
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  tabbar: {
    backgroundColor: '#369',
    overflow: 'hidden',
  },
  icon: {
    backgroundColor: 'transparent',
    color: 'white',
  },
  indicator: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#0084ff',
    margin: 6,
  },
  badge: {
    marginTop: 4,
    marginRight: 32,
    backgroundColor: '#f44336',
    height: 24,
    width: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 4,
  },
  count: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
    marginTop: -2,
  },
});

export default AssessmentTab;
