import React, {Fragment} from 'react';
import {FlatList, RefreshControl, ScrollView, Text, View} from 'react-native';
import Spinner from 'react-native-loading-spinner-overlay';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {Fonts} from '../../../../../config/AppConfig';
import Colors from '../../../../../config/Colors';
import AssessmentService from '../../../../api/assesment';
import AssessmentItem from '../../components/AssessmentItem';

export class CompletedAssessment extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      refreshing: false,
      showLoader: false,
      assessmentsList: [],
    };
  }
  /* istanbul ignore next */
  componentDidMount(): void {
    this.getAllCompletedAssessmentsFromServer();
    this.willFocusSubscription = this.props.navigation.addListener(
      'willFocus',
      () => {
        console.log('come here to foucs');
        this.getAllCompletedAssessmentsFromServer();
      },
    );
  }
  /* istanbul ignore next */
  componentWillUnmount(): void {}
  /* istanbul ignore next */
  getAllCompletedAssessmentsFromServer() {
    this.setState({showLoader: true});
    AssessmentService.getCompletedAssessmentsList()
      .then(res => {
        console.log('getCompletedAssessmentsList');
        console.log('Results of the complete assesment are ', res);
        this.setState({assessmentsList: res.data, showLoader: false});
      })
      .catch(err => {
        console.log('error');
        console.log(err);
      });
  }
  /* istanbul ignore next */
  onRefresh() {
    this.getAllCompletedAssessmentsFromServer();
  }
  /* istanbul ignore next */
  renderSeparator = () => {
    return (
      <View
        style={{
          height: 1,
          width: '80%',
          backgroundColor: Colors.line,
          alignSelf: 'flex-end',
        }}
      />
    );
  };
  /* istanbul ignore next */
  render() {
    return (
      <Fragment>
        <View
          style={{
            flex: 1,
            backgroundColor: Colors.BgColor,
            flexDirection: 'column',
            borderColor: 'red',
            borderWidth: 0,
          }}>
          <View style={{flex: 1, borderColor: 'red', borderWidth: 0}}>
            {this.state.assessmentsList?.length ? (
              <FlatList
                data={this.state.assessmentsList}
                style={{
                  paddingTop: hp(1.5),
                  borderColor: 'red',
                  borderWidth: 0,
                }}
                renderItem={({item}) => (
                  <AssessmentItem
                    item={item}
                    navigation={this.props.navigation}
                    completed={true}
                    titleDate={item?.modifiedDate}
                  />
                )}
                keyExtractor={item => item.id}
                refreshControl={
                  <RefreshControl
                    refreshing={this.state.refreshing}
                    onRefresh={this.onRefresh.bind(this)}
                  />
                }
              />
            ) : (
              <ScrollView
                contentContainerStyle={{
                  flex: 1,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
                refreshControl={
                  <RefreshControl
                    refreshing={this.state.refreshing}
                    onRefresh={this.onRefresh.bind(this)}
                  />
                }>
                <Text
                  style={{
                    fontSize: hp(2),
                    color: Colors.fontGrey,
                    fontFamily: Fonts.SourceSansRegular,
                  }}>
                  No Screening Available.
                </Text>
              </ScrollView>
            )}
          </View>

          {this.state.showLoader === true ? (
            <Spinner
              visible={this.state.showLoader}
              textContent={'Loading...'}
              textStyle={{color: '#FFF'}}
            />
          ) : null}
        </View>
      </Fragment>
    );
  }
}
export default CompletedAssessment;
