import {useFocusEffect} from '@react-navigation/native';
import React, {useState} from 'react';
import {
  FlatList,
  Image,
  Platform,
  SafeAreaView,
  Text,
  View,
} from 'react-native';
import {showMessage} from 'react-native-flash-message';
import Spinner from 'react-native-loading-spinner-overlay';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {connect, useDispatch, useSelector} from 'react-redux';
import {Colors} from '../../../../config';
import {Fonts} from '../../../../config/AppConfig';
import Images from '../../../../config/Images';
import VitalsService from '../../../api/vitals';
import {
  getBloodPressureFromGoogleFit,
  getHeartRateFromGoogleFit,
  getWeightFromGoogleFit,
} from '../../../helpers/GoogleFit/GoogleFitHandler';
import {
  getBloodPressureHK,
  getHeartRateHK,
  getWeightHK,
} from '../../../helpers/HealthKit/HealthKitHandler';
import {getVitalCategoryData} from '../action';
import AllVitals from '../components/AllVitals';
import MainHeader from '../components/MainHeader';

let willFocusSubscription = null;

const VitalsScreen = ({navigation}) => {
  const [loader, setLoader] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [vitalsList, setVitalList] = useState([]);
  const [bloodPressure, setBloodPressure] = useState();
  const [heartRate, setHeartRate] = useState();
  const [bodyWeight, setBodyWeight] = useState();
  const [bloodPressureGoogleFit, setBloodPressureGoogleFit] = useState();
  const [heartRateGoogleFit, setHeartRateGoogleFit] = useState();
  const [bodyWeightGoogleFit, setBodyWeightGoogleFit] = useState();

  const vitalsData = useSelector(state => state.vitalCategoryData);

  const dispatch = useDispatch();

  useFocusEffect(
    React.useCallback(() => {
      vitalService();
      if (Platform.OS === 'ios') {
        getBloodPressureHK()
          .then(results => {
            // Handle the resolved results here
            // dispatch(setStepsLive(results.value));
            setBloodPressure(results);

            // Do something with the results in your homeScreen component
          })
          .catch(error => {
            // Handle any errors that occurred during the execution of x() here
            console.error('Error calling x:', error);
          });
        getHeartRateHK()
          .then(results => {
            // Handle the resolved results here

            // dispatch(setStepsLive(results.value));
            setHeartRate(results);

            // Do something with the results in your homeScreen component
          })
          .catch(error => {
            // Handle any errors that occurred during the execution of x() here
            console.error('Error calling x:', error);
          });
        getWeightHK()
          .then(results => {
            // Handle the resolved results here
            // dispatch(setStepsLive(results.value));
            setBodyWeight(results);

            // Do something with the results in your homeScreen component
          })
          .catch(error => {
            // Handle any errors that occurred during the execution of x() here
            console.error('Error calling x:', error);
          });
      } 
      // else {
      //   console.log('ok im in');
      //   //here starts the calls from google fit for vitals
      //   getHeartRateFromGoogleFit()
      //     .then(res => {
      //       setHeartRateGoogleFit(res);
      //     })
      //     .catch(err => {
      //       console.log('User have denied the access', err);
      //     });
      //   getBloodPressureFromGoogleFit()
      //     .then(res => {
      //       setBloodPressureGoogleFit(res);
      //     })
      //     .catch(err => {
      //       console.log('User have denied the access', err);
      //     });
      //   getWeightFromGoogleFit()
      //     .then(res => {
      //       setBodyWeightGoogleFit(res);
      //     })
      //     .catch(err => {
      //       console.log('User have denied the access to weight', err);
      //     });
      // }
    }, []),
  );

  const vitalService = () => {
    setLoader(true);
    setIsRefreshing(false);
    VitalsService.getVitalCategoryData()
      .then(res => {
        if (res.statusCode === 200) {
          setVitalList(res.data);
          dispatch(getVitalCategoryData(res.data));
          setLoader(false);
        }
      })
      .catch(err => {
        setLoader(false);
        setVitalList([]);
        dispatch(getVitalCategoryData([]));
        console.log('Vitals Error', vitalsData.length);
        console.log(err);
        showMessage({
          message: 'Information',
          description: err.message,
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  };

  const onRefresh = () => {
    //set isRefreshing to true
    setIsRefreshing(true);
    vitalService();
    // and set isRefreshing to false at the end of your callApiMethod()
  };
  return (
    <SafeAreaView
      style={{
        flex: 1,
        height: '100%',
        backgroundColor: Colors.backgroundMainLogin,
        borderColor: 'red',
        borderWidth: 0,
      }}>
      <MainHeader navigation={navigation} name={'My Vitals'}>
        <Spinner
          visible={loader}
          textContent={'Loading...'}
          textStyle={{color: '#FFF'}}
        />

        <View
          style={{
            width: '94%',
            alignSelf: 'center',
            flex: 1,
            borderColor: 'green',
            borderWidth: 0,
          }}>
          <FlatList
            style={{
              marginBottom: hp(2),
              borderColor: 'green',
              borderWidth: 0,
              backgroundColor: 'transparent',
            }}
            data={vitalsList}
            keyExtractor={item => item.id}
            showsVerticalScrollIndicator={false}
            renderItem={({item}) => {
              return (
                <AllVitals
                  navigation={navigation}
                  vitalData={item}
                  openModal={() => onOpen()}
                  bpReadingsHealthKit={bloodPressure}
                  heartRateHealthkit={heartRate}
                  bodyWeightHealthKit={bodyWeight}
                  bpReadingsGoogleFit={bloodPressureGoogleFit}
                  heartRateGoogleFit={heartRateGoogleFit}
                  bodyWeightGoogleFit={bodyWeightGoogleFit}
                />
              );
            }}
            onRefresh={onRefresh}
            refreshing={isRefreshing}
          />
        </View>
      </MainHeader>
    </SafeAreaView>
  );
};
export default connect()(VitalsScreen);
