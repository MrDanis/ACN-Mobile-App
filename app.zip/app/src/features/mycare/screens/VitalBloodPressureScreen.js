import {useFocusEffect} from '@react-navigation/native';
import {
  Image,
  Linking,
  Platform,
  RefreshControl,
  SafeAreaView,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
 
import AsyncStorage from '@react-native-async-storage/async-storage';
import {default as Moment, default as moment} from 'moment';
import React, {useEffect, useRef, useState} from 'react';
import {showMessage} from 'react-native-flash-message';
import Spinner from 'react-native-loading-spinner-overlay';
import {Modalize} from 'react-native-modalize';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {connect, useSelector} from 'react-redux';
import SeriousCondition from '../../../../../assets/svg/seriousCondition.svg';
import {Colors, Images} from '../../../../config';
import {Fonts, OSSource} from '../../../../config/AppConfig';
import VitalsService from '../../../api/vitals';
import {getBloodPressureFromGoogleFit} from '../../../helpers/GoogleFit/GoogleFitHandler';
import {getBloodPressureHK} from '../../../helpers/HealthKit/HealthKitHandler';
import CustomTestChart from '../../home/screens/custom_chart';
import {modalHanlder} from '../../medication/actions';
import MainHeader from '../components/MainHeader';
import VitalsMeasureCard from '../components/VitalsMeasureCardWeight';
 
const VitalWeightScreen = props => {
  let dateType = 0;
  const {vitalsData} = props.route.params;
 
  const [isStack, setisStack] = useState(true);
  const [vitalData, setvitalData] = useState(vitalsData);
  const TODAY = moment(vitalData.measuredDate).format('YYYY-MM-DD');
  const YESTERDAY = moment(vitalData.measuredDate)
    .subtract(1, 'days')
    .format('YYYY-MM-DD');
  const [loader, setLoader] = useState(false);
  const modalizeRef = useRef(Modalize);
  const modalizeRefForNewValues = useRef(Modalize);
  const [historyData, setHistoryData] = useState();
  const [refreshing, setRefreshing] = useState(false);
  const homeApiData = useSelector(state => state.homeApiData);
  const [date, setDate] = useState(
    Moment(new Date()).format('yyyy-MM-DDThh:mm:ss'),
  );
  const [barData, setbarData] = useState([]);
  const [isSelectedDay, setisSelectedDay] = useState('Day');
  const [deviceName, setDeviceName] = useState('');
  const [isScrollable, setIsScrollable] = useState(true);
  const [sistolic, setSistolic] = useState(
    Platform.OS === 'android' ? 90 : 120,
  );
  const [diastolic, setDiastolic] = useState(
    Platform.OS === 'android' ? 50 : 80,
  );
  const [isHealthkit, setIsHealthKit] = useState(false);
  const [isGoogleFit, setIsGoogleFit] = useState(false);
 
  const [bloodFromHealth, setBloodFromHealth] = useState();
  const [bloodFromGoogleFit, setBloodFromGoogleFit] = useState();
  const convertUTCDateToLocalDate = date => {
    var newDate = new Date(
      date.getTime() + date.getTimezoneOffset() * 60 * 1000,
    );
    const dateTimeAndroid = moment(new Date(date)).format('h:mm');
 
    var offset = date.getTimezoneOffset() / 60;
    var hours = date.getHours();
    newDate.setHours(hours - offset);
 
    const dateTimeIos = moment(new Date(newDate)).format('h:mm');
 
    return Platform.OS === 'ios' ? dateTimeIos : dateTimeAndroid;
  };
 
  const convertUTCDateToAMPM = date => {
    var newDate = new Date(
      date.getTime() + date.getTimezoneOffset() * 60 * 1000,
    );
    const dateTimeAndroid = moment(new Date(date)).format('A');
 
    var offset = date.getTimezoneOffset() / 60;
    var hours = date.getHours();
    newDate.setHours(hours - offset);
 
    const dateTimeIos = moment(new Date(newDate)).format('A');
 
    return Platform.OS === 'ios' ? dateTimeIos : dateTimeAndroid;
  };
  function onOpen() {
    modalizeRef.current?.open();
  }
 
  function onClose() {
    modalizeRef.current?.close();
    props.navigation.pop();
  }
  function dialCall(number) {
    let phoneNumber = '';
    if (Platform.OS === 'android') {
      phoneNumber = `tel:${number}`;
    } else {
      phoneNumber = `telprompt:${number}`;
    }
    Linking.openURL(phoneNumber);
    onClose();
  }
  function sendHealthKitDataToDB() {
    // Check if the bloodFromHealthKit is comming from the healthkit or not
    // If it is comming then save it to Db otherwise ignore it
    if (
      !(
        bloodFromHealth === undefined ||
        bloodFromHealth === null ||
        bloodFromHealth.length === 0
      )
    ) {
      const data = {
        vitalTypeId: vitalData.id,
        source: OSSource,
        categoryData: [
          {
            vitalSubTypeId: 1,
            value: `${bloodFromHealth[0]?.bloodPressureSystolicValue}`,
          },
          {
            vitalSubTypeId: 2,
            value: `${bloodFromHealth[0]?.bloodPressureDiastolicValue}`,
          },
        ],
        createdSource: 1,
        dateCreated: moment(new Date()).utc().format('YYYY-MM-DDTHH:mm:ss.SSS'),
        loinc: vitalData.loinc,
      };
 
      VitalsService.addVital(data)
        .then(response => {
          getVitalHistory(date);
          onCloseNew();
        })
        .catch(err => {
          console.log('error in api call of send healthkit data to db');
          console.log(err);
        });
    } else {
      console.log(
        'Comming to the else because data is not comming from the healthkit',
      );
    }
  }
  function sendGoogleFitDataToDB() {
    // Check if the bloodFromHealthKit is comming from the healthkit or not
    // If it is comming then save it to Db otherwise ignore it
    if (
      !(
        bloodFromGoogleFit === undefined ||
        bloodFromGoogleFit === null ||
        bloodFromGoogleFit.length === 0
      )
    ) {
      const data = {
        vitalTypeId: vitalData.id,
        source: OSSource,
        categoryData: [
          {
            vitalSubTypeId: 1,
            value: `${
              bloodFromGoogleFit[bloodFromGoogleFit?.length - 1]?.systolic
            }`,
          },
          {
            vitalSubTypeId: 2,
            value: `${
              bloodFromGoogleFit[bloodFromGoogleFit?.length - 1]?.diastolic
            }`,
          },
        ],
        createdSource: 1,
        dateCreated: moment(
          bloodFromGoogleFit[bloodFromGoogleFit.length - 1].startDate,
        )
          .utc()
          .format('YYYY-MM-DDTHH:mm:ss.SSS'),
        loinc: vitalData.loinc,
      };
 
      VitalsService.addVital(data)
        .then(response => {
          getVitalHistory(date);
          onCloseNew();
        })
        .catch(err => {
          console.log('error in api call of send google fit data to db');
          console.log(err);
        });
    } else {
      console.log(
        'Comming to the else because data is not comming from the google fit',
      );
    }
  }
  function saveData() {
    if (isHealthkit) {
      saveToAsyncStorage(bloodFromHealth[0]);
      sendHealthKitDataToDB();
    } else if (isGoogleFit) {
      saveToAsyncStorage(bloodFromGoogleFit[bloodFromGoogleFit?.length - 1]);
      sendGoogleFitDataToDB();
    }
  }
  const compareWithLastSavedValue = async newValue => {
    try {
      const lastSavedValueString = await AsyncStorage.getItem(
        'lastSavedValueBloodPressure',
      );
      if (lastSavedValueString) {
        const lastSavedValue = JSON.parse(lastSavedValueString);
 
        // Convert date strings to Date objects
        const newDate = new Date(newValue);
        const lastSavedDate = new Date(lastSavedValue.startDate);
 
        // Compare based on Date objects
        if (newDate > lastSavedDate) {
          // The new value has a later startDate, prompt the user or take action
          onOpenNew();
        } else {
          // The new value has an equal or earlier startDate, no need to prompt
          //do nothing
        }
      } else {
        // No last saved value found, prompt the user or take action
 
        onOpenNew();
      }
    } catch (error) {
      console.error('Error reading from AsyncStorage:', error);
      // Handle the error as needed
    }
  };
  function checkForVitalDataUpdates() {
    if (
      !(
        bloodFromHealth === undefined ||
        bloodFromHealth === null ||
        bloodFromHealth.length === 0
      )
    ) {
      setIsHealthKit(true);
      setIsGoogleFit(false);
      compareWithLastSavedValue(bloodFromHealth[0].startDate);
    } else if (
      !(
        bloodFromGoogleFit === undefined ||
        bloodFromGoogleFit === null ||
        bloodFromGoogleFit.length === 0
      )
    ) {
      setIsGoogleFit(true);
      setIsHealthKit(false);
      compareWithLastSavedValue(
        bloodFromGoogleFit[bloodFromGoogleFit.length - 1].startDate,
      );
    }
  }
  const saveToAsyncStorage = async valueObject => {
    try {
      await AsyncStorage.setItem(
        'lastSavedValueBloodPressure',
        JSON.stringify(valueObject),
      );
    } catch (error) {
      console.error('Error saving to AsyncStorage:', error);
    }
  };
  function onOpenNew() {
    modalizeRefForNewValues.current?.open();
    // props.dispatch(modalHanlder(false));
  }
 
  function onCloseNew() {
    modalizeRefForNewValues.current?.close();
    // props.navigation.pop();
  }
 
  useFocusEffect(
    React.useCallback(() => {
      getVitalHistory(date);
    }, []),
  );
  useEffect(() => {
    if (Platform.OS === 'ios') {
      getBloodPressureHK()
        .then(results => {
          setBloodFromHealth(results);
          checkForVitalDataUpdates();
        })
        .catch(error => {
          // Handle any errors that occurred during the execution of x() here
          console.error('Error calling x:', error);
        });
    } else {
      getBloodPressureFromGoogleFit()
        .then(res => {
          setBloodFromGoogleFit(res);
          checkForVitalDataUpdates();
        })
        .catch(err => {
          console.log('User have denied the access', err);
        });
    }
    checkForVitalDataUpdates();
  }, [historyData]);
 
  const getVitalHistory = date => {
    setLoader(true);
 
    VitalsService.getVitalCategoryHistory(
      vitalData.id,
      Moment(new Date(date)).format('YYYY-MM-DD'),
      dateType,
      vitalData.loinc,
    )
      .then(response => {
        setLoader(false);
 
        if (response && response.statusCode === 200) {
          setHistoryData(response.data);
          getvitalDataForChart(response.data);
          setRefreshing(false);
        } else {
          showMessage({
            message: 'Information',
            description:
              'Authentication Failed. Provided information is not verified.',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        }
      })
      .catch(err => {
        setLoader(false);
        console.log('error');
        console.log(err);
        showMessage({
          message: 'Info',
          description: 'Internal Server Error',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  };
 
  function getvitalDataForChart(listData) {
    if (vitalsData.id === 1) {
      let newVitallist = [];
      let tempdata = [];
      if (dateType === 1) {
        let newDate = moment(date).subtract(7, 'days');
        const days = [];
        // For getting all the days form current day to previous day
        for (let i = 1; i <= 7; i++) {
          newDate = newDate.add(1, 'days');
          const dayName = newDate.format('dddd');
          days.push(dayName);
        }
        let objData = null;
        days.map((day, index) => {
          objData = listData.filter((data, index) => {
            if (day === moment(new Date(data.createdDate)).format('dddd')) {
              return data;
            }
          });
          tempdata.push(objData.length !== 0 ? objData[0] : {});
 
          if (objData.length !== 0) {
            newVitallist.push({
              stacks: [
                {
                  value: objData[0]?.vitalData
                    ? objData[0]?.vitalData[1]?.value
                    : 0,
                  label: '',
                  labelWidth: 20,
                  color: '#F44336',
                },
                {
                  value: objData[0]?.vitalData
                    ? objData[0]?.vitalData[0]?.value -
                      objData[0]?.vitalData[1]?.value
                    : 0,
                  label: '',
                  labelWidth: 20,
                  color: '#2962FF',
                },
              ],
              label: moment(new Date(objData[0]?.createdDate)).format('ddd'),
              spacing: 18,
              labelTextStyle: {color: 'gray', fontSize: 10},
            });
          } else {
            newVitallist.push({
              stacks: [
                {
                  value: 0,
                  label: '',
                  labelWidth: 20,
                  color: '#2962FF',
                },
                {
                  value: 0,
                  label: '',
                  labelWidth: 20,
                  color: '#F44336',
                },
              ],
              label: moment(day, 'dddd').format('ddd'),
              spacing: 18,
              labelTextStyle: {color: 'gray', fontSize: 10},
            });
          }
          //gfytfytrfyt
        });
        // setisStack(false);
      } else if (dateType === 2) {
        let newDate = moment(date).subtract(31, 'days');
        const days = [];
        for (let i = 0; i <= 30; i++) {
          newDate = newDate.add(1, 'days');
 
          const dayString = newDate.format('YYYY-MM-DD');
          days.push(dayString);
        }
 
        let objData = null;
        days.map((day, index) => {
          objData = listData.filter((data, index) => {
            if (
              day === moment(new Date(data.createdDate)).format('YYYY-MM-DD')
            ) {
              return data;
            }
          });
          tempdata.push(objData.length !== 0 ? objData[0] : {});
 
          // changin the flow according to stacks like the data of the week
 
          // previous code for saving the week data of the chart of blood pressure is starting from the below code
          if (objData.length !== 0) {
            // console.log('====================================');
            // console.log('objDataaaa', objData);
            // console.log('====================================');
            newVitallist.push({
              stacks: [
                {
                  value: objData[0]?.vitalData
                    ? objData[0]?.vitalData[1]?.value
                    : 0,
                  label: '', //j===0?'12A':j===12?'12P':j===24?'12A':j%2!==0?'':(dayFormatSample[j].split(':')[0]),
                  labelWidth: 20,
                  color: '#F44336', //: '#00D685'//Colors.purpleBar,
                },
                {
                  value: objData[0]?.vitalData
                    ? objData[0]?.vitalData[0]?.value -
                      objData[0]?.vitalData[1]?.value
                    : 0,
                  label: '', //j===0?'12A':j===12?'12P':j===24?'12A':j%2!==0?'':(dayFormatSample[j].split(':')[0]),
                  // spacing: 2,
                  labelWidth: 20,
                  color: '#2962FF', //: '#00D685'//Colors.purpleBar,
                },
              ],
              label: day.split('-')[2],
              spacing: 18,
              labelTextStyle: {color: 'gray', fontSize: 10},
            });
            // console.log('Data for month in if : ', newVitallist);
          } else {
            newVitallist.push({
              stacks: [
                {
                  value: 0,
                  label: '', //j===0?'12A':j===12?'12P':j===24?'12A':j%2!==0?'':(dayFormatSample[j].split(':')[0]),
                  labelWidth: 20,
                  color: '#2962FF', //: '#00D685'//Colors.purpleBar,
                },
                {
                  value: 0,
                  label: '', //j===0?'12A':j===12?'12P':j===24?'12A':j%2!==0?'':(dayFormatSample[j].split(':')[0]),
                  // spacing: 2,
                  labelWidth: 20,
                  color: '#F44336', //: '#00D685'//Colors.purpleBar,
                },
              ],
              label: day.split('-')[2],
              spacing: 18,
              labelTextStyle: {color: 'gray', fontSize: 10},
            });
          }
          // console.log('Data for month in else is : ', newVitallist);
          // Previous Code for the chart data of the week is End Above
        });
        // New code ends here
      } else {
        let dayFormatSample = [
          '12:00 AM',
          '01:00 AM',
          '02:00 AM',
          '03:00 AM',
          '04:00 AM',
          '05:00 AM',
          '06:00 AM',
          '07:00 AM',
          '08:00 AM',
          '09:00 AM',
          '10:00 AM',
          '11:00 AM',
          '12:00 PM',
          '01:00 PM',
          '02:00 PM',
          '03:00 PM',
          '04:00 PM',
          '05:00 PM',
          '06:00 PM',
          '07:00 PM',
          '08:00 PM',
          '09:00 PM',
          '10:00 PM',
          '11:00 PM',
          '12:00 AM',
        ];
        let stackData = [];
        console.log('List data is : ', listData);
        for (let j = 0; j < dayFormatSample.length; j++) {
          let groupedDayData = [];
          for (let k = 0; k < listData?.length; k++) {
            // moment
            //   .utc(moment.utc(listData[k]?.createdDate).format())
            //   .local()
            //   .format('hh:mm A');
            let recordSubmitTime = moment
              .utc(moment.utc(listData[k]?.createdDate).format())
              .local()
              .format('hh:mm A');
 
            let currentTime = moment(recordSubmitTime, 'hh:mm A');
            let afterTime = moment(dayFormatSample[j], 'hh:mm A');
            let beforeTime = moment(dayFormatSample[j + 1], 'hh:mm A');
            if (currentTime.isBetween(afterTime, beforeTime)) {
              groupedDayData.push(
                {
                  value: listData[k]?.vitalData
                    ? listData[k]?.vitalData[0]?.value
                    : 0,
                  label: '',
                  labelWidth: 20,
 
                  frontColor: listData[k]?.isCritical ? '#F44336' : '#00D685',
                  topLabelComponent: () => (
                    <Text
                      style={{
                        color: 'black',
                        fontSize: 8,
 
                        marginBottom: 5,
                        height: 10,
                      }}>
                      {listData[k].vitalData[0].value}
                    </Text>
                  ),
                },
                {
                  value: listData[k]?.vitalData
                    ? listData[k]?.vitalData[1].value
                    : 0,
                  label: '',
                  labelWidth: 20,
                  frontColor: listData[k]?.isCritical ? '#F44336' : '#00D685',
                  topLabelComponent: () => (
                    <Text
                      style={{
                        color: 'black',
                        fontSize: 8,
 
                        marginBottom: 5,
                        height: 10,
                      }}>
                      {listData[k].vitalData[1].value}
                    </Text>
                  ),
                },
              );
            }
          }
 
          let dayStack = {
            stacks: [
              {
                value:
                  groupedDayData?.length > 0 ? groupedDayData[1]?.value : 0,
                label: '',
                labelWidth: 20,
                color: '#F44336',
              },
              {
                value:
                  groupedDayData?.length > 0
                    ? groupedDayData[0]?.value - groupedDayData[1]?.value
                    : 0,
                label: '',
                labelWidth: 20,
                color: '#2962FF',
              },
            ],
            label:
              j === 0
                ? '12A'
                : j === 12
                ? '12P'
                : j === 24
                ? '12A'
                : j % 2 !== 0
                ? ''
                : dayFormatSample[j].split(':')[0],
            labelTextStyle: {color: 'gray', fontSize: 10},
          };
          stackData.push(dayStack);
        }
        newVitallist.push(...stackData);
 
        setisStack(true);
      }
 
      setbarData(newVitallist);
    } else {
      let newVitallist = [];
      Object.keys(listData).map(valAtIndex => {
        newVitallist.push({
          value: listData[valAtIndex].value,
          label: moment(new Date(listData[valAtIndex].createdDate)).format(
            'hh:mm A',
          ),
          labelWidth: 50,
          labelTextStyle: {color: 'grey', fontSize: 10},
          frontColor: listData[valAtIndex].isCritical ? '#F44336' : '#00D685',
        });
      });
 
      setbarData(newVitallist);
    }
  }
 
  const setDateTypeFunction = d => {
    dateType = d;
  };
 
  const scrollEnabled = isScroll => {
    setIsScrollable(isScroll);
    if (Platform.OS === 'android') {
      setSistolic(90);
      setDiastolic(50);
    }
  };
 
  return (
    <SafeAreaView
      style={{flex: 1, backgroundColor: Colors.backgroundMainLogin}}>
      <MainHeader navigation={props.navigation} name="Blood Pressure">
        <Modalize
          ref={modalizeRef}
          adjustToContentHeight={true}
          modalStyle={{borderTopRightRadius: 25, borderTopLeftRadius: 25}}>
          <View style={{padding: hp(3)}}>
            <View
              style={{
                flexDirection: 'column',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginTop: hp(1),
              }}>
              <SeriousCondition />
              <Text
                style={{
                  fontFamily: Fonts.SourceSansBold,
                  fontSize: hp(3),
                  flex: 1,
                  color: Colors.black1,
                  marginTop: hp(1),
                  marginLeft: hp(2),
                }}>
                Serious Condition
              </Text>
              <Text
                style={{
                  fontFamily: Fonts.SourceSansRegular,
                  fontSize: hp(1.8),
                  flex: 1,
                  color: Colors.black,
                  marginTop: hp(1),
                  marginLeft: hp(2),
                  textTransform: 'uppercase',
                }}>
                Please contact your care manager
              </Text>
            </View>
            <View
              style={{
                flexDirection: 'column',
                justifyContent: 'space-around',
                marginTop: hp(1),
                width: '100%',
              }}>
              <TouchableOpacity
                onPress={() => {
                  dialCall(homeApiData.common.careManagerPhone);
                }}
                style={{
                  flexDirection: 'row',
                  marginTop: hp(2),
                  marginBottom: hp(2),
                  marginRight: hp(3),
                  width: '100%',
                  borderWidth: 1,
                  height: 50,
                  borderColor: Colors.blueTextColor,
                  justifyContent: 'center',
                  alignItems: 'center',
                  borderRadius: 8,
                  backgroundColor: Colors.blueRxColor,
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansBold,
                    fontSize: hp(2.2),
                    flex: 1,
                    color: Colors.white,
                    textAlign: 'center',
                  }}>
                  Contact
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  onClose();
                }}
                style={{
                  flexDirection: 'row',
                  width: '100%',
                  height: 50,
                  backgroundColor: Colors.criticalVital,
                  justifyContent: 'center',
                  alignItems: 'center',
                  borderRadius: 8,
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansBold,
                    fontSize: hp(2.2),
                    flex: 1,
                    color: Colors.red,
                    textAlign: 'center',
                  }}>
                  Contact Later
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modalize>
        <Modalize
          ref={modalizeRefForNewValues}
          adjustToContentHeight={true}
          onClosed={() => {
            props.dispatch(modalHanlder(true));
          }}
          modalStyle={{
            borderTopRightRadius: 25,
            borderTopLeftRadius: 25,
            minHeight: 250,
            backgroundColor: Colors.white,
          }}>
          <View
            style={{
              justifyContent: 'center',
              backgroundColor: Colors.white,
              width: '90%',
              borderRadius: 3,
              alignSelf: 'center',
              marginVertical: hp(1.5),
            }}>
            <View
              style={{
                flexDirection: 'column',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginTop: hp(1),
              }}>
              <Image
                source={Images.completeAssessment}
                style={{
                  alignSelf: 'center',
                  height: hp(10),
                  width: hp(10),
                }}
              />
              <Text
                style={{
                  fontFamily: Fonts.SourceSansBold,
                  fontSize: hp(3),
                  flex: 1,
                  color: Colors.black1,
                  marginTop: hp(1),
                  marginLeft: hp(2),
                  textAlign: 'center',
                }}>
                Do you want to save the Blood Pressure value{'\n'}
                {isGoogleFit
                  ? `${
                      bloodFromGoogleFit[bloodFromGoogleFit?.length - 1]
                        ?.systolic
                    } / ${
                      bloodFromGoogleFit[bloodFromGoogleFit?.length - 1]
                        ?.diastolic
                    } `
                  : isHealthkit
                  ? `${bloodFromHealth[0]?.bloodPressureSystolicValue} / ${bloodFromHealth[0]?.bloodPressureDiastolicValue} `
                  : ''}{' '}
                mmHg ?
              </Text>
            </View>
            <View
              style={{
                flexDirection: 'column',
                justifyContent: 'space-around',
                marginTop: hp(1),
                width: '100%',
              }}>
              <TouchableOpacity
                onPress={() => {
                  saveData();
                }}
                style={{
                  flexDirection: 'row',
                  marginTop: hp(2),
                  marginBottom: hp(2),
                  marginRight: hp(3),
                  width: '100%',
                  borderWidth: 1,
                  height: 50,
                  borderColor: Colors.blueTextColor,
                  justifyContent: 'center',
                  alignItems: 'center',
                  borderRadius: 8,
                  backgroundColor: Colors.blueTextColor,
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansSemibold,
                    fontSize: hp(2.2),
                    flex: 1,
                    color: Colors.white,
                    textAlign: 'center',
                  }}>
                  Save
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  onCloseNew();
                  props.dispatch(modalHanlder(true));
                  if (isHealthkit) {
                    saveToAsyncStorage(bloodFromHealth[0]);
                  } else if (isGoogleFit) {
                    saveToAsyncStorage(
                      bloodFromGoogleFit[bloodFromGoogleFit.length - 1],
                    );
                  }
                }}
                style={{
                  flexDirection: 'row',
                  width: '100%',
                  height: 50,
                  backgroundColor: Colors.lightRed,
                  justifyContent: 'center',
                  alignItems: 'center',
                  borderRadius: 8,
                  marginBottom: hp(2),
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansSemibold,
                    fontSize: hp(2.2),
                    flex: 1,
                    color: Colors.red,
                    textAlign: 'center',
                  }}>
                  Cancel
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modalize>
        <View style={{flex: 1, backgroundColor: Colors.backgroundMainLogin,paddingTop:hp(3)}}>
          <ScrollView
            refreshControl={
              isScrollable ? (
                <RefreshControl
                  refreshing={refreshing}
                  onRefresh={() => {
                    setRefreshing(true);
                    getVitalHistory(date);
                  }}
                />
              ) : null
            }
            contentContainerStyle={{paddingBottom: hp(2)}}
            scrollEnabled={Platform.OS === 'android' ? isScrollable : true}
            nestedScrollEnabled={true}>
            <Spinner
              visible={loader}
              textContent={'Loading...'}
              textStyle={{color: '#FFF'}}
            />
 
            {/* CALENDER VIEW */}
 
            <View style={{width: '100%', alignSelf: 'center'}}>
              <View style={{width: '90%', alignSelf: 'center'}}>
                <VitalsMeasureCard
                  vitalData={vitalData}
                  setLoader={setLoader}
                  sliderValueSystolic={sistolic}
                  sliderValueDiastolic={diastolic}
                  navigation={props.navigation}
                  openModal={() => onOpen()}
                  showLine={false}
                  setIsScrollable={scrollEnabled}
                  isScrollable={isScrollable}
                />
              </View>
              { console.log('Bar Data is : ',barData) }
              <View>
                {
                  barData && ( 
                  <CustomTestChart
                    isstackData={isStack}
                    barDataRetrived={barData}
                    setDateType={setDateTypeFunction}
                    getVitalHistory={getVitalHistory}
                    date={date}
                    setisSelectedDay={setisSelectedDay}
                    isSelectedDay={isSelectedDay}
                    maxValue={310}
                    setIsScrollable={scrollEnabled}
                  />
                 )
                }

              </View>
              <View />
            </View>
          </ScrollView>
        </View>
      </MainHeader>
    </SafeAreaView>
  );
};
VitalWeightScreen.navigationOptions = {
  headerShown: false,
};
 
export default connect()(VitalWeightScreen);
