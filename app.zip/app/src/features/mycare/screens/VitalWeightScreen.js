import AsyncStorage from '@react-native-async-storage/async-storage';
import {useFocusEffect} from '@react-navigation/native';
import {default as Moment, default as moment} from 'moment';
import React, {useEffect, useRef, useState} from 'react';
import {
  Image,
  RefreshControl,
  SafeAreaView,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import Spinner from 'react-native-loading-spinner-overlay';
import {Modalize} from 'react-native-modalize';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {connect, useSelector} from 'react-redux';
import {Colors} from '../../../../config';
import {Fonts, OSSource} from '../../../../config/AppConfig';
import Images from '../../../../config/Images';
import VitalsService from '../../../api/vitals';
import {getWeightFromGoogleFit} from '../../../helpers/GoogleFit/GoogleFitHandler';
import {getWeightHK} from '../../../helpers/HealthKit/HealthKitHandler';
import CustomTestChart from '../../home/screens/custom_chart';
import {modalHanlder} from '../../medication/actions';
import MainHeader from '../components/MainHeader';
import VitalsMeasureCard from '../components/VitalsMeasureCardWeight';

const VitalWeightScreen = props => {
  let dateType = 0;
  const {vitalsData} = props.route.params;

  const [vitalData, setvitalData] = useState(vitalsData);
  const TODAY = moment(vitalData.measuredDate).format('YYYY-MM-DD');
  const YESTERDAY = moment(vitalData.measuredDate)
    .subtract(1, 'days')
    .format('YYYY-MM-DD');
  const [loader, setLoader] = useState(false);
  const [isHealthkit, setIsHealthKit] = useState(false);
  const [isGoogleFit, setIsGoogleFit] = useState(false);
  const [historyData, setHistoryData] = useState();
  const [refreshing, setRefreshing] = useState(false);
  const modalizeRef = useRef(Modalize);
  const homeApiData = useSelector(state => state.homeApiData);
  const [date, setDate] = useState(
    Moment(new Date()).format('yyyy-MM-DDThh:mm:ss'),
  );
  const [barData, setbarData] = useState([]);
  const [isSelectedDay, setisSelectedDay] = useState('Day');

  const [bodyWeightFromHealthKit, setBodyWeightFromHealthKit] = useState();
  const [bodyWeightFromGoogleFit, setBodyWeightFromGoogleFit] = useState();
  const convertUTCDateToLocalDate = date => {
    var newDate = new Date(
      date.getTime() + date.getTimezoneOffset() * 60 * 1000,
    );
    const dateTimeAndroid = moment(new Date(date)).format('h:mm');

    var offset = date.getTimezoneOffset() / 60;
    var hours = date.getHours();
    newDate.setHours(hours - offset);

    const dateTimeIos = moment(new Date(newDate)).format('h:mm');

    return Platform.OS === 'ios' ? dateTimeIos : dateTimeAndroid;
  };

  const convertUTCDateToAMPM = date => {
    var newDate = new Date(
      date.getTime() + date.getTimezoneOffset() * 60 * 1000,
    );
    const dateTimeAndroid = moment(new Date(date)).format('A');

    var offset = date.getTimezoneOffset() / 60;
    var hours = date.getHours();
    newDate.setHours(hours - offset);

    const dateTimeIos = moment(new Date(newDate)).format('A');

    return Platform.OS === 'ios' ? dateTimeIos : dateTimeAndroid;
  };
  function onOpen() {
    modalizeRef.current?.open();
  }

  function onClose() {
    modalizeRef.current?.close();
  }

  function checkForVitalDataUpdates() {
    if (
      !(
        bodyWeightFromHealthKit === undefined ||
        bodyWeightFromHealthKit === null ||
        bodyWeightFromHealthKit.length === 0
      )
    ) {
      setIsHealthKit(true);
      setIsGoogleFit(false);
      compareWithLastSavedValue(bodyWeightFromHealthKit[0].endDate);
    } else if (
      !(
        bodyWeightFromGoogleFit === undefined ||
        bodyWeightFromGoogleFit === null ||
        bodyWeightFromGoogleFit.length === 0
      )
    ) {
      setIsGoogleFit(true);
      setIsHealthKit(false);
      compareWithLastSavedValue(
        bodyWeightFromGoogleFit[bodyWeightFromGoogleFit.length - 1].endDate,
      );
    }
  }
  const saveToAsyncStorage = async valueObject => {
    try {
      await AsyncStorage.setItem(
        'lastSavedValueWeight',
        JSON.stringify(valueObject),
      );
    } catch (error) {
      console.error('Error saving to AsyncStorage:', error);
    }
  };
  useFocusEffect(
    React.useCallback(() => {
      getVitalHistory(date);
    }, []),
  );
  useEffect(() => {
    if (Platform.OS === 'ios') {
      getWeightHK()
        .then(results => {
          setBodyWeightFromHealthKit(results);
          checkForVitalDataUpdates();
        })
        .catch(error => {
          // Handle any errors that occurred during the execution of x() here
          console.error('Error calling x:', error);
        });
    } else {
      getWeightFromGoogleFit()
        .then((res) => {
          console.log('response from the google fit is : ',res);
          setBodyWeightFromGoogleFit(res);
          checkForVitalDataUpdates();
        })
        .catch(err => {
          console.log('User have denied the access', err);
        });
    }
  }, [historyData]);

  const getVitalHistory = date => {
    setLoader(true);

    VitalsService.getVitalCategoryHistory(
      vitalsData.id,
      Moment(new Date(date)).format('YYYY-MM-DD'),
      dateType,
      vitalData.loinc,
    )
      .then(response => {
        setLoader(false);
        if (response && response.statusCode === 200) {
          setHistoryData(response.data);
          getvitalDataForChart(response.data);
          setRefreshing(false);
        } else {
          showMessage({
            message: 'Information',
            description:
              'Authentication Failed. Provided information is not verified.',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        }
      })
      .catch(err => {
        setLoader(false);
        console.log('error');
        console.log(err);
        showMessage({
          message: 'Info',
          description: 'Internal Server Error',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  };
  function getvitalDataForChart(listData) {
    if (vitalsData.id === 1) {
      let newVitallist = [];
      Object.keys(listData).map(valAtIndex => {
        newVitallist.push(
          {
            value: listData[valAtIndex].vitalData[0].value,

            label: moment(new Date(listData[valAtIndex].createdDate)).format(
              'hh:mm A',
            ),
            labelWidth: 10,
            labelTextStyle: {color: 'grey', fontSize: 10},
            frontColor: '#00D685',
            topLabelComponent: () => (
              <Text
                style={{
                  color: 'black',
                  fontSize: 8,
                  marginBottom: 5,
                  height: 10,
                }}>
                {listData[valAtIndex].vitalData[0].value}
              </Text>
            ),
            spacing: 2,
          },
          {
            value: listData[valAtIndex].vitalData[1].value,
            frontColor: '#00D685',
            topLabelComponent: () => (
              <Text
                style={{
                  color: 'black',
                  fontSize: 8,
                  height: 10,
                  marginBottom: 5,
                }}>
                {listData[valAtIndex].vitalData[1].value}
              </Text>
            ),
          },
        );
      });

      setbarData(newVitallist);
    } else {
      let newVitallist = [];
      let tempdata = [];
      if (dateType === 1) {
        let newDate = moment(date).subtract(7, 'days');
        const days = [];
        for (let i = 1; i <= 7; i++) {
          newDate = newDate.add(1, 'days');
          const dayName = newDate.format('dddd');

          days.push(dayName);
        }

        let objData = null;
        days.map((day, index) => {
          objData = listData.filter((data, index) => {
            if (day === moment(new Date(data.createdDate)).format('dddd')) {
              return data;
            }
          });
          tempdata.push(objData.length !== 0 ? objData[0] : {});

          if (objData.length !== 0) {
            newVitallist.push({
              value: objData[0]?.vitalData
                ? objData[0]?.vitalData[0]?.value
                : 0,
              label: day.slice(0, 3),
              labelWidth: 10,
              labelTextStyle: {color: 'grey', fontSize: 10},
              frontColor: '#00D685',
              topLabelComponent: () => (
                <Text
                  style={{
                    color: 'black',
                    fontSize: 8,

                    marginBottom: 5,
                    height: 10,
                    width: hp(3),
                    textAlign: 'center',
                  }}>
                  {tempdata[index]?.vitalData
                    ? tempdata[index]?.vitalData[0]?.value
                    : ''}
                </Text>
              ),
              spacing: 20,
            });
          } else {
            newVitallist.push({
              value: 0,
              label: day.slice(0, 3),
              labelWidth: 10,
              labelTextStyle: {color: 'grey', fontSize: 10},
              frontColor: '#00D685',
              spacing: 20,
            });
          }
        });
      } else if (dateType === 2) {
        let newDate = moment(date).subtract(30, 'days');
        const days = [];
        for (let i = 1; i <= 30; i++) {
          newDate = newDate.add(1, 'days');

          const dayString = newDate.format('YYYY-MM-DD');
          days.push(dayString);
        }

        let objData = null;
        days.map((day, index) => {
          objData = listData.filter((data, index) => {
            if (
              day === moment(new Date(data.createdDate)).format('YYYY-MM-DD')
            ) {
              return data;
            }
          });
          tempdata.push(objData.length !== 0 ? objData[0] : {});

          if (objData.length !== 0) {
            newVitallist.push({
              value: objData[0]?.vitalData
                ? objData[0]?.vitalData[0]?.value
                : 0,
              label: day.slice(8, 10),
              labelWidth: 10,
              labelTextStyle: {color: 'grey', fontSize: 10},
              frontColor: '#00D685',
              topLabelComponent: () => (
                <Text
                  style={{
                    color: 'black',
                    fontSize: 8,

                    marginBottom: 5,
                    height: 10,
                    width: hp(3),
                    textAlign: 'center',
                  }}>
                  {tempdata[index]?.vitalData
                    ? tempdata[index]?.vitalData[0]?.value
                    : ''}
                </Text>
              ),
              spacing: 20,
            });
          } else {
            newVitallist.push({
              value: 0,
              label: day.slice(8, 10),
              labelWidth: 10,
              labelTextStyle: {color: 'grey', fontSize: 10},
              frontColor: '#00D685',
              spacing: 20,
            });
          }
        });
      } else {
        console.log(
          'data for the day is : ',
          Object.entries(listData),
          ' and list data is : ',
          listData,
        );
        // Same logic but it is not working like it is working in activities for the day data
        //let dayFormatSample = ['12:00 AM', '03:00 AM','06:00 AM','09:00 AM','12:00 PM','03:00 PM','06:00 PM','09:00 PM','12:00 AM'];
        let dayFormatSample = [
          '12:00 AM',
          '01:00 AM',
          '02:00 AM',
          '03:00 AM',
          '04:00 AM',
          '05:00 AM',
          '06:00 AM',
          '07:00 AM',
          '08:00 AM',
          '09:00 AM',
          '10:00 AM',
          '11:00 AM',
          '12:00 PM',
          '01:00 PM',
          '02:00 PM',
          '03:00 PM',
          '04:00 PM',
          '05:00 PM',
          '06:00 PM',
          '07:00 PM',
          '08:00 PM',
          '09:00 PM',
          '10:00 PM',
          '11:00 PM',
          '12:00 AM',
        ];
        let stackData = [];
        for (let j = 0; j < dayFormatSample.length; j++) {
          let groupedDayData = [];
          for (let k = 0; k < listData?.length; k++) {
            let recordSubmitTime = moment
              .utc(moment.utc(listData[k]?.createdDate).format())
              .local()
              .format('hh:mm A');
            let currentTime = moment(recordSubmitTime, 'hh:mm A');
            let afterTime = moment(dayFormatSample[j], 'hh:mm A');
            let beforeTime = moment(dayFormatSample[j + 1], 'hh:mm A');
            if (currentTime.isBetween(afterTime, beforeTime)) {
              groupedDayData.push({
                value: listData[k]?.value,
                label: '',
                labelWidth: 20,
                labelTextStyle: {color: 'gray', fontSize: 10},
                frontColor: '#00D685',
                topLabelComponent: () => (
                  <Text
                    style={{
                      color: 'black',
                      fontSize: 8,
                      // width: 20,
                      // marginLeft: 5,
                      marginBottom: 5,
                      height: 10,
                    }}>
                    {listData[k]?.value}
                  </Text>
                ),
              });
            }
          }

          let testData = {
            value: groupedDayData?.length > 0 ? groupedDayData[0]?.value : 0,
            label:
              j === 0
                ? '12A'
                : j === 12
                ? '12P'
                : j === 24
                ? '12A'
                : j % 2 !== 0
                ? ''
                : dayFormatSample[j].split(':')[0],
            spacing: 10,
            labelWidth: 20,
            labelTextStyle: {color: 'gray', fontSize: 10},
            frontColor: groupedDayData[0]?.frontColor,
            topLabelComponent: () => (
              <Text
                style={{
                  color: 'black',
                  fontSize: 8,
                  width: hp(3),
                  textAlign: 'center',
                }}>
                {groupedDayData[0]?.value}
              </Text>
            ),
          };
          stackData.push(testData);
        }
        newVitallist.push(...stackData);
      }

      setbarData(newVitallist);
    }
  }

  const setDateTypeFunction = d => {
    dateType = d;
  };
  function trimValue(originalValue, precision) {
    const hasDecimalPlaces = originalValue % 1 !== 0;
    if (hasDecimalPlaces) {
      return originalValue.toFixed(precision);
    } else {
      return originalValue.toString();
    }
  }
  function sendHealthKitDataToDB() {
    // Check if the heartRateFromHealthKit is comming from the healthkit or not
    // If it is comming then save it to Db otherwise ignore it
    console.log('data from parent is : ', bodyWeightFromHealthKit);
    if (
      !(
        bodyWeightFromHealthKit === undefined ||
        bodyWeightFromHealthKit === null ||
        bodyWeightFromHealthKit.length === 0
      )
    ) {
      const data = {
        vitalTypeId: vitalData.id,
        source: OSSource,
        categoryData: [
          {
            vitalSubTypeId: 13,
            value: trimValue(bodyWeightFromHealthKit[0].value * 0.453592, 1),
          },
        ],
        createdSource: 1,
        dateCreated: moment(bodyWeightFromHealthKit[0].endDate)
          .utc()
          .format('YYYY-MM-DDTHH:mm:ss.SSS'),
        loinc: vitalData.loinc,
      };

      VitalsService.addVital(data)
        .then(response => {
          getVitalHistory(date);
          onClose();
        })
        .catch(err => {
          console.log('error in api call of send healthkit data to db weight');
          console.log(err);
        });
    } else {
      console.log(
        'Comming to the else because data is not comming from the healthkit',
      );
    }
  }
  function sendGoogleFitDataToDB() {
    // Check if the heartRateFromHealthKit is comming from the healthkit or not
    // If it is comming then save it to Db otherwise ignore it
    console.log('data from parent is : ', bodyWeightFromGoogleFit);

    if (
      !(
        bodyWeightFromGoogleFit === undefined ||
        bodyWeightFromGoogleFit === null ||
        bodyWeightFromGoogleFit.length === 0
      )
    ) {
      const data = {
        vitalTypeId: vitalData.id,
        source: OSSource,
        categoryData: [
          {
            vitalSubTypeId: 13,
            value: trimValue(
              bodyWeightFromGoogleFit[bodyWeightFromGoogleFit.length - 1].value,
              1,
            ),
          },
        ],
        createdSource: 1,
        dateCreated: moment(
          bodyWeightFromGoogleFit[bodyWeightFromGoogleFit.length - 1].endDate,
        )
          .utc()
          .format('YYYY-MM-DDTHH:mm:ss.SSS'),
        loinc: vitalData.loinc,
      };

      VitalsService.addVital(data)
        .then(response => {
          getVitalHistory(date);
          onClose();
        })
        .catch(err => {
          console.log('error in api call of send google fit data to db weight');
          console.log(err);
        });
    } else {
      console.log(
        'Comming to the else because data is not comming from the google fit',
      );
    }
  }
  function saveData() {
    if (isHealthkit) {
      saveToAsyncStorage(bodyWeightFromHealthKit[0]);
      sendHealthKitDataToDB();
    } else if (isGoogleFit) {
      saveToAsyncStorage(
        bodyWeightFromGoogleFit[bodyWeightFromGoogleFit.length - 1],
      );
      sendGoogleFitDataToDB();
    }
  }
  const compareWithLastSavedValue = async newValue => {
    try {
      const lastSavedValueString = await AsyncStorage.getItem(
        'lastSavedValueWeight',
      );
      if (lastSavedValueString) {
        const lastSavedValue = JSON.parse(lastSavedValueString);

        // Convert date strings to Date objects
        const newDate = new Date(newValue);
        const lastSavedDate = new Date(lastSavedValue.endDate);

        // Compare based on Date objects
        if (newDate > lastSavedDate) {
          // The new value has a later startDate, prompt the user or take action
          onOpen();
        } else {
          // The new value has an equal or earlier startDate, no need to prompt
          //do nothing
        }
      } else {
        // No last saved value found, prompt the user or take action
        onOpen();
      }
    } catch (error) {
      console.error('Error reading from AsyncStorage:', error);
      // Handle the error as needed
    }
  };
  return (
    <SafeAreaView
      style={{flex: 1, backgroundColor: Colors.backgroundMainLogin}}>
      <MainHeader navigation={props.navigation} name="Weight">
        <Modalize
          ref={modalizeRef}
          adjustToContentHeight={true}
          onClosed={() => {
            props.dispatch(modalHanlder(true));
          }}
          modalStyle={{
            borderTopRightRadius: 25,
            borderTopLeftRadius: 25,
            minHeight: 250,
            backgroundColor: Colors.white,
          }}>
          <View
            style={{
              justifyContent: 'center',
              backgroundColor: Colors.white,
              width: '90%',
              borderRadius: 3,
              alignSelf: 'center',
              marginVertical: hp(1.5),
            }}>
            <View
              style={{
                flexDirection: 'column',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginTop: hp(1),
              }}>
              <Image
                source={Images.completeAssessment}
                style={{
                  alignSelf: 'center',
                  height: hp(10),
                  width: hp(10),
                }}
              />
              <Text
                style={{
                  fontFamily: Fonts.SourceSansBold,
                  fontSize: hp(3),
                  flex: 1,
                  color: Colors.black1,
                  marginTop: hp(1),
                  marginLeft: hp(2),
                  textAlign: 'center',
                }}>
                Do you want to save the weight value{' '}
                {isGoogleFit
                  ? trimValue(
                      bodyWeightFromGoogleFit[
                        bodyWeightFromGoogleFit.length - 1
                      ].value,
                      1,
                    )
                  : isHealthkit
                  ? trimValue(bodyWeightFromHealthKit[0]?.value * 0.453592, 1)
                  : ''}{' '}
                Kg ?
              </Text>
            </View>
            <View
              style={{
                flexDirection: 'column',
                justifyContent: 'space-around',
                marginTop: hp(1),
                width: '100%',
              }}>
              <TouchableOpacity
                onPress={() => {
                  saveData();
                }}
                style={{
                  flexDirection: 'row',
                  marginTop: hp(2),
                  marginBottom: hp(2),
                  marginRight: hp(3),
                  width: '100%',
                  borderWidth: 1,
                  height: 50,
                  borderColor: Colors.blueTextColor,
                  justifyContent: 'center',
                  alignItems: 'center',
                  borderRadius: 8,
                  backgroundColor: Colors.blueTextColor,
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansSemibold,
                    fontSize: hp(2.2),
                    flex: 1,
                    color: Colors.white,
                    textAlign: 'center',
                  }}>
                  Save
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  onClose();
                  props.dispatch(modalHanlder(true));
                  if (isHealthkit) {
                    saveToAsyncStorage(bodyWeightFromHealthKit[0]);
                  } else if (isGoogleFit) {
                    saveToAsyncStorage(
                      bodyWeightFromGoogleFit[
                        bodyWeightFromGoogleFit.length - 1
                      ],
                    );
                  }
                }}
                style={{
                  flexDirection: 'row',
                  width: '100%',
                  height: 50,
                  backgroundColor: Colors.lightRed,
                  justifyContent: 'center',
                  alignItems: 'center',
                  borderRadius: 8,
                  marginBottom: hp(2),
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansSemibold,
                    fontSize: hp(2.2),
                    flex: 1,
                    color: Colors.red,
                    textAlign: 'center',
                  }}>
                  Cancel
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modalize>
        <View style={{flex: 1, backgroundColor: Colors.backgroundMainLogin}}>
          <ScrollView
            refreshControl={
              <RefreshControl
                refreshing={refreshing}
                onRefresh={() => {
                  setRefreshing(true);
                  getVitalHistory(date);
                }}
              />
            }
            contentContainerStyle={{paddingBottom: hp(2)}}>
            <Spinner
              visible={loader}
              textContent={'Loading...'}
              textStyle={{color: '#FFF'}}
            />

            {/* Measure & History Card */}
            <View style={{width: '100%', alignSelf: 'center'}}>
              <View
                style={{
                  width: '90%',
                  alignSelf: 'center',
                  borderColor: 'red',
                  borderWidth: 0,
                }}>
                <VitalsMeasureCard
                  vitalData={vitalData}
                  setLoader={setLoader}
                  sliderValueParent={vitalsData.value}
                  navigation={props.navigation}
                  openModal={() => onOpen()}
                />
              </View>
               {console.log('Data of the : ',vitalsData)}
               {
                  vitalsData.name==='Weight'?
                  <CustomTestChart
                    barDataRetrived={barData}
                    setDateType={setDateTypeFunction}
                    getVitalHistory={getVitalHistory}
                    date={date}
                    setisSelectedDay={setisSelectedDay}
                    isSelectedDay={isSelectedDay}
                    maxValue={250}
                  />:
                  <CustomTestChart
                    barDataRetrived={barData}
                    setDateType={setDateTypeFunction}
                    getVitalHistory={getVitalHistory}
                    date={date}
                    setisSelectedDay={setisSelectedDay}
                    isSelectedDay={isSelectedDay}
                    maxValue={
                      barData?.length === 0
                        ? vitalsData?.criticalMaxRange
                        : parseInt(
                            ([...barData]?.sort((a, b) => b?.value - a?.value))[0]
                              ?.value,
                          ) + 50
                    }
                  />
               }

              {vitalData.name === 'Blood Pressure' ||
                (vitalData.name === 'Weight' && (
                  <>
                    <View
                      style={{
                        marginHorizontal: hp(2),
                        display: 'none',
                      }}>
                      <Text
                        style={{
                          color: Colors.noRecordFound,
                          marginVertical: hp(1),
                          fontFamily: Fonts.SourceSansRegular,
                        }}>
                        Connected Devices
                      </Text>
                      <View
                        style={{
                          width: '100%',
                          backgroundColor: Colors.white,
                          alignItems: 'center',
                          marginTop: hp(1),
                          borderRadius: 8,
                        }}>
                        {vitalData.name === 'Weight' ? (
                          <Image
                            style={{
                              width: 40,
                              height: 40,
                              marginTop: hp(2.8),
                            }}
                            resizeMode="contain"
                            source={require('../../../../../assets/images/connect_body_weight.png')}
                          />
                        ) : (
                          <Image
                            style={{
                              width: 40,
                              height: 40,
                              marginVertical: hp(1.5),
                            }}
                            resizeMode="contain"
                            source={require('../../../../../assets/images/icon_connect_device.png')}
                          />
                        )}

                        <TouchableOpacity
                          style={{flexDirection: 'row', alignItems: 'center'}}>
                          <Text
                            style={{
                              color: Colors.blueTextColor,
                              marginTop: hp(2),
                              marginBottom: hp(1.5),
                              fontFamily: Fonts.SourceSansSemibold,
                              fontSize: hp(4),
                              marginRight: hp(2),
                            }}>
                            +
                          </Text>
                          <Text
                            style={{
                              color: Colors.blueTextColor,
                              marginTop: hp(2),
                              marginBottom: hp(1.5),
                              fontFamily: Fonts.SourceSansRegular,
                              fontSize: hp(2.2),
                            }}>
                            Connect Device
                          </Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  </>
                ))}
            </View>
          </ScrollView>
        </View>
      </MainHeader>
    </SafeAreaView>
  );
};
VitalWeightScreen.navigationOptions = {
  headerShown: false,
};

export default connect()(VitalWeightScreen);
