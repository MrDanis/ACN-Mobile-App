import {default as Moment, default as moment} from 'moment';
import React, {useEffect, useRef, useState} from 'react';
import {
  Linking,
  SafeAreaView,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
  Image
} from 'react-native';

import Spinner from 'react-native-loading-spinner-overlay';
import {Modalize} from 'react-native-modalize';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {connect, useSelector} from 'react-redux';
import SeriousCondition from '../../../../../assets/svg/seriousCondition.svg';
import {Colors} from '../../../../config';
import {Fonts} from '../../../../config/AppConfig';
import VitalsService from '../../../api/vitals';
import CustomTestChart from '../../home/screens/custom_chart';
import MainHeader from '../components/MainHeader';
import VitalsMeasureCard from '../components/VitalsMeasureCardWeight';

const VitalTemperatureScreen = props => {
  let dateType = 0;
  const {vitalsData} = props.route.params;
  console.log('====================================');
  console.log('vitalsData', vitalsData);
  console.log('====================================');
  const [vitalData, setvitalData] = useState(vitalsData);
  const TODAY = moment(vitalData.measuredDate).format('YYYY-MM-DD');
  const YESTERDAY = moment(vitalData.measuredDate)
    .subtract(1, 'days')
    .format('YYYY-MM-DD');
  const [loader, setLoader] = useState(false);
  const modalizeRef = useRef(Modalize);
  const homeApiData = useSelector(state => state.homeApiData);
  const [date, setDate] = useState(
    Moment(new Date()).format('yyyy-MM-DDThh:mm:ss'),
  );
  const [barData, setbarData] = useState([]);
  const [isSelectedDay, setisSelectedDay] = useState('Day');
  const [isScrollable, setIsScrollable] = useState(true);

  function onClose() {
    modalizeRef.current?.close();
    props.navigation.pop();
  }
  function dialCall(number) {
    console.log('CareManager Phone Number', number);
    let phoneNumber = '';
    if (Platform.OS === 'android') {
      phoneNumber = `tel:${number}`;
    } else {
      phoneNumber = `telprompt:${number}`;
    }
    Linking.openURL(phoneNumber);
    onClose();
  }
  useEffect(() => {
    getVitalHistory(date);
  }, []);

  const getVitalHistory = date => {
    setLoader(true);

    VitalsService.getVitalCategoryHistory(
      vitalData.id,
      Moment(new Date(date)).format('YYYY-MM-DD'),
      dateType,
      vitalData.loinc,
    )
      .then(response => {
        setLoader(false);
        if (response && response.statusCode === 200) {
          getvitalDataForChart(response.data);
        } else {
          showMessage({
            message: 'Information',
            description:
              'Authentication Failed. Provided information is not verified.',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        }
      })
      .catch(err => {
        setLoader(false);
        console.log('error');
        console.log(err);
        showMessage({
          message: 'Info',
          description: 'Internal Server Error',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  };
  function getvitalDataForChart(listData) {
    let newVitallist = [];
    let tempdata = [];
    if (dateType === 1) {
      let newDate = moment(date).subtract(7, 'days');
      const days = [];
      for (let i = 1; i <= 7; i++) {
        newDate = newDate.add(1, 'days');
        const dayName = newDate.format('dddd');
        days.push(dayName);
      }

      let objData = null;
      days.map((day, index) => {
        objData = listData.filter((data, index) => {
          if (day === moment(new Date(data.createdDate)).format('dddd')) {
            return data;
          }
        });
        tempdata.push(objData.length !== 0 ? objData[0] : {});

        if (
          objData.length !== 0 &&
          tempdata[index] !== null &&
          tempdata[index] !== {}
        ) {
          newVitallist.push({
            value: objData[0]?.vitalData ? objData[0]?.vitalData[0]?.value : 0,
            label: day.slice(0, 3),
            labelWidth: 20,
            labelTextStyle: {color: 'grey', fontSize: 10},
            frontColor: objData[0]?.isCritical ? '#F44336' : '#00D685',
            topLabelComponent: () => (
              <View style={{borderColor: 'green', borderWidth: 0}}>
                <Text
                  style={{
                    color: 'black',
                    fontSize: 8,
                    width: '100%',

                    marginBottom: 5,
                    height: 10,
                    borderColor: 'red',
                    borderWidth: 0,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                  <Text>
                    {tempdata[index]?.vitalData
                      ? tempdata[index]?.vitalData[0]?.value
                      : ''}
                  </Text>
                </Text>
              </View>
            ),
            spacing: 18,
          });
        } else {
          newVitallist.push({
            value: 0,
            label: day.slice(0, 3),
            labelWidth: 20,
            labelTextStyle: {color: 'grey', fontSize: 10},
            frontColor: '#2962FF',
            spacing: 18,
          });
        }
      });
    } else if (dateType === 2) {
      let newDate = moment(date).subtract(30, 'days');
      const days = [];
      for (let i = 1; i <= 30; i++) {
        newDate = newDate.add(1, 'days');

        const dayString = newDate.format('YYYY-MM-DD');
        days.push(dayString);
      }

      let objData = null;
      // Mapping through all the dates of the month along with the api data in response
      days.map((day, index) => {
        objData = listData.filter((data, index) => {
          if (day === moment(new Date(data.createdDate)).format('YYYY-MM-DD')) {
            return data;
          }
        });
        tempdata.push(objData.length !== 0 ? objData[0] : {});

        if (objData.length !== 0) {
          newVitallist.push({
            value: objData[0]?.vitalData ? objData[0]?.vitalData[0]?.value : 0,
            label: day.slice(8, 10),
            labelWidth: 20,
            labelTextStyle: {color: 'grey', fontSize: 10},
            frontColor: objData[0]?.isCritical ? '#F44336' : '#00D685',
            topLabelComponent: () => (
              <View style={{borderColor: 'green', borderWidth: 0}}>
                <Text
                  style={{
                    color: 'black',
                    fontSize: 8,
                    width: '100%',

                    marginBottom: 5,
                    height: 10,
                    borderColor: 'red',
                    borderWidth: 0,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                  <Text>
                    {tempdata[index]?.vitalData
                      ? tempdata[index]?.vitalData[0]?.value
                      : ''}
                  </Text>
                </Text>
              </View>
            ),
            spacing: 18,
          });
        } else {
          newVitallist.push({
            value: 0,
            label: day.slice(8, 10),
            labelWidth: 20,
            labelTextStyle: {color: 'grey', fontSize: 10},
            frontColor: '#2962FF',
            spacing: 18,
          });
        }
      });
    } else {
      console.log('data before changing is : ', listData);
      //  Change In code with new Flow By Danish(Start)
      let dayFormatSample = [
        '12:00 AM',
        '01:00 AM',
        '02:00 AM',
        '03:00 AM',
        '04:00 AM',
        '05:00 AM',
        '06:00 AM',
        '07:00 AM',
        '08:00 AM',
        '09:00 AM',
        '10:00 AM',
        '11:00 AM',
        '12:00 PM',
        '01:00 PM',
        '02:00 PM',
        '03:00 PM',
        '04:00 PM',
        '05:00 PM',
        '06:00 PM',
        '07:00 PM',
        '08:00 PM',
        '09:00 PM',
        '10:00 PM',
        '11:00 PM',
        '12:00 AM',
      ];
      let stackData = [];
      for (let j = 0; j < dayFormatSample.length; j++) {
        let groupedDayData = [];
        for (let k = 0; k < listData?.length; k++) {
          let recordSubmitTime = moment
            .utc(moment.utc(listData[k]?.createdDate).format())
            .local()
            .format('hh:mm A');
          let currentTime = moment(recordSubmitTime, 'hh:mm A');
          let afterTime = moment(dayFormatSample[j], 'hh:mm A');
          let beforeTime = moment(dayFormatSample[j + 1], 'hh:mm A');
          if (currentTime.isBetween(afterTime, beforeTime)) {
            groupedDayData.push({
              value: listData[k]?.value,
              label: '',
              labelWidth: 20,
              labelTextStyle: {color: 'gray', fontSize: 10},
              frontColor: listData[k]?.isCritical ? '#F44336' : '#00D685',
              topLabelComponent: () => (
                <View>
                  <Text
                    style={{
                      color: 'black',
                      fontSize: 8,
                      width: '100%',

                      marginBottom: 5,
                      height: 10,
                      borderColor: 'red',
                      borderWidth: 0,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                    <Text
                      style={{
                        color: 'black',
                        fontSize: 8,

                        marginBottom: 5,
                        height: 10,
                      }}>
                      {listData[k]?.value}
                    </Text>
                  </Text>
                </View>
              ),
            });
          }
        }

        let testData = {
          value: groupedDayData?.length > 0 ? groupedDayData[0]?.value : 0,
          label:
            j === 0
              ? '12A'
              : j === 12
              ? '12P'
              : j === 24
              ? '12A'
              : j % 2 !== 0
              ? ''
              : dayFormatSample[j].split(':')[0],
          spacing: 10,
          labelWidth: 20,
          labelTextStyle: {color: 'gray', fontSize: 10},
          frontColor: groupedDayData[0]?.frontColor, //'#F44336', //: '#00D685'//Colors.purpleBar,
          topLabelComponent: () => (
            <View>
              <Text
                style={{
                  color: 'black',
                  fontSize: 8,
                  width: '100%',
                  marginBottom: 5,
                  height: 10,
                  borderColor: 'red',
                  borderWidth: 0,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                <Text style={{color: 'black', fontSize: 8}}>
                  {groupedDayData[0]?.value}
                </Text>
              </Text>
            </View>
          ),
        };

        stackData.push(testData);
      }

      newVitallist.push(...stackData);
    }

    setbarData(newVitallist);
  }

  const setDateTypeFunction = d => {
    dateType = d;
  };

  const scrollEnabled = isScroll => {
    setIsScrollable(isScroll);
  };

  return (
    <SafeAreaView
      style={{flex: 1, backgroundColor: Colors.backgroundMainLogin}}>
      <MainHeader navigation={props.navigation} name="Temperature">
        <Modalize
          ref={modalizeRef}
          adjustToContentHeight={true}
          modalStyle={{borderTopRightRadius: 25, borderTopLeftRadius: 25}}>
          <View style={{padding: hp(3)}}>
            <View
              style={{
                flexDirection: 'column',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginTop: hp(1),
              }}>
              <SeriousCondition />
              <Text
                style={{
                  fontFamily: Fonts.SourceSansBold,
                  fontSize: hp(3),
                  flex: 1,
                  color: Colors.black1,
                  marginTop: hp(1),
                  marginLeft: hp(2),
                }}>
                Serious Condition
              </Text>
              <Text
                style={{
                  fontFamily: Fonts.SourceSansRegular,
                  fontSize: hp(1.8),
                  flex: 1,
                  color: Colors.black,
                  marginTop: hp(1),
                  marginLeft: hp(2),
                  textTransform: 'uppercase',
                }}>
                Please contact your care manager
              </Text>
            </View>
            <View
              style={{
                flexDirection: 'column',
                justifyContent: 'space-around',
                marginTop: hp(1),
                width: '100%',
              }}>
              <TouchableOpacity
                onPress={() => {
                  dialCall(homeApiData.common.careManagerPhone);
                }}
                style={{
                  flexDirection: 'row',
                  marginTop: hp(2),
                  marginBottom: hp(2),
                  marginRight: hp(3),
                  width: '100%',
                  borderWidth: 1,
                  height: 50,
                  borderColor: Colors.blueTextColor,
                  justifyContent: 'center',
                  alignItems: 'center',
                  borderRadius: 8,
                  backgroundColor: Colors.blueRxColor,
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansBold,
                    fontSize: hp(2.2),
                    flex: 1,
                    color: Colors.white,
                    textAlign: 'center',
                  }}>
                  Contact
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  onClose();
                }}
                style={{
                  flexDirection: 'row',
                  // marginBottom: hp(2),
                  width: '100%',
                  height: 50,
                  backgroundColor: Colors.criticalVital,
                  justifyContent: 'center',
                  alignItems: 'center',
                  borderRadius: 8,
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansBold,
                    fontSize: hp(2.2),
                    flex: 1,
                    color: Colors.red,
                    textAlign: 'center',
                  }}>
                  Contact Later
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modalize>
        <View
          style={{
            flex: 1,
            backgroundColor: Colors.backgroundMainLogin,
          }}>
          <ScrollView
            style={{marginBottom: hp(2)}}
            scrollEnabled={Platform.OS === 'android' ? isScrollable : true}
            nestedScrollEnabled={true}>
            <Spinner
              visible={loader}
              textContent={'Loading...'}
              textStyle={{color: '#FFF'}}
            />

            {/* CALENDER VIEW */}

            {/* Measure & History Card */}
            <View style={{width: '100%', alignSelf: 'center'}}>
              <View style={{width: '90%', alignSelf: 'center'}}>
                <VitalsMeasureCard
                  vitalData={vitalData}
                  setLoader={setLoader}
                  sliderValueParent={vitalData.value}
                  navigation={props.navigation}
                  openModal={() => onOpen()}
                  showLine={false}
                  setIsScrollable={scrollEnabled}
                  isScrollable={isScrollable}
                />
              </View>
              <CustomTestChart
                barDataRetrived={barData}
                setDateType={setDateTypeFunction}
                getVitalHistory={getVitalHistory}
                date={date}
                setisSelectedDay={setisSelectedDay}
                isSelectedDay={isSelectedDay}
                maxValue={
                  barData?.length === 0
                    ? vitalsData?.criticalMaxRange
                    : parseInt(
                        ([...barData]?.sort((a, b) => b?.value - a?.value))[0]
                          ?.value,
                      ) + 50
                }
                setIsScrollable={scrollEnabled}
              />
              {vitalData.name === 'Blood Pressure' ||
                (vitalData.name === 'Weight' && (
                  <>
                    <View
                      style={{
                        marginHorizontal: hp(2),
                      }}>
                      <Text
                        style={{
                          color: Colors.noRecordFound,
                          marginVertical: hp(1),
                          fontFamily: Fonts.SourceSansRegular,
                        }}>
                        Connected Devices
                      </Text>
                      <View
                        style={{
                          width: '100%',
                          backgroundColor: Colors.white,
                          alignItems: 'center',
                          marginTop: hp(1),
                          borderRadius: 8,
                        }}>
                        {vitalData.name === 'Weight' ? (
                          <Image
                            style={{
                              width: 40,
                              height: 40,
                              marginTop: hp(2.8),
                            }}
                            resizeMode="contain"
                            source={require('../../../../../assets/images/connect_body_weight.png')}
                          />
                        ) : (
                          <Image
                            style={{
                              width: 40,
                              height: 40,
                              marginVertical: hp(1.5),
                            }}
                            resizeMode="contain"
                            source={require('../../../../../assets/images/icon_connect_device.png')}
                          />
                        )}

                        <TouchableOpacity
                          style={{flexDirection: 'row', alignItems: 'center'}}>
                          <Text
                            style={{
                              color: Colors.blueTextColor,
                              marginTop: hp(2),
                              marginBottom: hp(1.5),
                              fontFamily: Fonts.SourceSansSemibold,
                              fontSize: hp(4),
                              marginRight: hp(2),
                            }}>
                            +
                          </Text>
                          <Text
                            style={{
                              color: Colors.blueTextColor,
                              marginTop: hp(2),
                              marginBottom: hp(1.5),
                              fontFamily: Fonts.SourceSansRegular,
                              fontSize: hp(2.2),
                            }}>
                            Connect Device
                          </Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  </>
                ))}
            </View>
          </ScrollView>
        </View>
      </MainHeader>
    </SafeAreaView>
  );
};

export default connect()(VitalTemperatureScreen);
