/* istanbul ignore file */
import React, {Fragment} from 'react';
import {Text, TouchableOpacity, View} from 'react-native';
import DropDownPicker from 'react-native-dropdown-picker';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {Fonts} from '../../../../../config/AppConfig';
import Colors from '../../../../../config/Colors';
export class QuestionTypeDropDown extends React.PureComponent {
  /* istanbul ignore next */
  options = [];
  /* istanbul ignore next */
  selectedValue = '';
  /* istanbul ignore next */
  constructor(props) {
    super(props);
    this.dropdownRef = React.createRef();
    this.state = {selectedValue: '', open: false, isSelected: false};
    let array = [];
    props.item.options.map(row => {
      let object = {id: row.id, label: row.text, value: row.text};
      array.push(object);
    });
    this.options = array;
    const {SavedAnswers: answers} = props.item;
    if (props.item.savedAnswers.length > 0) {
      this.selectedValue = props.item.savedAnswers[0];
      this.setState({selectedValue: props.item.savedAnswers[0]});
    }
  }
  /* istanbul ignore next */
  onValueSelected = (value, index, data) => {
    this.props.onAnswer([value]);
    this.setState({selectedValue: value});
  };
  setValue = callback => {
    console.log('setValue', typeof callback);
    if (typeof callback === 'function') {
      const value = callback();
      this.props.onAnswer([value]);
      console.log('Value we get before saving the value : ', value);
      this.selectedValue = value.label;
      this.setState({selectedValue: value.label});
    } else {
      // const value = callback()
      let selectedAnswer = [callback];
      console.log('Value we get before savings the value : ', selectedAnswer);
      this.props.onAnswer(selectedAnswer);
      this.selectedValue = callback.label;
      this.setState({selectedValue: callback.label});
      this.setOpen();
    }
    // const value = callback()
    // this.props.onAnswer([value]);
    // console.log('Value we get before saving the value : ',value);
    // this.selectedValue= value
    // this.setState({ selectedValue: value })
  };
  /* istanbul ignore next */
  UNSAFE_componentWillReceiveProps(
    nextProps: Readonly<P>,
    nextContext: any,
  ): void {
    // console.log('nextProps.item');
    // console.log(nextProps.item);
    let array = [];
    nextProps.item.options.map(row => {
      console.log('Row for the last one is : ', row);
      // Change by danish because the assesment is showing the ids in the dropdowns
      // let object = {label: row.id, value: row.text};
      let object = {id: row.id, label: row.text, value: row.text};
      // Change by danish because the assesment is showing the ids in the dropdowns
      array.push(object);
    });
    this.options = array;
    const {SavedAnswers: answers} = nextProps.item;
    if (nextProps.item.savedAnswers.length > 0) {
      this.selectedValue = nextProps.item.savedAnswers[0];
      this.setState({selectedValue: nextProps.item.savedAnswers[0]});
    }
  }
  componentDidMount(): void {}
  setOpen() {
    this.setState({open: !this.state.open});
  }
  handleSelectedPress(value) {
    this.setValue(value);
    console.log('Comming from the dropdown icon is : ', value);
  }
  /* istanbul ignore next */
  render() {
    console.log('Options', this.options);
    return (
      <Fragment>
        <View style={{flex: 1}}>
          <View
            style={{
              marginTop: hp(3),
              marginLeft: hp(3),
              marginRight: hp(3),
            }}>
            <DropDownPicker
              open={this.state.open}
              items={this.options}
              value={this.selectedValue}
              setValue={this.setValue}
              containerStyle={{height: 200}}
              setOpen={() => this.setState({open: !this.state.open})}
              defaultValue={this.selectedValue}
              placeholder="Choose"
              placeholderStyle={{
                color: Colors.label,
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2),
              }}
              textStyle={{
                color: Colors.black,
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2),
              }}
              style={{
                borderRadius: 8,
                marginTop: hp(0.2),
                borderColor: Colors.line,
                paddingHorizontal: hp(2),
              }}
              controller={instance => (this.dropdownRef.current = instance)}
              renderListItem={props => {
                return (
                  <TouchableOpacity
                    onPress={() => {
                      this.handleSelectedPress(props);
                    }}>
                    <View
                      style={{
                        borderWidth: 0,
                        borderColor: 'red',
                        paddingLeft: hp(2),
                        paddingVertical: hp(1),
                        overflow: 'visible',
                      }}>
                      <Text
                        style={{
                          color: Colors.black,
                          fontFamily: Fonts.SourceSansRegular,
                          fontSize: hp(2),
                        }}>
                        {props.label}
                        {console.log('Props are : ', props)}
                      </Text>
                    </View>
                  </TouchableOpacity>
                );
              }}
            />
          </View>
        </View>
      </Fragment>
    );
  }
}
