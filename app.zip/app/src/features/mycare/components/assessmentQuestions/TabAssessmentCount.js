/* istanbul ignore file */
import React, {Fragment} from 'react';
import {Text} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {connect} from 'react-redux';
import {Fonts} from '../../../../../config/AppConfig';
import Colors from '../../../../../config/Colors';

class TabAssessmentCount extends React.PureComponent {
  /* istanbul ignore next */
  constructor(props) {
    super(props);
  }
  /* istanbul ignore next */
  componentDidMount(): void {}
  /* istanbul ignore next */
  componentWillReceiveProps(nextProps: Readonly<P>, nextContext: any): void {}
  /* istanbul ignore next */
  render() {
    return (
      <Fragment>
        <Text
          style={{
            fontSize: hp(1.8),
            fontFamily: Fonts.SourceSansRegular,
            color: Colors.white,
          }}>
          {global.newAssessmentCount}
        </Text>
      </Fragment>
    );
  }
}
/* istanbul ignore next */
const mapStateToProps = ({assessmentsList}) => ({
  assessmentsList,
});
/* istanbul ignore next */
export default connect(mapStateToProps)(TabAssessmentCount);
