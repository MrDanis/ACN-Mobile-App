/* istanbul ignore file */
import React from 'react';
import {Text, View} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {Fonts} from '../../../../config/AppConfig';
import Colors from '../../../../config/Colors';

const LegendComponent = ({id}) => {
  console.log('LegendComponent idddd', id);
  return (
    <View
      style={{
        flexDirection: 'row',
        width: '100%',
        marginLeft: hp(10),
        marginBottom: hp(4),
        marginTop: hp(2),
      }}>
      <Text
        style={{
          fontFamily: 'WisemanPTSymbols',
          fontSize: hp(4),
          color: Colors.homeGreen,
          marginTop: hp(0.4),
        }}>
        +
      </Text>
      <Text
        style={{
          fontFamily: Fonts.RobotoRegular,
          fontSize: hp(2),
          color: Colors.fontGrey,
        }}>
        Normal
      </Text>
      <Text
        style={{
          fontFamily: 'WisemanPTSymbols',
          fontSize: hp(4),
          marginLeft: hp(2),
          marginTop: hp(0.4),
          color: Colors.red,
        }}>
        +
      </Text>
      <Text
        style={{
          fontFamily: Fonts.RobotoRegular,
          fontSize: hp(2),
          color: Colors.fontGrey,
        }}>
        Critical
      </Text>
    </View>
  );
};

export default LegendComponent;
