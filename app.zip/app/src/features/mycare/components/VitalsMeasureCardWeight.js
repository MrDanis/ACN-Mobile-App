import moment from 'moment';
import React, {useEffect, useState} from 'react';
import {Platform, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import {showMessage} from 'react-native-flash-message';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {SvgCss} from 'react-native-svg';
import {useDispatch, useSelector} from 'react-redux';
import {Colors, Svgs} from '../../../../config';
import {Fonts, OSSource} from '../../../../config/AppConfig';
import VitalsService from '../../../api/vitals';
import {getVitalSubTypesData} from '../action/index';

import CustomSliderHeight from '../../discover/screens/components/customSliderHeight';
import CustomSliderTemperature from '../../discover/screens/components/customSliderTemperature';
import CustomSliderWeight from '../../discover/screens/components/customSliderWeight';
import CustomSliderWeightInLbs from '../../discover/screens/components/CustomSliderWeightInLbs';
import CustomSliderBPDiastolic from '../../discover/screens/components/customSliderBPDiastolic';
import CustomSliderBPSystolic from '../../discover/screens/components/customSliderBPSystolic';
import CustomSliderHeightCm from '../../discover/screens/components/customSliderHeightCm';
import CustomSliderHeightLeft from '../../discover/screens/components/customSliderHeightLeft';

const VitalsMeasureCard = ({
  vitalData,
  setLoader,
  navigation,
  openModal,
  sliderValueParent,
  sliderValueDiastolic,
  sliderValueSystolic,
  showLine,
  setIsScrollable,
  isScrollable,
}) => {
  const [systolic, setSystolic] = useState(null);
  const [diastolic, setDiastolic] = useState(null);
  const [vitalSubTypeValue, setvitalSubTypeValue] = useState('');
  const [textFieldValue, setTextFieldValue] = useState(null);
  const [vitalSubTypes, setVitalSubTypes] = useState([]);
  const [outOfRange, setOutOfRange] = useState(false);
  const [isEditable, setIsEditable] = useState(false);
  const userProfileData = useSelector(state => state.userProfileData);
  const [index, setIndex] = useState(0);
  const [cmBtn, SetCmBtn] = useState(true);
  const [ftBtn, setFtBtn] = useState(false);
  const [kgBtn, SetKgBtn] = useState(true);
  const [lbsBtn, setLbsBtn] = useState(false);
  var outRange = false;
  const [date, setdate] = useState(new Date());

  const [customValue, setCustomValue] = useState(0);
  const [valueLbs, setValueLbs] = useState(sliderValueParent * 2.20462);

  /// States for Temperature
  const [temperatureValue, settemperatureValue] = useState(90);

  /// States for Height
  const [cmValue, setcmValue] = useState(92);
  const [feetValue, setfeetValue] = useState(3);
  const [inchesValue, setinchesValue] = useState(0);

  const [sysValue, setSysValue] = useState(90); //useState(sliderValueSystolic);
  const [diastolicValue, setDiastolicValue] = useState(50); //useState(sliderValueDiastolic);

  const tempValue = 85;
  const [selectedButton, setSelectedButton] = useState('left');

  // const [tempValue, settempValue] = useState(85);

  function getDecimalValuesBeforeDot(decimalValue) {
    // Convert decimalValue to a string to ensure consistency
    const decimalString = String(decimalValue);

    // Find the index of the decimal point
    const decimalIndex = decimalString.indexOf('.');

    // If decimal point exists
    if (decimalIndex !== -1) {
      // Extract the decimal values before the decimal point
      const decimalValues = decimalString.substring(0, decimalIndex);

      // Return the decimal values as a string
      return decimalValues;
    }

    // If no decimal point exists, return an empty string
    return '';
  }

  function getDecimalValues(decimalValue) {
    // Convert decimalValue to a string to ensure consistency
    const decimalString = String(decimalValue);

    // Find the index of the decimal point
    const decimalIndex = decimalString.indexOf('.');

    // If decimal point exists
    if (decimalIndex !== -1) {
      // Extract the decimal values after the decimal point
      const decimalValues = decimalString.slice(decimalIndex + 1);

      // Return the decimal values as a string
      return decimalValues;
    }

    // If no decimal point exists, return an empty string
    return '';
  }

  function onValueChanged(value) {
    setCustomValue(value);
    setValueLbs(value);
  }

  function onValueChangedTemperature(value) {
    settemperatureValue(value);
  }

  function onValueChangedCm(value) {
    setcmValue(value);
  }
  function onValueChangedFeet(value) {
    setfeetValue(value);
  }
  function onValueChangedInches(value) {
    setinchesValue(value);
  }

  function onValueChangedSystolic(value) {
    setSysValue(value);
  }
  function onValueChangedDiastolic(value) {
    setDiastolicValue(value);
  }

  const dispatch = useDispatch();
  useEffect(() => {
    setLoader(true);
    // setLoaderSlider(true);
    console.log('Vitals SubType Data', vitalData.id, vitalData.loinc);

    VitalsService.getVitalSubTypeData(vitalData.loinc)
      .then(res => {
        if (res.statusCode === 200) {
          let sysVal = null;
          let diasVal = null;
          let val = null;
          setLoader(false);
          res.data.map(subType => {
            if (vitalData.loinc === '8480-6') {
              if (subType.name.toLowerCase() === 'systolic') {
                setSystolic(90);
                setSysValue(90);

                sysVal = subType.defaultValue;
              } else if (subType.name.toLowerCase() === 'diastolic') {
                setDiastolic(50);
                setDiastolicValue(50);

                diasVal = subType.defaultValue;
              }
            } else {
              val = subType.value === null ? subType.minRange : subType.value;
              console.debug('This is the subtype Value');
              console.debug(50);
              setTextFieldValue(50);

              onValueChanged(0);
              let feetInches = parseFloat(subType.defaultValue).toFixed(1);

              feetInches = feetInches.split('.');
            }
          });
          if (vitalData.loinc === '8480-6') {
            setvitalSubTypeValue(`${sysVal}/${diasVal}`);
          } else setvitalSubTypeValue(val);
          setVitalSubTypes(res.data);
          dispatch(getVitalSubTypesData(res.data));
        }
      })
      .catch(err => {
        setLoader(false);
        console.log('Vitals Error');
        showMessage({
          message: 'Information',
          description: err.message,
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
    if (isScrollable === false && Platform.OS === 'android') {
      setSysValue(90);
      setDiastolic(50);
    }
  }, []);
  function getTypeValueWithID() {
    const listObj = [];
    if (vitalData.loinc === '8480-6') {
      if (
        systolic === 0 ||
        systolic === '0' ||
        systolic === '' ||
        diastolic === 0 ||
        diastolic === '0' ||
        diastolic === ''
      ) {
        showMessage({
          message: 'Information',
          description: 'Please enter value between range',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      } else {
        vitalSubTypes.map(obj => {
          if (obj.id === 1 || obj.id === 2) {
            console.log('if Executed', obj);
            if (obj.name === 'Systolic') {
              if (systolic < obj.minRange || systolic > obj.maxRange) {
                showMessage({
                  message: 'Information',
                  description: 'Please enter value between range',
                  type: 'default',
                  icon: {icon: 'info', position: 'left'},
                  backgroundColor: Colors.red,
                });
              } else {
                console.log('systolic else executed', obj);
                const data = {
                  vitalSubTypeId: obj.id,
                  value: String(systolic),
                };
                listObj.push(data);
              }
            } else if (obj.name === 'Diastolic') {
              if (diastolic < obj.minRange || diastolic > obj.maxRange) {
                showMessage({
                  message: 'Information',
                  description: 'Please enter value between range',
                  type: 'default',
                  icon: {icon: 'info', position: 'left'},
                  backgroundColor: Colors.red,
                });
              } else {
                console.log('systolic else executed', obj);
                const data = {
                  vitalSubTypeId: obj.id,
                  value: String(diastolic),
                };
                listObj.push(data);
              }
            }
          }
        });
      }
    } else {
      if (
        textFieldValue === 0 ||
        textFieldValue === '0' ||
        textFieldValue === ''
      ) {
        showMessage({
          message: 'Information',
          description: 'Please enter value between range',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      } else {
        vitalSubTypes.map(obj => {
          if (textFieldValue < obj.minRange || textFieldValue > obj.maxRange) {
            showMessage({
              message: 'Information',
              description: 'Please enter value between range',
              type: 'default',
              icon: {icon: 'info', position: 'left'},
              backgroundColor: Colors.red,
            });
          } else {
            const data = {
              vitalSubTypeId: obj.id,
              value: String(textFieldValue),
            };
            listObj.push(data);
          }
        });
      }
    }

    return vitalData.loinc === '8480-6'
      ? listObj.length > 1
        ? listObj
        : []
      : listObj;
  }

  const addVitalHandler = () => {
    if (vitalData.loinc !== '29463-7') {
      setIsScrollable(true);
    }

    measureVitalCall();
  };
  const addVitalHandlerLbs = () => {
    measureVitalCallLbs();
  };

  const addHeightHanlderCm = () => {
    measureVitalCallHeight();
  };

  function measureVitalCallHeight() {
    ///IS Height
    if (vitalData.loinc === '8302-2') {
      const listObj = [];
      const catData = {
        vitalSubTypeId: vitalSubTypes[0].id,
        value: cmBtn
          ? String(convertCmToFeet(cmValue))
          : feetValue.toString() + '.' + inchesValue.toString(),
      };

      listObj.push(catData);
      setLoader(true);
      const data = {
        vitalTypeId: vitalData.id,
        source: OSSource,
        categoryData: listObj,
        createdSource: userProfileData.role === 'Patient' ? 1 : 2,
        dateCreated: moment(new Date()).utc().format('YYYY-MM-DDTHH:mm:ss.SSS'),
        loinc: vitalData.loinc,
      };
      console.log('Data before adding to the backend : ',data)
      VitalsService.addVital(data)
        .then(response => {
          setLoader(false);
          console.log('response');
          console.log(response);
          if (response && response.statusCode === 200) {
            setIsEditable(false);
            if (outOfRange) {
              openModal();
            } else {
              navigation.pop();
            }
          } else {
            showMessage({
              message: 'Information',
              description:
                'Authentication Failed. Provided information is not verified.',
              type: 'default',
              icon: {icon: 'info', position: 'left'},
              backgroundColor: Colors.red,
            });
          }
        })
        .catch(err => {
          setLoader(false);
          console.log('error');
          console.log(err);
          showMessage({
            message: 'Info',
            description: 'Out of range',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        });
    }
  }

  function measureVitalCall() {
    if (vitalData.loinc === '8480-6') {
      const listObj = [];
      const systolicData = {
        vitalSubTypeId: 1,
        value: String(sysValue),
      };
      const diastolicData = {
        vitalSubTypeId: 2,
        value: String(diastolicValue),
      };
      listObj.push(systolicData);
      listObj.push(diastolicData);

      setLoader(true);
      const data = {
        vitalTypeId: vitalData.id,
        source: OSSource,
        categoryData: listObj,
        createdSource: userProfileData.role === 'Patient' ? 1 : 2,
        dateCreated: moment(new Date()).utc().format('YYYY-MM-DDTHH:mm:ss.SSS'),
        loinc: vitalData.loinc,
      };
      VitalsService.addVital(data)
        .then(response => {
          setLoader(false);

          if (response && response.statusCode === 200) {
            setIsEditable(false);
            if (outOfRange) {
              openModal();
            } else {
              navigation.pop();
            }
          } else {
            showMessage({
              message: 'Information',
              description:
                'Authentication Failed. Provided information is not verified.',
              type: 'default',
              icon: {icon: 'info', position: 'left'},
              backgroundColor: Colors.red,
            });
          }
        })
        .catch(err => {
          setLoader(false);
          console.log('error');
          console.log(err);
          showMessage({
            message: 'Info',
            description: 'Out of range',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        });
    }

    ///IS Temperature
    else if (vitalData.loinc === '8310-5') {
      const listObj = [];
      const catData = {
        vitalSubTypeId: vitalSubTypes[0].id,
        value: String(temperatureValue),
      };
      listObj.push(catData);
      setLoader(true);
      const data = {
        vitalTypeId: vitalData.id,
        source: OSSource,
        categoryData: listObj,
        createdSource: userProfileData.role === 'Patient' ? 1 : 2,
        dateCreated: moment(new Date()).utc().format('YYYY-MM-DDTHH:mm:ss.SSS'),
        loinc: vitalData.loinc,
      };
      VitalsService.addVital(data)
        .then(response => {
          setLoader(false);

          if (response && response.statusCode === 200) {
            setIsEditable(false);
            if (outOfRange) {
              openModal();
            } else {
              navigation.pop();
            }
          } else {
            showMessage({
              message: 'Information',
              description:
                'Authentication Failed. Provided information is not verified.',
              type: 'default',
              icon: {icon: 'info', position: 'left'},
              backgroundColor: Colors.red,
            });
          }
        })
        .catch(err => {
          setLoader(false);
          console.log('error');
          console.log(err);
          showMessage({
            message: 'Info',
            description: err.message,
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        });
    }
    ///IS Height
    else if (vitalData.loinc === '8302-2') {
      const listObj = [];
      const catData = {
        vitalSubTypeId: vitalSubTypes[0].id,
        value: String(feetValue + '.' + inchesValue),
      };

      listObj.push(catData);
      setLoader(true);
      const data = {
        vitalTypeId: vitalData.id,
        source: OSSource,
        categoryData: listObj,
        createdSource: userProfileData.role === 'Patient' ? 1 : 2,
        dateCreated: moment(new Date()).utc().format('YYYY-MM-DDTHH:mm:ss.SSS'),
        loinc: vitalData.loinc,
      };
      VitalsService.addVital(data)
        .then(response => {
          setLoader(false);

          if (response && response.statusCode === 200) {
            setIsEditable(false);
            if (outOfRange) {
              openModal();
            } else {
              navigation.pop();
            }
          } else {
            showMessage({
              message: 'Information',
              description:
                'Authentication Failed. Provided information is not verified.',
              type: 'default',
              icon: {icon: 'info', position: 'left'},
              backgroundColor: Colors.red,
            });
          }
        })
        .catch(err => {
          setLoader(false);
          console.log('error');
          console.log(err);
          showMessage({
            message: 'Info',
            description: err.message,
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        });
    } else if (vitalData.loinc === '29463-7') {
      const listObj = [];
      const catData = {
        vitalSubTypeId: vitalSubTypes[0]?.id,
        value: String(customValue),
      };

      listObj.push(catData);
      console.log('afta', listObj);
      setLoader(true);
      const data = {
        vitalTypeId: vitalData.id,
        source: OSSource,
        categoryData: listObj,
        createdSource: userProfileData.role === 'Patient' ? 1 : 2,
        dateCreated: moment(new Date()).utc().format('YYYY-MM-DDTHH:mm:ss.SSS'),
        loinc: vitalData.loinc,
      };
      VitalsService.addVital(data)
        .then(response => {
          setLoader(false);

          if (response && response.statusCode === 200) {
            setIsEditable(false);
            if (outOfRange) {
              openModal();
            } else {
              navigation.pop();
            }
          } else {
            showMessage({
              message: 'Information',
              description:
                'Authentication Failed. Provided information is not verified.',
              type: 'default',
              icon: {icon: 'info', position: 'left'},
              backgroundColor: Colors.red,
            });
          }
        })
        .catch(err => {
          setLoader(false);
          console.log('error');
          console.log(err);
          showMessage({
            message: 'Info',
            description: err.message,
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        });
    }
  }
  function measureVitalCallLbs() {
    const listObj = [];
    const catData = {
      vitalSubTypeId: vitalSubTypes[0].id,
      value: String(parseInt(valueLbs / 2.205)),
    };

    listObj.push(catData);
    setLoader(true);
    const data = {
      vitalTypeId: vitalData.id,
      source: OSSource,
      categoryData: listObj,
      createdSource: userProfileData.role === 'Patient' ? 1 : 2,
      dateCreated: moment(new Date()).utc().format('YYYY-MM-DDTHH:mm:ss.SSS'),
      loinc: vitalData.loinc,
    };
    VitalsService.addVital(data)
      .then(response => {
        setLoader(false);
        if (response && response.statusCode === 200) {
          setIsEditable(false);
          if (outOfRange) {
            openModal();
          } else {
            navigation.pop();
          }
        } else {
          showMessage({
            message: 'Information',
            description:
              'Authentication Failed. Provided information is not verified.',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        }
      })
      .catch(err => {
        setLoader(false);
        console.log('error');
        console.log(err);
        showMessage({
          message: 'Info',
          description: err.message,
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  }
  const TemperatureMeasureCard = (
    <View
      style={{
        backgroundColor: Colors.white,
        marginTop: hp(5),
        marginBottom: hp(3),
        borderRadius: 8,
        width: '100%',
        shadowOffset: {width: 0.5, height: 0.5},
        shadowOpacity: 0.05,
        shadowRadius: 8,
        elevation: 1,
      }}>
      <View
        style={{
          flexDirection: 'row',
        }}>
        <View
          style={{
            alignSelf: 'center',
            flexDirection: 'row',
            alignItems: 'center',
            marginTop: hp(2.5),
            marginLeft: hp(2),
            marginBottom: hp(1),
            flex: 0.5,
          }}>
          <Text
            style={{
              fontFamily: Fonts.SourceSansRegular,
              fontSize: hp(1.7),
              alignContent: 'center',
              alignSelf: 'center',
              color: Colors.darkgrey,
              fontWeight: '400',
              marginRight: hp(0.5),
            }}>
            Range
          </Text>
          <Text
            style={{
              fontFamily: Fonts.SourceSansRegular,
              fontSize: hp(2),
              alignContent: 'center',
              alignSelf: 'center',
              fontWeight: '600',
              marginRight: hp(0.5),
              color: Colors.black4,
            }}>
            {temperatureValue}
          </Text>
          <Text
            style={{
              fontFamily: Fonts.SourceSansRegular,
              fontSize: hp(1.8),
              marginLeft: hp(0),
              color: Colors.darkgrey,
              fontWeight: '400',
              alignContent: 'center',
              alignSelf: 'center',
            }}>
            °F
          </Text>
        </View>
        <View
          style={{
            alignItems: 'flex-end',
            borderRadius: 8,
            alignSelf: 'center',
            flex: 0.5,
          }}>
          <View style={{flexDirection: 'row'}}>
            {Platform.OS === 'android' ? (
              <TouchableOpacity
                onPress={() => {
                  isScrollable ? setIsScrollable(false) : addVitalHandler();
                }}
                style={{
                  width: '100%',
                  alignSelf: 'center',
                  marginVertical: hp(1),
                  marginRight: hp(2.5),
                  alignItems: 'flex-end',
                }}>
                <Text
                  style={{
                    fontSize: hp(2),
                    fontFamily: Fonts.SourceSansRegular,
                    color: Colors.blueTextColor,
                  }}>
                  {isScrollable ? 'Edit' : 'Save'}
                </Text>
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                onPress={() => {
                  addVitalHandler();
                }}
                style={{
                  width: '100%',
                  alignSelf: 'center',
                  marginVertical: hp(1),
                  marginRight: hp(2.5),
                  alignItems: 'flex-end',
                }}>
                <Text
                  style={{
                    fontSize: hp(2),
                    fontFamily: Fonts.SourceSansRegular,
                    color: Colors.blueTextColor,
                  }}>
                  {'Save'}
                </Text>
              </TouchableOpacity>
            )}
            {Platform.OS === 'android' && !isScrollable && (
              <TouchableOpacity
                onPress={() => {
                  setIsScrollable(true);
                }}
                style={{
                  marginVertical: hp(1),
                  marginRight: hp(2.5),
                }}>
                {Platform.OS === 'android' && (
                  <Text
                    style={{
                      fontSize: hp(2),
                      fontFamily: Fonts.SourceSansRegular,
                      color: Colors.blueTextColor,
                    }}>
                    {!isScrollable && 'Cancel'}
                  </Text>
                )}
              </TouchableOpacity>
            )}
          </View>
          {/* )} */}
        </View>
      </View>

      {/* Height Guy & Slider */}
      <View
        style={{
          flexDirection: 'row',
          marginLeft: hp(2),
        }}>
        {/* SVG Height Guy */}
        <View>
          <SvgCss
            xml={Svgs.temperature_svg}
            width={hp(14.2)}
            height={hp(40)}
            fill={Colors.white}
            style={{
              marginTop: hp(3),
            }}
          />
        </View>
        {/* Custom Slider View */}
        <View
          style={{
            transform: [{rotate: '90deg'}],
            borderRadius: hp(2),
            paddingTop: hp(20),
            paddingLeft: hp(4),
            marginBottom: hp(2),
            width: '100%',
          }}>
          {temperatureValue && temperatureValue ? (
            <CustomSliderTemperature
              sliderValue={temperatureValue}
              setSliderValue={onValueChangedTemperature}
              vitalsSubTypesData={vitalSubTypes}
              isEditable={true}
            />
          ) : null}
        </View>
      </View>
      <View
        style={{
          paddingBottom: hp(4),
          alignContent: 'flex-end',
          alignSelf: 'flex-end',
          paddingRight: hp(14),
          paddingTop: hp(1),
        }}>
        <Text
          style={{
            fontFamily: Fonts.SourceSansRegular,
            fontSize: hp(1.7),
            color: Colors.darkGrey,
            fontWeight: '600',
          }}>
          {Platform.OS === 'ios'
            ? temperatureValue
            : vitalSubTypes && vitalSubTypes[0]?.minRange}{' '}
          °F
        </Text>
      </View>
    </View>
  );

  const BloodPressureMeasureCard = (
    <View
      style={{
        backgroundColor: Colors.white,
        shadowOffset: {width: 0.5, height: 0.5},
        shadowOpacity: 0.05,
        shadowRadius: 8,
        elevation: 10,
        borderRadius: 8,
      }}>
      <View style={{alignItems: 'flex-end'}}>
        <View style={{flexDirection: 'row'}}>
          {Platform.OS === 'android' ? (
            <TouchableOpacity
              onPress={() => {
                isScrollable ? setIsScrollable(false) : addVitalHandler();
                setSysValue(90);
                setDiastolicValue(50);
              }}
              style={{
                width: '100%',
                alignSelf: 'center',
                marginVertical: hp(1),
                marginRight: hp(2.5),
                alignItems: 'flex-end',
              }}>
              <Text
                style={{
                  fontSize: hp(2),
                  fontFamily: Fonts.SourceSansRegular,
                  color: Colors.blueTextColor,
                }}>
                {isScrollable ? 'Edit' : 'Save'}
              </Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              onPress={() => {
                addVitalHandler();
              }}
              style={{
                width: '100%',
                alignSelf: 'center',
                marginVertical: hp(1),
                marginRight: hp(2.5),
                alignItems: 'flex-end',
              }}>
              <Text
                style={{
                  fontSize: hp(2),
                  fontFamily: Fonts.SourceSansRegular,
                  color: Colors.blueTextColor,
                }}>
                {'Save'}
              </Text>
            </TouchableOpacity>
          )}
          {Platform.OS === 'android' && !isScrollable && (
            <TouchableOpacity
              onPress={() => {
                setIsScrollable(true);
              }}
              style={{
                marginVertical: hp(1),
                marginRight: hp(2.5),
              }}>
              {Platform.OS === 'android' && (
                <Text
                  style={{
                    fontSize: hp(2),
                    fontFamily: Fonts.SourceSansRegular,
                    color: Colors.blueTextColor,
                  }}>
                  {!isScrollable && 'Cancel'}
                </Text>
              )}
            </TouchableOpacity>
          )}
        </View>
        {/* )} */}
      </View>
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
        }}>
        <View
          style={{
            width: '30%',
            marginLeft: hp(3),
            flexDirection: 'row',
            alignItems: 'center',
          }}>
          <View
            style={{
              width: hp(1.5),
              height: hp(1.5),
              borderRadius: hp(2),
              backgroundColor: Colors.blueTextColor,
            }}
          />
          <Text
            style={{
              fontFamily: Fonts.SourceSansRegular,
              fontSize: hp(2),
              color: Colors.black,
              marginLeft: hp(1),
            }}>
            Systolic
          </Text>
        </View>
        <View
          style={{
            width: '30%',
            marginLeft: hp(3),
            flexDirection: 'row',
            alignItems: 'center',
          }}>
          <View
            style={{
              width: hp(1.5),
              height: hp(1.5),
              borderRadius: hp(2),
              backgroundColor: Colors.red3,
            }}
          />
          <Text
            style={{
              fontFamily: Fonts.SourceSansRegular,
              fontSize: hp(2),
              color: Colors.black,
              marginLeft: hp(1),
            }}>
            Diastolic
          </Text>
        </View>
      </View>
      <View
        style={{
          backgroundColor: Colors.white,
          width: '100%',
          paddingVertical: hp(5.5),
          flexDirection: 'row',
        }}>
        <View
          style={{
            transform: [{rotate: '-90deg'}],
            borderRadius: 8,
            width: '90%',
            paddingTop: hp(10),
            marginLeft: hp(-15),
            marginBottom: hp(-1),
          }}>
          <View
            style={{
              backgroundColor: Colors.white,
              width: '100%',
              marginTop: hp(10),
            }}>
            {Platform.OS === 'ios' ? (
              <CustomSliderBPSystolic
                sliderValue={sysValue}
                setSliderValue={onValueChangedSystolic}
                vitalsSubTypesData={vitalSubTypes}
                isEditable={true}
              />
            ) : (
              <CustomSliderBPSystolic
                sliderValue={isScrollable ? 90 : sysValue}
                setSliderValue={onValueChangedSystolic}
                vitalsSubTypesData={vitalSubTypes}
                isEditable={true}
              />
            )}
          </View>
        </View>
        <View
          style={{
            borderWidth: 1,
            marginLeft: hp(-2),
            borderColor: Colors.line,
            height: hp(36),
          }}
        />
        <View
          style={{
            transform: [{rotate: '90deg'}],
            borderRadius: 8,
            width: '90%',
            paddingTop: hp(22),
            marginBottom: hp(-1),
            paddingLeft: hp(-10),
          }}>
          <View
            style={{
              backgroundColor: Colors.white,
              width: '100%',
            }}>
            {Platform.OS === 'ios' ? (
              <CustomSliderBPDiastolic
                sliderValue={diastolicValue}
                setSliderValue={onValueChangedDiastolic}
                vitalsSubTypesData={vitalSubTypes}
                isEditable={true}
              />
            ) : (
              <CustomSliderBPDiastolic
                sliderValue={isScrollable ? 50 : diastolicValue}
                setSliderValue={onValueChangedDiastolic}
                vitalsSubTypesData={vitalSubTypes}
                isEditable={true}
              />
            )}
          </View>
        </View>
      </View>
      <View
        style={{
          alignItems: 'flex-end',
          paddingHorizontal: hp(1),
          marginTop: hp(-2),
          marginBottom: hp(1),
        }}>
        {Platform.OS === 'ios' ? (
          <Text
            style={{
              fontFamily: Fonts.SourceSansBold,
              fontSize: hp(3),
              color: Colors.black,
            }}>
            {sysValue}/{diastolicValue}
          </Text>
        ) : (
          <Text
            style={{
              fontFamily: Fonts.SourceSansBold,
              fontSize: hp(3),
              color: Colors.black,
            }}>
            {isScrollable ? 90 : sysValue}/{isScrollable ? 50 : diastolicValue}
          </Text>
        )}
        <Text
          style={{
            fontFamily: Fonts.SourceSansRegular,
            fontSize: hp(2),
            color: Colors.noRecordFound,
          }}>
          mm/hg
        </Text>
      </View>
    </View>
  );
  const WeightMeasureCard = (
    <View
      style={{
        backgroundColor: Colors.white,
        marginTop: hp(2),
        marginBottom: hp(3),
        borderRadius: 8,
        width: '100%',
        alignSelf: 'center',
        shadowOffset: {width: 0.5, height: 0.5},
        shadowOpacity: 0.05,
        shadowRadius: 8,
        elevation: 0,
      }}>
      <View
        style={{
          flexDirection: 'row',
          alignContent: 'space-between',
          borderColor: 'red',
          borderWidth: 0,
        }}>
        <View
          style={{
            alignSelf: 'center',
            flexDirection: 'row',
            alignItems: 'center',
            display: Platform.OS === 'ios' ? 'none' : 'flex',
          }}>
          <View
            style={{
              width: '65%',
            }}>
            <View>
              <View
                style={{
                  alignItems: 'center',
                  marginVertical: hp(2),
                }}>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'center',
                    backgroundColor: Colors.bleLayer4,
                    width: Platform.OS === 'ios' ? '67%' : hp(20),
                    borderRadius: hp(4),
                    borderColor: 'red',
                    borderWidth: 0,
                    marginLeft: hp(5),
                  }}>
                  <TouchableOpacity
                    style={{
                      minWidth: Platform.OS === 'ios' ? '40%' : '50%',
                      height: Platform.OS === 'android' ? hp(4) : hp(4),
                      flexDirection: 'row',
                      justifyContent: 'center',
                      alignItems: 'center',
                      backgroundColor: kgBtn
                        ? Colors.blueTextColor
                        : Colors.bleLayer4,
                      borderRadius: hp(4),
                      borderColor: 'green',
                      borderWidth: 0,
                    }}
                    onPress={() => {
                      SetKgBtn(true);
                      setLbsBtn(false);
                      setValueLbs(0);
                    }}>
                    <Text
                      style={{
                        color: kgBtn ? Colors.white : Colors.noRecordFound,
                      }}>
                      KG
                    </Text>
                    <View
                      style={{
                        position: 'absolute',
                        right: Platform.OS === 'ios' ? '30%' : '30%',
                        top: '20%',
                        borderRadius: hp(4),
                        width: 5,
                        height: 5,
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}></View>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={{
                      minWidth: Platform.OS === 'ios' ? '40%' : '50%',
                      height: Platform.OS === 'android' ? hp(4) : hp(4),
                      justifyContent: 'center',
                      alignItems: 'center',
                      backgroundColor: lbsBtn
                        ? Colors.blueTextColor
                        : Colors.bleLayer4,
                      borderRadius: hp(4),
                      shadowRadius: 5,
                      marginLeft: Platform.OS === 'ios' ? hp(0) : hp(0),
                      borderWidth: 0,
                      borderColor: 'blue',
                    }}
                    onPress={() => {
                      SetKgBtn(false);
                      setLbsBtn(true);
                      setValueLbs(0);
                    }}>
                    <Text
                      style={{
                        color: lbsBtn ? Colors.white : Colors.noRecordFound,
                      }}>
                      lbs
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </View>
        </View>
        <View
          style={{
            alignSelf: 'center',
            flexDirection: 'row',
            alignItems: 'center',
            display: Platform.OS === 'ios' ? 'flex' : 'none',
          }}>
          <View
            style={{
              width: '65%',
            }}>
            <View>
              <View
                style={{
                  alignItems: 'center',
                  marginVertical: hp(2),
                }}>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'center',
                    backgroundColor: Colors.bleLayer4,
                    width: Platform.OS === 'ios' ? '67%' : hp(20),
                    borderRadius: hp(4),
                  }}>
                  <TouchableOpacity
                    style={{
                      minWidth: Platform.OS === 'ios' ? '40%' : hp('23%'),
                      height: Platform.OS === 'android' ? hp(4) : hp(4),
                      flexDirection: 'row',
                      justifyContent: 'center',
                      alignItems: 'center',
                      backgroundColor: kgBtn
                        ? Colors.blueTextColor
                        : Colors.bleLayer4,
                      borderRadius: hp(4),
                    }}
                    onPress={() => {
                      SetKgBtn(true);
                      setLbsBtn(false);
                      setCustomValue(0);
                    }}>
                    <Text
                      style={{
                        color: kgBtn ? Colors.white : Colors.noRecordFound,
                      }}>
                      kg
                    </Text>
                    <View
                      style={{
                        position: 'absolute',
                        right: Platform.OS === 'ios' ? '30%' : '30%',
                        top: '20%',
                        borderRadius: hp(4),
                        width: 5,
                        height: 5,
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}></View>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={{
                      minWidth: Platform.OS === 'ios' ? '40%' : hp('23%'),
                      height: Platform.OS === 'android' ? hp(4) : hp(4),
                      justifyContent: 'center',
                      alignItems: 'center',
                      backgroundColor: lbsBtn
                        ? Colors.blueTextColor
                        : Colors.bleLayer4,
                      borderRadius: hp(4),
                      shadowRadius: 5,
                      marginLeft: Platform.OS === 'ios' ? hp(0) : hp(0),
                    }}
                    onPress={() => {
                      SetKgBtn(false);
                      setLbsBtn(true);
                      setValueLbs(0);
                    }}>
                    <Text
                      style={{
                        color: lbsBtn ? Colors.white : Colors.noRecordFound,
                      }}>
                      lbs
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </View>
        </View>
        <View
          style={{
            alignItems: 'center',

            borderRadius: 8,
            width: '50%',
            marginLeft: hp(0),
            alignSelf: 'center',
          }}>
          <TouchableOpacity
            onPress={() => {
              if (kgBtn) {
                addVitalHandler();
              } else {
                addVitalHandlerLbs();
              }
            }}>
            <Text
              style={{
                fontSize: hp(2),

                fontFamily: Fonts.SourceSansRegular,
                color: Colors.blueTextColor,
              }}>
              Save
            </Text>
          </TouchableOpacity>
        </View>
      </View>
      {kgBtn ? (
        <View
          style={{
            backgroundColor: Colors.white,
            borderRadius: hp(2),
            paddingTop: hp(2),
            paddingBottom: hp(2),
            width: '100%',
            borderColor: 'green',
            borderWidth: 0,
          }}>
          <CustomSliderWeight
            sliderValue={customValue}
            setSliderValue={onValueChanged}
            vitalsSubTypesData={vitalSubTypes}
            isEditable={true}
            kgBtn={kgBtn}
          />

          <View
            style={{
              marginTop: hp(2.5),
              borderWidth: 0.5,
              borderColor: Colors.line,
              width: '100%',
              shadowOffset: {width: 0.1, height: 3},
              shadowOpacity: 0.2,
              shadowRadius: 5,
              elevation: Platform.OS === 'ios' ? 20 : 0,
            }}
          />
          <View
            style={{
              flexDirection: 'column',
              alignItems: 'center',
            }}>
            <TouchableOpacity>
              <Text
                style={{
                  fontFamily: Fonts.SourceSansSemibold,
                  fontSize: hp(2.8),
                  marginTop: hp(2),
                  color: Colors.black,
                }}>
                {Math.floor(customValue)}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity style={{alignItems: 'center'}}>
              <Text
                style={{
                  fontFamily: Fonts.SourceSansRegular,
                  fontSize: hp(2.2),
                  color: Colors.blueGrayDisableText,
                }}>
                Kilogram
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      ) : (
        <View
          style={{
            backgroundColor: Colors.white,
            borderRadius: hp(2),
            paddingTop: hp(2),
            paddingBottom: hp(2),
            width: '100%',
            borderColor: 'red',
            borderWidth: 0,
          }}>
          <CustomSliderWeightInLbs
            sliderValue={valueLbs}
            setSliderValue={onValueChanged}
            vitalsSubTypesData={vitalSubTypes}
            isEditable={true}
            kgBtn={kgBtn}
          />

          <View
            style={{
              marginTop: hp(2.5),
              borderWidth: 0.5,
              borderColor: Colors.line,
              width: '100%',
              shadowOffset: {width: 0.1, height: 3},
              shadowOpacity: 0.2,
              shadowRadius: 5,
            }}
          />
          <View
            style={{
              flexDirection: 'column',
              alignItems: 'center',
            }}>
            <TouchableOpacity>
              <Text
                style={{
                  fontFamily: Fonts.SourceSansRegular,
                  fontSize: hp(2.8),
                  marginTop: hp(2),
                  color: Colors.black,
                  fontWeight: 'bold',
                }}>
                {Math.floor(valueLbs)}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity style={{alignItems: 'center'}}>
              <Text
                style={{
                  fontFamily: Fonts.SourceSansRegular,
                  fontSize: hp(2.2),
                  color: Colors.blueGrayDisableText,
                }}>
                pounds
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );

  const handleLeftButtonPress = () => {
    setSelectedButton('left');
    onLeftButtonPress();
  };

  const handleRightButtonPress = () => {
    setSelectedButton('right');
    onRightButtonPress();
  };
  const convertCmToFeet = cm => {
    const feetPerCm = 0.0328084; // 1 cm = 0.0328084 feet
    const feet = cm * feetPerCm;
    const wholeFeet = Math.floor(feet);
    const inches = (feet - wholeFeet) * 12;
    const [integerPart, decimalPart = ""] = inches.toString().split(".");
    let result = 0;
    if(integerPart === '0')
      {
          result = `${wholeFeet}`;
      }
      else
      {
        result = `${wholeFeet}.${integerPart}`
      }
      return result;
  };

  const convertFeetToCm = feet => {
    const cmPerFeet = 30.48; // 1 foot = 30.48 cm
    let cm = feet * cmPerFeet;
    cm = cm + 1;
    console.log('CM value before saving to DB : ',cm);
    setcmValue(cm.toFixed(0));

    return parseFloat(cm.toFixed(1));
  };

  const HeightCard = (
    <View
      style={{
        backgroundColor: Colors.white,
        marginTop: hp(5),
        marginBottom: hp(3),
        borderRadius: 8,
        width: '100%',

        shadowOffset: {width: 0.5, height: 0.5},
        shadowOpacity: 0.05,
        shadowRadius: 8,
        elevation: 1,
        borderColor: 'red',
        borderWidth: 0,
      }}>
      {/* Cm Ft and Edit Button */}
      <View
        style={{
          flexDirection: 'row',
          paddingTop: Platform.OS === 'ios' ? hp(0) : hp(2.5),
        }}>
        {/* ======================= Feet and CM Selection for android(Danish) =========================== */}
        <View
          style={{
            display: Platform.OS === 'ios' ? 'none' : 'flex',
            alignItems: 'flex-start',
            paddingLeft: hp(2.5),
            paddingRight: hp(2),
            flex: 0.5,
          }}>
          {/* Wrapper View Start */}
          <View
            style={{
              flex: 1,
              flexDirection: 'row',
              borderColor: 'green',
              borderWidth: 0,
              backgroundColor: Colors.bleLayer4,
              borderRadius: hp(4),
            }}>
            <TouchableOpacity
              onPress={() => {
                SetCmBtn(true);
                setFtBtn(false);
              }}
              style={{
                paddingVertical: hp(0.65),
                width: '50%',
                borderColor: 'blue',
                borderWidth: 0,
                borderRadius: hp(4),
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: cmBtn
                  ? Colors.blueTextColor
                  : Colors.bleLayer4,
              }}>
              <Text
                style={{color: cmBtn ? Colors.white : Colors.noRecordFound}}>
                cm
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => {
                setFtBtn(true);
                SetCmBtn(false);
              }}
              style={{
                paddingVertical: hp(0.65),
                width: '50%',
                borderColor: 'green',
                borderWidth: 0,
                borderRadius: hp(4),
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: ftBtn
                  ? Colors.blueTextColor
                  : Colors.bleLayer4,
              }}>
              <Text
                style={{color: ftBtn ? Colors.white : Colors.noRecordFound}}>
                ft
              </Text>
            </TouchableOpacity>
          </View>
          {/* Wrapper View End */}
        </View>

        <View
          style={{
            display: Platform.OS === 'ios' ? 'flex' : 'none',
            justifyContent: 'space-between',
            alignSelf: 'center',
            flexDirection: 'row',
            alignItems: 'center',
            marginTop: hp(2.5),
            marginLeft: hp(2),
            marginBottom: hp(1),
            borderColor: 'blue',
          }}>
          {/* The CM and Feet buttons */}
          <View
            style={{
              flex: 0.5,
              borderColor: 'red',
              borderWidth: 0,
            }}>
            <View>
              {console.log('CM Btn is : ',cmBtn)}
              <View
                style={{
                  alignItems: 'center',
                }}>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'center',
                    backgroundColor: Colors.bleLayer4,
                    width: Platform.OS === 'ios' ? '67%' : hp(20),
                    borderRadius: hp(4),
                  }}>
                  <TouchableOpacity
                    style={{
                      minWidth: Platform.OS === 'ios' ? '50%' : hp('23%'),
                      height: Platform.OS === 'android' ? hp(4) : hp(4),
                      flexDirection: 'row',
                      justifyContent: 'center',
                      alignItems: 'center',
                      backgroundColor: cmBtn
                        ? Colors.blueTextColor
                        : Colors.bleLayer4,
                      borderRadius: hp(4),
                    }}
                    onPress={() => {
                      SetCmBtn(true);
                      setFtBtn(false);
                    }}>
                    <Text
                      style={{
                        color: cmBtn ? Colors.white : Colors.noRecordFound,
                      }}>
                      cm
                    </Text>
                    <View
                      style={{
                        position: 'absolute',
                        right: Platform.OS === 'ios' ? '30%' : '30%',
                        top: '20%',
                        borderRadius: hp(4),
                        width: 5,
                        height: 5,
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}></View>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={{
                      minWidth: Platform.OS === 'ios' ? '48%' : hp('23%'),
                      height: Platform.OS === 'android' ? hp(4) : hp(4),
                      justifyContent: 'center',
                      alignItems: 'center',
                      backgroundColor: ftBtn
                        ? Colors.blueTextColor
                        : Colors.bleLayer4,
                      borderRadius: hp(4),
                      shadowRadius: 5,
                      marginLeft: Platform.OS === 'ios' ? hp(0) : hp(0),
                    }}
                    onPress={() => {
                      setFtBtn(true);
                      SetCmBtn(false);
                    }}>
                    <Text
                      style={{
                        color: ftBtn ? Colors.white : Colors.noRecordFound,
                      }}>
                      ft
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </View>
        </View>

        <View
          style={{
            borderRadius: 8,
            flex: 0.9,
          }}>
          <View
            style={{
              flexDirection: 'row',
              paddingRight: hp(2),
              width: '100%',
            }}>
            {Platform.OS === 'android' ? (
              <TouchableOpacity
                onPress={() => {
                  isScrollable ? setIsScrollable(false) : addHeightHanlderCm();
                }}
                style={{
                  alignSelf: 'center',
                  marginVertical: hp(1),
                  marginRight: hp(2.5),
                  alignItems: 'flex-end',
                  flex: 1,
                }}>
                <Text
                  style={{
                    fontSize: hp(2),
                    fontFamily: Fonts.SourceSansRegular,
                    color: Colors.blueTextColor,
                  }}>
                  {isScrollable ? 'Edit' : 'Save'}
                </Text>
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                onPress={() => {
                  addHeightHanlderCm();
                }}
                style={{
                  minWidth: '100%',
                  marginVertical: hp(1),
                  alignItems: 'flex-end',
                }}>
                <Text
                  style={{
                    fontSize: hp(2),
                    fontFamily: Fonts.SourceSansRegular,
                    color: Colors.blueTextColor,
                  }}>
                  {'Save'}
                </Text>
              </TouchableOpacity>
            )}
            {Platform.OS === 'android' && !isScrollable && (
              <TouchableOpacity
                onPress={() => {
                  setIsScrollable(true);
                }}
                style={{
                  marginVertical: hp(1),
                  alignItems: 'flex-end',
                }}>
                {Platform.OS === 'android' && (
                  <Text
                    style={{
                      fontSize: hp(2),
                      fontFamily: Fonts.SourceSansRegular,
                      color: Colors.blueTextColor,
                    }}>
                    {!isScrollable && 'Cancel'}
                  </Text>
                )}
              </TouchableOpacity>
            )}
          </View>
          {/* )} */}
        </View>
      </View>

      {/* HEIGHT SLIDER AND BOTTOM FEET TEXT PUT CONDITION */}
      {cmBtn ? (
        <View
          style={{
            borderColor: 'green',
            borderWidth: 0,
          }}>
          <View
            style={{
              flexDirection: 'row',
              marginLeft: hp(2),
              borderColor: 'red',
              borderWidth: 0,
            }}>
            <View
              style={{borderColor: 'blue', borderWidth: 0}}
              onTouchCancel={() => {}}
              onTouchMove={() => {}}>
              <SvgCss
                xml={Svgs.man_vector}
                width={hp(14.2)}
                height={hp(40)}
                fill={Colors.white}
                style={{
                  marginTop: hp(3),
                }}
              />
            </View>
            {/* Custom Slider View */}
            <View
              style={{
                transform: [{rotate: '90deg'}],
                borderRadius: hp(2),
                paddingTop: hp(20),
                paddingLeft: hp(4),
                marginBottom: hp(2),
                width: '100%',
                borderColor: 'green',
                borderWidth: 0,
              }}>
              <CustomSliderHeightCm
                sliderValue={cmValue}
                setSliderValue={onValueChangedCm}
                vitalsSubTypesData={vitalSubTypes}
                isEditable={true}
              />
            </View>
            {console.log(cmValue,
              'Test the value before assigning to the meter : ',sliderValueParent,
              cmValue === sliderValueParent
                ? convertFeetToCm(cmValue)
                : cmValue,
            )}
          </View>
          {/* F Bottom Button */}
          <View
            style={{
              alignContent: 'center',
              alignSelf: 'center',
              paddingTop: hp(2),
              paddingBottom: hp(2),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2.7),
                alignSelf: 'center',
                color: Colors.black,
                fontWeight: '600',
              }}>
                {
                  cmValue
                }
              {/* {Platform.OS === 'ios'
                ? cmValue === sliderValueParent
                  ? convertFeetToCm(cmValue)
                  : cmValue
                : 93} */}
            </Text>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(1.7),
                color: Colors.blueGrayDisableText,
                alignSelf: 'center',
                fontWeight: '600',
              }}>
              cm
            </Text>
          </View>
        </View>
      ) : (
        <View
          style={{
            zIndex: 1,
          }}>
          <View
            style={{
              transform: [{rotate: '270deg'}],
              position: 'absolute',
              marginTop: hp(20),
              marginLeft: hp(-11),
              borderColor:'red',
              borderWidth:0
            }}>
            <CustomSliderHeightLeft
              sliderValue={feetValue}
              setSliderValue={onValueChangedFeet}
              vitalsSubTypesData={vitalSubTypes}
              isEditable={true}
            />
          </View>

          {/* Height Guy & Slider */}
          <View
            style={{
              flexDirection: 'row',
              marginLeft: hp(13),
            }}>
            {/* SVG Height Guy */}
            <View>
              <SvgCss
                xml={Svgs.man_vector}
                width={hp(14.2)}
                height={hp(40)}
                fill={Colors.white}
                style={{
                  marginTop: hp(3),
                  marginLeft: hp(2),
                }}
              />
            </View>
            {/* Custom Slider View */}
            <View
              style={{
                transform: [{rotate: '90deg'}],
                borderRadius: hp(2),
                paddingTop: hp(22),
                marginBottom: hp(2),
                width: '100%',
              }}>
                {console.log('Value in inches is : ',inchesValue)}
              <CustomSliderHeight
                sliderValue={inchesValue}
                setSliderValue={onValueChangedInches}
                vitalsSubTypesData={vitalSubTypes}
                isEditable={true}
              />
            </View>
          </View>
          {/* F Bottom Button */}
          <View
            style={{
              alignContent: 'center',
              alignSelf: 'center',
              paddingTop: hp(2),
              paddingBottom: hp(2),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2.7),
                alignSelf: 'center',
                color: Colors.black,
                fontWeight: '600',
              }}>
              {feetValue}.{inchesValue}
            </Text>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2.7),
                alignSelf: 'center',
                color: Colors.black,
                fontWeight: '600',
              }}></Text>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(1.7),
                color: Colors.blueGrayDisableText,
                alignSelf: 'center',
                fontWeight: '600',
              }}>
              Feet/Inch
            </Text>
          </View>
        </View>
      )}
    </View>
  );

  ////////////////////////
  return vitalData.loinc === '8310-5'
    ? // It IS Temperature
      TemperatureMeasureCard
    : vitalData.loinc === '8302-2'
    ? // It IS Height
      HeightCard
    : vitalData.loinc === '29463-7'
    ? WeightMeasureCard
    : BloodPressureMeasureCard;
};
const styles = StyleSheet.create({
  thumb: {
    width: 20,
    height: 10,
    transform: [{rotate: '360deg'}],

    shadowColor: 'black',
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.5,
    shadowRadius: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 35 / 2,
    elevation: 5,
    color: Colors.transparent,
  },
  track: {
    height: hp(0),
    borderRadius: 20,
  },
  switchContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  switchButton: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'grey',
    backgroundColor: 'white',
    elevation: 2,
  },
  selectedButton: {
    backgroundColor: 'blue',
  },
  unselectedButton: {
    backgroundColor: 'white',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  container: {
    flex: 1,
  },
  tabbar: {
    backgroundColor: '#369',
    overflow: 'hidden',
  },
  icon: {
    backgroundColor: 'transparent',
    color: 'white',
  },
  indicator: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#0084ff',
    margin: 6,
  },
  badge: {
    marginTop: 4,
    marginRight: 32,
    backgroundColor: '#f44336',
    height: 24,
    width: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 4,
  },
  count: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
    marginTop: -2,
  },
});

export default VitalsMeasureCard;
