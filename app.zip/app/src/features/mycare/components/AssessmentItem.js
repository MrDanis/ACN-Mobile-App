import moment from 'moment';
import React from 'react';
import {Platform, Text, TouchableOpacity, View} from 'react-native';
import {AnimatedCircularProgress} from 'react-native-circular-progress';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
// import AssessmentIcon from '../../../../../assets/svg/AssesmentIcon.svg';
import {Colors} from '../../../../config';
import {Fonts} from '../../../../config/AppConfig';
import {SvgXml} from 'react-native-svg';
import svgs from '../../../../config/Svgs';
import {convertUTCDateToLocalDate} from '../../../helpers/Common';
const AssessmentItem = ({item, navigation, completed, titleDate}) => {
  const fill = item.completionPercentage;

  return (
    <TouchableOpacity
      onPress={() => {
        if (completed === true) {
          navigation.navigate('AssessmentSummary', {
            data: item,
            progress: 1,
            isCompleted: true,
            dateOfCompletion: titleDate,
          });
        } else {
          navigation.navigate('AssessmentParentQuestions', {
            itemData: item,
            fromPending: true,
            index: item.currentIndex ? item.currentIndex : 0,
            title: item.title,
          });
        }
      }}
      style={{
        backgroundColor: Colors.BgColor,
        height: 80,
        alignItems: 'center',
        width: '100%',
        justifyContent: 'center',
        marginVertical: Platform.OS === 'ios' ? hp(0.7) : hp(0.7),
      }}>
      <View
        style={{
          flexDirection: 'row',
          flex: 1,
          backgroundColor: Colors.white,
          borderRadius: hp(1.8),
          padding: hp(1),
          alignItems: 'center',
          justifyContent: 'space-between',
          width: Platform.OS === 'ios' ? '95%' : '90%',
          shadowOffset: {width: 0, height: 1},
          shadowOpacity: 0.1,
          shadowRadius: 8,
          elevation: Platform.OS === 'ios' ? 5 : 0,
        }}>
        <View
          style={{display: 'flex', flexDirection: 'row', alignItems: 'center'}}>
          <View>
            <SvgXml
              xml={svgs.assesmentIcon}
              height="40"
              width="40"
              style={{
                marginHorizontal: hp(1),
                borderColor: 'red',
                // borderWidth: 2,
              }}
            />
            {/* <AssessmentIcon /> */}
          </View>
          <View style={{marginLeft: hp(2)}}>
            <View
              style={{
                display: 'flex',
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <Text
                style={{
                  fontSize: 15,
                  fontFamily: Fonts.SourceSansRegular,
                  color: Colors.headingColor,
                  marginBottom: hp(0.1),
                  maxWidth: Platform.OS === 'android' ? hp(23) : hp(20),
                }}>
                {item.title}
              </Text>
            </View>

            {completed ? (
              <View style={{flexDirection: 'row'}}>
                <Text
                  style={{
                    fontSize: 13,
                    fontFamily: Fonts.SourceSansRegular,
                    color: Colors.noRecordFound,
                  }}>
                  {item.modifiedDate === null ||
                  moment(new Date(item.modifiedDate)).format('LL') ===
                    '01 January 2020'
                    ? 'N/A'
                    : moment(new Date(item.modifiedDate)).format('MMMM') +
                      ' ' +
                      moment(new Date(item.modifiedDate)).format('MM/DD/yyyy')}
                </Text>
              </View>
            ) : (
              <Text
                style={{
                  fontSize: 14,
                  fontFamily: Fonts.SourceSansRegular,
                  color: Colors.label,
                }}>
                {item.modifiedDate === null ||
                moment(new Date(item.modifiedDate)).format('LL') ===
                  '01 January 2020'
                  ? 'N/A'
                  : moment(new Date(item.modifiedDate)).format('MMMM') +
                    ' ' +
                    moment(new Date(item.modifiedDate)).format('MM/DD/yyyy')}
              </Text>
            )}
          </View>
        </View>
        <View
          style={{
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'center',
          }}>
          <AnimatedCircularProgress
            size={50}
            width={5}
            fill={fill}
            rotation={0}
            style={{marginRight: hp(1)}}
            tintColor={Colors.blueTextColor}
            backgroundColor={Colors.blueGrayDisableBG}>
            {fill => (
              <Text style={{color: Colors.noRecordFound, fontSize: hp(1.5)}}>
                {fill + '%'}
              </Text>
            )}
          </AnimatedCircularProgress>
          <SvgXml
            xml={svgs.arrowRight}
            height="25"
            width="15"
            style={{
              marginHorizontal: hp(1),
              borderColor: 'red',
              // borderWidth: 2,
            }}
          />
        </View>
      </View>
    </TouchableOpacity>
  );
};

export default AssessmentItem;
