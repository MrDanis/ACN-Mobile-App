import React, {Fragment} from 'react';
import {StyleSheet, Text, TouchableOpacity, View,Image} from 'react-native';

import {Colors, Images, Svgs} from '../../../../config/';
import {Fonts} from '../../../../config/AppConfig';

import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import {SvgCss} from 'react-native-svg';
const HeaderAssessment = ({navigation, children}) => {
  console.log('Assesment navigation is : ', navigation);

  return (
    <Fragment>
      <View
        style={{
          display: 'flex',
          flexDirection: 'row',
          backgroundColor: Colors.BgColor,
        }}>
        <View
          style={{
            display: 'flex',
            flexDirection: 'row',
            backgroundColor: Colors.BgColor,
            marginBottom: hp(1.5),
            marginTop: hp(1.5),
          }}>
          {/* header left  */}
          <View
            style={{
              width: wp('25%'),
              display: 'flex',
              flexDirection: 'row',
              justifyContent: 'space-between',
            }}>
            <TouchableOpacity
              onPress={() => {
                navigation.pop();
              }}
              style={{alignSelf: 'center'}}>
              <SvgCss
                xml={Svgs.arrowHeadLeft}
                width={hp(5)}
                height={hp(5)}
                fill={Colors.black}
                style={{marginLeft: hp(2)}}
              />
            </TouchableOpacity>
          </View>
          {/* header title */}
          <View
            style={{
              width: wp('50%'),
              display: 'flex',
              flexDirection: 'row',
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <Text
              style={{
                fontSize: hp(2.2),
                fontFamily: Fonts.SourceSansSemibold,
                color: Colors.black,
              }}>
              Assessments
            </Text>
          </View>
          <View
            style={{
              width: wp('25%'),
              display: 'flex',
              flexDirection: 'row',
              justifyContent: 'flex-end',
              alignItems: 'center',
            }}>
            <TouchableOpacity
              onPress={() => {
                console.log('helo');
                navigation.navigate('NotificationStack');
              }}
              style={{marginRight: hp(2)}}>
              <Image
                style={{
                  width: 20,
                  height: 25,
                }}
                source={Images.notification_dashboard}
              />
            </TouchableOpacity>
          </View>
        </View>
      </View>

      {children}
    </Fragment>
  );
};

export default HeaderAssessment;

const styles = StyleSheet.create({});
