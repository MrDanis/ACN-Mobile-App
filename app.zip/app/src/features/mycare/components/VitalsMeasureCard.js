import moment from 'moment';
import React, {useEffect, useState} from 'react';
import {StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import {showMessage} from 'react-native-flash-message';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {SvgCss} from 'react-native-svg';
import {useDispatch, useSelector} from 'react-redux';
import {Colors, Svgs} from '../../../../config';
import {Fonts, OSSource} from '../../../../config/AppConfig';
import VitalsService from '../../../api/vitals';
import CustomSliderTemperature from '../../discover/screens/components/customSliderTemperature';
import CustomSliderWeight from '../../discover/screens/components/customSliderWeight';
import {getVitalSubTypesData} from '../action/index';

const VitalsMeasureCard = ({
  vitalData,
  setLoader,
  navigation,
  openModal,
  sliderValueParent,
  showLine,
}) => {
  const [systolic, setSystolic] = useState(null);
  const [diastolic, setDiastolic] = useState(null);
  const [vitalSubTypeValue, setvitalSubTypeValue] = useState('');
  const [textFieldValue, setTextFieldValue] = useState(null);
  const [vitalSubTypes, setVitalSubTypes] = useState([]);
  const [outOfRange, setOutOfRange] = useState(false);
  const [outOfRangeError, setOutOfRangeError] = useState('');
  const userProfileData = useSelector(state => state.userProfileData);
  var outRange = false;
  const [date, setdate] = useState(new Date());

  const [customValue, setCustomValue] = useState(sliderValueParent);

  const tempValue = 85;
  function onValueChanged(value) {
    console.log('Outside');
    console.log('setting Temp');
    setCustomValue(value);
  }

  const dispatch = useDispatch();
  useEffect(() => {
    setLoader(true);
    // setLoaderSlider(true);
    VitalsService.getVitalSubTypeData(vitalData.loinc)
      .then(res => {
        console.log('Vitals SubType Data');
        console.log(res);
        if (res.statusCode === 200) {
          let sysVal = null;
          let diasVal = null;
          let val = null;
          setLoader(false);
          res.data.map(subType => {
            if (vitalData.id === 1) {
              if (subType.name.toLowerCase() === 'systolic') {
                setSystolic(subType.defaultValue);
                sysVal = subType.defaultValue;
              } else if (subType.name.toLowerCase() === 'diastolic') {
                setDiastolic(subType.defaultValue);
                diasVal = subType.defaultValue;
              }
            } else {
              val = subType.value === null ? subType.minRange : subType.value;
              console.debug('This is the subtype Value');
              console.debug(subType.value);
              setTextFieldValue(subType.defaultValue);

              onValueChanged(subType.value);
            }
          });
          if (vitalData.id === 1) {
            setvitalSubTypeValue(`${sysVal}/${diasVal}`);
          } else setvitalSubTypeValue(val);
          setVitalSubTypes(res.data);
          setCustomValue(res.data[0].defaultValue);
          dispatch(getVitalSubTypesData(res.data));
        }
      })
      .catch(err => {
        setLoader(false);
        console.log('Vitals Error');
        showMessage({
          message: 'Information',
          description: err.message,
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  }, []);

  function getTypeValueWithID() {
    const listObj = [];
    if (vitalData.id === 1) {
      if (
        systolic === 0 ||
        systolic === '0' ||
        systolic === '' ||
        diastolic === 0 ||
        diastolic === '0' ||
        diastolic === ''
      ) {
        showMessage({
          message: 'Information',
          description: 'Please enter value between range',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      } else {
        vitalSubTypes.map(obj => {
          if (obj.id === 1 || obj.id === 2) {
            if (obj.name === 'Systolic') {
              if (systolic < obj.minRange || systolic > obj.maxRange) {
                showMessage({
                  message: 'Information',
                  description: 'Please enter value between range',
                  type: 'default',
                  icon: {icon: 'info', position: 'left'},
                  backgroundColor: Colors.red,
                });
              } else {
                const data = {
                  vitalSubTypeId: obj.id,
                  value: String(systolic),
                };
                listObj.push(data);
              }
            } else if (obj.name === 'Diastolic') {
              if (diastolic < obj.minRange || diastolic > obj.maxRange) {
                showMessage({
                  message: 'Information',
                  description: 'Please enter value between range',
                  type: 'default',
                  icon: {icon: 'info', position: 'left'},
                  backgroundColor: Colors.red,
                });
              } else {
                const data = {
                  vitalSubTypeId: obj.id,
                  value: String(diastolic),
                };
                listObj.push(data);
              }
            }
          }
        });
      }
    } else {
      if (
        textFieldValue === 0 ||
        textFieldValue === '0' ||
        textFieldValue === ''
      ) {
        showMessage({
          message: 'Information',
          description: 'Please enter value between range',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      } else {
        vitalSubTypes.map(obj => {
          if (textFieldValue < obj.minRange || textFieldValue > obj.maxRange) {
            showMessage({
              message: 'Information',
              description: 'Please enter value between range',
              type: 'default',
              icon: {icon: 'info', position: 'left'},
              backgroundColor: Colors.red,
            });
          } else {
            const data = {
              vitalSubTypeId: obj.id,
              value: String(textFieldValue),
            };
            listObj.push(data);
          }
        });
      }
    }

    return vitalData.id === 1 ? (listObj.length > 1 ? listObj : []) : listObj;
  }

  const addVitalHandler = () => {
    measureVitalCall();
  };

  function measureVitalCall() {
    const categoryMeasurement = getTypeValueWithID();
    if (categoryMeasurement.length) {
      setLoader(true);
      const data = {
        vitalTypeId: vitalData.id,
        source: OSSource,
        categoryData: categoryMeasurement,
        createdSource: userProfileData.role === 'Patient' ? 1 : 2,
        dateCreated: moment(new Date()).utc().format('YYYY-MM-DDTHH:mm:ss.SSS'),
        loinc: vitalData.loinc,
      };
      VitalsService.addVital(data)
        .then(response => {
          setLoader(false);
          if (response && response.statusCode === 200) {
            if (outOfRange) {
              openModal();
            } else {
              navigation.pop();
            }
          } else {
            showMessage({
              message: 'Information',
              description:
                'Authentication Failed. Provided information is not verified.',
              type: 'default',
              icon: {icon: 'info', position: 'left'},
              backgroundColor: Colors.red,
            });
          }
        })
        .catch(err => {
          setLoader(false);
          console.log('error');
          console.log(err);
          showMessage({
            message: 'Info',
            description: err.message,
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        });
    }
  }
  const TemperatureMeasureCard = (
    <View
      style={{
        backgroundColor: Colors.white,
        alignItems: 'center',
        marginTop: hp(5),
        marginBottom: hp(3),
        borderRadius: 8,
        width: '100%',
        paddingVertical: hp(5.5),
        alignSelf: 'center',
        shadowOffset: {width: 0.5, height: 0.5},
        shadowOpacity: 0.05,
        shadowRadius: 8,
        elevation: 10,
      }}>
      <View
        style={{
          transform: [{rotate: '90deg'}],

          alignItems: 'center',
          borderRadius: 8,
          width: '100%',
          paddingVertical: hp(14),
          alignSelf: 'center',
          marginTop: hp(-10.5),
          marginLeft: hp(8),
        }}>
        <View
          style={{
            width: '100%',
            alignSelf: 'center',
          }}>
          <Text
            style={{
              fontFamily: Fonts.SourceSansRegular,
              fontSize: hp(2.5),
              color: Colors.black4,
            }}>
            H
          </Text>
        </View>

        <View
          style={{
            backgroundColor: Colors.white,
            borderRadius: hp(2),
            paddingTop: hp(2),
            paddingBottom: hp(2),
            width: '100%',
          }}>
          <CustomSliderTemperature
            sliderValue={customValue}
            setSliderValue={onValueChanged}
            vitalsSubTypesData={vitalSubTypes}
          />
          {this.showLine ? (
            <View>
              <View
                style={{
                  marginTop: hp(2.5),
                  borderWidth: 0.5,
                  borderColor: Colors.line,
                  width: '100%',
                  shadowOffset: {width: 0.1, height: 3},
                  shadowOpacity: 0.2,
                  shadowRadius: 5,
                  elevation: 20,
                }}
              />
              <View
                style={{
                  flexDirection: 'column',
                  alignItems: 'center',
                }}>
                <TouchableOpacity
                  onPress={() =>
                    navigation.navigate('VitalHistory', {vitalData: vitalData})
                  }>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontSize: hp(2.8),
                      marginTop: hp(2),
                      color: Colors.black,
                      fontWeight: 'bold',
                    }}>
                    {customValue === 50 ? 50 : customValue}
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() =>
                    navigation.navigate('VitalHistory', {vitalData: vitalData})
                  }
                  style={{alignItems: 'center'}}>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontSize: hp(2.2),
                      color: Colors.blueTextColor,
                    }}>
                    Kilogram
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          ) : (
            <View>
              <View
                style={{
                  marginTop: hp(2.5),
                  borderWidth: 0.5,
                  borderColor: Colors.transparent,
                  width: '100%',
                  shadowOffset: {width: 0.1, height: 3},
                  shadowOpacity: 0.2,
                  shadowRadius: 5,
                  elevation: 20,
                }}
              />
              <View
                style={{
                  flexDirection: 'column',
                  alignItems: 'center',
                }}>
                <TouchableOpacity>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontSize: hp(2.8),
                      marginTop: hp(2),
                      color: Colors.black,
                      fontWeight: 'bold',
                    }}></Text>
                </TouchableOpacity>
                <TouchableOpacity style={{alignItems: 'center'}}>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontSize: hp(2.2),
                      color: Colors.blueTextColor,
                    }}></Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        </View>
      </View>
      <View>
        <View
          style={{
            zIndex: 1,
            width: '100%',
            alignSelf: 'center',
            marginVertical: hp(1),
            position: 'absolute',
            flexDirection: 'row',
            alignContent: 'center',
            alignSelf: 'center',
            alignItems: 'flex-start',
            marginTop: hp(-48.5),
          }}>
          <Text
            style={{
              fontFamily: Fonts.SourceSansRegular,
              fontSize: hp(1.7),
              marginLeft: hp(2),
              alignContent: 'center',
              alignSelf: 'center',
              color: Colors.darkgrey,
              fontWeight: '400',
              marginRight: hp(0.5),
            }}>
            Range
          </Text>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2),
                alignContent: 'center',
                alignSelf: 'center',
                fontWeight: '600',
                marginRight: hp(0.5),
                color: Colors.black4,
              }}>
              {92}
            </Text>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(1.8),
                marginLeft: hp(0),
                color: Colors.darkgrey,
                fontWeight: '400',
                alignContent: 'center',
                alignSelf: 'center',
              }}>
              °F
            </Text>
          </View>
        </View>
        <View>
          <SvgCss
            xml={Svgs.temperature_svg}
            width={hp(14.2)}
            height={hp(40)}
            fill={Colors.white}
            style={{
              marginTop: hp(-45),
              marginLeft: hp(-20),
              marginBottom: hp(-20),
            }}
          />
        </View>
        <View>
          <Text
            style={{
              fontFamily: Fonts.SourceSansRegular,
              fontSize: hp(1.7),
              position: 'absolute',
              marginLeft: hp(3.9),
              color: Colors.darkGrey,
              fontWeight: '600',

              marginTop: hp(-11),
            }}>
            °F
          </Text>
        </View>
      </View>
    </View>
  );

  return vitalData.id === 4 ? (
    TemperatureMeasureCard
  ) : (
    <View
      style={{
        backgroundColor: Colors.white,
        alignItems: 'center',
        marginTop: hp(2),
        marginBottom: hp(3),
        borderRadius: 8,
        width: '100%',
        alignSelf: 'center',
        shadowOffset: {width: 0.5, height: 0.5},
        shadowOpacity: 0.05,
        shadowRadius: 8,
        elevation: 10,
      }}>
      <View
        style={{
          width: '90%',
          alignSelf: 'center',
          marginVertical: hp(1),
          alignItems: 'flex-end',
        }}>
        <Text
          style={{
            fontFamily: Fonts.SourceSansRegular,
            fontSize: hp(2.5),
            marginLeft: hp(2),
            color: Colors.black4,
          }}>
          H
        </Text>
      </View>

      <View
        style={{
          backgroundColor: Colors.white,
          borderRadius: hp(2),
          paddingTop: hp(2),
          paddingBottom: hp(2),
          width: '100%',
        }}>
        <CustomSliderWeight
          sliderValue={customValue}
          setSliderValue={onValueChanged}
          vitalsSubTypesData={vitalSubTypes}
        />

        <View
          style={{
            marginTop: hp(2.5),
            borderWidth: 0.5,
            borderColor: Colors.line,
            width: '100%',
            shadowOffset: {width: 0.1, height: 3},
            shadowOpacity: 0.2,
            shadowRadius: 5,
            elevation: 20,
          }}
        />
        <View
          style={{
            flexDirection: 'column',
            alignItems: 'center',
          }}>
          <TouchableOpacity
            onPress={() =>
              navigation.navigate('VitalHistory', {vitalData: vitalData})
            }>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2.8),
                marginTop: hp(2),
                color: Colors.black,
                fontWeight: 'bold',
              }}>
              {customValue === 50 ? 50 : customValue}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() =>
              navigation.navigate('VitalHistory', {vitalData: vitalData})
            }
            style={{alignItems: 'center'}}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2.2),
                color: Colors.blueTextColor,
              }}>
              Kilogram
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};
const sliderStyle = StyleSheet.create({
  thumb: {
    width: 20,
    height: 10,
    transform: [{rotate: '360deg'}],

    shadowColor: 'black',
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.5,
    shadowRadius: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 35 / 2,
    elevation: 5,
    color: Colors.transparent,
  },
  track: {
    height: hp(0),
    borderRadius: 20,
  },
});

export default VitalsMeasureCard;
