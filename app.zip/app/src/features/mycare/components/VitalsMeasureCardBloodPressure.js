import moment from 'moment';
import React, {useEffect, useState} from 'react';
import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import {showMessage} from 'react-native-flash-message';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {useDispatch, useSelector} from 'react-redux';
import {Colors, Images} from '../../../../config';
import {Fonts, OSSource} from '../../../../config/AppConfig';
import VitalsService from '../../../api/vitals';
import LineGaugeVertical from '../../discover/screens/components/src_ruler_gauge/LineGuageVertical';
import {getVitalSubTypesData} from '../action/index';

const VitalsMeasureCardBloodPressure = ({
  vitalData,
  setLoader,
  navigation,
  openModal,
  sliderValueParent,
}) => {
  const [systolic, setSystolic] = useState(null);
  const [diastolic, setDiastolic] = useState(null);
  const [vitalSubTypeValue, setvitalSubTypeValue] = useState('');
  const [textFieldValue, setTextFieldValue] = useState(null);
  const [vitalSubTypes, setVitalSubTypes] = useState([]);
  const [outOfRange, setOutOfRange] = useState(false);
  const [isEditable, setIsEditable] = useState(false);
  const userProfileData = useSelector(state => state.userProfileData);
  var outRange = false;

  const [customValue, setCustomValue] = useState(0);

  const tempValue = 85;
  function onValueChanged(value) {
    console.log('Outside');
    setCustomValue(value);
  }

  const dispatch = useDispatch();
  useEffect(() => {
    setLoader(true);
    // setLoaderSlider(true);
    VitalsService.getVitalSubTypeData(vitalData.loinc)
      .then(res => {
        console.log('Vitals SubType Data');
        console.log(res);
        if (res.statusCode === 200) {
          let sysVal = null;
          let diasVal = null;
          let val = null;
          setLoader(false);
          res.data.map(subType => {
            if (vitalData.id === 1) {
              if (subType.name.toLowerCase() === 'systolic') {
                setSystolic(subType.defaultValue);
                sysVal = subType.defaultValue;
              } else if (subType.name.toLowerCase() === 'diastolic') {
                setDiastolic(subType.defaultValue);
                diasVal = subType.defaultValue;
              }
            } else {
              val = subType.value === null ? subType.minRange : subType.value;
              console.debug('This is the subtype Value');
              console.debug(subType.value);
              setTextFieldValue(subType.defaultValue);

              onValueChanged(subType.value);
            }
          });
          if (vitalData.id === 1) {
            setvitalSubTypeValue(`${sysVal}/${diasVal}`);
          } else setvitalSubTypeValue(val);
          setVitalSubTypes(res.data);
          setCustomValue(res.data[0].defaultValue);
          dispatch(getVitalSubTypesData(res.data));
        }
      })
      .catch(err => {
        setLoader(false);
        console.log('Vitals Error');
        showMessage({
          message: 'Information',
          description: err.message,
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  }, []);

  function getTypeValueWithID() {
    const listObj = [];
    if (vitalData.id === 1) {
      if (
        systolic === 0 ||
        systolic === '0' ||
        systolic === '' ||
        diastolic === 0 ||
        diastolic === '0' ||
        diastolic === ''
      ) {
        showMessage({
          message: 'Information',
          description: 'Please enter value between range',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      } else {
        vitalSubTypes.map(obj => {
          if (obj.id === 1 || obj.id === 2) {
            console.log('if Executed', obj);
            if (obj.name === 'Systolic') {
              if (systolic < obj.minRange || systolic > obj.maxRange) {
                showMessage({
                  message: 'Information',
                  description: 'Please enter value between range',
                  type: 'default',
                  icon: {icon: 'info', position: 'left'},
                  backgroundColor: Colors.red,
                });
              } else {
                console.log('systolic else executed', obj);
                const data = {
                  vitalSubTypeId: obj.id,
                  value: String(systolic),
                };
                listObj.push(data);
              }
            } else if (obj.name === 'Diastolic') {
              if (diastolic < obj.minRange || diastolic > obj.maxRange) {
                showMessage({
                  message: 'Information',
                  description: 'Please enter value between range',
                  type: 'default',
                  icon: {icon: 'info', position: 'left'},
                  backgroundColor: Colors.red,
                });
              } else {
                console.log('systolic else executed', obj);
                const data = {
                  vitalSubTypeId: obj.id,
                  value: String(diastolic),
                };
                listObj.push(data);
              }
            }
            // else {
            //         console.log('else executed', obj)
            //         const data = {
            //             vitalSubTypeId: obj.id,
            //             value: obj.id === 1 ? String(systolic) : String(diastolic),
            //         };
            //         listObj.push(data);
            //     }
          }
        });
      }
    } else {
      if (
        textFieldValue === 0 ||
        textFieldValue === '0' ||
        textFieldValue === ''
      ) {
        showMessage({
          message: 'Information',
          description: 'Please enter value between range',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      } else {
        vitalSubTypes.map(obj => {
          if (textFieldValue < obj.minRange || textFieldValue > obj.maxRange) {
            showMessage({
              message: 'Information',
              description: 'Please enter value between range',
              type: 'default',
              icon: {icon: 'info', position: 'left'},
              backgroundColor: Colors.red,
            });
          } else {
            const data = {
              vitalSubTypeId: obj.id,
              value: String(textFieldValue),
            };
            listObj.push(data);
          }
        });
      }
    }

    return vitalData.id === 1 ? (listObj.length > 1 ? listObj : []) : listObj;
  }

  const addVitalHandler = () => {
    measureVitalCall();
  };

  function measureVitalCall() {
    const listObj = [];
    const catData = {
      vitalSubTypeId: vitalSubTypes[0].id,
      value: String(customValue),
    };
    listObj.push(catData);
    setLoader(true);
    const data = {
      vitalTypeId: vitalData.id,
      source: OSSource,
      categoryData: listObj,
      createdSource: userProfileData.role === 'Patient' ? 1 : 2,
      dateCreated: moment(new Date()).utc().format('YYYY-MM-DDTHH:mm:ss.SSS'),
      loinc: vitalData.loinc,
    };
    console.log('addVitalDetails Data', data);
    VitalsService.addVital(data)
      .then(response => {
        setLoader(false);
        if (response && response.statusCode === 200) {
          setIsEditable(false);
          if (outOfRange) {
            openModal();
          } else {
            navigation.pop();
          }
        } else {
          showMessage({
            message: 'Information',
            description:
              'Authentication Failed. Provided information is not verified.',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        }
      })
      .catch(err => {
        setLoader(false);
        console.log('error');
        console.log(err);
        showMessage({
          message: 'Info',
          description: err.message,
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  }
  return (
    <View
      style={{
        backgroundColor: Colors.white,
        alignItems: 'center',
        marginTop: hp(2),
        marginBottom: hp(3),
        borderRadius: 8,
        width: '100%',
        alignSelf: 'center',
        shadowOffset: {width: 0.5, height: 0.5},
        shadowOpacity: 0.05,
        shadowRadius: 8,
        elevation: 10,
      }}>
      {!isEditable ? (
        <TouchableOpacity
          onPress={() => setIsEditable(true)}
          style={{
            width: '100%',
            alignSelf: 'center',
            marginVertical: hp(1),
            marginRight: hp(2.5),
            alignItems: 'flex-end',
          }}>
          <Image
            source={Images.edit_assessment}
            style={{width: hp(2.5), height: hp(2.5)}}
          />
        </TouchableOpacity>
      ) : (
        <TouchableOpacity
          onPress={() => {
            addVitalHandler();
          }}
          style={{
            width: '100%',
            alignSelf: 'center',
            marginVertical: hp(1),
            marginRight: hp(2.5),
            alignItems: 'flex-end',
          }}>
          <Text
            style={{
              fontSize: hp(2),
              fontFamily: Fonts.SourceSansRegular,
              color: Colors.blueTextColor,
            }}>
            Save
          </Text>
        </TouchableOpacity>
      )}

      <View
        style={{
          backgroundColor: Colors.white,
          borderRadius: hp(2),
          paddingTop: hp(2),
          paddingBottom: hp(2),
          width: '100%',
        }}>
        <LineGaugeVertical min={0} max={250} isEditable={isEditable} />

        <View
          style={{
            marginTop: hp(2.5),
            borderWidth: 0.5,
            borderColor: Colors.line,
            width: '100%',
            shadowOffset: {width: 0.1, height: 3},
            shadowOpacity: 0.2,
            shadowRadius: 5,
            elevation: 20,
          }}
        />
        <View
          style={{
            flexDirection: 'column',
            alignItems: 'center',
          }}>
          <TouchableOpacity>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2.8),
                marginTop: hp(2),
                color: Colors.black,
                fontWeight: 'bold',
              }}>
              {customValue === 50 ? 50 : customValue}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity style={{alignItems: 'center'}}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2.2),
                color: Colors.blueTextColor,
              }}>
              Kilogram
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};
const sliderStyle = StyleSheet.create({
  thumb: {
    width: 20,
    height: 10,
    transform: [{rotate: '360deg'}],

    shadowColor: 'black',
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.5,
    shadowRadius: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 35 / 2,
    elevation: 5,
    color: Colors.transparent,
  },
  track: {
    height: hp(0),
    borderRadius: 20,
  },
});

export default VitalsMeasureCardBloodPressure;
