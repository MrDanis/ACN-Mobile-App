//import liraries
import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity,Image} from 'react-native';

import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {SvgCss} from 'react-native-svg';
import {Colors, Images, Svgs} from '../../../../config';
import {Fonts} from '../../../../config/AppConfig';

// create a component
const MainHeader = ({navigation, children, name, notifDisabled}) => {
  console.log('inside main header');
  return (
    <View style={styles.container}>
      <View
        style={{
          alignItems: 'center',
          justifyContent: 'center',
          flexDirection: 'row',
          marginTop: name.includes('Screenings') ? hp(3) : hp(1),
          borderColor: 'purple',
        }}>
        <View style={{flex: 0.25, paddingLeft: hp(1)}}>
          <SvgCss
            xml={Svgs.arrowHeadLeft}
            width={hp(4)}
            height={hp(4)}
            fill={Colors.black}
            onPress={() => {
              navigation.pop();
            }}
          />
        </View>
        <View style={{flex: 0.6, alignItems: 'center'}}>
          <Text
            style={{
              color: Colors.black,
              fontSize: hp(2.5),
              fontFamily: Fonts.SourceSansSemibold,
            }}>
            {name}
          </Text>
        </View>
        <View style={{flex: 0.25, alignItems: 'flex-end'}}>
          <TouchableOpacity
            onPress={() => navigation.navigate('NotificationStack')}>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'flex-start',
                marginRight: hp(2),
              }}>
              {notifDisabled && notifDisabled === true ? (
                <View></View>
              ) : (
                <Image
                  style={{
                    width: hp(2),
                    height: hp(2.5),
                  }}
                  source={Images.notification_dashboard}
                />
              )}
            </View>
          </TouchableOpacity>
        </View>
      </View>
      {children}
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    // justifyContent: 'center',
    flex: 1,
    backgroundColor: Colors.BgColor,
    borderColor: 'red',
  },
});

//make this component available to the app
export default MainHeader;
