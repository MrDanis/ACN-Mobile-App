import {View, Text, TouchableOpacity, Image, Platform} from 'react-native';
import React, {useRef, useEffect, useState} from 'react';
import {Colors, Images} from '../../../../config';
import {CURRENT_TARGET, Fonts} from '../../../../config/AppConfig';
import {
  heightPercentageToDP as hp,
  heightPercentageToDP,
} from 'react-native-responsive-screen';

import {SvgCssUri, SvgUri, SvgWithCssUri} from 'react-native-svg';
import colors from '../../../../config/Colors';
import moment from 'moment';

// This is the card Component of the Vital Screen.
const AllVitals = ({
  vitalData,
  navigation,
  openModal,
  bpReadingsHealthKit,
  heartRateHealthkit,
  bodyWeightHealthKit,
  bpReadingsGoogleFit,
  heartRateGoogleFit,
  bodyWeightGoogleFit,
}) => {
  const [loaded, setLoaded] = useState(false);

  console.log('This is the critical data bro',(vitalData));
  return (
    <>
      <TouchableOpacity
        onPress={() => {
          console.debug('This is the vitalsData');
          console.debug(vitalData.isCritical);
          console.log('====================================');
          console.log(vitalData,'Critical value of the vital is : ',vitalData.isCritical)
          console.log(vitalData, 'vitalData', vitalData.loinc);
          console.log('====================================');
          if (vitalData.loinc === '29463-7') {
            console.log('came in weight ');
            navigation.navigate('VitalWeight', {
              vitalsData: vitalData,
              bodyWeightFromHealthKit: bodyWeightHealthKit,
              bodyWeightFromGoogleFit: bodyWeightGoogleFit,
            });
          }
          if (vitalData.loinc === '8480-6') {
            console.log('Here in the blood prssure');
            navigation.navigate('VitalBloodPressure', {
              vitalsData: vitalData,
              bloodFromHealth: bpReadingsHealthKit,
              bloodFromGoogleFit: bpReadingsGoogleFit,
            });
          }
          if (vitalData.loinc === '8310-5') {
            navigation.navigate('VitalTemperature', {vitalsData: vitalData});
          }
          if (vitalData.loinc === '8302-2') {
            navigation.navigate('VitalHeight', {vitalsData: vitalData});
          }
          if (vitalData.loinc === '8867-4') {
            navigation.navigate('VitalPulseRate', {
              vitalsData: vitalData,
              heartRateFromHealth: heartRateHealthkit,
              heartRateFromGoogleFit: heartRateGoogleFit,
            });
          }
        }}>
        <View
          style={{
            padding: hp(2),
            backgroundColor: Colors.white,
            marginTop: hp(3),
            borderRadius: hp(1),
            marginHorizontal: Platform.OS === 'ios' ? 0 : hp(0.5),
            borderColor: Colors.line,
            borderWidth: 0.33,
            elevation: Platform.OS === 'ios' ? 20 : 2,
          }}>
            {/* {
              (vitalData.isCritical)&&(
            <View style={{alignSelf:'flex-end',backgroundColor:colors.red2,borderColor:'red',borderWidth:3,marginBottom:hp(1),width:'20%',borderRadius:50 }}>
                      <Text style={{textAlign:'center',paddingVertical:hp(1),width:'100%',color:colors.white,fontSize:hp(1.5),fontWeight:'600'}}>
                          Critical
                      </Text>
                 
            </View>
              )
            } */}
          <View
            style={{
              marginBottom: hp(1),
              flexDirection: 'row',
              alignItems: 'center',
            }}>
            <View
              style={{
                width: '50%',
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <Image
                source={{uri: vitalData.icon}}
                style={{width: hp(4), height: hp(4)}}
              />
              <Text
                style={{
                  paddingHorizontal: hp(1),
                  fontFamily: Fonts.SourceSansRegular,
                  color: Colors.black,
                  fontSize: hp(2),
                }}>
                {vitalData.name === null ? '' : vitalData.name}
              </Text>
            </View>
            <View
              style={{
                justifyContent: 'flex-end',
                width: '50%',
                alignItems: 'center',
                flexDirection: 'row',
              }}>
              <Text
                style={{
                  paddingLeft: hp(2.5),
                  paddingRight: hp(0.5),

                  fontFamily: Fonts.SourceSansRegular,
                  color: Colors.blueGrayDisableText,
                  fontSize: hp(1.9),
                }}>
                {vitalData.measuredDate === null ||
                vitalData.measuredDate === '0001-01-01T00:00:00'
                  ? ''
                  : moment(vitalData.measuredDate).format('ddd, MMM DD, YYYY')}
              </Text>
              <Image
                style={{
                  width: hp(1.0),
                  height: hp(1.0),
                  alignSelf: 'center',
                }}
                source={Images.rightArrow}
              />
            </View>
          </View>
          {vitalData.value !== null ? (
            <View
              style={{
                alignContent: 'space-between',
                alignItems: 'flex-end',
                flexDirection: 'row',
              }}>
              <View
                style={{
                  flex: 1,
                  flexDirection: 'row',
                  alignContent: 'center',
                  alignItems: 'center',
                }}>
                <Text
                  style={{
                    paddingRight: hp(0.5),
                    marginTop: hp(0),
                    fontFamily: Fonts.SourceSansBold,
                    fontSize: hp(3),
                    color: Colors.black,
                  }}>
                  {vitalData.value === null ? '' : vitalData.value}
                </Text>
                {vitalData.isCritical &&
                  // vitalData.id !== 10 &&
                  // vitalData.id !== 9 && 
                  (
                    <View>
                      <Image
                        style={{
                          width: 15,
                          height: 15,
                          marginLeft: hp(0.5),
                        }}
                        resizeMode="contain"
                        source={require('../../../../../assets/images/icon_alert_fill.png')}
                      />
                    </View>
                  )}
              </View>
              {vitalData.isCritical &&
                // vitalData.id !== 10 &&
                // vitalData.id !== 9 &&
                 (
                  <View>
                    <View
                      style={{
                        paddingLeft: 9,
                        paddingRight: 8,
                        paddingVertical: 2,
                        backgroundColor: colors.red3,
                        borderRadius: 20,
                        elevation: 10,
                      }}>
                      <Text style={{color: Colors.white, fontSize: hp(1.5)}}>
                        {'Critical'}
                      </Text>
                    </View>
                  </View>
                )}
            </View>
          ) : (
            <View>
              <Text
                style={{
                  fontFamily: Fonts.SourceSansSemibold,
                  fontSize: hp(2),
                  color: Colors.black,
                }}>
                Keeping a record will help you and your doctor.
              </Text>
            </View>
          )}

          <View>
            <Text
              style={{
                fontFamily: Fonts.SourceSansSemibold,
                fontSize: hp(1.7),
                color: Colors.blueGrayDisableText,
              }}>
              {vitalData.unit === null || vitalData.value === null
                ? `Learn more about your ${vitalData.name} `
                : vitalData.unit}
            </Text>
          </View>
        </View>
      </TouchableOpacity>
    </>
  );
};

export default AllVitals;
