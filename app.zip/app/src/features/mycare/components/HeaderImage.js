import moment from 'moment';
import React from 'react';
import {Text, View,Image} from 'react-native';

import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {Fonts, baseUrl} from '../../../../config/AppConfig';
import colors from '../../../../config/Colors';

const HeaderImage = ({userProfileData}) => {
  function getAge(dateString: string) {
    const date = moment(new Date(userProfileData.dateOfBirth)).format(
      'YYYY-MM-DD',
    );
    const years = moment().diff(date, 'years');

    return years < 1 ? '' : ', ' + years + 'yrs';
  }
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        marginLeft: hp(1),
        marginVertical: 15,
      }}>
      {userProfileData.imagePath !== null &&
      userProfileData.imagePath !== '' ? (
        <Image
          style={{
            width: 60,
            height: 60,
            borderRadius: 30,
            marginVertical: hp(1),
          }}
          source={{
            uri: baseUrl + '/' + userProfileData.imagePath + '?' + new Date(),
            //priority: Image.priority.high,
          }}
        />
      ) : (
        <Image
          style={{
            width: 60,
            height: 60,
            borderRadius: 30,
            marginVertical: hp(1),
          }}
          resizeMode="contain"
          source={require('../../../../../assets/images/user_logo.png')}
        />
      )}
      <View style={{marginLeft: hp(2)}}>
        <Text
          style={{
            fontFamily: Fonts.SourceSansBold,
            fontSize: hp(3),
            color: colors.black4,
            textTransform: 'capitalize',
          }}>
          {userProfileData.firstName.toLowerCase() +
            ' ' +
            userProfileData.lastName.toLowerCase()}
        </Text>
        <View style={{flexDirection: 'row'}}>
          {userProfileData.gender !== null && userProfileData.gender !== '' && (
            <>
              <Text
                style={{
                  fontFamily: Fonts.SourceSansRegular,
                  fontSize: hp(2),
                  color: colors.noRecordFound,
                }}>
                {userProfileData.gender === '2' ? 'Female' : 'Male'}
              </Text>
            </>
          )}
          <Text
            style={{
              fontFamily: Fonts.SourceSansRegular,
              fontSize: hp(2),
              color: colors.noRecordFound,
            }}>
            {getAge(userProfileData.dateOfBirth)}
          </Text>
        </View>
      </View>
    </View>
  );
};

export default HeaderImage;
