/* istanbul ignore file */
export const getAllergiesData = data => ({
  type: 'GET_ALLERGIES_DATA',
  data,
});
