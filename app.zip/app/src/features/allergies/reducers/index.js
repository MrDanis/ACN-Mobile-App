/* istanbul ignore file */
export const allergiesData = (state = false, action) => {
  switch (action.type) {
    case 'GET_ALLERGIES_DATA':
      return action.data;
    default:
      return state;
  }
};
