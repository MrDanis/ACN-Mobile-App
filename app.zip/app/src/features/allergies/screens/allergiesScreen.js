//import liraries
import {useFocusEffect} from '@react-navigation/native';
import moment from 'moment';
import React, {useMemo, useRef, useState} from 'react';
import {
  FlatList,
  Image,
  RefreshControl,
  SafeAreaView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import Spinner from 'react-native-loading-spinner-overlay';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {useDispatch} from 'react-redux';

import {Colors, Images} from '../../../../config';
import {Fonts} from '../../../../config/AppConfig';
import AllergiesService from '../../../api/allergies';
import MainHeader from '../../mycare/components/MainHeader';
import {allergiesData} from '../reducers';

const Allergies = ({navigation, route}) => {
  const [allergies, setAllergies] = useState([]);
  const [testName, setTestName] = useState('');
  const [labName, setLabName] = useState('');
  const [description, setDescription] = useState('');
  const [imageObject, setImageObject] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [loader, setLoader] = useState(false);
  const [downloader, setDownloader] = useState(false);

  const dispatch = useDispatch();
  const swipeableRef = useRef(null);
  const bottomSheetRef = useRef(null);
  const modalizeRef = useRef(null);
  const modalizeRefEmail = useRef(null);
  const modalizeShare = useRef(null);
  const cameraRef = useRef(null);
  const [refreshing, setRefreshing] = useState(false);
  const snapPoints = useMemo(() => ['25%', '50%'], []);
  const [instance, setInstance] = useState();
  useFocusEffect(
    React.useCallback(() => {
      setLoader(true);
      AllergiesGetData();
    }, []),
  );

  const onRefresh = () => {
    console.log('====================================');
    console.log('here in refresh');
    console.log('====================================');
    setRefreshing(true);
    AllergiesGetData();
  };

  const AllergiesGetData = () => {
    AllergiesService.getAllergiesData().then(response => {
      console.log('====================================');
      console.log('res', response);
      console.log('====================================');
      if (response && response.statusCode === 200) {
        setLoader(false);
        setRefreshing(false);
        setAllergies(response.data);
        dispatch(allergiesData(response.data));
      } else {
        setRefreshing(false);
        setLoader(false);
        setAllergies([]);
      }
    });
  };

  const dateFormat = item => {
    return (
      <Text
        style={{
          color: Colors.noRecordFound,
          fontFamily: Fonts.SourceSansRegular,
          fontSize: hp(1.5),
        }}>
        {moment(item.allergyDate).format('ddd, MMM DD, YYYY')}
      </Text>
    );
  };

  return (
    <>
      <SafeAreaView
        style={{
          backgroundColor: Colors.BgColor,
          flex: 1,
          borderColor: 'blue',
          borderWidth: 0,
        }}>
        <Spinner
          visible={loader}
          textContent={'Loading...'}
          textStyle={{color: '#FFF'}}
        />
        <Spinner
          visible={downloader}
          textContent={'Downloading...'}
          textStyle={{color: '#FFF'}}
        />

        <View style={{flex: 1, borderColor: 'red', borderWidth: 0}}>
          <MainHeader name={'Allergies'} navigation={navigation}>
            {allergies?.length <= 0 || allergies === null ? (
              <View
                style={{
                  borderColor: 'red',
                  borderWidth: 0,
                  flex: 1,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                <Image
                  source={Images.emptyIcon}
                  style={{
                    alignSelf: 'center',
                    height: hp(16),
                    width: hp(18),
                  }}
                />
                <Text
                  style={{
                    fontSize: hp(2),
                    fontFamily: Fonts.SourceSansBold,
                    color: Colors.noRecordFound,
                    marginTop: hp(4),
                    marginRight: hp(10),
                    marginLeft: hp(10),
                    textAlign: 'center',
                  }}>
                  No Record Found
                </Text>
              </View>
            ) : (
              <View style={{flex: 1, alignItems: 'center', paddingTop: hp(2)}}>
                <FlatList
                  data={allergies}
                  style={{flex: 1, width: '100%'}}
                  contentContainerStyle={{
                    width: '100%',
                    alignItems: 'center',
                  }}
                  renderItem={({item, index}) => (
                    <>
                      <View
                        style={{
                          borderRadius: 10,
                          minWidth: '94%',
                          marginLeft: hp(1),
                          marginRight: hp(1),
                          marginBottom: hp(2),
                          shadowOffset: {width: 0.5, height: 0.5},
                          shadowOpacity: 0.1,
                          shadowRadius: 8,
                          elevation: 3,
                          backgroundColor: Colors.white,
                          flexDirection: 'row',
                          alignItems: 'center',
                          padding: hp(2),
                        }}>
                        <View
                          style={{
                            flexDirection: 'row',
                            flex: 1,
                            alignItems: 'center',
                          }}>
                          <Image
                            resizeMode="contain"
                            style={{
                              width: hp(5.5),
                              height: hp(5.5),
                            }}
                            source={Images.allergyblock_Icon}
                          />
                          <View
                            style={{
                              justifyContent: 'center',
                              width: '80%',
                            }}>
                            <View
                              style={{
                                marginLeft: hp(2),
                                flexDirection: 'row',
                                alignItems: 'center',
                              }}>
                              <Text
                                numberOfLines={2}
                                style={{
                                  color: Colors.black4,
                                  fontFamily: Fonts.SourceSansRegular,
                                  fontSize: hp(1.8),
                                  textTransform: 'capitalize',
                                }}>
                                {item.name}{' '}
                              </Text>
                            </View>
                            <View
                              style={{
                                marginLeft: hp(2),
                                flexDirection: 'row',
                                alignItems: 'center',
                              }}>
                              <Text
                                style={{
                                  color: Colors.noRecordFound,
                                  fontFamily: Fonts.SourceSansRegular,
                                  fontSize: hp(1.5),
                                }}>
                                {item.severity} - {item.status}
                              </Text>
                            </View>
                            <View
                              style={{
                                marginLeft: hp(2),
                                flexDirection: 'row',
                                alignItems: 'center',
                              }}>
                              <Text
                                style={{
                                  color: Colors.noRecordFound,
                                  fontFamily: Fonts.SourceSansRegular,
                                  fontSize: hp(1.5),
                                }}>
                                {dateFormat(item)}
                              </Text>
                            </View>
                          </View>
                        </View>
                      </View>
                    </>
                  )}
                  refreshControl={
                    <RefreshControl
                      refreshing={refreshing}
                      onRefresh={onRefresh}
                    />
                  }
                  keyExtractor={item => Math.random().toString(36).substr(2, 9)}
                />
              </View>
            )}
          </MainHeader>
        </View>
      </SafeAreaView>
    </>
  );
};

export default Allergies;

const styles = StyleSheet.create({
  leftAction: {
    flex: 1,
    backgroundColor: '#497AFC',
    justifyContent: 'center',
  },
  actionText: {
    color: Colors.black,
    fontSize: 16,
    backgroundColor: 'transparent',
    padding: 10,
  },
  rightAction: {
    alignItems: 'center',
    flex: 1,
    justifyContent: 'center',
  },
});
