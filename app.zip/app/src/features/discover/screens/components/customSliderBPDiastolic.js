import React, {useEffect} from 'react';
import {Dimensions, StyleSheet, Text, View} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {SvgCss} from 'react-native-svg';
import {Colors} from 'react-native/Libraries/NewAppScreen';
import {Svgs} from '../../../../../config';
import LineGauge from './src_ruler_gauge/LineGuage';

const {width} = Dimensions.get('screen');

const CustomSliderBPDiastolic = ({
  sliderValue,
  setSliderValue,
  vitalsSubTypesData,
  isEditable,
}) => {
  console.log('====================================');
  console.log('vitalsSubTypesData', vitalsSubTypesData);
  console.log('====================================');
  const customValue = 85;

  console.log('this is the value:');
  useEffect(() => {}, [sliderValue]);
  return (
    <View
      style={{
        borderColor: 'red',
        borderWidth: 0,
      }}>
      {/* ///This is the slider stick sticking out */}
      <View
        style={{
          zIndex: -1,
          marginBottom: width * -0.09,
          marginLeft: width * 0.345,
        }}>
        <SvgCss
          xml={Svgs.slider_toucbpad_red}
          width={hp(5)}
          height={hp(4.3)}
          fill={Colors.black}
          onPress={() => this.props.navigation.pop()}
          style={{marginHorizontal: hp(0.3), transform: [{rotate: '270deg'}]}}
        />
      </View>
      <View
        style={{
          zIndex: 1,
          marginLeft: sliderValue < 100 ? width * 0.38 : width * 0.37,
          position: 'absolute',
          marginTop: 7,
          fontSize: 19,
          transform: [{rotate: '270deg'}],
          color: 'black',
          fontWeight: 'bold',
        }}>
        <Text
          style={{
            zIndex: -0,

            fontSize: 12,
            color: 'white',
            fontWeight: 'bold',
          }}>
          {sliderValue === 98.6 ? 98 : sliderValue}
        </Text>
      </View>

      <View>
        <LineGauge
          rotateText={true}
          min={50}
          max={112}
          value={sliderValue}
          onChange={setSliderValue}
          isEditable={isEditable}
          type={1.5}
        />
      </View>
    </View>
  );
};

export default CustomSliderBPDiastolic;

const styles = StyleSheet.create({});
