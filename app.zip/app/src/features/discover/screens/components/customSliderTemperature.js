import React from 'react';
import {Dimensions, Platform, StyleSheet, Text, View} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {SvgCss} from 'react-native-svg';
import {Colors} from 'react-native/Libraries/NewAppScreen';
import {Svgs} from '../../../../../config';
import LineGauge from './src_ruler_gauge/LineGuage';

const {width} = Dimensions.get('screen');

const CustomSliderTemperature = ({
  sliderValue,
  setSliderValue,
  vitalsSubTypesData,
  isEditable,
}) => {
  console.log('====================================');
  console.log('sliderValue', sliderValue);
  console.log('====================================');
  const customValue = 85;

  console.log('this is the value for the slider : ', vitalsSubTypesData);

  return (
    <View style={{}}>
      {/* ///This is the slider stick sticking out */}
      <View
        style={{
          zIndex: -1,
          marginBottom: width * -0.09,
          marginLeft: width * 0.345,
        }}>
        <SvgCss
          xml={Svgs.slider_toucbpad}
          width={hp(5)}
          height={hp(4.3)}
          fill={Colors.black}
          onPress={() => this.props.navigation.pop()}
          style={{marginHorizontal: hp(0.4), transform: [{rotate: '270deg'}]}}
        />
      </View>
      <View
        style={{
          zIndex: 1,
          marginLeft: sliderValue < 100 ? width * 0.38 : width * 0.37,
          position: 'absolute',
          marginTop: 7,
          fontSize: 19,
          transform: [{rotate: '270deg'}],
          color: 'black',
          fontWeight: 'bold',
        }}>
        <Text
          style={{
            zIndex: -0,

            fontSize: 12,

            color: 'white',
            fontWeight: 'bold',
            borderColor: 'red',
            borderWidth: 0,
          }}>
          {sliderValue && sliderValue}
        </Text>
      </View>

      {console.log('Sliding value is : ', sliderValue)}
      {sliderValue && sliderValue ? (
        <View>
          <LineGauge
            rotateText={true}
            min={90}
            max={110}
            value={
              Platform.OS === 'ios'
                ? sliderValue && sliderValue
                : sliderValue && sliderValue
            }
            onChange={setSliderValue}
            isEditable={isEditable}
          />
        </View>
      ) : null}
    </View>
  );
};

export default CustomSliderTemperature;

const styles = StyleSheet.create({});
