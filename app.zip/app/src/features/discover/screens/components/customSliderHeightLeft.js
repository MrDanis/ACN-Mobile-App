import React from 'react';
import {Dimensions, StyleSheet, Text, View} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {SvgCss} from 'react-native-svg';
import {Svgs} from '../../../../../config';
import LineGaugeHeight from './src_ruler_gauge/LineGuageHeight';

const {width} = Dimensions.get('screen');

const CustomSliderHeightLeft = ({
  sliderValue,
  setSliderValue,
  vitalsSubTypesData,
  isEditable,
}) => {
  console.log('====================================');
  console.log('sliderValue', sliderValue);
  console.log('====================================');
  const customValue = 5;

  console.log('this is the value:');

  return (
    <View>
      {/* ///This is the slider stick sticking out */}
      <View
        style={{
          zIndex: -1,
          marginBottom: width * -0.06,
          marginLeft: width * 0.345,
        }}>
        <SvgCss
          xml={Svgs.slider_toucbpad}
          width={hp(5)}
          height={hp(4.3)}
          onPress={() => this.props.navigation.pop()}
          style={{marginHorizontal: hp(0.4), transform: [{rotate: '270deg'}]}}
        />
      </View>
      <View
        style={{
          zIndex: 1,
          marginLeft: sliderValue < 100 ? width * 0.39 : width * 0.37,
          position: 'absolute',

          marginTop: 7,
          transform: [{rotate: '90deg'}],
        }}>
        <Text
          style={{
            zIndex: -0,

            fontSize: 12,

            color: 'white',
            fontWeight: 'bold',
          }}>
          {sliderValue}
        </Text>
      </View>

      <View>
        <LineGaugeHeight
          rotateText={true}
          min={3}
          max={9}
          value={3}
          onChange={setSliderValue}
          isEditable={isEditable}
          type={1}
        />
      </View>
    </View>
  );
};

export default CustomSliderHeightLeft;

const styles = StyleSheet.create({});
