import React, {useEffect} from 'react';
import {Dimensions, StyleSheet, Text, View} from 'react-native';
import LineGauge from './src_ruler_gauge/LineGuage';

const {width} = Dimensions.get('screen');

const CustomSliderWeight = ({
  sliderValue,
  setSliderValue,
  vitalsSubTypesData,
  isEditable,
  kgBtn,
}) => {
  console.log('====================================');
  console.log('vitalsSubTypesData', vitalsSubTypesData);
  console.log('====================================');

  console.log('this is the value:');
  useEffect(() => {}, [kgBtn]);
  return (
    <View
      style={{
        borderColor: 'purple',
        borderWidth: 0,
      }}>
      <View
        style={{
          zIndex: -1,
          marginBottom: width * -0.13,
          marginLeft: width * 0.345,
          borderColor: 'orange',
          borderWidth: 0,
        }}>
        <View
          style={{
            borderRadius:
              Math.round(
                Dimensions.get('window').width +
                  Dimensions.get('window').height,
              ) / 2,
            width: Dimensions.get('window').width * 0.12,
            height: Dimensions.get('window').width * 0.12,

            backgroundColor: '#607D8B',
            justifyContent: 'center',
            alignItems: 'center',
            borderColor: 'red',
            borderWidth: 0,
          }}></View>
        <View
          style={{
            width: Dimensions.get('window').width * 0.08,
            marginLeft: Dimensions.get('window').width * 0.01,

            marginTop: Dimensions.get('window').width * -0.026,
            height: Dimensions.get('window').width * 0.02,
            borderTopWidth: Dimensions.get('window').width * 0.05,
            borderTopColor: '#607D8B',
            borderLeftColor: 'transparent',
            borderLeftWidth: Dimensions.get('window').width * 0.049,
            borderRightColor: 'transparent',
            borderRightWidth: Dimensions.get('window').width * 0.05,
            borderBottomColor: 'transparent',
          }}></View>
      </View>
      <Text
        style={{
          zIndex: 1,
          marginLeft: sliderValue < 100 ? width * 0.38 : width * 0.36,
          marginTop: 1,
          fontSize: 19,
          color: 'white',
          fontWeight: 'bold',
          borderColor: 'green',
          borderWidth: 0,
        }}>
        {Math.floor(sliderValue)}
      </Text>
      <Text
        style={{
          marginLeft: width * 0.383,
          marginBottom: width * -0.08,
          fontSize: 12,
          color: 'white',
          fontWeight: 'bold',
          zIndex: 1,
        }}>
        kg
      </Text>
      <View style={{borderColor: 'red', borderWidth: 0}}>
        <LineGauge
          min={0}
          max={250}
          value={sliderValue}
          onChange={setSliderValue}
          isEditable={isEditable}
        />
      </View>
    </View>
  );
};

export default CustomSliderWeight;

const styles = StyleSheet.create({});
