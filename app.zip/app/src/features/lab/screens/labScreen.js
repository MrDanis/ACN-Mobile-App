import {useFocusEffect} from '@react-navigation/native';
import moment from 'moment';
import React, {useEffect, useMemo, useRef, useState} from 'react';
import {
  FlatList,
  Image,
  Platform,
  Pressable,
  RefreshControl,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import {Swipeable} from 'react-native-gesture-handler';
import Spinner from 'react-native-loading-spinner-overlay';
import {Modalize} from 'react-native-modalize';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {useDispatch} from 'react-redux';
import DownloadGreyIcon from '../../../../../assets/svg/DownloadGreyIcon.svg';
// import ViewIcon from '../../../../../assets/svg/ViewIcon.svg';

import {CameraRoll} from '@react-native-camera-roll/camera-roll';
import {showMessage} from 'react-native-flash-message';
import RNFetchBlob from 'rn-fetch-blob';
import {Colors, Images} from '../../../../config';
import {Fonts} from '../../../../config/AppConfig';
import BlueButtonService from '../../../api/bluebutton';
import LabService from '../../../api/lab';
import {getEmailSharingResource} from '../../bluebutton/action';
import EmailPopover from '../../bluebutton/screens/component/EmailPopover';
import UploadResultModal from '../../imaging&Radiology/components/uploadResultModal';
import {modalHanlder} from '../../medication/actions';
import MainHeader from '../../mycare/components/MainHeader';
import {labsData} from '../reducers';
import Share from 'react-native-share';
import ModuleWiseService from '../../../api/genericModule';
import svgs from '../../../../config/Svgs';
import {SvgCss} from 'react-native-svg';

const Labs = ({navigation, route}) => {
  const [lab, setLab] = useState(null);
  const [testName, setTestName] = useState('');
  const [labName, setLabName] = useState('');
  const [description, setDescription] = useState('');
  const [imageObject, setImageObject] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [loader, setLoader] = useState(false);
  const [downloader, setDownloader] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [imageUri, setImageUri] = useState(null);

  const dispatch = useDispatch();
  const swipeableRef = useRef(new Map());
  const bottomSheetRef = useRef(null);
  const modalizeRef = useRef(null);
  const modalizeRefEmail = useRef(null);
  const modalizeShare = useRef(null);
  const cameraRef = useRef(null);
  const [refreshing, setRefreshing] = useState(false);
  const snapPoints = useMemo(() => ['25%', '50%'], []);
  const [instance, setInstance] = useState();
  useFocusEffect(
    React.useCallback(() => {
      setLoader(true);
      labsGetData();
    }, []),
  );
  useEffect(() => {
    getSourceData();
  }, []);
  const onRefresh = () => {
    setRefreshing(true);
    labsGetData();
  };
  const getSourceData = () => {
    BlueButtonService.getShareSource()
      .then(response => {
        setLoader(false);
        if (response) {
          if (response.statusCode === 200) {
            const dummyArray = [];

            response.data?.map((itemAtIndex, index) => {
              dummyArray.push({
                id: itemAtIndex.id,
                name: itemAtIndex.name,
                url: itemAtIndex.url,
              });
            });

            dispatch(getEmailSharingResource(dummyArray));
          }
        }
      })
      .catch(error => {
        this.setState({showLoader: false});
        console.log('getSharingResourceDropDown Error', error);
        console.log(error);
        showMessage({
          message: 'Info',
          description: 'Internal Server Error',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  };
  const labsGetData = () => {
    LabService.getLabsData().then(response => {
      console.log('res', response);
      if (response && response.statusCode === 200) {
        setLoader(false);
        setRefreshing(false);
        setLab(response.data);
        dispatch(labsData(response.data));
      } else {
        setRefreshing(false);
        setLoader(false);
        setLab([]);
      }
    });
  };
  const renderRightAction = (x, progress, item) => {
    const trans = progress.interpolate({
      inputRange: [0, 1],
      outputRange: [x, 1],
    });
    return (
      <View
        style={{
          flex: 1,
          transform: [{translateX: 0}],
          justifyContent: 'center',
          flexDirection: 'row',
        }}>
        <Pressable
          onPress={() => {
            console.log('before transfer', item);
            navigation.navigate('ViewReport', {data: item});
          }}
          style={[
            styles.rightAction,
            {
              backgroundColor: Colors.bleLayer4,
            },
          ]}>
          <SvgCss
            xml={svgs.ViewIcon}
            width={hp(3)}
            height={hp(3)}
            fill={Colors.black}
          />
          <Text
            style={{
              //fontFamily: Fonts.SourceSansRegular,
              color: Colors.noRecordFound,
              fontSize: hp(1.3),
            }}>
            View
          </Text>
        </Pressable>
        <Pressable
          onPress={() => {
            setDownloader(true);
            const data = {
              ModuleName: 0,
              id: item.id,
              isEmr: item.isEmrLab,
            };
            ModuleWiseService.getGenericModuleWise(data)
              .then(res => {
                console.log('module wise data', res);
                const extension = res.data.filePath.split('.');
                console.log('extension', extension);
                if (extension[extension.length - 1] === 'pdf') {
                  if (Platform.OS === 'ios') {
                    const dataURL = `data:application/pdf;base64,${res.data.fileBase64String}`;
                    // downloadBase64Pdf(res.data);
                    const shareOptions = {
                      message: extension[0],
                      url: dataURL,
                      title: res.data.filePath,
                    };
                    Share.open(shareOptions)
                      .then(res => {
                        console.log('Image shared successfully', res);
                        setDownloader(false);
                        if (res.success === true) {
                          showMessage({
                            message: 'File Downloaded',
                            description:
                              'Your file has been downloaded successfully',
                            type: 'success',
                          });
                        }
                        // Optionally, handle success or show a success message
                      })
                      .catch(error => {
                        setDownloader(false);
                        console.error('Error sharing image:', error);
                        // Optionally, handle the error or show an error message
                      });
                  } else {
                    downloadBase64Pdf(res.data.fileBase64String);
                  }
                } else if (
                  extension[extension.length - 1] === 'jpg' ||
                  extension[extension.length - 1] === 'png' ||
                  extension[extension.length - 1] === 'jpeg'
                ) {
                  if (Platform.OS === 'ios') {
                    setDownloader(false);
                    // handleSaveToPhotos(res.data);
                    downloadBase64Image(
                      res.data.fileBase64String,
                      extension[extension.length - 1],
                    );
                  } else {
                    downloadBase64Image(
                      res.data.fileBase64String,
                      extension[extension.length - 1],
                    );
                  }
                }
              })
              .catch(error => {
                console.log('====================================');
                console.log('error', error);
                console.log('====================================');
                setDownloader(false);
              });
          }}
          style={[
            styles.rightAction,
            {
              backgroundColor: Colors.bleLayer4,
            },
          ]}>
          <View
            style={{
              flex: 1,
              borderColor: 'green',
              borderWidth: 0,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <SvgCss
              xml={svgs.DownloadGreyIcon}
              width={hp(2)}
              height={hp(2)}
              fill={Colors.black}
            />
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                color: Colors.noRecordFound,
                fontSize: hp(1.3),
                marginTop: hp(0.8),
              }}>
              Download
            </Text>
          </View>
        </Pressable>
      </View>
    );
  };

  const renderRightActions = (progress, item) => {
    return (
      <View
        style={{
          width: hp(20),
          marginRight: hp(1),
          height: hp(10),
        }}>
        {renderRightAction(150, progress, item)}
      </View>
    );
  };

  const dateFormat = item => {
    const utcTime = moment(item.testDate).utc();
    const actualTime = moment(utcTime).format('hh:mm A');

    if (item.isCompleted) {
      return (
        <Text
          style={{
            color: Colors.noRecordFound,
            fontFamily: Fonts.SourceSansRegular,
            fontSize: hp(1.5),
          }}>
          {moment(item.testDate).utc().format('ddd, MMM DD, YYYY')}
        </Text>
      );
    } else {
      return (
        <Text
          style={{
            color: Colors.noRecordFound,
            fontFamily: Fonts.SourceSansRegular,
            fontSize: hp(1.5),
          }}>
          Pending
        </Text>
      );
    }
  };

  function onOpen() {
    dispatch(modalHanlder(false));
    modalizeRef.current?.open();
  }

  function onClose() {
    labsGetData();
    dispatch(modalHanlder(true));
    modalizeRef.current?.close();
    setTestName('');
    setLabName('');
    setDescription('');
    setImageObject(null);
  }

  function onOpenEmail() {
    dispatch(modalHanlder(false));
    modalizeRefEmail.current?.open();
  }

  function onCloseEmail() {
    dispatch(modalHanlder(true));
    modalizeRefEmail.current?.close();
  }

  const downloadBase64Pdf = item => {
    // Replace 'your_base64_string' with your actual base64 PDF string
    const base64String = item;
    console.log('====================================');
    console.log('base64String', base64String);
    console.log('====================================');
    // Convert the base64 string to a Blob
    // const pdfBlob = RNFetchBlob.base64.decode(base64String);

    // Set the file path where you want to save the PDF
    const pdfPath = `${RNFetchBlob.fs.dirs.DocumentDir}/document.pdf`;

    // Download the PDF
    RNFetchBlob.fs
      .writeFile(pdfPath, base64String, 'base64')
      .then(() => {
        setDownloader(false);

        const options = {
          type: 'application/pdf',
          url: `file://${pdfPath}`,
        };
        Share.open(options)
          .then(res => {
            console.log('PDF shared successfully.', res);
            showMessage({
              message: 'File Downloaded',
              description: 'Your file has been downloaded successfully',
              type: 'success',
            });
          })
          .catch(error => {
            console.error('Error sharing PDF:', error);
          });
        console.log('PDF downloaded successfully at:', pdfPath);
      })
      .catch(error => {
        setDownloader(false);
        console.error('Error downloading PDF:', error);
      });
  };

  const downloadBase64Image = (item, extension) => {
    // Replace 'your_base64_string' with your actual base64 PDF string
    const base64String = item;

    // Set the file path where you want to save the PDF
    const imgPath = `${RNFetchBlob.fs.dirs.DocumentDir}/image.${extension}`;

    // Download the PDF
    RNFetchBlob.fs
      .writeFile(imgPath, base64String, 'base64')
      .then(() => {
        setDownloader(false);
        console.log('====================================');
        console.log('write file', `file://${imgPath}`);
        console.log('====================================');

        setImageUri(`file://${imgPath}`);

        console.log('image downloaded successfully at:', imgPath);
        CameraRoll.save(`file://${imgPath}`)
          .then(res => {
            if (res) {
              console.log('====================================');
              console.log('save pic in android', res);
              console.log('====================================');
              showMessage({
                message: 'File Downloaded',
                description: 'Your file has been downloaded successfully',
                type: 'success',
              });
            }
          })
          .catch(err => {
            console.log('Error in saving the image to gallery : ', err);
          });
      })
      .catch(error => {
        setDownloader(false);
        console.error('Error downloading Image:', error);
      });
  };

  function onOpenShare(item) {
    modalizeShare.current?.open();
    dispatch(modalHanlder(false));
  }

  function onCloseShare() {
    modalizeShare.current?.close();
    dispatch(modalHanlder(true));
  }
  const handleSaveToPhotos = data => {
    if (Platform.OS === 'ios') {
      console.log('====================================');
      console.log('here in save', data.fileBase64String);
      console.log('====================================');
      // setImageUri(`file:/${imagePath}`);
      CameraRoll.save(`data:image/jpg;base64,${data.fileBase64String}`, {
        type: 'photo',
      })
        .then(() => {
          console.log('Image saved to Photos app');
          // Alert.alert('Image Saved Successfully');
          showMessage({
            message: 'File Downloaded',
            description: 'Your file has been downloaded successfully',
            type: 'success',
          });
          setDownloader(false);
        })
        .catch(error => {
          setDownloader(false);
          console.log('Error saving image to Photos app:', error);
        });
    } else {
      console.log('Now it is comming for the android', base64String);
      handleSavePictureInAndroid(base64String);
    }
  };
  const handleSavePictureInAndroid = base64String => {};
  const handleOpenRight = id => {
    console.log('handle touch', id);
    const swipeable = swipeableRef.current.get(id);
    console.log('swipeable id', swipeable);
    if (swipeable) {
      swipeable.openRight();
    }
  };
  return (
    <>
      <SafeAreaView
        style={{
          backgroundColor: Colors.BgColor,
          flex: 1,
          borderColor: 'blue',
          borderWidth: 0,
        }}>
        <Spinner
          visible={loader}
          textContent={'Loading...'}
          textStyle={{color: '#FFF'}}
        />
        <Spinner
          visible={downloader}
          textContent={`Downloading...`}
          textStyle={{color: '#FFF'}}
        />
        <Modalize
          ref={modalizeShare}
          backgroundColor={Colors.black2}
          adjustToContentHeight={true}
          withHandle={false}
          onClosed={() => {
            dispatch(modalHanlder(true));
          }}
          modalStyle={{borderTopRightRadius: 25, borderTopLeftRadius: 25}}>
          <View
            style={{
              backgroundColor: Colors.transparent,
              flex: 1,
              width: '100%',
              alignSelf: 'center',
              borderRadius: 10,
              justifyContent: 'center',
              alignItems: 'center',
              paddingBottom: hp(4),
            }}>
            <EmailPopover
              moduleID={9}
              dismissModal={() => onCloseShare()}
              labItem={instance}
              name={'Lab'}
            />
          </View>
        </Modalize>
        <Modalize
          ref={modalizeRefEmail}
          backgroundColor={Colors.black2}
          onClosed={() => {
            console.log('====================================');
            console.log('onClosed modal');
            console.log('====================================');
            dispatch(modalHanlder(true));
          }}
          adjustToContentHeight={true}
          withHandle={false}
          modalStyle={{borderTopRightRadius: 25, borderTopLeftRadius: 25}}>
          <View
            style={{
              backgroundColor: Colors.transparent,
              flex: 1,
              width: '100%',
              alignSelf: 'center',
              borderRadius: 10,
              justifyContent: 'center',
              alignItems: 'center',
              paddingBottom: hp(4),
            }}>
            <EmailPopover
              moduleID={9}
              dismissModal={() => onCloseEmail()}
              onOpen={() => onOpenEmail('')}
            />
          </View>
        </Modalize>
        <Modalize
          ref={modalizeRef}
          withHandle={false}
          adjustToContentHeight={true}
          onClosed={() => {
            console.log('====================================');
            console.log('onClosed modal');
            console.log('====================================');
            dispatch(modalHanlder(true));
            setTestName('');
            setDescription('');
            setImageObject(null);
          }}
          modalStyle={{
            borderTopRightRadius: 25,
            borderTopLeftRadius: 25,
            minHeight: '85%',
            backgroundColor: Colors.white,
          }}>
          <UploadResultModal
            onClose={onClose}
            onOpen={onOpen}
            testName={testName}
            labName={labName}
            setLabName={setLabName}
            description={description}
            setTestName={setTestName}
            setDescription={setDescription}
            imageObject={imageObject}
            setImageObject={setImageObject}
            isLab={true}
            setLoader={setLoader}
            labsGetData={labsGetData}
          />
        </Modalize>
        <View style={{flex: 1, borderColor: 'red', borderWidth: 0}}>
          <MainHeader name={'Labs'} navigation={navigation}>
            {lab?.length <= 0 || lab === null ? (
              <View
                style={{
                  borderColor: 'red',
                  borderWidth: 0,
                  flex: 1,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                <Image
                  style={{
                    width: 100,
                    height: 100,
                    borderRadius: 10,
                  }}
                  source={{
                    uri: imageUri,
                    //priority: Image.priority.high,
                  }}
                />
                {console.log('Lab data is : ', lab)}
                <Image
                  source={Images.emptyIcon}
                  style={{
                    alignSelf: 'center',
                    height: hp(16),
                    width: hp(18),
                  }}
                />
                <Text
                  style={{
                    fontSize: hp(2),
                    fontFamily: Fonts.SourceSansBold,
                    color: Colors.noRecordFound,
                    marginTop: hp(4),
                    marginRight: hp(10),
                    marginLeft: hp(10),
                    textAlign: 'center',
                  }}>
                  No Record Found
                </Text>
              </View>
            ) : (
              <View style={{flex: 1, alignItems: 'center', paddingTop: hp(3)}}>
                <FlatList
                  data={lab}
                  style={{flex: 1, width: '100%'}}
                  contentContainerStyle={{
                    width: '100%',
                    alignItems: 'center',
                  }}
                  renderItem={({item, index}) => (
                    <>
                      <Pressable onPress={() => handleOpenRight(index)}>
                        <Swipeable
                          onSwipeableOpen={swipe => {
                            console.log('====================================');
                            console.log('swipe', swipe);
                            console.log('====================================');
                          }}
                          ref={ref => {
                            if (ref) {
                              swipeableRef.current.set(index, ref);
                            }
                          }}
                          renderRightActions={progress =>
                            renderRightActions(progress, item)
                          }>
                          <View
                            style={{
                              borderRadius: 10,
                              height: hp(10),
                              minWidth: '94%',
                              marginLeft: hp(1),
                              marginRight: hp(1),
                              marginBottom: hp(2),
                              shadowOffset: {width: 0.5, height: 0.5},
                              shadowOpacity: 0.1,
                              shadowRadius: 8,
                              elevation: 3,
                              backgroundColor: Colors.white,
                              flexDirection: 'row',
                              alignItems: 'center',
                              padding: hp(2),
                            }}>
                            <View
                              style={{
                                flexDirection: 'row',
                                flex: 1,
                              }}>
                              <View
                                style={{
                                  width: hp(5.5),
                                  height: hp(5.5),
                                  backgroundColor: Colors.green_lab,
                                  borderRadius: 10,
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                }}>
                                <Image
                                  resizeMode="contain"
                                  style={{width: hp(3.5), height: hp(3.5)}}
                                  source={Images.lab_icon_dashboard}
                                />
                              </View>
                              <View
                                style={{
                                  justifyContent: 'center',
                                  width: '45%',
                                }}>
                                <View
                                  style={{
                                    marginLeft: hp(2),
                                    flexDirection: 'row',
                                    alignItems: 'center',
                                  }}>
                                  <Text
                                    numberOfLines={2}
                                    style={{
                                      color: Colors.black4,
                                      fontFamily: Fonts.SourceSansRegular,
                                      fontSize: hp(1.8),
                                    }}>
                                    {item.testName}{' '}
                                  </Text>
                                </View>
                                <View
                                  style={{
                                    marginLeft: hp(2),
                                    flexDirection: 'row',
                                    alignItems: 'center',
                                  }}>
                                  <Text
                                    style={{
                                      color: Colors.noRecordFound,
                                      fontFamily: Fonts.SourceSansRegular,
                                      fontSize: hp(1.5),
                                    }}>
                                    {moment
                                      .utc(moment.utc(item?.testDate).format())
                                      .local()
                                      .format('hh:mm A')}
                                  </Text>
                                  <View
                                    style={{
                                      width: hp(0.5),
                                      height: hp(0.5),
                                      borderRadius: hp(0.5),
                                      backgroundColor: Colors.textFieldGrey,
                                      marginHorizontal: hp(1),
                                    }}
                                  />

                                  {dateFormat(item)}
                                </View>
                              </View>
                            </View>
                            {item.isSelf && (
                              <View>
                                <Text
                                  style={{
                                    color: Colors.labRed,
                                    fontFamily: Fonts.SourceSansRegular,
                                    fontSize: hp(1.7),
                                    marginTop: hp(-3),
                                  }}>
                                  Self Upload
                                </Text>
                              </View>
                            )}
                          </View>
                        </Swipeable>
                      </Pressable>
                    </>
                  )}
                  refreshControl={
                    <RefreshControl
                      refreshing={refreshing}
                      onRefresh={onRefresh}
                    />
                  }
                  keyExtractor={item => Math.random().toString(36).substr(2, 9)}
                />
              </View>
            )}

            <View style={{zIndex: 80, display: 'none'}}>
              <TouchableOpacity
                onPress={() => onOpenEmail()}
                style={{
                  position: 'absolute',
                  bottom: Platform.OS === 'ios' ? hp(13) : hp(17),
                  left: hp(37),
                  elevation: 80,
                }}>
                <View
                  style={{
                    backgroundColor: Colors.blueTextColor,
                    width: 55,
                    height: 55,
                    borderRadius: 45,
                    borderColor: 'green',
                    borderWidth: 2,
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  <Image source={Images.shareIcon} />
                </View>
              </TouchableOpacity>
            </View>
          </MainHeader>
        </View>
        <TouchableOpacity
          onPress={() => onOpen()}
          style={{
            position: 'absolute',
            bottom: route?.params?.previousScreen ? '18%' : '13%',
            right: 10,
            elevation: 80,
            borderWidth: 0,
            borderColor: 'green',
          }}>
          <View
            style={{
              backgroundColor: Colors.green_lab,
              width: 55,
              height: 55,
              borderRadius: 45,
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <Image
              source={Images.lab_floating_icon}
              style={{width: hp(3), height: hp(4)}}
            />
          </View>
        </TouchableOpacity>
      </SafeAreaView>
    </>
  );
};

export default Labs;

const styles = StyleSheet.create({
  leftAction: {
    flex: 1,
    backgroundColor: '#497AFC',
    justifyContent: 'center',
  },
  actionText: {
    color: Colors.black,
    fontSize: 16,
    backgroundColor: 'transparent',
    padding: 10,
  },
  rightAction: {
    borderColor: 'red',
    borderWidth: 0,
    alignItems: 'center',
    flex: 1,
    justifyContent: 'center',
  },
});
