//import liraries
import {useFocusEffect} from '@react-navigation/native';
import React, {useState} from 'react';
import {Image, SafeAreaView, View} from 'react-native';
import {showMessage} from 'react-native-flash-message';
import Spinner from 'react-native-loading-spinner-overlay';
import PDFView from 'react-native-view-pdf';
import {Colors} from '../../../../config';
import ModuleWiseService from '../../../api/genericModule';
import MainHeader from '../../mycare/components/MainHeader';
import {WebView} from 'react-native-webview';
const ViewReport = ({navigation, route}) => {
  const [loader, setLoader] = useState(false);
  const [emrPdf, setemrPdf] = useState('');
  const [localpdf, setLocalPdf] = useState('');
  useFocusEffect(
    React.useCallback(() => {
      setLoader(true);
      let data = {
        ModuleName: 0,
        id: route?.params?.data?.id,
        isEmr: route?.params?.data?.isEmrLab,
      };
      ModuleWiseService.getGenericModuleWise(data)
        .then(res => {
          console.log('Response of lab internal api is : ', res);

          if (route?.params?.data?.filePath.endsWith('.pdf')) {
            console.log('Response of the api in case of PDF from EMR : ', res);
            setemrPdf(res?.data?.fileBase64String);
          } else {
            setLocalPdf(res?.data?.fileBase64String);
          }

          setLoader(false);
        })
        .catch(err => {
          console.log('Error of the api is : ', err);
          setLoader(false);
        });
    }, []),
  );
  return (
    <>
      <SafeAreaView
        style={{
          backgroundColor: Colors.BgColor,
          flex: 1,
          borderColor: 'blue',
          borderWidth: 0,
        }}>
        <Spinner
          visible={loader}
          textContent={'Loading...'}
          textStyle={{color: '#FFF'}}
        />

        <View style={{flex: 1, borderColor: 'red', borderWidth: 0}}>
          <MainHeader
            name={'Lab Result'}
            navigation={navigation}
            notifDisabled={true}>
            <View style={{flex: 1}}>
              {emrPdf ? (
                <PDFView
                  fadeInDuration={0}
                  style={{flex: 1}}
                  resource={emrPdf}
                  resourceType={'base64'}
                  onLoad={() => {
                    setLoader(false);
                  }}
                  onError={error => {
                    console.log('Error is pdf : ', error);
                    setLoader(false);
                    showMessage({
                      message: 'Something went wrong',
                      description: 'Could not load pdf',
                      type: 'default',
                      icon: {icon: 'info', position: 'left'},
                      backgroundColor: Colors.red,
                    });
                  }}
                />
              ) : (
                <Image
                  source={{uri: `data:image/jpeg;base64,${localpdf}`}}
                  style={{
                    width: '100%',
                    height: '90%',
                  }}
                  onLoad={() => {
                    setLoader(false);
                  }}
                  resizeMode="contain"
                />
              )}
            </View>
            {console.log('url of the emr pdf : ', emrPdf)}
          </MainHeader>
        </View>
      </SafeAreaView>
    </>
  );
};

export default ViewReport;
