//import liraries
import React from 'react';
import {Image, Text, View} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import colors from '../../../../config/Colors';
const ContactTab = props => {
  return (
    <View
      style={{flexDirection: 'column', height: hp(20), alignItems: 'center'}}>
      <Image source={props.iconimage} style={{tintColor: colors.red}} />
      <Text
        style={{
          paddingTop: props.name === 'Care Coordinator' ? hp(1.3) : hp(0),
          color: colors.black2,
          fontSize: hp(1.9),
        }}>
        {props.name}
      </Text>
    </View>
  );
};

export default ContactTab;
