import React from 'react';
import {Image, Text, View} from 'react-native';
import {Colors} from '../../../../config';
import {Fonts} from '../../../../config/AppConfig';

import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import colors from '../../../../config/Colors';

class ProvidersContactCard extends React.PureComponent {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <>
        <View
          style={{
            backgroundColor: colors.white,
            flexDirection: 'row',
            alignItems: 'center',
          }}>
          <Image
            style={{
              width: 50,
              height: 50,
              marginLeft: hp(2),
              resizeMode: 'contain',
            }}
            source={this.props.iconimage}
          />
          <View>
            <Text
              style={{
                marginHorizontal: hp(2),
                fontFamily: Fonts.SourceSansRegular,
                color: Colors.black,
                fontSize: hp(2),
              }}>
              {this.props.name}
            </Text>
            <Text
              style={{
                marginHorizontal: hp(2),
                fontFamily: Fonts.SourceSansRegular,
                color: Colors.blueGrayDisableText,
                fontSize: hp(2),
              }}>
              {this.props.physicianSpeciality}
            </Text>
          </View>
        </View>
      </>
    );
  }
}

export default ProvidersContactCard;
