/* istanbul ignore file */
export const getLabData = data => ({
  type: 'GET_LAB_DATA',
  data,
});
export const getListOfDocumentType = data => ({
  type: 'GET_LIST_OF_DOCUMENT',
  data,
});
