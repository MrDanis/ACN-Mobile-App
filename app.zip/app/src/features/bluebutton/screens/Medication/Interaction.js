/* istanbul ignore file */
import React, {Fragment} from 'react';
import {
  FlatList,
  Image,
  PanResponder,
  SafeAreaView,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Spinner from 'react-native-loading-spinner-overlay';
import {
  heightPercentageToDP,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {Colors, Svgs} from '../../../../../config';
import {Fonts} from '../../../../../config/AppConfig';
import Images from '../../../../../config/Images';
import MedicationService from '../../../../api/medication';
import InteractionItem from '../component/InteractionItem';
import {SvgCss} from 'react-native-svg';

class Interaction extends React.PureComponent {
  static navigationOptions = {
    //To hide the ActionBar/NavigationBar
    header: null,
    headerBackTitle: '',
  };

  constructor(props) {
    super(props);
    this.state = {
      showLoader: false,
      interaction: this.props.route.params.interactionDetails,
      interactionDetails: null,
    };
  }
  state = {
    show: true,
  };
  interactionDetailObj = null;
  _panResponder = {};
  timer = 0;
  componentDidMount(): void {
    this._panResponder = PanResponder.create({
      onStartShouldSetPanResponder: () => {
        this.resetTimer();
        return true;
      },
      onMoveShouldSetPanResponder: (_, gesture) => {
        if (gesture?.moveX > gesture?.moveY) {
          this.resetTimer();
          return false;
        }
        this.resetTimer();
        return true;
      },
      onStartShouldSetPanResponderCapture: () => {
        this.resetTimer();
        return false;
      },
      onMoveShouldSetPanResponderCapture: () => false,
      onPanResponderTerminationRequest: () => true,
      onShouldBlockNativeResponder: () => false,
    });
    this.timer = setTimeout(
      () => this.setState({show: true}),
      this.state.timeNoAction,
    );
    this.setState({showLoader: true});
    let serviceData = {
      ndcs: this.state.interaction.ndcs,
      primaryNDC: this.state.interaction.drugCode,
      type: this.state.interaction.type,
    };
    console.log('Interaction APi data', serviceData);
    MedicationService.getInteractionHistory(serviceData)
      .then(response => {
        this.setState({showLoader: false});
        if (response) {
          console.log('====================================');
          console.log(
            'res',
            response,
            'state of interaction is : ',
            this.state.interaction.type,
          );
          console.log('====================================');
          if (response.statusCode === 200) {
            if (this.state.interaction.type == 0) {
              this.interactionDetailObj = response.data?.drugToDrugInteractions;
              this.setState({
                interactionDetails: response.data?.drugToDrugInteractions,
              });
            } else if (this.state.interaction.type == 1) {
              this.interactionDetailObj = response.data?.drugToFoodInteractions;
              this.setState({
                interactionDetails: response.data?.drugToFoodInteractions,
              });
            } else if (this.state.interaction.type == 2) {
              this.interactionDetailObj =
                response.data?.drugToAllergyInteraction;
              this.setState({
                interactionDetails: response.data?.drugToAllergyInteraction,
              });
            } else if (this.state.interaction.type == 3) {
              this.interactionDetailObj = response.data?.drugToLabInteractions;
              this.setState({
                interactionDetails: response.data?.drugToLabInteractions,
              });
            }

            this.setState({
              interactionDetails: this.interactionDetailObj,
            });
            console.log(
              'Get Interaction detail Response',
              this.state.interactionDetails,
            );
          } else {
            this.setState({
              interactionDetails: [],
            });
          }
        }
      })
      .catch(error => {
        this.setState({showLoader: false});
        console.log('getInteractionHistoryError', error);
        console.log(error);
      });
  }
  resetTimer() {
    console.log('====================================');
    console.log('reset');
    console.log('====================================');
    clearTimeout(this.timer);
    if (this.state.show) {
      this.setState({show: false});
    }
    this.timer = setTimeout(
      () => this.setState({show: true}),
      this.state.timeNoAction,
    );
  }
  componentWillMount(): void {
    this._panResponder = PanResponder.create({
      onStartShouldSetPanResponder: () => {
        this.resetTimer();
        return true;
      },
      onMoveShouldSetPanResponder: (_, gesture) => {
        if (gesture?.moveX > gesture?.moveY) {
          this.resetTimer();
          return false;
        }
        this.resetTimer();
        return true;
      },
      onStartShouldSetPanResponderCapture: () => {
        this.resetTimer();
        return false;
      },
      onMoveShouldSetPanResponderCapture: () => false,
      onPanResponderTerminationRequest: () => true,
      onShouldBlockNativeResponder: () => false,
    });
    this.timer = setTimeout(
      () => this.setState({show: true}),
      this.state.timeNoAction,
    );
  }
  renderSeparator = () => {
    return (
      <View
        style={{
          height: 1,
          width: '92%',
          backgroundColor: Colors.lightGrey,
          marginRight: hp(1),
          marginTop: hp(1),
          marginBottom: hp(1),
          alignSelf: 'center',
        }}
      />
    );
  };

  render() {
    return (
      <Fragment>
        <SafeAreaView style={{flex: 1}}>
          <Spinner
            visible={this.state.showLoader}
            textContent={'Please Wait....'}
            textStyle={{color: '#FFF'}}
          />
          <View
            style={{
              flexDirection: 'row',
              width: '100%',
              alignItems: 'center',
              height: hp(7.5),
              borderBottomWidth: 1,
              borderColor: Colors.line,
              backgroundColor: Colors.white,
            }}
            {...this._panResponder.panHandlers}>
            <SvgCss
              style={{marginLeft: hp(2)}}
              xml={Svgs.arrowHeadLeft}
              width={hp(4)}
              height={hp(4)}
              fill={Colors.black}
              onPress={() => {
                console.log('pressed');
                this.props.navigation.goBack();
                this.resetTimer();
              }}
            />
            {/* <TouchableOpacity
              onPress={() => {
                console.log('pressed');
                this.props.navigation.goBack();
                this.resetTimer();
              }}>
              <Text
                style={{
                  fontFamily: 'WisemanPTSymbols',
                  marginLeft: heightPercentageToDP(2),
                  fontSize: hp(5),
                  color: Colors.black1,
                }}>
                W
              </Text>
            </TouchableOpacity> */}
            <Text
              style={{
                fontFamily: Fonts.SourceSansSemibold,
                textAlign: 'center',
                fontSize: hp(2.5),
                color: Colors.black1,
                flex: 0.85,
              }}>
              Interaction(s)
            </Text>
          </View>
          {Object.entries(this.state.interaction).length > 0 ? (
            <View
              style={{flex: 1, padding: hp(1), backgroundColor: 'white'}}
              {...this._panResponder.panHandlers}>
              <View
                {...this._panResponder.panHandlers}
                style={{
                  flexDirection: 'row',
                  paddingHorizontal: hp(2),
                  paddingVertical: hp(1),
                  alignItems: 'center',
                }}>
                <Image
                  style={{
                    width: 60,
                    height: 60,
                    marginLeft: hp(2),
                    marginRight: hp(1),
                    resizeMode: 'contain',
                  }}
                  source={Images.medicineListIcon}
                />
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansBold,
                    fontSize: hp(2.5),
                    color: Colors.black1,
                    textAlign: 'left',
                    marginHorizontal: hp(2.5),
                  }}>
                  {`${this.state.interaction.count} ${this.state.interaction.name}`}
                </Text>
              </View>
              <FlatList
                style={{margin: hp(2)}}
                data={this.state.interactionDetails}
                ItemSeparatorComponent={this.renderSeparator}
                renderItem={({item, index}) => {
                  console.log('====================================');
                  console.log(
                    'Item of the interaction is : ',
                    this.state.interactionDetails,
                  );
                  console.log('====================================');
                  return (
                    <InteractionItem
                      item={item}
                      action={() => {
                        this.resetTimer();
                        this.props.navigation.navigate(
                          'InteractionDetailScreen',
                          {
                            details: this.state.interactionDetails,
                            indexOfItem: index,
                            typeOfInteraction: this.state.interaction.type, //this.interactionDetailObj.type, this is commented because its always undefine
                          },
                        );
                      }}
                    />
                  );
                }}
                keyExtractor={item => item.id}
              />
            </View>
          ) : (
            this.state.showLoader === false &&
            Object.entries(this.state.interaction).length === 0 && (
              <View
                style={{
                  flex: 1,
                  alignItems: 'center',
                  justifyContent: 'center',
                  paddingBottom: hp(10),
                }}
                {...this._panResponder.panHandlers}>
                <Image
                  source={Images.emptyIcon}
                  style={{
                    alignSelf: 'center',
                    height: hp(16),
                    width: hp(18),
                  }}
                />
                <Text
                  style={{
                    fontSize: hp(2.5),
                    fontFamily: Fonts.SourceSansBold,
                    color: Colors.black4,
                    marginTop: hp(4),
                    marginRight: hp(10),
                    marginLeft: hp(10),
                    textAlign: 'center',
                  }}>
                  No Record Found
                </Text>
              </View>
            )
          )}
        </SafeAreaView>
      </Fragment>
    );
  }
}

export default Interaction;
