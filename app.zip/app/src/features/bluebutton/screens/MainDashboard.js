/* istanbul ignore file */
import React, {Fragment} from 'react';
import {
  BackHandler,
  FlatList,
  Modal,
  PanResponder,
  SafeAreaView,
  Text,
  TouchableOpacity,
  Image,
  View,
} from 'react-native';
import Spinner from 'react-native-loading-spinner-overlay';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import WebView from 'react-native-webview';
import {connect} from 'react-redux';
import {Colors, Images} from '../../../../config';
import {Fonts, baseUrl} from '../../../../config/AppConfig';
import AuthService from '../../../api/auth';
import MedicationService from '../../../api/medication';
import ProfileService from '../../../api/profile';
import {getUserProfile} from '../../profile/action';
import MedicalHistoryCard from './component/MedicalHistoryCard';

import moment from 'moment';

import {NavigationActions} from 'react-navigation';
import {
  isACOUserLogin,
  isBlueButtonRefreshToken,
  isBlueButtonToken,
} from '../../../helpers/Common';
import {
  BlueButtonAccessToken,
  BlueButtonRefreshToken,
  IsAcoUserLogin,
  retrieveItem,
  storeItem,
} from '../../../helpers/LocalStorage';

import {BlurView} from '@react-native-community/blur';
import {showMessage} from 'react-native-flash-message';
import IconInfo from '../../../../../assets/svg/icon_info_green.svg';
import BlueButtonService from '../../../api/bluebutton';
import {getEmailSharingResource} from '../action';

class MainDashboard extends React.PureComponent {
  static navigationOptions = {
    //To hide the ActionBar/NavigationBar
    header: null,
    headerBackTitle: '',
  };

  constructor(props) {
    super(props);
    this.handleBackButtonClick = this.handleBackButtonClick.bind(this);

    this.state = {
      html: '',
      showLoader: false,
      isAcoUserLogin: false,
      isBlueButton: false,
      isBlueRefresh: false,
      showBlueButtonLoading: false,
      isWebViewRedirectedError: 'auto',
      sessionModal: false,
      timeNoAction: this.props.appLogoutTime,
      scroll: true,
      historyData: [],
      newDataHistory: [],
      isBlueButtonCode: false,
      alreadyHere: false,
      isClaims: this.props?.route?.params?.params === 1 ? true : false,
      enum: {
        Diseases: 1,
        Allergies: 2,
        AppointmentHistory: 3,
        Coverage: 4,
        HospitalAlert: 5,
        Medication: 6,
        Procedure: 7,
        Provider: 8,
        Labs: 9,
        Imaging: 10,
      },
    };
  }
  state = {
    show: true,
  };
  _panResponder = {};
  timer = 0;
  setSessionModalVisible() {
    this.setState({sessionModal: !this.state.sessionModal});
  }
  componentWillMount(): void {
    this.willFocusSubscription = this.props.navigation.addListener(
      'focus',
      async () => {
        this.timer = setTimeout(() => {
          console.log('====================================');
          console.log('here at will mount for claims');
          console.log('====================================');
          this.setState({show: true});
        }, this.state.timeNoAction);
        console.log('backin willMount');
        console.log('====================================');
        console.log('modal property', this.state.sessionModal);
        console.log('====================================');
        BackHandler.addEventListener(
          'hardwareBackPress',
          this.handleBackButtonClick,
        );
      },
    );
  }
  resetTimer() {
    console.log('reset in dashboard');
    clearTimeout(this.timer);
    if (this.state.show) {
      this.setState({show: false}, async () => {
        this.setSessionModalVisible();
      });
    }
    this.timer = setTimeout(() => {
      console.log('====================================');
      console.log('here at will reset');
      console.log('====================================');
      this.setState({show: true});
    }, this.state.timeNoAction);
  }
  async GetShareSources() {
    BlueButtonService.getShareSource()
      .then(response => {
        if (response) {
          if (response.statusCode === 200) {
            const dummyArray = [];
            console.log('length', Object.entries(response.data).length);
            console.log('api recieved resources', response.data);

            response.data?.map((itemAtIndex, index) => {
              dummyArray.push({
                id: itemAtIndex?.id,
                name: itemAtIndex?.name,
                url: itemAtIndex?.url,
              });
            });
            console.log('DropDown Valuessss', dummyArray);

            this.props.dispatch(getEmailSharingResource(dummyArray));
          }
        }
      })
      .catch(error => {
        this.setState({showLoader: false});
        console.log('getSharingResourceDropDown Error', error);
        console.log(error);
        showMessage({
          message: 'Info',
          description: 'Internal Server Error',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  }
  async GetAllHistoryCall(callType) {
    // console.log('runnain');
    console.log('Call type for the history is : ', callType);
    if (callType === 0) {
      this.setState({showBlueButtonLoading: true});
    }
    this.setState({showLoader: true});

    MedicationService.GetAllHistory()
      .then(response => {
        console.log('get all history for drop response is : ', response);
        console.log(response.data);

        if (response && response.statusCode === 200) {
          this.setState({historyData: response.data});
          const newArray = Object.keys(response.data[0])
            .map(key => {
              const value = response.data[0][key];
              // Check if the value is of type 'object' and not null
              if (typeof value === 'object' && value !== null) {
                return value;
              }
              return null; // Return null if not an object
            })
            .filter(item => item !== null); // Filter out null values

          console.log('this is the new array medical history : ', newArray);
          this.setState({newDataHistory: newArray});
          this.setState({showLoader: false});
          console.log(
            'Blue Button login status is :',
            this.state.showBlueButtonLoading,
          );
          this.setState({showBlueButtonLoading: false});
        }
      })
      .catch(error => {
        console.log(error);
        this.setState({showLoader: false});
        showMessage({
          message: 'Info',
          description: 'Internal Server Error',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  }
  async getProfileData() {
    var isLogin = await isACOUserLogin();
    var isBlueButton = await isBlueButtonToken();
    if (!isLogin && isBlueButton) {
      this._panResponder = PanResponder.create({
        onStartShouldSetPanResponder: () => {
          this.resetTimer();
          return true;
        },
        onMoveShouldSetPanResponder: (e, gestureState) => {
          this.resetTimer();
          return !(gestureState.dx === 0 && gestureState.dy === 0);
        },
        onStartShouldSetPanResponderCapture: () => {
          this.resetTimer();
          return false;
        },
        onMoveShouldSetPanResponderCapture: () => false,
        onPanResponderTerminationRequest: () => true,
        onShouldBlockNativeResponder: () => false,
      });
      this.timer = setTimeout(() => {
        console.log('====================================');
        console.log('here at profile data');
        console.log('====================================');
        this.setState({show: true});
      }, this.state.timeNoAction);
    }
    ProfileService.getUserProfile()
      .then(response => {
        console.log('getUserProfile');
        console.log(this.props.userProfileData.isTokenExpired);
        if (response && response.Status === true && response.Data.Profile) {
          this.props.dispatch(getUserProfile(response.Data.Profile));
        }
      })
      .catch(error => {
        console.log(error);
      });
  }

  async componentDidMount(): void {
    console.log(
      'Previous screen routes are :',
      this.props?.route?.params?.params,
    );
    this.setState({showLoader: true});
    this.willFocusSubscription = this.props.navigation.addListener(
      'focus',
      async () => {
        console.log(
          'come here to fokos in case of bluebutton login',
          this.props,
        );

        var isLogin = await isACOUserLogin();
        var isBlueButton = await isBlueButtonToken();
        var isRefreshToken = await isBlueButtonRefreshToken();
        console.log('isLoginDashboard');
        console.log(isLogin);
        console.log('isBlueButton');
        console.log(isBlueButton);
        console.log('isBlueRefresh');
        console.log(isRefreshToken);
        this.setState({isBlueRefresh: isRefreshToken});

        this.setState({isBlueButton: isBlueButton});
        //change blue to refresh token temp asad
        if (isLogin === false && !isBlueButton) {
          console.log('Comming to blue button not login ', isBlueButton);
          if (this.state.alreadyHere) {
            this.setState({
              isACOUserLogin: false,
              alreadyHere: true,
            });
          } else {
            this.setState({
              showLoader: true,
              isACOUserLogin: false,
              alreadyHere: true,
            });
          }
          console.log('====================================');
          console.log('already here', this.state.alreadyHere);
          console.log('====================================');
        } else {
          console.log(
            'Comming to blue button section when the when not login ',
            isBlueButton,
          );
          this.setState({
            showLoader: false,
            isACOUserLogin: true,
          });
        }
        console.log(
          'Calling these apis in case of comming back from the bluebutton logIn',
        );
        // change here to get new access temp asad add code to check if there is no access token then get and store access token first
        if (isRefreshToken || this.state.isClaims) {
          console.log('This will work when atleast one of the user is login');
          console.log('Blue Button login : ', isBlueButton);
          console.log('Dashboard login : ', isLogin);
          this.GetShareSources();
          this.GetAllHistoryCall();
          console.log('Blue Button login Calls Start');
          console.log('Blue Button login Calls End');
        } else {
          console.log('Bluebutton : ', isBlueButton);
          console.log('Dashboard : ', isBlueButton);
          console.log('is login ', isLogin);
        }
      },
    );
    this.willFocusSubscription = this.props.navigation.addListener(
      'focus',
      async () => {
        this.timer = setTimeout(() => {
          console.log('====================================');
          console.log('here at did mount');
          console.log(
            'This must work when the user is login with the blue button and is navigating back to the main dashboard from the sub module...',
          );
          console.log('====================================');
          this.setState({show: true});
        }, this.state.timeNoAction);

        BackHandler.addEventListener(
          'hardwareBackPress',
          this.handleBackButtonClick,
        );
        console.log(
          'Current Stack screen',
          this.props.navigation.state.routeName,
        );

        var isLogin = await isACOUserLogin();
        var isBlueButton = await isBlueButtonToken();
        console.log('isLoginDashboard in case of blue button');
        console.log(isLogin);
        console.log('isBlueButton in case of blue button');
        console.log(isBlueButton);
        this.setState({isBlueButton: isBlueButton});
        if (isLogin === false && !isBlueButton) {
          this.setState({
            showLoader: true,
            isACOUserLogin: false,
          });
        } else {
          this.setState({
            showLoader: false,
            isACOUserLogin: true,
          });
        }
        this.refreshBlueButtonToken();
        this.getSharingResourceDropDown();
        this._panResponder = PanResponder.create({
          onStartShouldSetPanResponderCapture: () => {
            clearTimeout(this.timer);
            return false;
          },
          onMoveShouldSetPanResponder: (e, gestureState) => {
            this.resetTimer();
            return !(gestureState.dx === 0 && gestureState.dy === 0);
          },
        });
      },
    );
  }

  getSharingResourceDropDown() {
    BlueButtonService.getShareSource()
      .then(response => {
        this.setState({showLoader: false});
        if (response) {
          if (response.Status === true) {
            console.log(JSON.stringify('getSharingResourceDropDown'));
            console.log(JSON.stringify(response.Data));
            this.props.dispatch(getEmailSharingResource(response.Data));
          }
        }
      })
      .catch(error => {
        this.setState({showLoader: false});
        console.log('getSharingResourceDropDown Error', error);
        console.log(error);
      });
  }
  async refreshBlueButtonToken() {
    let refreshToken = await retrieveItem(BlueButtonRefreshToken);
    console.log('refreshToken');
    console.log(refreshToken);
    if (refreshToken && this.props.userProfileData.isTokenExpired === true) {
      this.setState({showLoader: true});
      AuthService.getBlueButtonRefreshToken()
        .then(res => {
          this.setState({showLoader: false});
          console.log('getBlueButtonAccessToken');
          console.log(res);
          if (res && res.statusCode === 200) {
            storeItem(BlueButtonAccessToken, res.data.accessToken);
            storeItem(BlueButtonRefreshToken, res.data.refreshToken);
            storeItem(IsAcoUserLogin, 'false');
            this.setState({
              bluetoken: res.data.accessToken,
            });
          }
        })
        .catch(err => {
          this.setState({showLoader: false});
          console.log('getBlueButtonAccessTokenError');
          console.log(err);
        });
    }
  }
  componentWillUnmount() {}
  removeEventListener() {
    BackHandler.removeEventListener(
      'hardwareBackPress',
      this.handleBackButtonClick,
    );
  }
  async componentDidUpdate() {
    console.log('this is bluebutton status before', this.state.isBlueRefresh);
    var isRefreshToken = await isBlueButtonRefreshToken();
    console.log('update state with new token ', isRefreshToken);
    this.setState({isBlueRefresh: isRefreshToken});
  }
  resetProfieStack() {
    this.props.navigation.reset(
      [NavigationActions.navigate({routeName: 'Profile'})],
      0,
    );
  }
  handleBackButtonClick() {}
  getAge(dateString: string) {
    console.log('====================================');
    console.log(
      'date',
      moment(new Date(this.props.userProfileData.dateOfBirth)).format(
        'YYYY-MM-DD',
      ),
    );
    console.log('====================================');
    const date = moment(
      new Date(this.props.userProfileData.dateOfBirth),
    ).format('YYYY-MM-DD');
    const years = moment().diff(date, 'years');
    console.log('====================================');
    console.log('years', years);
    console.log('====================================');

    return years + 'yrs';
  }

  onNavigationStateChange = webViewState => {
    console.log('here on back');
    console.log('webViewState');
    console.log('webViewState', webViewState);
    console.log('webViewState.url', webViewState.url);
    if (
      webViewState.url.includes(
        this.props?.homeApiData?.blueButton?.callbackUrl,
      ) &&
      !webViewState.url.includes(this.props?.homeApiData?.blueButton?.clientID)
    ) {
      var appLink = webViewState.url;
      var urlParts = appLink.split('?');
      console.log('urlParts');
      console.log(urlParts);
      let code = urlParts[1].split('=')[1];
      console.log(code);
      //Danish (START)
      this.setState({isBlueButtonCode: true});
      //Danish (END)

      if (code === 'access_denied') {
        this.props.navigation.goBack();
        alert(
          'You need to allow permission for your blue button account to access your medical data',
        );
      } else {
        // if we have the blueButton code then we will do the below process and update the bluebutton state
        if (!this.state.isBlueButtonCode) {
          console.log('Check by danish....');
          let dataObj = {};
          dataObj.code = code;
          this.setState({showBlueButtonLoading: true});
          AuthService.getBlueButtonAccessToken(dataObj)
            .then(async res => {
              console.log('getBlueButtonAccessToken response is : ', res);
              console.log(res);
              if (res && res.statusCode === 200) {
                storeItem(BlueButtonAccessToken, res.data.accessToken);
                storeItem(BlueButtonRefreshToken, res.data.refreshToken);
                storeItem(IsAcoUserLogin, 'false');
                this.setState({isBlueButton: true, isBlueButtonCode: false});
              }
              console.log('Calling the profile api after getting the token...');
              console.log('Blue Button login Calls Start');
              console.log('Step 1 start');
              this.getProfileData().then(res => {
                console.log(
                  'response of the getProfileData when user login from the blue button : ',
                  res,
                );
              });
              console.log('Step 2 start');
              this.GetShareSources().then(res => {
                console.log(
                  'response of the GetShareSources when user login from the blue button : ',
                  res,
                );
              });
              console.log('Step 3 start');
              this.GetAllHistoryCall(0).then(res => {
                console.log(
                  'response of the GetAllHistoryCall when user login from the blue button : ',
                  res,
                );
              });
              console.log('Step 3 ends');

              console.log(
                'Blue Button login Calls End',
                this.state.isBlueButtonCode,
              );
            })
            .catch(err => {
              this.setState({showLoader: false});
              console.log('getBlueButtonAccessTokenError');
              console.log(err);
            });
        }
      }
    }
  };
  render() {
    console.log('this.props.homeApiData');
    console.log(this.props.homeApiData);
    return (
      <Fragment>
        <SafeAreaView style={{flex: 1, backgroundColor: Colors.BgColor}}>
          {console.log(
            'Screen type is : ',
            this.props?.route?.params,
            this.state.isClaims,
          )}
          {this.state.showBlueButtonLoading === false ? (
            <Spinner
              visible={
                this.props?.route?.params?.params === 0
                  ? this.state.showLoader
                  : this.state.showLoader ||
                    this.state.newDataHistory.length <= 0
              }
              textContent={'Loading....'}
              textStyle={{color: '#FFF'}}
            />
          ) : (
            <Spinner
              visible={this.state.showBlueButtonLoading}
              textContent={'Loading....'}
              textStyle={{color: '#FFF'}}
            />
          )}

          <Modal
            animationType={'fade'}
            transparent={true}
            visible={this.state.sessionModal}>
            <BlurView
              blurType="light"
              blurAmount={10}
              style={{
                flex: 1,
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <View
                style={{
                  backgroundColor: Colors.transparent,
                  flex: 1,
                  width: '100%',
                  alignSelf: 'center',
                  borderRadius: 10,
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <View
                  style={{
                    backgroundColor: Colors.white,
                    height: 200,
                    width: '80%',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    borderRadius: 10,
                  }}>
                  <IconInfo width={hp(35)} height={hp(10)} />
                  <Text
                    style={{
                      fontSize: hp(2.2),
                      fontFamily: Fonts.NunitoBold,
                      textAlign: 'center',
                      marginBottom: hp(1),
                    }}>
                    {' '}
                    {'Session has expired.\n' + 'Please login again.'}
                  </Text>
                  <TouchableOpacity
                    style={{
                      width: '65%',
                      marginBottom: hp(1.5),
                      height: hp(7),
                      alignSelf: 'center',
                      borderRadius: 5,
                      borderColor: Colors.cyan,
                      justifyContent: 'center',
                      alignItems: 'center',
                      backgroundColor: Colors.green_50,
                    }}
                    onPress={() => {
                      console.log('====================================');
                      console.log(
                        'isAcoLogin in touchable',
                        this.props.userProfileData.isAcoPatient,
                      );
                      console.log('====================================');
                      if (this.props.userProfileData.isAcoPatient === true) {
                        this.setState({
                          modalVisible: false,
                          sessionModal: false,
                          show: false,
                        });
                        clearTimeout(this.timer);
                        storeItem(IsAcoUserLogin, 'false');

                        this.props.navigation.navigate('AuthenticationType');
                      } else {
                        this.setState(
                          {sessionModal: false, show: false},
                          async () => {
                            storeItem(BlueButtonAccessToken, '');
                            storeItem(BlueButtonRefreshToken, '');
                            storeItem(IsAcoUserLogin, 'false');
                            this.resetTimer();
                            var isLogin = await isACOUserLogin();
                            var isBlueButton = await isBlueButtonToken();
                            console.log('isLoginDashboard');
                            console.log(isLogin);
                            console.log('isBlueButton');
                            console.log(isBlueButton);
                            this.setState({isBlueButton: isBlueButton});
                            if (isLogin === false && !isBlueButton) {
                              this.setState({
                                showLoader: true,
                                isACOUserLogin: false,
                              });
                            } else {
                              this.setState({
                                showLoader: false,
                                isACOUserLogin: true,
                              });
                            }
                            this.refreshBlueButtonToken();
                            this.getSharingResourceDropDown();
                            this._panResponder = PanResponder.create({
                              onStartShouldSetPanResponderCapture: () => {
                                clearTimeout(this.timer);
                                return false;
                              },
                            });
                          },
                        );
                      }
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.NunitoBold,
                        fontSize: hp(2.6),
                        color: Colors.green,
                      }}>
                      Ok
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </BlurView>
          </Modal>
          <View
            style={{flex: 1, backgroundColor: Colors.BgColor}}
            collapsable={false}>
          
            {this.state.isACOUserLogin ? (
              <View>
                <View
                  style={{
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexDirection: 'row',
                    marginTop: hp(1.5),
                    marginBottom: hp(2),
                  }}>
                  <View style={{flex: 0.25, marginLeft: hp(2)}}>
                    {this.props.userProfileData.imagePath !== null &&
                    this.props.userProfileData.imagePath !== '' ? (
                      <TouchableOpacity
                        onPress={() =>
                          this.props.navigation.navigate('Profile')
                        }>
                        <Image
                          style={{
                            width: hp(5),
                            height: hp(5),
                            marginLeft: hp(1),
                            borderRadius: 10,
                          }}
                          source={{
                            uri:
                              baseUrl +
                              '/' +
                              this.props.userProfileData.imagePath +
                              '?' +
                              new Date(),
                            //priority: Image.priority.high,
                          }}
                        />
                      </TouchableOpacity>
                    ) : (
                      <TouchableOpacity
                        onPress={() =>
                          this.props.navigation.navigate('Profile')
                        }>
                        <Image
                          style={{
                            width: hp(5),
                            height: hp(5),
                            borderRadius: 10,
                            marginLeft: hp(1),
                          }}
                          resizeMode="contain"
                          source={require('../../../../../assets/images/user_logo.png')}
                        />
                      </TouchableOpacity>
                    )}
                  </View>
                  <View style={{flex: 0.5, alignItems: 'center'}}>
                    <Text
                      style={{
                        color: Colors.black,
                        fontSize: hp(2.5),
                        fontFamily: Fonts.SFProSemibold,
                      }}>
                      Medical History
                    </Text>
                  </View>
                  <View style={{flex: 0.25, alignItems: 'flex-end'}}>
                    <TouchableOpacity
                      onPress={() =>
                        this.props.navigation.navigate('NotificationStack')
                      }>
                      <View
                        style={{
                          flexDirection: 'row',
                          justifyContent: 'flex-start',
                          marginRight: hp(2),
                        }}>
                        <Image
                          style={{
                            width: hp(2),
                            height: hp(2.5),
                          }}
                          source={Images.notification_dashboard}
                        />
                      </View>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            ) : (
              this.state.isBlueRefresh && (
                <View>
                  <View
                    style={{
                      alignItems: 'center',
                      justifyContent: 'center',
                      flexDirection: 'row',
                      marginTop: hp(1.5),
                      marginBottom: hp(2),
                    }}>
                    <View style={{flex: 0.25, marginLeft: hp(2)}}>
                      {this.props.userProfileData.imagePath !== null &&
                      this.props.userProfileData.imagePath !== '' ? (
                        <TouchableOpacity
                          onPress={() =>
                            this.props.navigation.navigate('Profile')
                          }>
                          <Image
                            style={{
                              width: hp(5),
                              height: hp(5),
                              marginLeft: hp(1),
                              borderRadius: 10,
                            }}
                            source={{
                              uri:
                                baseUrl +
                                '/' +
                                this.props.userProfileData.imagePath +
                                '?' +
                                new Date(),
                              //priority: Image.priority.high,
                            }}
                          />
                        </TouchableOpacity>
                      ) : (
                        <TouchableOpacity
                          onPress={() =>
                            this.props.navigation.navigate('Profile')
                          }>
                          <Image
                            style={{
                              width: hp(5),
                              height: hp(5),
                              borderRadius: 10,
                              marginLeft: hp(1),
                            }}
                            resizeMode="contain"
                            source={require('../../../../../assets/images/user_logo.png')}
                          />
                        </TouchableOpacity>
                      )}
                    </View>
                    <View style={{flex: 0.5, alignItems: 'center'}}>
                      <Text
                        style={{
                          color: Colors.black,
                          fontSize: hp(2.5),
                          fontFamily: Fonts.SourceSansSemibold,
                        }}>
                        Medical History
                      </Text>
                    </View>
                    <View style={{flex: 0.25, alignItems: 'flex-end'}}>
                      <TouchableOpacity
                        onPress={() =>
                          this.props.navigation.navigate('NotificationStack')
                        }>
                        <View
                          style={{
                            flexDirection: 'row',
                            justifyContent: 'flex-start',
                            marginRight: hp(2),
                          }}>
                          <Image
                            style={{
                              width: hp(2),
                              height: hp(2.5),
                            }}
                            source={Images.notification_dashboard}
                          />
                        </View>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              )
            )}

            {/* {console.log(
              'this is deciding condition',
              this.state.isBlueRefresh || this.state.isClaims,
            )}
            {console.log(
              'uri: ',
              this.props.homeApiData?.blueButton?.authUrl +
                '?response_type=code&client_id=' +
                this.props.homeApiData?.blueButton?.clientID +
                '&redirect_uri=' +
                this.props.homeApiData?.blueButton?.callbackUrl,
            )} */}
            {this.state.isBlueRefresh || this.state.isClaims ? (
              <FlatList
                contentContainerStyle={{
                  backgroundColor: Colors.BgColor,
                }}
                data={this.state.newDataHistory}
                renderItem={({item}) => {
                  return (
                    <TouchableOpacity
                      onPress={() => {
                        this._panResponder = {};
                        this.resetTimer();
                        console.log('touchable', item);
                        this.removeEventListener();
                        if (item.moduleId === 6) {
                          this.props.navigation.navigate('Medication');
                        }
                        if (item.moduleId === 'T') {
                          this.props.navigation.navigate('AppointmentScreen');
                        }
                        if (item.moduleId === 1) {
                          this.props.navigation.navigate('Diseases');
                        }
                        if (item.moduleId === 7) {
                          this.props.navigation.navigate('Procedure');
                        }
                        if (item.moduleId === 4) {
                          this.props.navigation.navigate('CoverageScreen');
                        }
                        if (item.moduleId === 8) {
                          this.props.navigation.navigate('ProviderScreen');
                        }
                        if (item.moduleId === 2) {
                          this.props.navigation.navigate('AllergiesScreen');
                        }
                        if (item.moduleId === 5) {
                          this.props.navigation.navigate('HospitalVisitScreen');
                        }
                      }}
                      style={{
                        backgroundColor: Colors.white,
                        borderRadius: 8,
                        flex: 1,
                        shadowOffset: {width: 0.5, height: 0.5},
                        shadowOpacity: 0.1,
                        shadowRadius: 8,
                        elevation: 10,
                        justifyContent: 'space-between',
                        marginHorizontal: hp(2),
                        marginVertical: hp(1.5),
                        borderRadius: 0,
                        borderColor: 'red',
                      }}
                      {...this._panResponder.panHandlers}>
                      {console.log('came top flat list')}
                      <MedicalHistoryCard item={item} />
                    </TouchableOpacity>
                  );
                }}
              />
            ) : (
              <WebView
                style={{flex: 1}}
                source={{
                  uri:
                    this.props.homeApiData?.blueButton?.authUrl +
                    '?response_type=code&client_id=' +
                    this.props.homeApiData?.blueButton?.clientID +
                    '&redirect_uri=' +
                    this.props.homeApiData?.blueButton?.callbackUrl,
                }}
                onNavigationStateChange={this.onNavigationStateChange}
                javaScriptEnabled={true}
                domStorageEnabled={true}
                startInLoadingState={false}
                onLoadStart={() => {
                  console.log('loading start of webview');
                  this.setState({showLoader: true});
                }}
                onLoadEnd={() => {
                  console.log('loading end of webview');
                  this.setState({showLoader: false});
                }}
                onHttpError={syntheticEvent => {
                  const {nativeEvent} = syntheticEvent;
                  if (nativeEvent.statusCode === 404) {
                    this.setState({isWebViewRedirectedError: 'none'});
                  }
                }}
                containerStyle={{
                  borderColor: 'red',
                  borderWidth: 0,
                  display:
                    this.state.isWebViewRedirectedError === 'none'
                      ? 'none'
                      : 'flex',
                }}
              />
            )}
          </View>
        </SafeAreaView>
      </Fragment>
    );
  }
}

/* istanbul ignore next */
const mapStateToProps = ({
  homeApiData,
  userProfileData,
  emailSharingResourceData,
  appLogoutTime,
}) => ({
  homeApiData,
  userProfileData,
  emailSharingResourceData,
  appLogoutTime,
});
export default connect(mapStateToProps)(MainDashboard);
