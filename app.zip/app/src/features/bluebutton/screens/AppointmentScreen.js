/* istanbul ignore file */
import React, {Component, Fragment, useState, useRef} from 'react';
import {
  FlatList,
  Text,
  TouchableOpacity,
  View,
  SafeAreaView,
  Modal,
  Image,
  PanResponder,
  Pressable,
  RefreshControl,
} from 'react-native';
import {Colors} from '../../../../config';
import {
  heightPercentageToDP,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {Fonts} from '../../../../config/AppConfig';
import RightIcon from '../../../../../assets/svg/icon_arrow_right.svg';
import ShareIcon from '../../../../../assets/svg/icon_share.svg';
import HistoryIcon from '../../../../../assets/svg/icon_history.svg';
import {getAppointment} from '../action';
import BlueButtonService from '../../../api/bluebutton';
import Spinner from 'react-native-loading-spinner-overlay';
import {connect} from 'react-redux';
import EmptyIcon from '../../../../../assets/svg/empty_norecords.svg';
import Share from 'react-native-share';
import EmailPopover from './component/EmailPopover';
import {showMessage} from 'react-native-flash-message';
import Images from '../../../../config/Images';
import {Svgs} from '../../../../config';
import Carousel, {Pagination} from 'react-native-snap-carousel';
import AppointmentSlideComponent from './component/AppointmentCard';
import colors from '../../../../config/Colors';

import {SvgCss} from 'react-native-svg';
import Moment from 'moment';
import AppointmentIcon from '../../../../../assets/svg/AppointmentIcon.svg';
import AppointmentService from '../../../api/appointment';
import svgs from '../../../../config/Svgs';

const data = [
  {key: 'A', name: 'Coverage'},
  {key: 'B', name: 'Medication'},
  {key: 'C', name: 'Appointments'},
  {key: 'D', name: 'My Providers'},
  {key: 'E', name: 'Diseases'},
  {key: 'F', name: 'Allergies'},
  {key: 'G', name: 'Procedures'},
  {key: 'H', name: 'Hospital Visits'},
];
class AppointmentScreen extends Component {
  static navigationOptions = {
    //To hide the ActionBar/NavigationBar
    header: null,
    headerBackTitle: '',
  };
  constructor(props) {
    super(props);
    this.state = {
      showLoader: false,
      modalVisible: false,
      emailID: '',
      appointmentHistory: [],
      timeNoAction: this.props.appLogoutTime,
      upcoming: true,
      completed: false,
      missed: false,
      activeIndex: 0,
      upcomingAppointmentData: [],
      completedAppointmentData: [],
      missedAppointmentData: [],
      refreshing: false,
    };
  }

  componentDidMount(): void {
    this.willFocusSubscription = this.props.navigation.addListener(
      'focus',
      async () => {
        this.appointmentDataCall();
      },
    );
  }

  appointmentDataCall = () => {
    this.setState({showLoader: true});
    // const data = {
    //   orderColumn: '',
    //   orderDirection: '',
    //   pageNum: 1,
    //   pageSize: 100,
    //   patientId: 0,
    //   locationId: 0,
    // };
    const arrayUpcommingData = [];
    const arrayCompletedData = [];
    const arrayMissedData = [];
    AppointmentService.getAppointment()
      .then(response => {
        this.setState({showLoader: false, refreshing: false});
        console.log('getAppointmentHistory');
        console.log(response);
        if (response) {
          if (response.statusCode === 200) {
            console.log('====================================');
            console.log('hehe', response.data);
            console.log('====================================');
            response.data.map(data => {
              if (data.status === 'Missed') {
                arrayMissedData.push(data);
              } else if (data.status === 'Completed') {
                arrayCompletedData.push(data);
              } else if (
                data.status === 'Upcoming' &&
                data.startTime !== null
              ) {
                arrayUpcommingData.push(data);
              }
            });
            this.getMissedDataWRTDate(arrayMissedData);
            this.getCompletedDataWRTDate(arrayCompletedData);
            this.getUpcomingDataWRTDate(arrayUpcommingData);
            this.props.dispatch(getAppointment(response.data));
            this.setState({appointmentHistory: response.data});
          } else {
            this.props.dispatch(getAppointment([]));
            this.setState({appointmentHistory: []});
          }
        }
      })
      .catch(error => {
        this.setState({showLoader: false, refreshing: false});
        console.log('getAppointmentHistoryError');
        console.log(error);
        showMessage({
          message: 'Info',
          description: 'Internal Server Error',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  };

  onRefresh = () => {
    console.log('====================================');
    console.log('here in refresh');
    console.log('====================================');
    this.setState({refreshing: true});
    this.appointmentDataCall();
  };

  getMissedDataWRTDate = data => {
    let missedDateArr = [];
    let missedDataWithDate = [];
    data.map(objAtIndex => {
      let notificationDate = objAtIndex.startTime.split('T')[0];
      if (missedDateArr.indexOf(notificationDate) === -1) {
        missedDateArr.push(notificationDate);
      }
    });
    missedDateArr.map(dateAtIndex => {
      let objData = [];
      data.map(objAtIndex => {
        if (dateAtIndex === objAtIndex.startTime.split('T')[0]) {
          objData.push(objAtIndex);
        }
      });
      missedDataWithDate.push({
        key: dateAtIndex,
        value: objData,
      });
    });
    console.log('====================================');
    console.log('missedDataWithDate', missedDataWithDate);
    console.log('====================================');
    this.setState({
      missedAppointmentData: missedDataWithDate,
    });
  };

  getUpcomingDataWRTDate = data => {
    let upcomingDateArr = [];
    let upcomingDataWithDate = [];
    data.map(objAtIndex => {
      let notificationDate = objAtIndex?.startTime?.split('T')[0];

      if (upcomingDateArr.indexOf(notificationDate) === -1) {
        upcomingDateArr.push(notificationDate);
      }
    });
    upcomingDateArr.map(dateAtIndex => {
      let objData = [];
      data.map(objAtIndex => {
        if (dateAtIndex === objAtIndex.startTime.split('T')[0]) {
          objData.push(objAtIndex);
        }
      });
      upcomingDataWithDate.push({
        key: dateAtIndex,
        value: objData,
      });
    });
    console.log('====================================');
    console.log('upcomingDataWithDate', upcomingDataWithDate);
    console.log('====================================');
    this.setState({
      upcomingAppointmentData: upcomingDataWithDate.reverse(),
    });
  };

  getCompletedDataWRTDate = data => {
    let completedDateArr = [];
    let completedDataWithDate = [];
    data.map(objAtIndex => {
      let notificationDate = objAtIndex.startTime.split('T')[0];
      if (completedDateArr.indexOf(notificationDate) === -1) {
        completedDateArr.push(notificationDate);
      }
    });
    completedDateArr.map(dateAtIndex => {
      let objData = [];
      data.map(objAtIndex => {
        if (dateAtIndex === objAtIndex.startTime.split('T')[0]) {
          objData.push(objAtIndex);
        }
      });
      completedDataWithDate.push({
        key: dateAtIndex,
        value: objData,
      });
    });
    console.log('====================================');
    console.log('completedDataWithDate', completedDataWithDate);
    console.log('====================================');
    this.setState({
      completedAppointmentData: completedDataWithDate,
    });
  };

  setModalVisible() {
    this.setState({modalVisible: !this.state.modalVisible});
  }

  isTodayYesterday = date => {
    let today = Moment().format('YYYY-MM-DD');
    let yesterday = Moment().subtract(1, 'day').format('YYYY-MM-DD');

    const formattedDate = Moment(date).format('YYYY-MM-DD');

    if (Moment(formattedDate).isSame(today, 'day')) {
      return 'Today';
    } else if (Moment(formattedDate).isSame(yesterday, 'day')) {
      return 'Yesterday';
    } else {
      return Moment(new Date(formattedDate)).format('M/D/YYYY').toUpperCase();
    }
  };
  renderSeparator = () => {
    return (
      <View
        style={{
          display: 'flex',
          justifyContent: 'flex-end',
          flexDirection: 'row',
          marginTop: hp(1.7),
        }}>
        <View
          style={{
            borderWidth: 0.5,
            borderColor: Colors.line,
            width: Platform.OS === 'ios' ? '76%' : '77%',
          }}
        />
      </View>
    );
  };
  render() {
    return (
      <Fragment>
        <SafeAreaView style={{flex: 1, backgroundColor: Colors.BgColor}}>
          <Spinner
            visible={this.state.showLoader}
            textContent={'Please Wait....'}
            textStyle={{color: '#FFF'}}
          />
          <Modal
            animationType="slide"
            transparent={true}
            visible={this.state.modalVisible}
            onRequestClose={() => {
              this.setModalVisible();
            }}>
            <View
              style={{
                flex: 1,
                justifyContent: 'center',
                alignItems: 'center',
                paddingBottom: hp(4),
              }}>
              <EmailPopover
                moduleID={3}
                dismissModal={() => this.setModalVisible()}
                onOpen={() => this.onOpen(this.state.emailID)}
              />
            </View>
          </Modal>
          <View style={{flex: 1, backgroundColor: Colors.BgColor}}>
            <View
              style={{
                flexDirection: 'row',
                width: '100%',
                alignItems: 'center',
                height: hp(7.5),
                borderBottomWidth: 0.5,
                borderColor: Colors.BgColor,
                backgroundColor: Colors.BgColor, //this.props.navigation.goBack();
              }}>
              <SvgCss
                style={{marginLeft: hp(2)}}
                xml={svgs.arrowHeadLeft}
                width={hp(4)}
                height={hp(4)}
                fill={Colors.black}
                onPress={() => {
                  this.props.navigation.goBack();
                }}
              />
              <Text
                style={{
                  fontFamily: Fonts.SourceSansSemibold,
                  textAlign: 'center',
                  fontSize: hp(2.5),
                  color: Colors.black1,
                  flex: 1,
                }}>
                Appointment
              </Text>

              <View style={{flex: 0.2, alignItems: 'flex-end'}}>
                <TouchableOpacity
                  onPress={() =>
                    this.props.navigation.navigate('NotificationStack')
                  }>
                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'flex-start',
                      marginRight: hp(2),
                    }}>
                    <Image
                      style={{
                        width: hp(2),
                        height: hp(2.5),
                        // marginRight:-20,
                        // marginHorizontal: hp(3),
                        // marginTop:10,
                      }}
                      source={Images.notification_dashboard}
                    />
                    {/* <TouchableOpacity>
                      <SvgCss
                        xml={Svgs.settings_Icon}
                        width={hp(2.2)}
                        height={hp(2.3)}
                        fill={Colors.black}
                        onPress={() => this.props.navigation.pop()}
                        style={{marginHorizontal: hp(1.5)}}
                      />
                    </TouchableOpacity> */}
                  </View>
                </TouchableOpacity>
              </View>
            </View>
            <View
              style={{
                backgroundColor: Colors.BgColor,
                width: '100%',
                paddingBottom: hp(2),
                flexDirection: 'row',
                justifyContent: 'center',
                marginTop: hp(2),
                // borderWidth: 1,
              }}>
              <View
                style={{
                  color: Colors.bleLayer4,
                  backgroundColor: Colors.bleLayer4,
                  width: '90%',
                  borderRadius: 10,
                  flexDirection: 'row',
                  paddingTop: hp(0),
                  paddingBottom: hp(0),
                  borderBottomColor: Colors.BgColor,
                  borderBottomWidth: 1,
                }}>
                <TouchableOpacity
                  onPress={() => {
                    this.setState({
                      lastVisit: this.state.emergencyArray,
                      upcoming: true,
                      completed: false,
                      missed: false,
                      name: 'Emergency',
                    });
                  }}>
                  <View
                    style={{
                      minWidth: Platform.OS === 'ios' ? '33.3%' : '35%',
                      height: Platform.OS === 'android' ? hp(6) : hp(6),
                      borderRadius: 10,
                      justifyContent: 'space-around',
                      alignItems: 'center',
                      justifyContent: 'center',
                      backgroundColor:
                        this.state.upcoming === true
                          ? Colors.blueTextColor
                          : Colors.transparent,
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansRegular,
                        fontSize: hp(2),

                        color:
                          this.state.upcoming === true
                            ? Colors.white
                            : Colors.label,
                        marginLeft: hp(1),
                        marginBottom: hp(0),
                      }}>
                      Upcoming
                    </Text>
                  </View>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => {
                    this.setState({
                      lastVisit: this.state.inPatientArray,
                      upcoming: false,
                      completed: true,
                      missed: false,
                      name: 'In-Patient',
                    });
                  }}>
                  <View
                    style={{
                      minWidth: Platform.OS === 'ios' ? '33.3%' : '35%',
                      height: Platform.OS === 'android' ? hp(6) : hp(6),
                      borderRadius: 10,
                      justifyContent: 'space-around',
                      alignItems: 'center',
                      justifyContent: 'center',
                      backgroundColor:
                        this.state.completed === true
                          ? Colors.blueTextColor
                          : Colors.transparent,
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansRegular,
                        fontSize: hp(2),
                        color:
                          this.state.completed === true
                            ? Colors.white
                            : Colors.label,
                        marginHorizontal: hp(1),
                        marginBottom: hp(0),
                      }}>
                      Completed
                    </Text>
                  </View>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => {
                    this.setState({
                      lastVisit: this.state.outPatientArray,
                      upcoming: false,
                      completed: false,
                      missed: true,
                      name: 'Out-Patient',
                    });
                  }}>
                  <View
                    style={{
                      minWidth: Platform.OS === 'ios' ? '33.3%' : '35%',
                      height: Platform.OS === 'android' ? hp(6) : hp(6),
                      borderRadius: 10,

                      alignItems: 'center',
                      justifyContent: 'center',
                      backgroundColor:
                        this.state.missed === true
                          ? Colors.blueTextColor
                          : Colors.transparent,
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansRegular,
                        fontSize: hp(2),
                        color:
                          this.state.missed === true
                            ? Colors.white
                            : Colors.label,
                        marginHorizontal: hp(0),
                        marginBottom: hp(0),
                      }}>
                      Missed
                    </Text>
                  </View>
                </TouchableOpacity>
              </View>
            </View>
            {/* <View
              style={{flex: 1, flexDirection: 'row', justifyContent: 'center'}}>
              <Carousel
                layout={'default'}
                ref={ref => (this.carousel = ref)}
                data={this.state.carouselItems}
                sliderWidth={300}
                itemWidth={300}
                renderItem={this._renderItem}
                onSnapToItem={index => this.setState({activeIndex: index})}
              />
            </View> */}
            {this.state.upcoming === true ? (
              <View
                style={{
                  minWidth: '100%',
                  backgroundColor: Colors.white,
                  marginTop: hp(2.5),
                  flex: 1,
                  marginTop: hp(2),
                  borderTopLeftRadius: hp(2.5),
                  borderTopRightRadius: hp(2.5),
                  shadowOffset: {width: 0.5, height: 0.5},
                  shadowOpacity: 0.1,
                  shadowRadius: 5,
                  elevation: 5,
                }}>
                {/* <AppointmentSlideComponent /> */}

                {this.state.upcomingAppointmentData.length ? (
                  <FlatList
                    contentContainerStyle={{marginHorizontal: hp(1)}}
                    data={this.state.upcomingAppointmentData}
                    // onEndReached={({distanceFromEnd}) => {
                    //   console.log('Distance', distanceFromEnd);
                    //   if (
                    //     !this.state.showLoader &&
                    //     this.state.pageNumber !== 0 &&
                    //     parseInt(distanceFromEnd) >= 0
                    //   ) {
                    //     this.state.historyList.length > 0 &&
                    //       this.getModuleHistory('get');
                    //   }
                    // }}
                    // onEndReachedThreshold={0.05}
                    keyExtractor={item => {
                      return item.id;
                    }}
                    refreshControl={
                      <RefreshControl
                        refreshing={this.state.refreshing}
                        onRefresh={this.onRefresh}
                      />
                    }
                    ItemSeparatorComponent={this.renderSeparator}
                    renderItem={({item}) => {
                      return (
                        <View style={{paddingTop: hp(1)}}>
                          {/* {console.log('item being recivedd', item)} */}
                          <Text
                            style={{
                              marginHorizontal: hp(2),
                              fontSize: hp(2),
                              fontFamily: Fonts.SourceSansSemibold,
                              color: Colors.black4,
                            }}>
                            {item.key &&
                              item.key.split('-').reverse().join('-')}
                            {/* {this.isTodayYesterday(
                              Moment(item.key).format('L'),
                            )} */}
                          </Text>

                          {item?.value && item?.value.length
                            ? item?.value.map((data, index) => {
                                return (
                                  <View style={{}} key={index}>
                                    <View
                                      style={{
                                        flexDirection: 'row',
                                        // marginVertical: hp(1),
                                        alignItems: 'center',
                                        // borderWidth: 1,
                                        marginTop: hp(1.5),
                                      }}>
                                      <View
                                        style={{
                                          borderRadius: hp(1),
                                          // backgroundColor: Colors.bleLayer4,
                                          marginHorizontal: hp(2),
                                          paddingVertical: hp(1.5),
                                          width:
                                            Platform.OS === 'ios'
                                              ? hp(6.5)
                                              : hp(7),
                                          height:
                                            Platform.OS === 'android'
                                              ? hp(7)
                                              : hp(6.5),
                                          display: 'flex',
                                          flexDirection: 'row',
                                          justifyContent: 'center',
                                          alignItems: 'center',
                                        }}>
                                        <SvgCss
                                          style={{marginLeft: hp(2)}}
                                          xml={svgs.AppointmentIcon}
                                          width={hp(4)}
                                          height={hp(4)}
                                          fill={Colors.black}
                                        />
                                        {/* <AppointmentIcon
                                          height="50"
                                          width="50"
                                          style={{marginHorizontal: hp(2)}}
                                        /> */}
                                      </View>
                                      <View
                                        style={{
                                          flexDirection: 'column',
                                          width: '75%',
                                          alignItems: 'flex-start',
                                          justifyContent: 'space-around',
                                        }}>
                                        <Text
                                          style={{
                                            fontSize: hp(2),
                                            fontFamily: Fonts.SourceSansRegular,
                                            color: Colors.black4,
                                            marginTop: hp(0.3),
                                          }}>
                                          You have {data?.title} with{' '}
                                          {data?.appointmentWith}
                                        </Text>
                                        <View
                                          style={{
                                            mrginTop: hp(1),
                                            borderColor: 'red',
                                            borderWidth: 0,
                                            display: 'flex',
                                            width: '100%',
                                            flexDirection: 'row',
                                            alignItems: 'center',
                                            justifyContent: 'flex-start',
                                          }}>
                                          <View
                                            style={{
                                              flex: 1,
                                              borderColor: 'green',
                                              borderWidth: 0,
                                              display: 'flex',
                                              flexDirection: 'row',
                                            }}>
                                            <Text
                                              style={{
                                                fontSize: hp(1.9),
                                                fontFamily:
                                                  Fonts.SourceSansRegular,
                                                color: Colors.blueBackground,
                                                marginTop:
                                                  Platform.OS === 'ios'
                                                    ? hp(0.5)
                                                    : hp(0),
                                                marginRight: hp(0.5),
                                              }}>
                                              {data?.emrStatus}
                                            </Text>
                                            <Text
                                              style={{
                                                fontSize: hp(1.9),
                                                fontFamily:
                                                  Fonts.SourceSansRegular,
                                                color: Colors.noRecordFound,
                                                marginTop:
                                                  Platform.OS === 'ios'
                                                    ? hp(0.5)
                                                    : hp(0),
                                              }}>
                                              {Moment.utc(
                                                Moment.utc(
                                                  data?.startTime,
                                                ).format(),
                                              )
                                                .local()
                                                .format('LT')}
                                            </Text>
                                          </View>
                                          {data?.appointmentType === 92 ? (
                                            <View
                                              style={{
                                                flex: 0.25,
                                                borderColor: 'blue',
                                                borderWidth: 0,
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'start',
                                              }}>
                                              <SvgCss
                                                xml={svgs.ProiderVideoCallIcon}
                                                style={{marginRight: hp(20)}}
                                                width={hp(4)}
                                                height={hp(4)}
                                                fill={Colors.black}
                                                onPress={() => {
                                                  // this.props.navigation.navigate('MeetingWithCM',{
                                                  //          data:{
                                                  //            asc_token:"eyJhbGciOiJSUzI1NiIsImtpZCI6IjU3Qjg2NEUwQjM0QUQ0RDQyRTM3OTRBRTAyNTAwRDVBNTE5MjA1RjUiLCJ4NXQiOiJWN2hrNExOSzFOUXVONVN1QWxBTldsR1NCZlUiLCJ0eXAiOiJKV1QifQ.eyJza3lwZWlkIjoiYWNzOmU0N2U3YTI4LTNhODYtNDQyMS1iMmNhLWIzNGMyMzQwMGQ5ZV8wMDAwMDAyNC03ODYzLTg3YjEtNzEzNy04ZTNhMGQwMDJkMTEiLCJzY3AiOjE3OTIsImNzaSI6IjE3MzQ1MDQyMTEiLCJleHAiOjE3MzQ1OTA2MTEsInJnbiI6ImFtZXIiLCJhY3NTY29wZSI6InZvaXAiLCJyZXNvdXJjZUlkIjoiZTQ3ZTdhMjgtM2E4Ni00NDIxLWIyY2EtYjM0YzIzNDAwZDllIiwicmVzb3VyY2VMb2NhdGlvbiI6InVuaXRlZHN0YXRlcyIsImlhdCI6MTczNDUwNDIxMX0.J_drUruvDN7lXOVg93tWbK6Y1oDo2JjMpYepI5QGNUGSkCJbOlXe2MoKduLlL49tgMzSzmSVpGwCtMqFRlPobZiuREmdWAjUdgKKZy4y3dFkG6t4KdTdKAdkzSFqFijWh7v8E1-jLvpd8sgtXDE1rRCT3pdEMXQHrYuwDe6wGKRIWQQnh0xJTibnDLv4eFDoiVBgr4LRNdFDk5n__nWyy8jFd0-fLE9X5TmtuvK8gZR0JOes0inXfffzc8zNLh6r2zCNk4qrPKxP0oNPG0N6SLUh9ufHlecOq0fUR2JFGZu5pBIF66P7LuYJj4GlNPpm6pD5xCKid4O6rIGXdodukg",
                                                  //            room:"99411912672893562"
                                                  //          }
                                                  //         })

                                                  this.setState({
                                                    showLoader: true,
                                                  });
                                                  AppointmentService.roomCallWithProvider(
                                                    data?.id,
                                                  )
                                                    .then(res => {
                                                      console.log(
                                                        'Response of the Provider call is : ',
                                                        res,
                                                      );
                                                      if (res?.data?.isError) {
                                                        showMessage({
                                                          message: 'Info',
                                                          description: `${res?.data?.message}`,
                                                          type: 'default',
                                                          icon: {
                                                            icon: 'info',
                                                            position: 'left',
                                                          },
                                                          backgroundColor:
                                                            Colors.red,
                                                        });
                                                      } else {
                                                        if (
                                                          (res?.data
                                                            ?.acccessToken !==
                                                            '' ||
                                                            res?.data
                                                              .acccessToken !==
                                                              null ||
                                                            res?.data
                                                              ?.acccessToken !==
                                                              undefined) &&
                                                          (res?.data?.roomId !==
                                                            '' ||
                                                            res?.data
                                                              ?.roomId !==
                                                              null ||
                                                            res?.data
                                                              ?.roomId !==
                                                              undefined)
                                                        ) {
                                                          // Initiate the room call from here
                                                          // this.props.navigation.navigate(
                                                          //   'MeetingWithCM',
                                                          //   {
                                                          //     data: {
                                                          //       asc_token:
                                                          //         res?.data
                                                          //           ?.acccessToken,
                                                          //       room: res?.data
                                                          //         ?.roomId,
                                                          //     },
                                                          //   },
                                                          // );
                                                          this.props.navigation.navigate(
                                                            'IncomingCallScreenEMR',
                                                            {
                                                              data: {
                                                                asc_token:
                                                                  res?.data
                                                                    ?.acccessToken,
                                                                caller: '123',
                                                                room: res?.data
                                                                  ?.roomId,
                                                                caller_id:
                                                                  '123',
                                                                type: 1,
                                                              },
                                                            },
                                                          );
                                                        } else {
                                                          // if the erorr is not true but playload doesnot match to initiate the call
                                                          showMessage({
                                                            message: 'Info',
                                                            description:
                                                              'Room does not exist yet.',
                                                            type: 'default',
                                                            icon: {
                                                              icon: 'info',
                                                              position: 'left',
                                                            },
                                                            backgroundColor:
                                                              Colors.red,
                                                          });
                                                        }
                                                      }
                                                      this.setState({
                                                        showLoader: false,
                                                      });
                                                    })
                                                    .catch(error => {
                                                      this.setState({
                                                        showLoader: false,
                                                      });
                                                      console.log(
                                                        'Error of the call is : ',
                                                        error,
                                                      );
                                                      showMessage({
                                                        message: 'Info',
                                                        description:
                                                          'Internal Server Error',
                                                        type: 'default',
                                                        icon: {
                                                          icon: 'info',
                                                          position: 'left',
                                                        },
                                                        backgroundColor:
                                                          Colors.red,
                                                      });
                                                    });
                                                }}
                                              />
                                              {/* <Pressable 
                                                 >
                                                  <Text>Call</Text>
                                                 </Pressable> */}
                                            </View>
                                          ) : null}
                                        </View>
                                      </View>
                                    </View>
                                  </View>
                                );
                              })
                            : ''}
                        </View>
                      );
                    }}
                  />
                ) : (
                  this.state.showLoader === false &&
                  this.state.upcomingAppointmentData.length === 0 && (
                    <View
                      style={{
                        flex: 1,
                        // alignItems: 'center',
                        // justifyContent: 'center',
                        paddingTop: hp(10),
                      }}
                      // {...this._panResponder.panHandlers}
                    >
                      <Image
                        source={Images.emptyIcon}
                        style={{
                          alignSelf: 'center',
                          height: hp(16),
                          width: hp(18),
                        }}
                      />
                      <Text
                        style={{
                          fontSize: hp(2),
                          fontFamily: Fonts.SourceSansBold,
                          color: Colors.black4,
                          marginTop: hp(4),
                          marginRight: hp(10),
                          marginLeft: hp(10),
                          textAlign: 'center',
                        }}>
                        No Record Found
                      </Text>
                    </View>
                  )
                )}
                <Pressable
                  style={{
                    position: 'absolute',
                    top: hp('50%'),
                    right: 0,
                    zIndex: 1111,
                  }}
                  onPress={() =>
                    this.props.navigation.navigate('ScheduleAppointment')
                  }>
                  <Image
                    source={Images.appointmentPlus}
                    style={{
                      alignSelf: 'center',
                      height: hp(10),
                      width: hp(10),
                    }}
                  />
                </Pressable>
                {/* <Text style={{position: 'absolute', top: 10, zIndex: 1111}}>
                  asad
                </Text> */}
              </View>
            ) : this.state.completed === true ? (
              <View
                style={{
                  minWidth: '100%',
                  backgroundColor: Colors.white,
                  marginTop: hp(2.5),
                  flex: 1,
                  marginTop: hp(2),
                  borderTopLeftRadius: hp(2.5),
                  borderTopRightRadius: hp(2.5),
                  shadowOffset: {width: 0.5, height: 0.5},
                  shadowOpacity: 0.1,
                  shadowRadius: 5,
                  elevation: 5,
                }}>
                {this.state.completedAppointmentData.length ? (
                  <FlatList
                    contentContainerStyle={{marginHorizontal: hp(1)}}
                    data={this.state.completedAppointmentData}
                    // onEndReached={({distanceFromEnd}) => {
                    //   console.log('Distance', distanceFromEnd);
                    //   if (
                    //     !this.state.showLoader &&
                    //     this.state.pageNumber !== 0 &&
                    //     parseInt(distanceFromEnd) >= 0
                    //   ) {
                    //     this.state.historyList.length > 0 &&
                    //       this.getModuleHistory('get');
                    //   }
                    // }}
                    // onEndReachedThreshold={0.05}
                    keyExtractor={item => {
                      return item.id;
                    }}
                    refreshControl={
                      <RefreshControl
                        refreshing={this.state.refreshing}
                        onRefresh={this.onRefresh}
                      />
                    }
                    ItemSeparatorComponent={this.renderSeparator}
                    renderItem={({item}) => {
                      return (
                        <View style={{paddingTop: hp(1)}}>
                          {console.log('item being recivedd*', item)}
                          <Text
                            style={{
                              marginHorizontal: hp(2),
                              fontSize: hp(2),
                              fontFamily: Fonts.SourceSansSemibold,
                              color: Colors.black4,
                            }}>
                            {/* {this.isTodayYesterday(Moment(item.key).format('L')) : null} */}
                            {Moment(item?.key,'YYYY-MM-DD').format('DD-MM-YYYY')}
                          </Text>

                          {item?.value && item?.value.length
                            ? item?.value.map((data, index) => {
                                return (
                                  <View style={{}} key={index}>
                                    <View
                                      style={{
                                        flexDirection: 'row',
                                        // marginVertical: hp(1),
                                        alignItems: 'center',
                                        // borderWidth: 1,
                                        marginTop: hp(1.5),
                                      }}>
                                      <View
                                        style={{
                                          borderRadius: hp(1),
                                          // backgroundColor: Colors.bleLayer4,
                                          marginHorizontal: hp(2),
                                          paddingVertical: hp(1.5),
                                          width:
                                            Platform.OS === 'ios'
                                              ? hp(6.5)
                                              : hp(7),
                                          height:
                                            Platform.OS === 'android'
                                              ? hp(7)
                                              : hp(6.5),
                                          display: 'flex',
                                          flexDirection: 'row',
                                          justifyContent: 'center',
                                          alignItems: 'center',
                                        }}>
                                        <SvgCss
                                          style={{marginLeft: hp(2)}}
                                          xml={svgs.AppointmentIcon}
                                          width={hp(4)}
                                          height={hp(4)}
                                          fill={Colors.black}
                                        />
                                        {/* <AppointmentIcon
                                          height="50"
                                          width="50"
                                          style={{marginHorizontal: hp(2)}}
                                        /> */}
                                      </View>
                                      <View
                                        style={{
                                          flexDirection: 'column',
                                          width: '75%',
                                          alignItems: 'flex-start',
                                          justifyContent: 'space-around',
                                        }}>
                                        <Text
                                          style={{
                                            fontSize: hp(2),
                                            fontFamily: Fonts.SourceSansRegular,
                                            color: Colors.black4,
                                            marginTop: hp(0.3),
                                          }}>
                                          You have {data?.title} with{' '}
                                          {data?.appointmentWith}
                                        </Text>
                                        <View
                                          style={{
                                            flexDirection: 'row',
                                            alignItems: 'center',
                                            justifyContent: 'flex-start',
                                          }}>
                                          <Text
                                            style={{
                                              fontSize: hp(1.9),
                                              fontFamily:
                                                Fonts.SourceSansRegular,
                                              color: Colors.badgeGreen,
                                              marginTop:
                                                Platform.OS === 'ios'
                                                  ? hp(0.5)
                                                  : hp(0),
                                              marginRight: hp(0.5),
                                            }}>
                                            {data.emrStatus}
                                          </Text>
                                          <Text
                                            style={{
                                              fontSize: hp(1.9),
                                              fontFamily:
                                                Fonts.SourceSansRegular,
                                              color: Colors.noRecordFound,
                                              marginTop:
                                                Platform.OS === 'ios'
                                                  ? hp(0.5)
                                                  : hp(0),
                                            }}>
                                            {Moment.utc(
                                              Moment.utc(
                                                data?.startTime,
                                              ).format(),
                                            )
                                              .local()
                                              .format('LT')}
                                          </Text>
                                        </View>
                                      </View>
                                    </View>
                                  </View>
                                );
                              })
                            : ''}
                        </View>
                      );
                    }}
                  />
                ) : (
                  this.state.showLoader === false &&
                  this.state.completedAppointmentData.length === 0 && (
                    <View
                      style={{
                        flex: 1,
                        alignItems: 'center',
                        justifyContent: 'center',
                        paddingBottom: hp(10),
                      }}
                      // {...this._panResponder.panHandlers}
                    >
                      <Image
                        source={Images.emptyIcon}
                        style={{
                          alignSelf: 'center',
                          height: hp(16),
                          width: hp(18),
                        }}
                      />
                      <Text
                        style={{
                          fontSize: hp(2),
                          fontFamily: Fonts.SourceSansBold,
                          color: Colors.black4,
                          marginTop: hp(4),
                          marginRight: hp(10),
                          marginLeft: hp(10),
                          textAlign: 'center',
                        }}>
                        No Record Found
                      </Text>
                    </View>
                  )
                )}
                {/* <Image
                  source={Images.appointmentPlus}
                  style={{
                    position: 'absolute',
                    top: '80%',
                    right: 0,
                    zIndex: 1111,
                    alignSelf: 'center',
                    height: hp(10),
                    width: hp(10),
                  }}
                />{' '} */}
                {/* <Pressable
                  style={{
                    position: 'absolute',
                    top: '82%',
                    right: 0,
                    zIndex: 1111,
                  }}
                  onPress={() =>
                    this.props.navigation.navigate('ScheduleAppointment')
                  }>
                  <Image
                    source={Images.appointmentPlus}
                    style={{
                      position: 'absolute',
                      top: '80%',
                      right: 0,
                      zIndex: 1111,
                      alignSelf: 'center',
                      height: hp(10),
                      width: hp(10),
                    }}
                  />
                </Pressable> */}
                <Pressable
                  style={{
                    position: 'absolute',
                    top: hp('50%'),
                    right: 0,
                    zIndex: 1111,
                  }}
                  onPress={() =>
                    this.props.navigation.navigate('ScheduleAppointment')
                  }>
                  <Image
                    source={Images.appointmentPlus}
                    style={{
                      alignSelf: 'center',
                      height: hp(10),
                      width: hp(10),
                    }}
                  />
                </Pressable>
              </View>
            ) : this.state.missed === true ? (
              <View
                style={{
                  minWidth: '100%',
                  backgroundColor: Colors.white,
                  marginTop: hp(2.5),
                  flex: 1,
                  marginTop: hp(2),
                  borderTopLeftRadius: hp(2.5),
                  borderTopRightRadius: hp(2.5),
                  shadowOffset: {width: 0.5, height: 0.5},
                  shadowOpacity: 0.1,
                  shadowRadius: 5,
                  elevation: 5,
                }}>
                {this.state.missedAppointmentData.length ? (
                  <FlatList
                    contentContainerStyle={{marginHorizontal: hp(1)}}
                    data={this.state.missedAppointmentData}
                    // onEndReached={({distanceFromEnd}) => {
                    //   console.log('Distance', distanceFromEnd);
                    //   if (
                    //     !this.state.showLoader &&
                    //     this.state.pageNumber !== 0 &&
                    //     parseInt(distanceFromEnd) >= 0
                    //   ) {
                    //     this.state.historyList.length > 0 &&
                    //       this.getModuleHistory('get');
                    //   }
                    // }}
                    // onEndReachedThreshold={0.05}
                    keyExtractor={item => {
                      return item.id;
                    }}
                    refreshControl={
                      <RefreshControl
                        refreshing={this.state.refreshing}
                        onRefresh={this.onRefresh}
                      />
                    }
                    ItemSeparatorComponent={this.renderSeparator}
                    renderItem={({item}) => {
                      return (
                        <View style={{paddingTop: hp(1)}}>
                          {/* {console.log('item being recivedd', item)} */}
                          <Text
                            style={{
                              marginHorizontal: hp(2),
                              fontSize: hp(2),
                              fontFamily: Fonts.SourceSansSemibold,
                              color: Colors.black4,
                            }}>
                            {/* {this.isTodayYesterday(item?.key)} */}
                            {Moment(item?.key,'YYYY-MM-DD').format('DD-MM-YYYY')}
                            {/* {item?.key} */}
                          </Text>

                          {item?.value && item?.value.length
                            ? item?.value.map((data, index) => {
                                return (
                                  <View style={{}} key={index}>
                                    <View
                                      style={{
                                        flexDirection: 'row',
                                        // marginVertical: hp(1),
                                        alignItems: 'center',
                                        // borderWidth: 1,
                                        marginTop: hp(1.5),
                                      }}>
                                      <View
                                        style={{
                                          borderRadius: hp(1),

                                          marginHorizontal: hp(2),
                                          paddingVertical: hp(1.5),
                                          width:
                                            Platform.OS === 'ios'
                                              ? hp(6.5)
                                              : hp(7),
                                          height:
                                            Platform.OS === 'android'
                                              ? hp(7)
                                              : hp(6.5),
                                          display: 'flex',
                                          flexDirection: 'row',
                                          justifyContent: 'center',
                                          alignItems: 'center',
                                        }}>
                                        <SvgCss
                                          style={{marginLeft: hp(2)}}
                                          xml={svgs.AppointmentIcon}
                                          width={hp(4)}
                                          height={hp(4)}
                                          fill={Colors.black}
                                        />
                                        {/* <AppointmentIcon
                                          height="50"
                                          width="50"
                                          style={{marginHorizontal: hp(2)}}
                                        /> */}
                                      </View>
                                      <View
                                        style={{
                                          flexDirection: 'column',
                                          width: '75%',
                                          alignItems: 'flex-start',
                                          justifyContent: 'space-around',
                                        }}>
                                        <Text
                                          style={{
                                            fontSize: hp(2),
                                            fontFamily: Fonts.SourceSansRegular,
                                            color: Colors.black4,
                                            marginTop: hp(0.3),
                                          }}>
                                          You have {data?.title} with{' '}
                                          {data?.appointmentWith}
                                        </Text>
                                        <View
                                          style={{
                                            flexDirection: 'row',
                                            alignItems: 'center',
                                            justifyContent: 'flex-start',
                                          }}>
                                          <Text
                                            style={{
                                              fontSize: hp(1.9),
                                              fontFamily:
                                                Fonts.SourceSansRegular,
                                              color: Colors.red,
                                              marginTop:
                                                Platform.OS === 'ios'
                                                  ? hp(0.5)
                                                  : hp(0),
                                              marginRight: hp(0.5),
                                            }}>
                                            {data.emrStatus}
                                          </Text>
                                          <Text
                                            style={{
                                              fontSize: hp(1.9),
                                              fontFamily:
                                                Fonts.SourceSansRegular,
                                              color: Colors.noRecordFound,
                                              marginTop:
                                                Platform.OS === 'ios'
                                                  ? hp(0.5)
                                                  : hp(0),
                                            }}>
                                            {Moment.utc(
                                              Moment.utc(
                                                data?.startTime,
                                              ).format(),
                                            )
                                              .local()
                                              .format('LT')}
                                          </Text>
                                        </View>
                                      </View>
                                    </View>
                                  </View>
                                );
                              })
                            : ''}
                        </View>
                      );
                    }}
                  />
                ) : (
                  this.state.showLoader === false &&
                  this.state.missedAppointmentData.length === 0 && (
                    <View
                      style={{
                        flex: 1,
                        alignItems: 'center',
                        justifyContent: 'center',
                        paddingBottom: hp(10),
                      }}>
                      <Image
                        source={Images.emptyIcon}
                        style={{
                          alignSelf: 'center',
                          height: hp(16),
                          width: hp(18),
                        }}
                      />
                      <Text
                        style={{
                          fontSize: hp(2),
                          fontFamily: Fonts.SourceSansBold,
                          color: Colors.black4,
                          marginTop: hp(4),
                          marginRight: hp(10),
                          marginLeft: hp(10),
                          textAlign: 'center',
                        }}>
                        No Record Found
                      </Text>
                    </View>
                  )
                )}
                <Pressable
                  style={{
                    position: 'absolute',
                    top: hp('50%'),
                    right: 0,
                    zIndex: 1111,
                  }}
                  onPress={() =>
                    this.props.navigation.navigate('ScheduleAppointment')
                  }>
                  <Image
                    source={Images.appointmentPlus}
                    style={{
                      alignSelf: 'center',
                      height: hp(10),
                      width: hp(10),
                    }}
                  />
                </Pressable>
              </View>
            ) : null}

            {/* {this.state.appointmentHistory.length ? (
              <FlatList
                contentContainerStyle={{marginHorizontal: hp(1)}}
                data={this.state.appointmentHistory}
                ItemSeparatorComponent={this.renderSeparator}
                renderItem={({item}) => {
                  return (
                    <TouchableOpacity
                      onPress={() => {
                        this.props.navigation.navigate('AppointmentDetail', {
                          data: item,
                        });
                      }}
                      style={{
                        borderRadius: 4,
                        flex: 1,
                        flexDirection: 'row',
                        padding: hp(2),
                      }}>
                      <View style={{flex: 1}}>
                        <Text
                          style={{
                            fontFamily: Fonts.NunitoSemiBold,
                            color: Colors.label,
                          }}>
                          {item.dateTime}
                        </Text>
                        <Text
                          style={{
                            marginTop: hp(0.5),
                            fontFamily: Fonts.NunitoBold,
                            fontSize: hp(2),
                          }}>
                          {item.physician}
                        </Text>
                      </View>
                      <View
                        style={{
                          alignSelf: 'center',
                        }}>
                        <RightIcon />
                      </View>
                    </TouchableOpacity>
                  );
                }}
              />
            ) : (
              this.state.showLoader === false &&
              this.state.appointmentHistory.length === 0 && (
                <View
                  style={{
                    flex: 1,
                    alignItems: 'center',
                    justifyContent: 'center',
                    paddingBottom: hp(10),
                    backgroundColor: Colors.BgColor,
                  }}>
                  <Image
                    source={Images.emptyIcon}
                    style={{
                      alignSelf: 'center',
                      height: hp(16),
                      width: hp(18),
                    }}
                  />
                  <Text
                    style={{
                      fontSize: hp(2),
                      fontFamily: Fonts.SourceSansBold,
                      color: Colors.noRecordFound,
                      marginTop: hp(4),
                      marginRight: hp(10),
                      marginLeft: hp(10),
                      textAlign: 'center',
                    }}>
                    No Record Found
                  </Text>
                </View>
              )
            )} */}
          </View>
        </SafeAreaView>
      </Fragment>
    );
  }
}
/* istanbul ignore next */
const mapStateToProps = ({appointmentData}) => ({
  appointmentData,
});
export default connect(mapStateToProps)(AppointmentScreen);
