import {default as Moment, default as moment} from 'moment';
import React, {Fragment, useEffect, useRef, useState} from 'react';
import {
  FlatList,
  Pressable,
  SafeAreaView,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
  Image,
  Platform,
} from 'react-native';
import CalendarStrip from 'react-native-calendar-strip';
import {showMessage} from 'react-native-flash-message';
import {Modalize} from 'react-native-modalize';
import {
  heightPercentageToDP,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import svgs from '../../../../../config/Svgs';
import {SvgCss, SvgXml} from 'react-native-svg';

import Spinner from 'react-native-loading-spinner-overlay';
import ShareSuccess from '../../../../../../assets/svg/ShareSuccess.svg';
import AppointmentService from '../../../../api/appointment';
import {getTimeSlots, getlocationsProvider} from '../../action';
import {connect, useDispatch} from 'react-redux';
import ClockBlue from '../../../../../../assets/svg/ClockBlue.svg';
import UserBlue from '../../../../../../assets/svg/UserBlue.svg';
import {Colors, Images} from '../../../../../config';
import {Fonts} from '../../../../../config/AppConfig';

const ScheduleAppointment = ({navigation, userProfileData}) => {
  console.log('====================================');
  console.log('userProfileData', userProfileData);
  console.log('====================================');
  const [selectPhysicianScreen, setSelectPhysicianScreen] = useState(true);
  const [dateScreen, setDateScreen] = useState(false);
  const [confirmationScreen, setConfirmationScreen] = useState(false);
  const [loader, setLoader] = useState(false);
  const [timeSelected, setTimeSelected] = useState(null);
  const [providerLocation, setProviderLocation] = useState(null);
  const [timeSlots, setTimeSlots] = useState([]);
  const [timeSlotSelected, setTimeSlotSelected] = useState(null);
  const [selectedPhysician, setSelectedPhysician] = useState(null);
  const [selectedDate, setSelectedDate] = useState(
    Moment(new Date()).format('yyyy-MM-DDThh:mm:ss'),
  );
  const [selectedDateUtc, setSelectedDateUtc] = useState(
    Moment(new Date()).format('yyyy-MM-DDThh:mm:ss'),
  );
  const dispatch = useDispatch();
  useEffect(() => {
    console.log('====================================');
    console.log('new date', moment(new Date()).format('YYYY-MM-DDTHH:MMz'));
    console.log('====================================');
    setLoader(true);
    AppointmentService.getlocationsProvider()
      .then(response => {
        setLoader(false);
        console.log('getlocationsProvider');
        console.log(response);
        if (response) {
          if (response.statusCode === 200) {
            console.log('====================================');
            console.log('getlocationsProvider', response.data);
            console.log('====================================');
            dispatch(getlocationsProvider(response.data));
            setProviderLocation(response.data);
          } else {
            dispatch(getlocationsProvider([]));
            setProviderLocation([]);
          }
        }
      })
      .catch(error => {
        setLoader(false);
        console.log('getlocationsProvider');
        console.log(error);
        showMessage({
          message: 'Info',
          description: 'Internal Server Error',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  }, []);

  const generateTimeSlots = (start, end, interval) => {
    const result = [];
    let currentTime =
      start / 60 < 10 ? `0${start / 60}:00` : `${start / 60}:00`;
    let endTime = end / 60 < 10 ? `0${end / 60}:00` : `${end / 60}:00`;

    while (currentTime.toString() <= endTime.toString()) {
      result.push(currentTime);
      const [hours, minutes] = currentTime.split(':');
      const date = new Date(0, 0, 0, hours, minutes);
      date.setMinutes(date.getMinutes() + interval);
      currentTime = `${date.getHours().toString().padStart(2, '0')}:${date
        .getMinutes()
        .toString()
        .padStart(2, '0')}`;
    }
    console.log('====================================');
    console.log('result', result);
    console.log('====================================');
    setTimeSlots(result);
    setLoader(false);
    // return result;
  };

  const getTimeSlotsData = (item, date) => {
    setLoader(true);
    const data = {
      providerId: item.providerId,
      locationId: item.locationId,
      appointmentDate: date,
      appointmentReasonId: 0,
    };
    console.log('====================================');
    console.log('get time slot', data);
    console.log('====================================');
    AppointmentService.getTimeSlots(data)
      .then(response => {
        setLoader(false);
        console.log('getTimeSlots');
        console.log(response);
        if (response) {
          if (response.statusCode === 200) {
            if (response.data.length > 0) {
              generateTimeSlots(
                response.data[0].workTimeStartMinute,
                response.data[0].workTimeEndMinute,
                response.data[0].appointmentSlotSizeInMinutes,
                setTimeSlotSelected(response.data[0]),
              );
            } else {
              setTimeSlots([]);
            }
          } else {
            dispatch(getTimeSlots([]));
            setTimeSlots([]);
          }
        }
      })
      .catch(error => {
        setLoader(false);
        console.log('getTimeSlots');
        console.log(error);
        showMessage({
          message: 'Info',
          description: 'Internal Server Error',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  };

  const modalize = useRef(null);
  const renderSeparator = () => {
    return (
      <View
        style={{
          display: 'flex',
          justifyContent: 'flex-end',
          flexDirection: 'row',
          marginTop: hp(1.7),
        }}>
        <View
          style={{
            borderWidth: 0.5,
            borderColor: Colors.line,
            width: Platform.OS === 'ios' ? '76%' : '77%',
          }}
        />
      </View>
    );
  };
  const handleDateSelected = date => {
    console.log('date is : ', date);

    setSelectedDate(Moment(date).format('yyyy-MM-DDThh:mm:ss'));
    setSelectedDateUtc(date);

    getTimeSlotsData(selectedPhysician, date);
  };
  function onOpen() {
    modalize.current?.open();
  }

  function onClose() {
    modalize.current?.close();
  }
  function converterTimer(date, time) {
    // Parse the date from "here1" using moment
    // console.log('tolo', JSON.stringify(date), time);
    const parsedDate = moment(date);

    // Extract the time from "here2" and set it in the parsed date
    const parsedDateTime = parsedDate.set({
      hour: moment(time, 'HH:mm').hour(),
      minute: moment(time, 'HH:mm').minute(),
      second: 0, // You can adjust this if needed
      millisecond: 0, // You can adjust this if needed
    });

    // Convert the parsed date and time to UTC
    const utcDateTime = parsedDateTime.utc().format();

    console.log('date converted is ', utcDateTime);
    return utcDateTime;
  }
  const scheduleAppointmentCall = () => {
    let end = null;
    const [hours, minutes] = timeSelected.split(':');
    const date = new Date(0, 0, 0, hours, minutes);
    date.setMinutes(
      date.getMinutes() + timeSlotSelected.appointmentSlotSizeInMinutes,
    );
    end = `${date.getHours().toString().padStart(2, '0')}:${date
      .getMinutes()
      .toString()
      .padStart(2, '0')}`;

    const startTime = `${selectedDate.split('T')[0]}T${timeSelected}`;
    const endTime = `${selectedDate.split('T')[0]}T${end}`;

    const utcStartTime = moment(startTime).utc();
    const utcEndTime = moment(endTime).utc();

    let dataForApi = {
      providerId: selectedPhysician.providerId,
      locationId: selectedPhysician.locationId,
      startDate: utcStartTime.format(),
      endDate: utcEndTime.format(),
    };
    console.log('====================================');
    console.log('dataForApi', dataForApi);
    console.log('====================================');
    console.log('====================================');
    console.log(
      'selected date and time',
      selectedDate,
      timeSelected?.startTime,
    );
    console.log('====================================');
    converterTimer(selectedDate, timeSelected?.startTime);
    AppointmentService.createAppointment(dataForApi)
      .then(response => {
        console.log('response from schedule api is here', response);
        if (response && response.statusCode === 200) {
          setLoader(false);
          onClose();
          showMessage({
            message: 'Success',
            description: 'Appointment has been saved successfully',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.green,
          });
          const eventConfig = {
            title: 'Add Event to calendar',
            // and other options
          };

          navigation.navigate('AppointmentScreen');
        } else {
          console.log('====================================');
          console.log('response error', response);
          console.log('====================================');
          alert(response.Error.ErrorMessage);
        }
      })
      .catch(err => {
        setLoader(false);
        console.log('error from api error');
        console.log(err);
        showMessage({
          message: err.title,
          description: err.detail,
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  };
  const timeDifferentiator = time => {
    const selectedDateTime = moment(selectedDateUtc._d);
    const appointmentDateTime = moment(
      `${selectedDateTime.format('YYYY-MM-DD')}T${time}`,
    );

    const currentDateTime = moment();
    if (appointmentDateTime.isBefore(currentDateTime)) {
      return true;
      // Your logic for handling past appointment time
    } else {
      return false;
      // Your logic for handling future appointment time
    }
  };

  function convertTo12HourFormat(time24) {
    console.log('====================================');
    console.log('time24', time24);
    console.log('====================================');
    // Split the time string into hours and minutes
    const [hours, minutes] = time24.split(':');

    // Parse the hours and minutes into integers
    let hoursInt = parseInt(hours, 10);
    let minutesInt = parseInt(minutes, 10);

    // Determine AM/PM
    const period = hoursInt >= 12 ? 'PM' : 'AM';

    // Convert to 12-hour format
    hoursInt = hoursInt % 12 || 12;

    // Ensure minutes are displayed with leading zero if needed
    const minutesString = minutesInt < 10 ? `0${minutesInt}` : minutesInt;

    // Construct the 12-hour format time string
    const time12 = `${hoursInt}:${minutesString} ${period}`;

    return time12;
  }

  const getBreakTime = (time, index) => {
    let breakTimeSlot = [];
    let breakTimeStart =
      timeSlotSelected.breakTimeStartMinute / 60 < 10
        ? `0${timeSlotSelected.breakTimeStartMinute / 60}:00`
        : `${timeSlotSelected.breakTimeStartMinute / 60}:00`;
    let breakTimeEnd =
      timeSlotSelected.breakTimeEndMinute / 60 < 10
        ? `0${timeSlotSelected.breakTimeEndMinute / 60}:00`
        : `${timeSlotSelected.breakTimeEndMinute / 60}:00`;
    // console.log('====================================');
    // console.log('breakTime', time);
    // console.log('====================================');
    // console.log('====================================');
    // console.log('selected provider', timeSlotSelected);
    // console.log('====================================');
    while (breakTimeStart <= breakTimeEnd) {
      breakTimeSlot.push(breakTimeStart);
      const [hours, minutes] = breakTimeStart.split(':');
      const date = new Date(0, 0, 0, hours, minutes);
      date.setMinutes(
        date.getMinutes() + timeSlotSelected.appointmentSlotSizeInMinutes,
      );
      breakTimeStart = `${date.getHours().toString().padStart(2, '0')}:${date
        .getMinutes()
        .toString()
        .padStart(2, '0')}`;
    }

    if (breakTimeSlot.includes(time)) {
      return true;
    } else {
      return false;
    }
  };

  return (
    <Fragment>
      <SafeAreaView style={{flex: 1, backgroundColor: Colors.BgColor}}>
        <Spinner
          visible={loader}
          textContent={'Please Wait....'}
          textStyle={{color: '#FFF'}}
        />
        <Modalize
          ref={modalize}
          adjustToContentHeight={true}
          backgroundColor={Colors.black2}
          withHandle={true}
          modalStyle={{
            borderTopRightRadius: 25,
            borderTopLeftRadius: 25,
          }}>
          <View
            style={{
              display: 'flex',
              alignItems: 'center',
              flexDirection: 'column',
              marginTop: hp(4),
            }}>
            <SvgCss
              style={{marginLeft: hp(2)}}
              xml={svgs.ShareSuccess}
              width={hp(4)}
              height={hp(4)}
              fill={Colors.black}
            />
            {/* <ShareSuccess /> */}
            <Text
              style={{
                fontFamily: Fonts.SourceSansBold,
                fontSize: hp(3),
                marginTop: hp(2.2),
              }}>
              Confirmation
            </Text>
          </View>
          <View
            style={{
              display: 'flex',
              alignItems: 'flex-start',
              flexDirection: 'column',
              marginTop: hp(1.5),
              marginHorizontal: hp(3),
            }}>
            <View style={{marginTop: hp(2.5)}}>
              <Text
                style={{
                  color: Colors.noRecordFound,
                  fontFamily: Fonts.SourceSansRegular,
                  fontSize: hp(2),
                }}>
                Patient Name
              </Text>
              <Text
                style={{
                  color: Colors.black,
                  fontFamily: Fonts.SFProSemibold,
                  fontSize: hp(2.2),
                }}>
                {userProfileData.fullName}
              </Text>
            </View>
            <View style={{marginTop: hp(2.5)}}>
              <Text
                style={{
                  color: Colors.noRecordFound,
                  fontFamily: Fonts.SourceSansRegular,
                  fontSize: hp(2),
                }}>
                Physician Name
              </Text>
              <Text
                style={{
                  color: Colors.black,
                  fontFamily: Fonts.SFProSemibold,
                  fontSize: hp(2.2),
                }}>
                {selectedPhysician?.providerName}
              </Text>
            </View>
            <View style={{marginTop: hp(2.5)}}>
              <Text
                style={{
                  color: Colors.noRecordFound,
                  fontFamily: Fonts.SourceSansRegular,
                  fontSize: hp(2),
                }}>
                Date/Time
              </Text>
              <Text
                style={{
                  color: Colors.black,
                  fontFamily: Fonts.SFProSemibold,
                  fontSize: hp(2.2),
                }}>
                {`${moment(selectedDate).format(
                  'MMM DD,YYYY',
                )} - ${timeSelected}`}
              </Text>
            </View>
            <View style={{marginTop: hp(2.5)}}>
              <Text
                style={{
                  color: Colors.noRecordFound,
                  fontFamily: Fonts.SourceSansRegular,
                  fontSize: hp(2),
                }}>
                Patient Email
              </Text>
              <Text
                style={{
                  color: Colors.black,
                  fontFamily: Fonts.SFProSemibold,
                  fontSize: hp(2.2),
                }}>
                {userProfileData.email}
              </Text>
            </View>
            <View style={{marginTop: hp(2.5)}}>
              <Text
                style={{
                  color: Colors.noRecordFound,
                  fontFamily: Fonts.SourceSansRegular,
                  fontSize: hp(2),
                }}>
                Patient Phone Number
              </Text>
              <Text
                style={{
                  color: Colors.black,
                  fontFamily: Fonts.SFProSemibold,
                  fontSize: hp(2.2),
                }}>
                {userProfileData.phone === null || userProfileData.phone === ''
                  ? '-'
                  : userProfileData.phone}
              </Text>
            </View>
          </View>
          <View style={{marginTop: hp(13)}}>
            <View
              style={{
                borderRadius: hp(1),
                marginHorizontal: hp(2.2),
                marginBottom: hp(3.2),
                display: 'flex',
                justifyContent: 'space-between',
                flexDirection: 'row',
              }}>
              <TouchableOpacity
                onPress={() => {
                  onClose();
                  setDateScreen(false);
                  setSelectPhysicianScreen(true);
                  setSelectedPhysician(null);
                }}
                style={{
                  borderRadius: hp(1),
                  flex: 1,
                  height: hp(6.5),
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'center',
                  alignItems: 'center',
                  backgroundColor: Colors.bleLayer3,
                }}>
                <Text
                  style={{
                    color: Colors.blueTextColor,
                    fontFamily: Fonts.SourceSansSemibold,
                    fontSize: hp(2.2),
                  }}>
                  Edit
                </Text>
              </TouchableOpacity>
              <View style={{flex: 0.1}}></View>
              <TouchableOpacity
                onPress={() => {
                  // setLoader(true);
                  scheduleAppointmentCall();
                }}
                style={{
                  borderRadius: hp(1),
                  flex: 1,

                  height: hp(6.5),
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'center',
                  alignItems: 'center',
                  backgroundColor: Colors.blueTextColor,
                }}>
                <Text
                  style={{
                    color: Colors.white,
                    fontFamily: Fonts.SourceSansSemibold,
                    fontSize: hp(2.2),
                  }}>
                  Book Appointment
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modalize>
        {/* Header */}
        <View
          style={{
            // borderWidth: 1,
            // borderColor: 'red',
            backgroundColor: Colors.BgColor,
          }}>
          <View
            style={{
              flexDirection: 'row',
              width: '100%',
              alignItems: 'center',
              height: hp(7.5),
              borderBottomWidth: 0.5,
              borderColor: Colors.BgColor,
              backgroundColor: Colors.BgColor,
            }}>
            {/* <TouchableOpacity
              onPress={() => {
                navigation.pop();
              }}>
              <Text
                style={{
                  fontFamily: 'WisemanPTSymbols',
                  marginLeft: heightPercentageToDP(2),
                  marginRight: heightPercentageToDP(1),
                  fontSize: hp(5),

                  color: Colors.black1,
                }}>
                W
              </Text>
            </TouchableOpacity> */}
            <SvgCss
              style={{marginLeft: hp(2)}}
              xml={svgs.arrowHeadLeft}
              width={hp(4)}
              height={hp(4)}
              fill={Colors.black}
              onPress={() => {
                navigation.pop();
              }}
            />
            <Text
              style={{
                fontFamily: Fonts.SourceSansSemibold,
                textAlign: 'center',
                fontSize: hp(2.5),
                color: Colors.black,
                flex: 1,
              }}>
              Schedule Appointment
            </Text>

            <View style={{flex: 0.2, alignItems: 'flex-end'}}>
              <TouchableOpacity
                onPress={() => navigation.navigate('NotificationStack')}>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'flex-start',
                    marginRight: heightPercentageToDP(2),
                  }}>
                  <Image
                    style={{
                      width: hp(2),
                      height: hp(2.5),
                      // marginRight:-20,
                      // marginHorizontal: hp(3),
                      // marginTop:10,
                    }}
                    source={Images.notification_dashboard}
                  />
                  {/* <TouchableOpacity>
                    <SvgCss
                      xml={Svgs.settings_Icon}
                      width={hp(2.2)}
                      height={hp(2.3)}
                      fill={Colors.black}
                      onPress={() => this.props.navigation.pop()}
                      style={{marginHorizontal: hp(1.5)}}
                    />
                  </TouchableOpacity> */}
                </View>
              </TouchableOpacity>
            </View>
          </View>
        </View>
        {/* select Physician */}
        <View
          style={{
            flex: 1,
            backgroundColor: Colors.white,
            marginTop: hp(2),
            borderTopLeftRadius: hp(2.5),
            borderTopRightRadius: hp(2.5),
            shadowOffset: {width: 0.5, height: 0.5},
            shadowOpacity: 0.1,
            shadowRadius: 5,
            elevation: 5,
          }}>
          {selectPhysicianScreen === true ? (
            <View>
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginTop: hp(4.2),
                  marginBottom: hp(3.5),
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansSemibold,
                    color: Colors.black,
                    fontSize: hp(2.5),
                  }}>
                  Select Physician
                </Text>
              </View>
              <FlatList
                contentContainerStyle={{
                  marginHorizontal: hp(1),
                }}
                style={{marginBottom: hp(12)}}
                data={providerLocation}
                ItemSeparatorComponent={renderSeparator}
                renderItem={({item}) => {
                  // convertTo12HourFormat(item);
                  const startTime24 =
                    item.workTimeStartMinute / 60 < 10
                      ? `0${item.workTimeStartMinute / 60}:00`
                      : `${item.workTimeStartMinute / 60}:00`;
                  const endTime24 =
                    item.workTimeEndMinute / 60 < 10
                      ? `0${item.workTimeEndMinute / 60}:00`
                      : `${item.workTimeEndMinute / 60}:00`;
                  const time24 = `${startTime24} - ${endTime24}`;
                  return (
                    <View style={{paddingTop: hp(1), flex: 1}}>
                      <TouchableOpacity
                        onPress={() => {
                          setSelectPhysicianScreen(false);
                          setDateScreen(true);
                          console.log('ok lets move', item);
                          setSelectedPhysician(item);

                          getTimeSlotsData(item, selectedDate);
                        }}>
                        <View style={{flex: 1}}>
                          <View
                            style={{
                              flexDirection: 'row',
                              marginVertical: hp(1),
                              alignItems: 'center',
                            }}>
                            <View
                              style={{
                                borderRadius: hp(1),
                                marginHorizontal: hp(2),
                                paddingVertical: hp(1.5),
                                marginTop: hp(0.5),
                                width: Platform.OS === 'ios' ? hp(6.5) : hp(7),
                                height:
                                  Platform.OS === 'android' ? hp(7) : hp(6.5),
                                display: 'flex',
                                flexDirection: 'row',
                                justifyContent: 'center',
                                alignItems: 'center',
                              }}>
                              <SvgXml
                                xml={svgs.UserBlue}
                                height="50"
                                width="50"
                                style={{
                                  marginHorizontal: hp(2),
                                }}
                              />
                              {/* <UserBlue
                                height="50"
                                width="50"
                                style={{marginHorizontal: hp(2)}}
                              /> */}
                            </View>
                            <View
                              style={{
                                flexDirection: 'column',
                                alignItems: 'flex-start',
                                justifyContent: 'space-around',
                              }}>
                              <Text
                                style={{
                                  fontSize: hp(2.2),
                                  fontFamily: Fonts.SourceSansSemibold,
                                  color: Colors.black,
                                  marginTop: hp(0.3),
                                }}>
                                {item.providerFullName}
                              </Text>
                              <View
                                style={{
                                  flexDirection: 'row',
                                  alignItems: 'center',
                                  justifyContent: 'flex-start',
                                }}>
                                <View
                                  style={{
                                    width:
                                      item.workTimeStartMinute === 0
                                        ? '70%'
                                        : '50%',
                                    borderColor: 'red',
                                    borderWidth: 0,
                                  }}>
                                  <Text
                                    style={{
                                      fontSize: hp(2),
                                      fontFamily: Fonts.SourceSansRegular,
                                      color: Colors.noRecordFound,
                                      marginTop:
                                        Platform.OS === 'ios' ? hp(0.5) : hp(0),
                                    }}>
                                    {item.specialty}
                                  </Text>
                                </View>
                                {item.workTimeStartMinute === 0 ? null : (
                                  <View
                                    style={{
                                      flexDirection: 'row',
                                      justifyContent: 'center',
                                      alignItems: 'center',
                                      borderColor: 'red',
                                      borderWidth: 0,
                                    }}>
                                    <SvgXml
                                      xml={svgs.ClockBlue}
                                      height="15"
                                      width="15"
                                      style={{
                                        marginHorizontal: hp(0.5),
                                        marginTop:
                                          Platform.OS === 'ios'
                                            ? hp(0.5)
                                            : hp(0),
                                      }}
                                    />
                                    {/* <ClockBlue
                                      height="15"
                                      width="15"
                                      style={{
                                        marginHorizontal: hp(1),
                                        marginTop:
                                          Platform.OS === 'ios'
                                            ? hp(0.5)
                                            : hp(0),
                                      }}
                                    /> */}

                                    <Text
                                      style={{
                                        fontSize: hp(1.2),
                                        fontFamily: Fonts.SourceSansRegular,
                                        color: Colors.noRecordFound,
                                        marginTop:
                                          Platform.OS === 'ios'
                                            ? hp(0.5)
                                            : hp(0),
                                      }}>
                                      {convertTo12HourFormat(
                                        time24?.split('-')[0],
                                      )}{' '}
                                      -{' '}
                                      {convertTo12HourFormat(
                                        time24?.split('-')[1],
                                      )}
                                    </Text>
                                  </View>
                                )}
                              </View>
                            </View>
                          </View>
                        </View>
                      </TouchableOpacity>
                    </View>
                  );
                }}
              />
            </View>
          ) : dateScreen === true ? (
            <ScrollView>
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginTop: hp(3),
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansSemibold,
                    color: Colors.black,
                    fontSize: hp(2.5),
                  }}>
                  Select your Date
                </Text>
              </View>
              {/* Calender */}
              <View>
                <CalendarStrip
                  scrollable
                  calendarAnimation={{type: 'sequence', duration: 2}}
                  daySelectionAnimation={{
                    type: 'background',
                    duration: 200,
                    borderWidth: 1,
                    highlightColor: Colors.blueHeadingColor,
                    borderHighlightColor: Colors.bleLayer4,
                  }}
                  style={{
                    height: hp(10),
                    width: '95%',
                    marginLeft: hp(1),
                    padding: hp(1),
                    justifyContent: 'center',
                  }}
                  innerStyle={{
                    flex: 1,
                  }}
                  calendarHeaderStyle={{color: Colors.transparent}}
                  calendarColor={Colors.white}
                  dateNumberStyle={{
                    color: Colors.black,
                    fontSize: hp(1.5),
                  }}
                  disabledDateNameStyle={{color: 'black'}}
                  disabledDateNumberStyle={{
                    color: Colors.black,
                    fontSize: hp(1.3),
                  }}
                  minDate={moment(new Date()).subtract(3, 'days')}
                  datesBlacklist={[
                    moment(new Date()).subtract(1, 'days'),
                    moment(new Date()).subtract(2, 'days'),
                    moment(new Date()).subtract(3, 'days'),
                  ]}
                  dateNameStyle={{color: Colors.black, fontSize: hp(1.3)}}
                  highlightDateNumberStyle={{
                    color: Colors.white,
                    fontSize: hp(1.5),
                  }}
                  highlightDateContainerStyle={{
                    backgroundColor: Colors.blueTextColor,
                    borderRadius: 30,

                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                  highlightDateNameStyle={{
                    color: Colors.white,
                    fontSize: hp(1.3),
                  }}
                  iconContainer={{flex: 0.02}}
                  selectedDate={selectedDate}
                  onDateSelected={date => handleDateSelected(date)}
                />
              </View>

              <View
                style={{
                  borderTopColor: Colors.line,
                  borderTopWidth: hp(0.2),
                  marginTop: hp(3),
                }}></View>
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginTop: hp(3),
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansSemibold,
                    color: Colors.black,
                    fontSize: hp(2.5),
                  }}>
                  Selected Physician
                </Text>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansRegular,
                    color: Colors.black,
                    fontSize: hp(2.2),
                    marginTop: hp(1),
                  }}>
                  {selectedPhysician?.providerFullName}
                </Text>
              </View>
              {timeSlots.length > 0 ? (
                <>
                  <View
                    style={{
                      display: 'flex',
                      flexDirection: 'row',
                      justifyContent: 'center',
                      alignItems: 'center',
                      marginTop: hp(3),
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansSemibold,
                        color: Colors.black,
                        fontSize: hp(2.5),
                      }}>
                      Select your Time
                    </Text>
                  </View>
                  <View
                    style={{
                      display: 'flex',
                      flexDirection: 'row',
                      flexWrap: 'wrap',
                      marginTop: hp(1.5),
                      marginHorizontal: hp(1),
                      justifyContent: 'flex-start',
                    }}>
                    {timeSlots?.map((item, index) => {
                      return (
                        <Pressable
                          disabled={
                            timeDifferentiator(item) ||
                            getBreakTime(item, index)
                          }
                          key={index}
                          onPress={() => {
                            console.log('iol', item);
                            setTimeSelected(item);
                          }}>
                          <View
                            style={{
                              borderWidth: 1,
                              backgroundColor:
                                timeDifferentiator(item) ||
                                getBreakTime(item, index)
                                  ? Colors.line
                                  : item === timeSelected
                                  ? Colors.blueTextColor
                                  : Colors.bleLayer4,
                              width: hp(9),
                              height: hp(6),
                              borderColor: Colors.bleLayer3,
                              margin: hp(1),
                              display: 'flex',
                              flexDirection: 'row',
                              justifyContent: 'center',
                              alignItems: 'center',
                              borderRadius: hp(1.2),
                            }}>
                            <Text
                              style={{
                                textAlign: 'center',
                                color:
                                  timeDifferentiator(item) ||
                                  getBreakTime(item, index)
                                    ? Colors.blueGrayDisableText
                                    : item === timeSelected
                                    ? Colors.white
                                    : Colors.blueTextColor,
                                fontFamily: Fonts.SourceSansRegular,
                                fontSize: hp(2.2),
                              }}>
                              {item}
                            </Text>
                          </View>
                        </Pressable>
                      );
                    })}
                  </View>
                  <View
                    style={{
                      borderRadius: hp(1),
                      marginTop: hp(4),
                      marginHorizontal: hp(4),
                      marginBottom: hp(1),
                    }}>
                    <TouchableOpacity
                      disabled={timeSlots.length <= 0 && true}
                      onPress={() => {
                        if (timeSelected != null) {
                          onOpen();
                        } else {
                          alert('Select Time');
                        }
                      }}
                      style={{
                        borderRadius: hp(1),
                        height: hp(6.5),
                        display: 'flex',
                        flexDirection: 'row',
                        justifyContent: 'center',
                        alignItems: 'center',
                        backgroundColor: Colors.blueTextColor,
                        opacity: timeSlots.length <= 0 ? 0.5 : 1,
                      }}>
                      <Text
                        style={{
                          color: Colors.white,
                          fontFamily: Fonts.SourceSansSemibold,
                          fontSize: hp(2.2),
                        }}>
                        Next
                      </Text>
                    </TouchableOpacity>
                  </View>
                </>
              ) : (
                <View
                  style={{
                    flex: 1,
                    alignItems: 'center',
                    justifyContent: 'center',
                    minHeight: '80%',
                  }}>
                  <Text
                    style={{
                      textAlign: 'center',
                      color: Colors.blueTextColor,
                      fontFamily: Fonts.SourceSansRegular,
                      fontSize: hp(2.2),
                    }}>
                    Physician is not available
                  </Text>
                </View>
              )}
            </ScrollView>
          ) : null}
        </View>
      </SafeAreaView>
    </Fragment>
  );
};
const mapStateToProps = ({userProfileData}) => ({
  userProfileData,
});
export default connect(mapStateToProps)(ScheduleAppointment);
