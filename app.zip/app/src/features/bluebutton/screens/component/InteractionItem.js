/* istanbul ignore file */
import React from 'react';
import {Text, TouchableOpacity, View} from 'react-native';

import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import InteractionIcon from '../../../../../../assets/svg/interaction.svg';
import {Colors} from '../../../../../config';
import {Fonts} from '../../../../../config/AppConfig';
import svgs from '../../../../../config/Svgs';
import {SvgCss} from 'react-native-svg';
class IntercationItem extends React.PureComponent {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <View
        style={{
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: hp(1),
        }}>
        <TouchableOpacity
          style={{
            borderRadius: 4,
            flex: 1,
            alignItems: 'center',
            justifyContent: 'center',
            flexDirection: 'row',
            width: '100%',
          }}
          onPress={this.props.action}>
          <View
            style={{
              alignItems: 'center',
              justifyContent: 'flex-start',
              flexDirection: 'row',
              flex: 1,
              padding: hp(1),
              flexWrap: 'wrap',
            }}>
            {console.log('This is the props : ', this.props)}
            <Text
              style={{
                fontFamily: Fonts.SourceSansBold,
                fontSize: hp(1.9),
                color: Colors.darkGrey1,
                textAlign: 'center',
                textTransform: 'capitalize',
              }}
              numberOfLines={0}
              ellipsizeMode="tail">
              {/* {this.props.item?.interactionOneName?.trim()} */}
              {this.props.item?.clinicalEffects}
            </Text>
            <SvgCss
              xml={svgs.InteractionIcon}
              width={hp(5)}
              height={hp(5)}
              marginRight={hp(2)}
              fill={Colors.black}
            />
            {/* <InteractionIcon style={{width: '10%', marginHorizontal: hp(1)}} /> */}
            <Text
              style={{
                fontFamily: Fonts.SourceSansBold,
                color: Colors.darkGrey1,
                fontSize: hp(1.9),
                textAlign: 'center',
                textTransform: 'capitalize',
              }}
              numberOfLines={0}
              ellipsizeMode="tail">
              {this.props.item?.interactionTwoName?.trim()}
            </Text>
          </View>
          {/* TestNonAcoTwo@gmail.com */}
          <View
            style={{
              width: '10%',
              alignSelf: 'center',
              paddingVertical: hp(1),
              justifyContent: 'flex-end',
              alignItems: 'center',
            }}>
            {/* <Text
              style={{
                fontFamily: 'WisemanPTSymbols',
                fontSize: hp(4),
                color: Colors.black1,
              }}>
              X
            </Text> */}
          </View>
        </TouchableOpacity>
      </View>
    );
  }
}

export default IntercationItem;
