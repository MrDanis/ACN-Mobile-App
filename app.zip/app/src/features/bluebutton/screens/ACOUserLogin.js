/* istanbul ignore file */
import moment from 'moment';
import React, {Fragment} from 'react';
import {
  BackHandler,
  Image,
  SafeAreaView,
  ScrollView,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import {showMessage} from 'react-native-flash-message';
import Spinner from 'react-native-loading-spinner-overlay';
import DateTimePicker from 'react-native-modal-datetime-picker';
import {
  heightPercentageToDP,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {NavigationActions} from 'react-navigation';
import {connect} from 'react-redux';
import {Colors, Images} from '../../../../config';
import {Fonts} from '../../../../config/AppConfig';
import AuthService from '../../../api/auth';
import {
  BlueButtonAccessToken,
  IsAcoUserLogin,
  removeItemValue,
  storeItem,
} from '../../../helpers/LocalStorage';

var radio_props = [
  {label: 'Part A', value: 0},
  {label: 'Part B', value: 1},
];

class ACOUserLogin extends React.PureComponent {
  static navigationOptions = {
    //To hide the ActionBar/NavigationBar
    header: null,
    headerBackTitle: '',
  };

  constructor(props) {
    super(props);
    this.state = {
      referenceNumber: '',
      startDate: moment(new Date()).format('MM/DD/yyyy'),
      planType: -1,
      mrn: '',
      isDatePickerVisible: false,
      referenceError: '',
      dateError: '',
      iSOStartDate: '',
      enableSubmitButton: false,
    };
    this.handleBackButtonClick = this.handleBackButtonClick.bind(this);
  }

  hideDatePicker() {
    this.setState({isDatePickerVisible: false});
  }

  componentDidMount(): void {
    BackHandler.addEventListener(
      'hardwareBackPress',
      this.handleBackButtonClick,
    );
    {
      this.props.userProfileData.referenceNumber
        ? this.setState({
            referenceNumber: this.props.userProfileData.referenceNumber,
          })
        : '';
    }
  }

  resetProfieStack() {
    this.props.navigation.reset(
      [NavigationActions.navigate({routeName: 'Profile'})],
      0,
    );
  }

  handleBackButtonClick() {}

  setDate(date) {
    var newDate = new Date(date);
    console.log('hours');
    console.log(newDate.getHours());
    if (newDate.getHours() === 0) {
      newDate.setDate(date.getDate() + 1);
    }

    console.log('newDate');
    console.log(newDate);
    this.setState(
      {
        startDate: moment(date).format('l'),
        dateError: '',
        iSOStartDate: newDate,
      },
      () => {
        this.hideDatePicker();
        this.enableDisbaleSubmitButton();
      },
    );
  }

  componentWillUnmount() {
    this.removeEventListener();
  }
  removeEventListener() {
    BackHandler.removeEventListener(
      'hardwareBackPress',
      this.handleBackButtonClick,
    );
  }

  enableDisbaleSubmitButton() {
    if (this.state.referenceNumber === '') {
      this.setState({enableSubmitButton: false});
    } else {
      this.setState({enableSubmitButton: true});
    }
  }

  render() {
    let gender = '';
    if (
      this.props.userProfileData.gender !== null &&
      this.props.userProfileData.gender === '1'
    ) {
      gender = 'Male';
    } else if (
      this.props.userProfileData.gender !== null &&
      this.props.userProfileData.gender === '2'
    ) {
      gender = 'Female';
    } else {
      gender = '';
    }
    return (
      <Fragment>
        <SafeAreaView style={{flex: 1}}>
          <Spinner
            visible={this.state.showLoader}
            textContent={'Please Wait....'}
            textStyle={{color: '#FFF'}}
          />
          <DateTimePicker
            isVisible={this.state.isDatePickerVisible}
            onCancel={() => this.hideDatePicker()}
            mode={'date'}
            maximumDate={new Date()}
            titleIOS={'Pick a Date'}
            value={new Date(this.state.startDate)}
            date={new Date(this.state.startDate)}
            titleStyle={{fontSize: hp(2)}}
            onConfirm={date => {
              console.log('====================================');
              console.log(
                'startDate',
                moment(date).format('YYYY-MM-DDTHH:mm:ss'),
              );
              console.log('====================================');
              this.setState({startDate: date, iSOStartDate: new Date(date)});
              this.hideDatePicker();
            }}
          />
          <ScrollView>
            <View style={{flex: 1}}>
              <View
                style={{
                  width: '100%',
                  alignItems: 'center',
                  justifyContent: 'center',
                  height: hp(7.5),
                  borderBottomWidth: 0.5,
                  borderColor: Colors.lightGrey,
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansSemibold,
                    fontSize: hp(2.5),
                    color: Colors.black1,
                    flex: 1,
                    textTransform: 'capitalize',
                  }}>
                  Authorization
                </Text>
              </View>
              <View style={{paddingHorizontal: hp(2)}}>
                <View
                  style={{
                    flexDirection: 'row',
                    marginTop: hp(3),
                    marginBottom: hp(2),
                  }}>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansSemibold,
                      fontSize: hp(2.2),
                      flex: 1,
                      color: Colors.black1,
                    }}>
                    First Name
                  </Text>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      marginLeft: heightPercentageToDP(5),
                      fontSize: hp(2.2),
                      color: Colors.black2,
                      textTransform: 'capitalize',
                    }}>
                    {this.props.userProfileData.firstName !== null
                      ? this.props.userProfileData.firstName
                      : ''}
                  </Text>
                </View>
                <View
                  style={{
                    height: 1,
                    width: '100%',
                    backgroundColor: Colors.line,
                    marginRight: hp(2),
                  }}
                />
                <View
                  style={{
                    flexDirection: 'row',
                    marginTop: hp(2),
                    marginBottom: hp(2),
                  }}>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansSemibold,
                      fontSize: hp(2.2),
                      flex: 1,
                      color: Colors.black1,
                    }}>
                    Last Name
                  </Text>
                  <Text
                    key={Math.random().toString(36).substr(2, 9)}
                    style={{
                      marginRight: hp(0.5),
                      fontFamily: Fonts.SourceSansRegular,
                      fontSize: hp(2.2),
                      color: Colors.black2,
                      textTransform: 'capitalize',
                    }}>
                    {this.props.userProfileData.lastName !== null
                      ? this.props.userProfileData.lastName
                      : ''}
                  </Text>
                </View>
                <View
                  style={{
                    height: 1,
                    width: '100%',
                    backgroundColor: Colors.line,
                    marginRight: hp(2),
                  }}
                />
                <View
                  style={{
                    flexDirection: 'row',
                    marginTop: hp(2),
                    marginBottom: hp(2),
                  }}>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansSemibold,
                      fontSize: hp(2.2),
                      flex: 1,
                      color: Colors.black1,
                    }}>
                    D.O.B
                  </Text>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      marginLeft: heightPercentageToDP(5),
                      fontSize: hp(2.2),
                      color: Colors.black2,
                    }}>
                    {this.props.userProfileData.dateOfBirth === null ||
                    this.props.userProfileData.dateOfBirth === ''
                      ? ''
                      : moment(
                          new Date(this.props.userProfileData.dateOfBirth),
                        ).format('L')}
                  </Text>
                </View>
                <View
                  style={{
                    height: 1,
                    width: '100%',
                    backgroundColor: Colors.line,
                    marginRight: hp(2),
                  }}
                />
                <View
                  style={{
                    flexDirection: 'row',
                    marginTop: hp(2),
                    marginBottom: hp(2),
                  }}>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansSemibold,
                      fontSize: hp(2.2),
                      flex: 1,
                      color: Colors.black1,
                    }}>
                    Gender
                  </Text>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      marginLeft: heightPercentageToDP(5),
                      fontSize: hp(2.2),
                      color: Colors.black2,
                    }}>
                    {gender}
                  </Text>
                </View>
              </View>
              <View style={{margin: hp(3), flex: 1}}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansSemibold,
                    fontSize: hp(3),
                    marginBottom: hp(2),
                    color: Colors.black1,
                  }}>
                  Access
                </Text>
                <View
                  style={[
                    {
                      width: '100%',
                      marginTop: hp(2),
                      alignSelf: 'center',
                      alignItems: 'flex-start',
                      justifyContent: 'center',
                    },
                  ]}>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontSize: hp(2),
                      color: Colors.noRecordFound,
                      marginTop: hp(2),
                    }}>
                    Start Date
                  </Text>
                  <TouchableOpacity
                    style={{
                      width: '100%',
                      borderRadius: 10,
                      height: 50,
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderWidth: 1,
                      borderColor: Colors.lightGrey,
                    }}
                    onPress={() => {
                      this.setState({isDatePickerVisible: true});
                    }}>
                    <View
                      style={{
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        padding: hp(1),
                        flex: 1,
                        width: '100%',
                        borderRadius: 10,
                        backgroundColor: Colors.white,
                      }}>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansRegular,
                          fontSize: hp(2.2),
                          color: Colors.black,
                          justifyContent: 'center',
                        }}>
                        {moment(this.state.startDate).format('MM/DD/yyyy')}
                      </Text>
                      <Image
                        source={Images.calenderIcon}
                        style={{
                          tintColor: Colors.forgetColor,
                          height: hp(3),
                          width: hp(3),
                          marginRight: hp(1),
                          alignSelf: 'center',
                        }}
                      />
                    </View>
                  </TouchableOpacity>
                </View>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansRegular,
                    fontSize: hp(2),
                    color: Colors.noRecordFound,
                    marginTop: hp(2),
                  }}>
                  MRN
                </Text>
                <TextInput
                  onChangeText={MRN => this.setState({referenceNumber: MRN})}
                  value={this.state.referenceNumber}
                  style={{
                    borderWidth: 1,
                    borderColor: Colors.line,
                    borderRadius: 8,
                    backgroundColor: Colors.white,
                    fontFamily: Fonts.SourceSansRegular,
                    paddingVertical: hp(1.3),
                    paddingHorizontal: hp(2),
                    fontSize: hp(2),
                    marginTop: hp(0.2),
                    height: 50,
                    color: Colors.blueGrayDisableText,
                  }}
                  selectTextOnFocus={false}
                  editable={
                    this.props.userProfileData.referenceNumber !== null &&
                    this.props.userProfileData.referenceNumber !== ''
                      ? false
                      : true
                  }
                  onSubmitEditing={this.enableDisbaleSubmitButton()}
                  selectionColor={Colors.blueTextColor}
                  placeholder=""
                  placeholderTextColor={Colors.blueGrayDisableText}
                />

                <TouchableOpacity
                  disabled={!this.state.enableSubmitButton}
                  onPress={() => {
                    let data = {};
                    data.referenceNumber = this.state.referenceNumber;
                    data.startDate = moment(
                      new Date(this.state.startDate),
                    ).format('YYYY-MM-DDThh:mm:ss.SSS');

                    this.setState({showLoader: true});

                    AuthService.loginACOUser(data)
                      .then(response => {
                        console.log('response');
                        console.log(response);
                        this.setState({showLoader: false});
                        if (response && response.statusCode === 200) {
                          this.removeEventListener();
                          removeItemValue(BlueButtonAccessToken);
                          storeItem(IsAcoUserLogin, 'true').then(login => {
                            console.log(login);
                          });
                          this.props.navigation.navigate('Medical History', {
                            screen: 'MainDashboard',
                          });
                        } else {
                          showMessage({
                            message: 'Information',
                            description:
                              'Authentication Failed. Provided information is not verified.',
                            type: 'default',
                            icon: {icon: 'info', position: 'left'},
                            backgroundColor: Colors.red,
                          });
                        }
                      })
                      .catch(err => {
                        this.setState({showLoader: false});
                        console.log('error');
                        console.log(err);
                        showMessage({
                          message: 'Information',
                          description: 'Server Error',
                          type: 'default',
                          icon: {icon: 'info', position: 'left'},
                          backgroundColor: Colors.red,
                        });
                      });
                  }}
                  style={{
                    width: '100%',
                    marginTop: hp(4),
                    height: hp(7),
                    alignSelf: 'center',
                    borderRadius: 5,
                    marginHorizontal: '5%',
                    borderColor: Colors.cyan,
                    justifyContent: 'center',
                    alignItems: 'center',
                    backgroundColor:
                      this.state.enableSubmitButton === true
                        ? Colors.blueTextColor
                        : Colors.blueGrayDisableBG,
                  }}>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansBold,
                      fontSize: hp(2),
                      color:
                        this.state.enableSubmitButton === true
                          ? Colors.white
                          : Colors.blueGrayDisableText,
                    }}>
                    Submit
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          </ScrollView>
        </SafeAreaView>
      </Fragment>
    );
  }
}

const mapStateToProps = ({userProfileData}) => ({
  userProfileData,
});
export default connect(mapStateToProps)(ACOUserLogin);
