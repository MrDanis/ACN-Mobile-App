import { View, Text,Pressable,SafeAreaView } from 'react-native'
import React,{useState} from 'react'
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';
import MainHeader from '../mycare/components/MainHeader'
const SpecificEMRdata = ({navigation,route}) => {
    console.log('Data from the parent screen is : ',route.params)
    const [modalesAndData,setmodalesAndData]= useState({
      modules:[
          {subModuleId:'1',moduleName:'Pulse Rate'},
          {subModuleId:'2',moduleName:'Height'},
          {subModuleId:'3',moduleName:'Weight'},
          {subModuleId:'4',moduleName:'Blood Pressure'},
          {subModuleId:'5',moduleName:'Temprature'},
      ],
      selectedModule:''
    })
    return (
     <SafeAreaView style={{flex: 1, backgroundColor: '#F8F8F8'}}>
      <MainHeader
        name={`${route?.params?.selectedEmrName}(${route?.params?.selectedEmrModule?.moduleName})`}
        navigation={navigation}
        notifDisabled={true}
      >
      {
               modalesAndData.modules.map((item,index)=>{
                return(
                <Pressable style={{padding:hp(2),width:'50%'}} key={index} >
                  <Text >
                     {item?.moduleName}
                  </Text>
                </Pressable>
                )
              })
           }
      </MainHeader>
     
    </SafeAreaView>
  )
}

export default SpecificEMRdata