import { View, Text,Pressable,SafeAreaView } from 'react-native'
import React,{useState} from 'react'
import { heightPercentageToDP as hp } from 'react-native-responsive-screen'
import colors from '../../../config/Colors'
import MainHeader from '../mycare/components/MainHeader'
const EmrSelection = ({navigation}) => {
   const [EmrDataList,setEmrDataList] = useState([
    {
        name:'Epic',
        icon:'',
        id:'1'
    },
    {
        name:'Cerner',
        icon:'',
        id:'2'
    },
    {
        name:'Ethina',
        icon:'',
        id:'3'
    },
    {
        name:'RCM EMR',
        icon:'',
        id:'4'
    },
   ])
  return (
    <SafeAreaView style={{flex: 1,borderColor:'red',borderWidth:0}}>
      <View style={{borderColor:'red',borderWidth:0,flex:1}}>
        <MainHeader
          name={'EMR Selection'}
          navigation={navigation}
          notifDisabled={true}
        >
        <View style={{flex:1,display:'flex',flexDirection:'column',alignItems:'flex-start',padding:hp(1)}}>
       {
        EmrDataList.map((item,index)=>{
            return(
              <Pressable 
                style={{width:'100%',backgroundColor:colors.blueTextColor,borderRadius:10,borderColor:'red',padding:hp(1.25),marginVertical:hp(1.25)}} 
                onPress={()=>{navigation.navigate('SpecificEmr',{ EMrName:item.name,EmrId:item.id})}}>
                <Text style={{textAlign:'center',color:colors.white,fontWeight:'500',fontSize:hp(2)}}>
                    {item?.name}
                </Text>
              </Pressable>     
            )
        })
       }
    </View>
        </MainHeader>
      </View>
  </SafeAreaView>
  )
}

export default EmrSelection