import { View, Text, Pressable,SafeAreaView } from 'react-native'
import React,{useState} from 'react'
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';
import MainHeader from '../mycare/components/MainHeader';
const SpecificEmr = ({navigation,route}) => {
  console.log('data from the previous screen is : ',route.params);
  const [modalesAndData,setmodalesAndData]= useState({
    modules:[
        {moduleId:'1',moduleName:'Vitals'},
        {moduleId:'2',moduleName:'Medications'},
        {moduleId:'3',moduleName:'Assesments'},
        {moduleId:'4',moduleName:'Appointments'},
        {moduleId:'5',moduleName:'Labs'},
    ],
    selectedModule:''
  })
  return (
    <SafeAreaView style={{flex: 1}}>
   
           <MainHeader
            name={`${route?.params?.EMrName}`}
            navigation={navigation}
            notifDisabled={true}
           >
            {
               modalesAndData.modules.map((item,index)=>{
                return(
                <Pressable style={{padding:hp(2),width:'50%'}} key={index} onPress={()=>{navigation.navigate('SpecificEMRdata',{selectedEmrModule:item,selectedEmrName:route?.params?.EMrName})}}>
                  <Text >
                     {item?.moduleName}
                  </Text>
                </Pressable>
                )
              })
           }
           </MainHeader>
      </SafeAreaView>
  )
}

export default SpecificEmr