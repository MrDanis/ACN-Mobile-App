/* istanbul ignore file */
export const cmCallEndStatus = (
  state = {isCallEndedbeforeJoining: false, roomId: {roomId: '', userId: ''}},
  action,
) => {
  console.log('Action before joining the call is : ', action);
  switch (action.type) {
    case 'UPDATE_CALL_END_STATUS':
      return action.status;
    default:
      return state;
  }
};
export const cmStatusData = (state = {}, action) => {
  switch (action.type) {
    case 'UPDATE_STATUS':
      return action.status;
    default:
      return state;
  }
};
export const signalRStatus = (state = false, action) => {
  switch (action.type) {
    case 'SIGNALR_CONNECTION':
      return action.status;
    default:
      return state;
  }
};
export const splashSignalRStatus = (state = false, action) => {
  switch (action.type) {
    case 'SPLASH_SIGNALR_CONNECTION':
      return action.status;
    default:
      return state;
  }
};
export const careCoordinationContactList = (state = false, action) => {
  switch (action.type) {
    case 'CARECOORDINATION_CONTACT_LIST':
      return action.data;
    default:
      return state;
  }
};
export const physicianContactList = (state = false, action) => {
  switch (action.type) {
    case 'PHYSICIAN_CONTACT_LIST':
      return action.data;
    default:
      return state;
  }
};
export const historyData = (state = [], action) => {
  switch (action.type) {
    case 'CLEAR_DATA':
      state.pop();
      return [];
    case 'HISTORY_DATA':
      
      return state.length ? [...action.data, ...state] : action.data;
    case 'SEND_MESSAGE':
      return [action.message, ...state];
    default:
      return state;
  }
};
export const unReadMessageData = (state = false, action) => {
  switch (action.type) {
    case 'Unread_Messages_Data':
      return action.data;
    default:
      return state;
  }
};
export const newMessage = (state = false, action) => {
  switch (action.type) {
    case 'NEW_MESSAGE':
      return {...state, message: action.data};
    default:
      return state;
  }
};
