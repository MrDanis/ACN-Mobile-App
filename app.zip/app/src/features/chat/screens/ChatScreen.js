import AsyncStorage from '@react-native-async-storage/async-storage';
import he from 'he';
import moment from 'moment';
import React from 'react';
import {
  FlatList,
  Image,
  Keyboard,
  Platform,
  RefreshControl,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Animated,
} from 'react-native';
import AudioRecorderPlayer, {
  AVEncoderAudioQualityIOSType,
  AVEncodingOption,
  AudioEncoderAndroidType,
  AudioSourceAndroidType,
} from 'react-native-audio-recorder-player';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import {PERMISSIONS, RESULTS, check, request} from 'react-native-permissions';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import {SvgCss} from 'react-native-svg';
import {connect} from 'react-redux';
import {Colors, Svgs} from '../../../../config';
import {Fonts} from '../../../../config/AppConfig';
import colors from '../../../../config/Colors';
import {isSameDay} from '../../../helpers/Common';
import {AuthToken, retrieveItem} from '../../../helpers/LocalStorage';
import {
  GetChatHistory,
  sendMessagetoCM,
  updateReadStatus,
  eventEmitter,
} from '../../../helpers/signalR/SignalRService';
import {clearData} from '../actions';
import Header from '../components/Header';
import images from '../../../../config/Images';
import ChatService from '../../../api/chat';
import Slider from 'react-native-slider';
import RNFS from 'react-native-fs';
import Sound from 'react-native-sound';
// create a component
var paegNo = 0;
var myRef = null;
var arrHistory = [];
Platform.OS === 'ios' && Sound.setCategory('Playback');
export class ChatScreen extends React.PureComponent {
  static navigationOptions = {
    //To hide the ActionBar/NavigationBar
    header: null,
    headerBackTitle: 'Messages',
  };
  constructor(props) {
    super(props);
    console.log(
      'this is the data thats being recieved in the chat component',
      props,
    );
    console.log('User Signature from redux is : ', this.props.getUserSiganture);
    this.state = {
      patientId:
        this.props.getUserSiganture === undefined ||
        this.props.getUserSiganture === null ||
        Object.keys(this.props.getUserSiganture).length === 0
          ? `PAT_${this.props.homeApiData?.common?.patientId}_${this.props.homeApiData?.common?.acoKey}`
          : this.props.getUserSiganture,
      isLoading: false,
      refreshing: false,
      arrMessage: [],
      customPagenatorList: {
        dataList: [],
        pageNo: 0,
      },
      currentMessage: '',
      stickyHeaderIndices: [0],
      status: 0,
      showText: false,
      height: 0,
      pageNumber: 0,
      scrolling: true,
      isCareCordinator: props?.route?.params?.care,
      doctorInitials: props?.route?.params?.data?.name
        ? props?.route?.params?.data?.name
          ? props?.route?.params?.data?.name.split(' ')[0][0] +
            ' ' +
            (props?.route?.params?.data?.name.split(' ')[1][0] === undefined
              ? props?.route?.params?.data?.name.split(' ')[2][0]
              : props?.route?.params?.data?.name.split(' ')[1][0])
          : ''
        : props?.route?.params?.physicianInitials,
      userInitials: props?.userProfileData?.fullName
        ? props?.userProfileData?.fullName.split(' ')[0][0] +
          ' ' +
          (props?.userProfileData?.fullName.split(' ')[1][0] === undefined
            ? props?.userProfileData?.fullName.split(' ')[2][0]
            : props?.userProfileData?.fullName.split(' ')[1][0])
        : '',
      selectedCareManagerID: props?.route?.params?.selectedCareManagerID,
      selectedCareManagerName: props?.route?.params?.care
        ? props?.route?.params?.data?.name
        : props?.route?.params?.data?.physicianName,
      isRecording: false,
      isPlaying: false,
      isPaused: false,
      isPlayingMessageId: null,
      recordPath: '',
      isLoggingIn: false,
      recordSecs: 0,
      recordTime: '00:00',
      currentPositionSec: 0,
      durationSec: 0,
      playTime: '00:00',
      duration: '00:00',
      waveformData: new Array(32).fill(1),
      timeStampVn: null,
    };
    this.sound = null;
    this.playbackInterval = null;
    this.audioRecorderPlayer = new AudioRecorderPlayer();
    this.audioRecorderPlayer.setSubscriptionDuration(0.09);
    this.animationRefs = this.state.waveformData.map(
      () => new Animated.Value(1),
    );
  }
  /* istanbul ignore next */
  handleNewMessageEffect(prevProps) {
    console.log(
      ' new messagre recieved newMessageEffect',
      prevProps.newMessage.message,
      this.props.newMessage.message,
    );
    if (
      this.props?.newMessage?.message?.applicationSource === 1 &&
      this.props.newMessage.message.senderId ===
        this.state.selectedCareManagerID
    ) {
      console.log(
        'updating read status with message id ',
        `${this.props.newMessage.message.id}`,
        'and with care id of',
        this.state.selectedCareManagerID,
      );
      updateReadStatus(
        `${this.props?.newMessage?.message?.id}`,
        this.state.selectedCareManagerID,
      );
    }
  }
  checkMicrophonePermission = async () => {
    const permission = Platform.select({
      ios: PERMISSIONS.IOS.MICROPHONE,
      android: PERMISSIONS.ANDROID.RECORD_AUDIO,
    });

    const result = await check(permission);

    if (result === RESULTS.DENIED) {
      const requestResult = await request(permission);
      console.log('Microphone permission request result: ', requestResult);
    } else if (result === RESULTS.GRANTED) {
      console.log('Microphone permission granted');
      return true;
    } else {
      console.log('Permission status: ', result);
      return false;
    }
  };
  uploadVoiceNote = async audioPath => {
    // thing need to be sent
    // url duration and time
    console.log('here in sending ');

    ChatService.uploadVoiceNote(audioPath).then(response => {
      let jsonofvn = '';
      try {
        const payloadForVn = {
          filePath: response.data.filePath,
          signatureStampVn: this.state.timeStampVn,
        };
        jsonofvn = JSON.stringify(payloadForVn);
        console.log(jsonofvn, 'jsonofvn');
      } catch (error) {
        console.log('err', error);
      }

      console.log('upload response', response);
      if (response.data.error === false) {
        console.log('upload successful', response.data.filePath);
        sendMessagetoCM(
          {
            senderId: this.state.patientId,
            slectedCmName: this.state?.selectedCareManagerName,
          },
          this.props?.userProfileData,
          this.state?.selectedCareManagerID,
          null,
          jsonofvn,
          6,
        );
      } else {
        console.log('upload failed');
      }
    });
    // Log FormData for debugging
    // for (let [key, value] of formData.entries()) {
    //   console.log('form data', key, value);
    // }

    // const authToken = await retrieveItem(AuthToken);
    // console.log('auth token audiooo', authToken);
    // try {
    //   // Make the POST request using fetch
    //   const response = await fetch(
    //     'https://uatpatientengagementapi.wmi360.com/api/Chat/SaveVoiceNotes',
    //     {
    //       method: 'POST',
    //       headers: {
    //         accept: 'text/plain',
    //         Authorization: `Bearer ${authToken}`, // Replace with your token
    //         'Content-Type': 'multipart/form-data',
    //       },
    //       body: formData, // Attach the FormData as the body
    //     },
    //   );
    //   console.log('response audio', response.json());

    //   // Check if the request was successful
    //   if (!response.ok) {
    //     throw new Error(`HTTP error! Status: ${response.status}`);
    //   }

    //   // Parse the response
    //   const responseData = await response.json();
    //   console.log('Upload successful:', responseData);
    //   return responseData;
    // } catch (error) {
    //   console.error('Error uploading voice note:', error);
    //   throw error;
    // }
  };
  onStartRecord = async () => {
    console.log('recording started ... ');
    // const path = `${RNFS.DocumentDirectoryPath}/hello.m4a`; for android
    let tempStamp = new Date().toISOString();
    const path = `${tempStamp}.m4a`;
    this.setState({timeStampVn: tempStamp});

    const audioSet = {
      AudioEncoderAndroid: AudioEncoderAndroidType.AAC,
      AudioSourceAndroid: AudioSourceAndroidType.MIC,
      AVEncoderAudioQualityKeyIOS: AVEncoderAudioQualityIOSType.high,
      AVNumberOfChannelsKeyIOS: 2,
      AVFormatIDKeyIOS: AVEncodingOption.aac,
    };
    console.log('audioSet', audioSet);
    try {
      const uri = await this.audioRecorderPlayer.startRecorder(path, audioSet);
      this.audioRecorderPlayer.addRecordBackListener(e => {
        const amplitude = Math.random() * 30;
        let newWaveform = [...this.state.waveformData];
        newWaveform.shift(); // Remove the oldest value
        newWaveform.push(amplitude); // Add the new value
        this.setState({waveformData: newWaveform});
        this.animationRefs.forEach((anim, i) => {
          Animated.timing(anim, {
            toValue: newWaveform[i],
            duration: 100,
            useNativeDriver: false,
          }).start();
        });
        console.log('the audio eee', e);
        this.setState({
          isRecording: true,
          recordSecs: e.currentPosition,
          recordTime: this.audioRecorderPlayer
            .mmssss(Math.floor(e.currentPosition))
            .slice(0, -3),
        });
      });
      console.log(`uri audio: ${uri}`);
    } catch (error) {
      console.log('Error recording voice note:', error);
    }
  };
  handleRecordedVoice = async send => {
    const result = await this.audioRecorderPlayer.stopRecorder();
    this.audioRecorderPlayer.removeRecordBackListener();
    this.setState({
      isRecording: false,
      recordSecs: 0,
      recordTime: 0,
      waveformData: new Array(32).fill(1),
    });

    console.log('this is the result of audio recording ', result);
    if (send) {
      console.log('sendig rec');
      this.uploadVoiceNote(result);
    }
  };

  onTogglePlay = async item => {
    console.log('toggling play item ', item.message);
    const fileName = `${item.signatureStampVn}.m4a`;
    const localPath = `${RNFS.DocumentDirectoryPath}/${fileName}`;
    if (this.state.isPlaying || this.state.isPaused) {
      if (this.state.isPlaying) {
        // Pause the audio
        this.sound.pause(() => {
          console.log('Playback paused');
          clearInterval(this.playbackInterval); // Stop updating position
          this.setState({isPlaying: false, isPaused: true});
        });
      } else if (this.state.isPaused) {
        // Resume from paused state
        this.sound.play(success => {
          if (success) {
            console.log('Playback finished successfully');
            clearInterval(this.playbackInterval);
            this.setState({
              isPlaying: false,
              isPaused: false,
              isPlayingMessageId: null,
              currentPositionSec: 0,
              playTime: '00:00',
            });
            this.sound = null;
          } else {
            console.log('Playback failed due to audio decoding errors');
          }
        });
        this.setState({isPlaying: true, isPaused: false});
        this.startPositionUpdater(); // Resume updating position
        console.log('Playback resumed');
      }
    } else {
      // Start playing a new audio
      try {
        const fileExists = await RNFS.exists(localPath);
        console.log('File exists:', fileExists, 'Path:', localPath);
        if (!fileExists) {
          console.log(
            `Downloading audio for message ${item.signatureStampVn}...`,
          );
          const download = RNFS.downloadFile({
            fromUrl: item.message,
            toFile: localPath,
          });
          await download.promise;
          console.log('Download complete:', localPath);
        }

        const stats = await RNFS.stat(localPath);
        console.log('File stats:', stats);
        if (stats.size === 0) throw new Error('File is empty');

        this.sound = new Sound(localPath, '', error => {
          if (error) {
            console.log('Failed to load sound', error);
            return;
          }

          const durationSec = this.sound.getDuration();
          console.log('Duration in seconds:', durationSec);

          this.sound.play(success => {
            if (success) {
              console.log('Playback finished successfully');
            } else {
              console.log('Playback failed due to audio decoding errors');
            }
            clearInterval(this.playbackInterval);
            this.setState({
              isPlaying: false,
              isPaused: false,
              isPlayingMessageId: null,
              currentPositionSec: 0,
              playTime: '00:00',
            });
            this.sound = null;
          });

          this.setState({
            isPlaying: true,
            isPaused: false,
            isPlayingMessageId: item.id,
            duration: this.formatTime(durationSec),
            durationSec: durationSec,
          });

          this.startPositionUpdater();
        });
      } catch (error) {
        console.log('Error in playback process:', error);
      }
    }
  };
  startPositionUpdater = () => {
    if (this.playbackInterval) clearInterval(this.playbackInterval);
    this.playbackInterval = setInterval(() => {
      if (this.sound && this.state.isPlaying) {
        this.sound.getCurrentTime((seconds, isPlaying) => {
          if (isPlaying) {
            this.setState({
              currentPositionSec: seconds,
              playTime: this.formatTime(seconds),
            });
          }
        });
      }
    }, 100); // Update every 100ms for smooth slider movement
  };
  seekTo = async value => {
    if (this.sound) {
      this.sound.setCurrentTime(value);
      this.setState({
        currentPositionSec: value,
        playTime: this.formatTime(value),
      });
      console.log('Seeked to:', value);
    }
  };
  // Helper to format time (e.g., "00:05" from seconds)
  formatTime = seconds => {
    const minutes = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${minutes < 10 ? '0' : ''}${minutes}:${
      secs < 10 ? '0' : ''
    }${secs}`;
  };

  // Optional: Update play time every second
  updatePlayTime = () => {
    if (this.sound && this.state.isPlaying) {
      this.sound.getCurrentTime(seconds => {
        this.setState({playTime: this.formatTime(seconds)});
      });
      setTimeout(this.updatePlayTime, 1000);
    }
  };
  handleMessageUpdate = data => {
    arrHistory.forEach(obj => {
      if (typeof obj.isRead !== 'undefined') {
        obj.isRead = true; // Only update if isRead exists
      }
    });
  };
  componentDidMount() {
    console.log('Here in the component did mount ');
    myRef = this;
    eventEmitter.on('messageReadStatusUpdate', this.handleMessageUpdate);
    this.loadHistory();
  }
  componentDidUpdate(prevProps, prevState) {
    if (prevProps.newMessage?.message !== this.props.newMessage?.message) {
      this.handleNewMessageEffect(prevProps);
    }
    let resultString = '';
    if (prevState.arrMessage !== this.state.arrMessage) {
      let filterChatData = [...this.state.arrMessage].filter(
        item =>
          (item.senderId === this.state.patientId &&
            item.receiverId === this.state.selectedCareManagerID) ||
          (item.senderId === this.state.selectedCareManagerID &&
            item.receiverId === this.state.patientId),
      );
      console.log('Filter chat data ', filterChatData);
      //gathering ids for updating unread status
      filterChatData.forEach(item => {
        console.log('this is the item in the current loop', item);
        if (
          item.senderId === this.state.selectedCareManagerID &&
          item.receiverId === this.state.patientId &&
          item.isRead === false
        ) {
          // Add the ID to the result string
          resultString += (resultString ? ',' : '') + item.id;
        }
      });
      console.log('this is the resultant id array', resultString);
      if (resultString !== '') {
        updateReadStatus(resultString, this.state.selectedCareManagerID);
      }
      this.createHistoryList([...filterChatData].reverse(), true);
    }
  }
  componentWillUnmount() {
    if (this.sound) {
      this.sound.stop();
      this.sound.release();
    }
    eventEmitter.off('messageReadStatusUpdate', this.handleMessageUpdate);
    if (this.playbackInterval) clearInterval(this.playbackInterval);
  }
  /* istanbul ignore next */
  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.historyData !== prevState.arrMessage) {
      console.log('getDerivedStateFromProps nextProps', nextProps.historyData);
      return {arrMessage: nextProps.historyData};
    } else {
      return null;
    }
  }
  /* istanbul ignore next */
  showText(text) {
    myRef.setState({
      showText: text,
    });
  }
  /* istanbul ignore next */
  onRefresh() {
    console.log('====================================');
    console.log('here in refresh');
    console.log('====================================');
    this.setState({scrolling: false});
    this.loadHistory();
  }
  replaceSymbolsWithHtmlEntities(text) {
    return he.decode(text);
  }
  /* istanbul ignore next */
  async loadHistory() {
    let sign = await AsyncStorage.getItem('signature');
    console.log('Signature in load history function is : ', sign);
    this.props.dispatch(clearData([]));
    this.setState({arrMessage: []});
    arrHistory = [];
    GetChatHistory(this.state.patientId, this.state.selectedCareManagerID);
    console.log(
      'payload for loading history care cordinator is ',
      this.state.isCareCordinator,
      'sender id',
      this.state.patientId,
      'reciver id',
      this.state?.selectedCareManagerID,
    );
  }
  // ============Function responsible for the custom pagination (START)
  handleCustomPagenation(data, limit) {
    const result = [];
    for (let i = 0; i < data.length; i += limit) {
      const chunk = data.slice(i, i + limit); // Take a slice of the array
      result.push(chunk);
    }
    let paginatorData = {
      dataList: result,
      paegNo: 0,
    };
    this.setState(prevState => ({
      customPagenatorList: {
        ...prevState.customPagenatorList, // Spread previous customPagenatorList
        pageNo: paginatorData.paegNo, // Update pageNo
        dataList: [
          ...prevState.customPagenatorList.dataList,
          paginatorData.dataList,
        ],
      },
    }));

    // this.setState({...this.state,customPagenatorList:paginatorData});
    this.createHistoryList(
      [...result].reverse()[this.state.customPagenatorList.pageNo],
      true,
    );
    console.log(
      'Resulten array is : ',
      result.length,
      'data at Zero : ',
      result[0],
      'Result Data : ',
      result,
    );
    console.log(
      'data for the custom pagination is : ',
      data,
      'and limit of the list is : ',
      limit,
    );
  }
  // =============Function responsible for the custom pagination (END)
  // =============Handle scroll to Top (START)===============
  handleScroll = event => {
    // Check if the user has scrolled to the top
    // console.log('Top data is : ', this.state.customPagenatorList);
    // console.log('Event is : ', event);
    if (event.nativeEvent.contentOffset.y <= 0) {
      // this.setState({...customPagenatorList,paegNo:this.state.customPagenatorList.pageNo+1});

      let tempObj = {
        dataList: this.state.customPagenatorList.dataList,
        pageNo: this.state.customPagenatorList.pageNo + 1,
      };
      console.log('Data before change is : ', tempObj);
      // this.setState(prevState => ({
      //   customPagenatorList: {
      //     ...prevState.customPagenatorList, // Spread previous customPagenatorList
      //     pageNo: prevState.customPagenatorList.pageNo + 1, // Update pageNo
      //     dataList: [...prevState.customPagenatorList.dataList, ...tempObj.dataList],
      //   },
      // }))
      // console.log(this.state.customPagenatorList,'Temp data object is : ',tempObj);
      // console.log('Next page list is : ',[...this.state.customPagenatorList.dataList[this.state.customPagenatorList.pageNo]])
      // this.createHistoryList([...this.state.customPagenatorList.dataList[this.state.customPagenatorList.pageNo]].reverse(), true);

      // Alert.alert('We will implement the scroll to top');
      // loadMoreData(); // Trigger loading when at the top
    }
  };
  // =============Handle scroll to Top (END)===============
  /* istanbul ignore next */
  createHistoryList(data, flag) {
    console.log('==========createHistoryList==========================');
    console.log('messages history data', data);
    console.log('====================================');
    arrHistory = [];
    data.map(item => {
      if (!arrHistory.length) {
        item.showTime = true;
        var date = {};
        date.isDate = true;
        date.timeStamp = item.timeStamp;
        arrHistory.push(date);
      } else if (
        !isSameDay(
          new Date(arrHistory[arrHistory.length - 1].timeStamp),
          new Date(item.timeStamp),
        )
      ) {
        arrHistory[arrHistory.length - 1].showTime = true;
        item.showTime = true;
        var date = {};
        date.isDate = true;
        date.timeStamp = item.timeStamp;
        arrHistory.push(date);
      } else {
        arrHistory[arrHistory.length - 1].showTime = true;
        item.showTime = true;
      }
      arrHistory.push(item);
    });
    var arr = [];
    arrHistory.map(obj => {
      if (obj.isDate) {
        arr.push(arrHistory.indexOf(obj));
      }
    });
    // console.log('====================================');
    // console.log('sticky header', arr);
    // console.log('====================================');
    this.setState({
      stickyHeaderIndices: arr,
    });
    console.log('history array', arrHistory);
    // console.log('Page Number', this.state.pageNumber);
  }
  containsHTML = text => /<[^>]*>/.test(text);
  renderItem(item, patientId, acoKey, careManagerId) {
    // console.log('====================================');
    // console.log('item in flatLissst', item);
    //this line need to be taken cared of
    // console.log('====================================');
    // console.log(`here in the masseges : ${this.state.patientId}`);

    return (
      <>
        {item.isDate && item.isDate === true ? (
          <View
            style={{
              justifyContent: 'center',
              alignItems: 'center',
              marginVertical: hp(2),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                color: Colors.noRecordFound,
                fontSize: hp(1.7),
              }}>
              {moment(item.timeStamp).format('MM/DD/YYYY')}
            </Text>
          </View>
        ) : null}
        {/* {console.log(
          item,
          'Sender ID : ',
          item.senderId,
          'Reviver ID : ',
          careManagerId,
        )}
        {console.log('this is the item chat', item, careManagerId)} */}
        {/* {console.log('doc initials', this.state.doctorInitials)} */}
        {item.senderId &&
          item.senderId.toLowerCase() === careManagerId?.toLowerCase() &&
          item.showTime &&
          item.showTime === true && (
            <View
              style={{
                marginVertical: hp(1.5),
                marginHorizontal: hp(2),
                flexDirection: 'row',
                alignItems: 'flex-end',
              }}>
              {this.state.doctorInitials === '' ? (
                <Image
                  source={require('../../../../../assets/images/user_logo.png')}
                  style={{
                    width: 35,
                    height: 35,
                    borderColor: 'red',
                    borderWidth: 0,
                  }}
                />
              ) : (
                <View
                  style={{
                    width: 35,
                    height: 35,
                    borderColor: 'red',
                    backgroundColor: '#A9B4C2',
                    borderWidth: 0,
                    borderRadius: 50,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                  <Text style={{fontSize: hp(1.5), color: 'black'}}>
                    {this.state.doctorInitials}
                  </Text>
                </View>
              )}
              <View
                style={{
                  marginLeft: hp(1.5),
                  backgroundColor:
                    item.senderId === careManagerId.toLowerCase()
                      ? Colors.bleLayer4
                      : Colors.blueGrayDisableBG,
                  borderRadius: 8,
                  maxWidth: '85%',
                }}>
                <Text
                  style={{
                    color: Colors.headingColor,
                    fontSize: hp(2),
                    fontFamily: Fonts.SourceSansRegular,
                    paddingHorizontal: hp(2),
                    paddingTop: hp(1),
                    // borderWidth: 1,
                  }}>
                  {this.replaceSymbolsWithHtmlEntities(item?.message)}
                </Text>
                <View style={{display: 'flex', flexDirection: 'row'}}>
                  <Text
                    style={{
                      color: Colors.noRecordFound,
                      fontSize: hp(1.5),
                      fontFamily: Fonts.SourceSansRegular,
                      paddingHorizontal: hp(1),
                      paddingBottom: hp(1),
                      paddingTop: hp(1),
                      // borderWidth: 1,
                    }}>
                    {moment
                      .utc(moment.utc(item.timeStamp).format())
                      .local()
                      .format('hh:mm A')}
                  </Text>
                </View>
              </View>
            </View>
          )}
        {/* reciever */}
        {item.senderId === this.state.patientId &&
          item.showTime &&
          item.showTime === true && (
            <View
              style={{
                marginVertical: hp(1.5),
                marginHorizontal: hp(1.5),
                flexDirection: 'row',
                alignItems: 'flex-end',
                alignSelf: 'flex-end',
              }}>
              <View
                style={{
                  marginLeft: hp(2),
                  marginRight: hp(1),
                  backgroundColor:
                    item.senderId === this.state.patientId
                      ? Colors.blueGrayDisableBG
                      : Colors.white,
                  borderRadius: 8,
                  maxWidth: '85%',
                  // borderWidth: 1,
                  display: 'flex',
                  flexDirection: 'row',
                }}>
                {item.messageType === 6 && (
                  <View style={{justifyContent: 'center', paddingLeft: hp(1)}}>
                    <TouchableOpacity onPress={() => this.onTogglePlay(item)}>
                      <Image
                        source={
                          this.state.isPlaying &&
                          this.state.isPlayingMessageId === item.id
                            ? images.pauseIconChat
                            : images.playIconChat
                        }
                        style={{
                          height: hp(4.5),
                          width: hp(4.5),
                        }}
                      />
                    </TouchableOpacity>
                  </View>
                )}
                <View style={{}}>
                  {/* put seek bar here no extra design just seek bar  */}
                  {item.messageType === 6 ? (
                    <View
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        paddingHorizontal: hp(2),
                        // borderWidth: 1,
                        paddingTop: hp(2),
                      }}>
                      <Slider
                        style={{width: 100, height: 25}}
                        minimumValue={0}
                        maximumValue={this.state.durationSec}
                        minimumTrackTintColor={Colors.blueTextColor}
                        maximumTrackTintColor="#D9D9D9"
                        thumbTintColor={Colors.TextColor}
                        thumbStyle={{width: 12, height: 12}}
                        value={
                          item.id === this.state.isPlayingMessageId
                            ? this.state.currentPositionSec
                            : 0
                        }
                        onSlidingComplete={value => this.seekTo(value)}
                      />
                      <Text
                        style={{
                          fontSize: hp(1.5),
                          color: Colors.noRecordFound,
                          marginLeft: hp(0.5),
                        }}>
                        {item.id === this.state.isPlayingMessageId
                          ? this.state.playTime
                          : '00:00'}
                      </Text>
                    </View>
                  ) : (
                    <Text
                      style={{
                        color: Colors.headingColor,
                        fontSize: hp(2),
                        fontFamily: Fonts.SourceSansRegular,
                        paddingHorizontal: hp(2),
                        paddingTop: hp(1),
                        paddingBottom: hp(1),
                      }}>
                      {item.message}
                    </Text>
                  )}
                  <View
                    style={{
                      flexDirection: 'row',
                      // justifyContent: 'flex-start',
                    }}>
                    <Text
                      style={{
                        color: Colors.noRecordFound,
                        fontSize: hp(1.5),
                        fontFamily: Fonts.SourceSansRegular,
                        paddingLeft: hp(2),
                        paddingRight: hp(0.7),
                        paddingBottom: hp(1),
                        // paddingTop: hp(1),
                        // borderWidth: 1,
                      }}>
                      {moment
                        .utc(moment.utc(item.timeStamp).format())
                        .local()
                        .format('hh:mm A')}
                    </Text>
                    {item.hasOwnProperty('isRead') ? (
                      <Image
                        source={
                          item.isRead === true
                            ? require('../../../../../assets/images/read.png')
                            : require('../../../../../assets/images/sent.png')
                        }
                        style={{
                          width: 15,
                          height: 15,
                          borderColor: 'red',
                          // borderWidth: 1,
                          marginRight: hp(1),
                          // marginLeft: hp(0.5),
                          alignSelf: 'center',
                        }}
                      />
                    ) : null}
                  </View>
                </View>
              </View>
              {this.state.userInitials === '' ? (
                <Image
                  source={require('../../../../../assets/images/user_logo.png')}
                  style={{
                    width: 35,
                    height: 35,
                    borderColor: 'red',
                    borderWidth: 0,
                  }}
                />
              ) : (
                <View
                  style={{
                    width: 35,
                    height: 35,
                    borderColor: 'red',
                    backgroundColor: '#D4E1F3',
                    borderWidth: 0,
                    borderRadius: 50,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                  <Text style={{fontSize: hp(1.5), color: 'black'}}>
                    {this.state.userInitials}
                  </Text>
                </View>
              )}
            </View>
          )}
      </>
    );
  }

  renderBody = () => {
    return (
      <View
        style={{
          height: Platform.OS === 'ios' ? '85%' : '90%',
          borderTopLeftRadius: 30,
          borderTopRightRadius: 30,
          backgroundColor: Colors.white,
          shadowOffset: {width: 0.5, height: 0.5},
          shadowOpacity: 0.1,
          shadowRadius: 8,
          paddingTop: hp(2),
          border: 0,
          borderColor: 'red',
        }}>
        <FlatList
          ref="flatList"
          onContentSizeChange={() => {
            this.state.scrolling ? this.refs.flatList.scrollToEnd() : null;
          }}
          data={arrHistory}
          keyExtractor={(item, index) => index.toString()}
          stickyHeaderIndices={this.state.stickyHeaderIndices}
          contentContainerStyle={{paddingTop: 10, paddingBottom: 10}}
          renderItem={({item, index}) =>
            this.renderItem(
              item,
              this.props.homeApiData?.common?.patientId,
              this.props.homeApiData?.common?.acoKey,
              this.state.selectedCareManagerID,
            )
          }
          onScroll={this.handleScroll}
          refreshControl={
            <RefreshControl
              //refresh control used for the Pull to Refresh
              refreshing={this.state.refreshing}
              onRefresh={this.onRefresh.bind(this)}
            />
          }
        />
      </View>
    );
  };

  changeText(value) {
    const result = value.replace(/[^a-zA-Z0-9.,?!@#%&*-=+:; ]/gi, '');

    this.setState({currentMessage: result});
  }
  render() {
    return (
      <View style={styles.container}>
        <StatusBar
          backgroundColor={Colors.white}
          barStyle="dark-content"
          hidden={false}
        />
        <Header
          navigation={this.props.navigation}
          careData={this.props.route.params}
          homeApiData={this.props.homeApiData.common}
          activeCmID={this.state.selectedCareManagerID}
          resetCount={this.props?.route?.params?.resetCounter}
          nameToReset={this.props?.route?.params?.data?.name}>
          <KeyboardAwareScrollView
            style={{flex: 1}}
            contentContainerStyle={{
              flex: 1,
              marginTop: hp(2),
              backgroundColor: Colors.white,
              borderTopLeftRadius: hp(3),
              borderTopRightRadius: hp(3),
              shadowOffset: {width: 0.5, height: 0.5},
              shadowOpacity: 0.15,
              shadowRadius: 5,
              elevation: 5,
            }}
            extraScrollHeight={Platform.isPad ? 100 : 40}
            scrollEnabled={false}
            enableAutomaticScroll={true}
            keyboardShouldPersistTaps="handled">
            {arrHistory.length ? (
              this.renderBody()
            ) : (
              <ScrollView
                contentContainerStyle={{
                  flex: 1,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
                refreshControl={
                  <RefreshControl
                    refreshing={this.state.refreshing}
                    onRefresh={this.onRefresh.bind(this)}
                  />
                }>
                <Text
                  style={{
                    fontSize: hp(2),
                    color: Colors.noRecordFound,
                    fontFamily: Fonts.SourceSansRegular,
                  }}>
                  No Message Available.
                </Text>
              </ScrollView>
            )}
            {/* <View
              style={{
                borderWidth: 1,
                display: 'flex',
                flexDirection: 'row',
                justifyContent: 'space-evenly',
              }}>
              <TouchableOpacity onPress={() => this.onStartPlay()}>
                <Text>Play</Text>
              </TouchableOpacity>
              <Text>{this.state.recordTime}</Text>
              <TouchableOpacity>
                <Text>Delete</Text>
              </TouchableOpacity>
            </View>
            <View>
              <Text>{this.state.playTime}</Text>
            </View> */}
            <View
              style={{
                backgroundColor: Colors.white,
                // borderRadius: 1,
                borderWidth: 0,
                borderColor: 'purple',
                borderTopColor: Colors.transparent,

                height:
                  this.state.currentMessage === ''
                    ? hp(8)
                    : Math.max(1, this.state.currentMessage.length),
                maxHeight: hp(10),
                minHeight: hp(8),
                borderWidth: 0,
                borderColor: 'red',
              }}>
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  alignItems: 'flex-start',
                  backgroundColor: Colors.white,
                  borderTopColor: Colors.transparent,
                  margin: hp(1),
                  borderWidth: 0,
                  height:
                    this.state.currentMessage === ''
                      ? hp(8.5)
                      : Math.max(1, this.state.currentMessage.length),
                  maxHeight: hp(15),
                  minHeight: hp(8),
                }}>
                <View
                  style={{
                    flex: 7,
                    marginBottom: hp(2),
                    borderColor: 'green',
                    borderWidth: 0,
                    height:
                      this.state.currentMessage.length <= 50
                        ? hp(5)
                        : Math.max(2, this.state.currentMessage.length),
                    borderRadius: 10,
                    backgroundColor: Colors.blueGrayDisableBG,
                    alignItems:
                      this.state.currentMessage.length > 60
                        ? 'flex-end'
                        : 'center',
                    flexDirection: 'row',
                    marginHorizontal: hp(0),
                    marginVertical:
                      this.state.currentMessage.length > 60 ? hp(2) : 0,
                  }}>
                  {this.state.isRecording ? (
                    <View
                      style={{
                        display: 'flex',
                        flexDirection: 'row',
                        gap: 12,
                      }}>
                      <TouchableOpacity
                        onPress={() => this.handleRecordedVoice(false)}>
                        <Image
                          source={images.binMessage}
                          style={{
                            alignSelf: 'center',
                            height: hp(3.8),
                            width: hp(3.8),
                            marginLeft: wp(2),
                          }}
                        />
                      </TouchableOpacity>
                      <View
                        style={{
                          flexDirection: 'row',
                          // height: hp(4),
                          alignItems: 'center',
                          // borderWidth: 1,
                        }}>
                        {this.animationRefs.map((anim, index) => (
                          <Animated.View
                            key={index}
                            style={{
                              width: wp(0.6),
                              height: anim,
                              backgroundColor: colors.darkgrey,
                              marginHorizontal: 2,
                              borderRadius: 2,
                            }}
                          />
                        ))}
                      </View>
                      <Text
                        style={{alignSelf: 'center', color: colors.darkgrey}}>
                        {this.state.recordTime}
                      </Text>
                    </View>
                  ) : (
                    <TextInput
                      placeholder="write your message"
                      style={{
                        width: '95%',
                        borderColor: 'red',
                        // borderWidth: 1,
                        paddingHorizontal: hp(1),
                        fontFamily: Fonts.SourceSansRegular,
                        fontSize: hp(2),
                        color: Colors.black4,
                      }}
                      multiline={true}
                      onChangeText={value => {
                        this.changeText(value);
                      }}
                      value={this.state.currentMessage}
                    />
                  )}
                </View>
                <TouchableOpacity
                  style={{
                    flex: 1,
                    marginTop: hp(0.5),
                    alignItems: 'flex-end',
                    paddingRight: hp(1),
                    // borderWidth: 1,
                  }}
                  onPress={() => {
                    console.log('btn pressed');
                    if (
                      this.state.currentMessage &&
                      this.state.currentMessage.trim() !== ''
                    ) {
                      if (this.containsHTML(this.state.currentMessage)) {
                        showMessage({
                          message: 'Info',
                          description: 'Cannot enter Html tags',
                          type: 'default',
                          icon: {icon: 'info', position: 'left'},
                          backgroundColor: Colors.red,
                        });
                        return;
                      } else {
                        sendMessagetoCM(
                          {
                            senderId: this.state.patientId,
                            slectedCmName: this.state?.selectedCareManagerName,
                          },
                          this.props?.userProfileData,
                          this.state?.selectedCareManagerID,
                          null,
                          this.state?.currentMessage,
                          1,
                        );
                        this.setState({currentMessage: ''});
                        console.log(
                          'this is the state after the message has been sent',
                          this.state.currentMessage,
                        );
                        this.refs.current?.scrollToEnd();
                        Keyboard.dismiss();
                      }
                    } else {
                      // this.trying();

                      console.log('fire audio recording ');
                      this.state.isRecording
                        ? this.handleRecordedVoice(true)
                        : this.onStartRecord();
                    }
                  }}>
                  {this.state.currentMessage || this.state.isRecording ? (
                    <Image
                      source={require('../../../../../assets/images/icon_send_up.png')}
                      style={{
                        width: 35,
                        height: 35,
                      }}
                    />
                  ) : (
                    <View
                      style={{
                        // borderWidth: 1,
                        padding: hp(0.79),
                        backgroundColor: colors.blueTextColor,
                        borderRadius: hp(5),
                      }}>
                      <SvgCss
                        style={
                          {
                            // marginLeft: hp(2),
                            // borderWidth: 1,
                          }
                        }
                        xml={Svgs.Icon_mic_White}
                        width={hp(2.7)}
                        height={hp(2.7)}
                        fill={Colors.black}
                      />
                    </View>
                  )}
                </TouchableOpacity>
              </View>
            </View>
          </KeyboardAwareScrollView>
        </Header>
      </View>
    );
  }
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.BgColor,
    // borderWidth: 1,
    // borderColor: 'red',
    paddingBottom: hp(2),
  },
});

const mapStateToProps = ({
  homeApiData,
  historyData,
  cmStatusData,
  userProfileData,
  getUserSiganture,
  newMessage,
}) => ({
  homeApiData,
  historyData,
  cmStatusData,
  userProfileData,
  getUserSiganture,
  newMessage,
});

//make this component available to the app
export default connect(mapStateToProps)(ChatScreen);
