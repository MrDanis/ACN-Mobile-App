import React, {useEffect, useState} from 'react';
import {
  FlatList,
  Image,
  SafeAreaView,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {useSelector} from 'react-redux';
import images from '../../../../../app/config/Images';
import {Colors} from '../../../../config';
import colors from '../../../../config/Colors';
import PharmacyContactCard from '../components/PharmacyContactCard';
import ProvidersContactCard from '../components/ProvidersContactCard';
import {messageEmitter} from '../../../helpers/signalR/SignalRService';
import ChatService from '../../../api/chat';
import LabService from '../../../api/lab';
import MedicationService from '../../../api/medication';
import CareCoordinationContactCard from '../components/CareCoordinationContactCard';
import {
  getUserRecentChats,
  updateUserChatStatus,
} from '../../../helpers/signalR/SignalRService';
import {connect} from 'react-redux';
import PushNotification from 'react-native-push-notification';
import Spinner from 'react-native-loading-spinner-overlay';
import {useFocusEffect} from '@react-navigation/native';
const Contacts = ({navigation, route, newMessage}) => {
  const homeApiData = useSelector(state => state.homeApiData);
  const patientId = useSelector(state => state.getUserSiganture);
  const unreadChatCount = useSelector(state => state?.unReadMessageData);

  const userProfileData = useSelector(state => state.userProfileData);
  const [provider, setProvider] = useState(
    userProfileData?.source === 0 ? true : false,
  );
  const [pharmacy, setPharmacy] = useState(
    userProfileData?.source === 1 ? true : false,
  );
  const [lab, setLab] = useState(false);
  const [careCoordinator, setcCreCoordinator] = useState(false);
  const [careCoordinatorConatctList, setCareCoordinatorConatctList] =
    useState(null);
  const [providerContactList, setProviderContactList] = useState(null);
  const [pharmaciesContactList, setPharmaciesContactList] = useState(null);
  const [labsContactList, setLabsContactList] = useState(null);

  console.log('====================================');
  console.log(newMessage, 'userProfileData', userProfileData);
  console.log('====================================');
  useFocusEffect(
    React.useCallback(() => {
      console.log('rouets form the push is :', route.params);
      if (route?.params?.isVedioCalling) {
        navigation.navigate('Video');
      }

      ChatService.getPhysicianContacts().then(response => {
        console.log('====================================');
        console.log('getPhysicianContacts', response);
        console.log('====================================');
        setProviderContactList(response.data);
      });
      // ChatService.getCareCoordinationContacts().then(response => {
      //   console.log('====================================');
      //   console.log('getCareCoordinationContacts', response);
      //   console.log('====================================');
      //   const updatedContacts = reorderArray(newMessage, response.data);
      //   console.log('this is the sorted array of corns ', updatedContacts);

      //   setCareCoordinatorConatctList(updatedContacts);
      // });
      MedicationService.getPatientPharmacy().then(response => {
        console.log('====================================');
        console.log('getCarePharmaciesContacts', response);
        console.log('====================================');
        setPharmaciesContactList(response.data);
      });
      LabService.getLabsContactData().then(response => {
        console.log('====================================');
        console.log('getCareLabsContacts', response);
        console.log('====================================');
        setLabsContactList(response.data);
      });
    }, []),
  );
  useEffect(() => {
    // console.log('rouets form the push is :', route.params);
    // if (route?.params?.isVedioCalling) {
    //   navigation.navigate('Video');
    // }
    // ChatService.getPhysicianContacts().then(response => {
    //   console.log('====================================');
    //   console.log('getPhysicianContacts', response);
    //   console.log('====================================');
    //   setProviderContactList(response.data);
    // });
    // ChatService.getCareCoordinationContacts().then(response => {
    //   console.log('====================================');
    //   console.log('getCareCoordinationContacts', response);
    //   console.log('====================================');
    //   const updatedContacts = reorderArray(newMessage, response.data);
    //   console.log('this is the sorted array of corns ', updatedContacts);
    //   setCareCoordinatorConatctList(updatedContacts);
    // });
    // MedicationService.getPatientPharmacy().then(response => {
    //   console.log('====================================');
    //   console.log('getCarePharmaciesContacts', response);
    //   console.log('====================================');
    //   setPharmaciesContactList(response.data);
    // });
    // LabService.getLabsContactData().then(response => {
    //   console.log('====================================');
    //   console.log('getCareLabsContacts', response);
    //   console.log('====================================');
    //   setLabsContactList(response.data);
    // });
    // getUserRecentChats(patientId, userProfileData.phone, 0);
  }, []);

  const reorderArray = (message, array) => {
    // Return a new array without mutating the original one
    if (message && message.senderName) {
      const matchedIndex = array.findIndex(
        contact => contact.name === message.senderName,
      );

      // If a match is found, create a new array with the matched object at the start
      if (matchedIndex !== -1) {
        const [matchedObject] = array.splice(matchedIndex, 1); // Remove the matched object
        return [matchedObject, ...array]; // Add it to the start of a new array
      }
    }

    // If no match, return the original array unchanged
    return array;
  };
  const renderSeparator = () => {
    return (
      <View
        style={{
          height: 1,
          width: '75%',
          backgroundColor: Colors.lightGrey,
          // marginLeft: hp(8),
          alignSelf: 'flex-end',
          marginVertical: hp(1),
        }}
      />
    );
  };
  return (
    <SafeAreaView style={{backgroundColor: Colors.BgColor}}>
      <View
        style={{
          backgroundColor: Colors.BgColor,
          borderColor: 'green',
          borderWidth: 0,
        }}>
        <View
          style={{
            flexDirection: 'row',
            backgroundColor: colors.BgColor,
            width: '95%',
            height: hp(12),
            marginLeft: hp(1.5),
            paddingTop: hp(3),
            justifyContent: 'space-evenly',
          }}>
          {userProfileData?.source === 0 && (
            <TouchableOpacity
              onPress={() => {
                setLab(false);
                setPharmacy(false);
                setProvider(true);
                setcCreCoordinator(false);
              }}>
              <View
                style={{
                  flexDirection: 'column',
                  height: hp(20),
                  alignItems: 'center',
                }}>
                <Image
                  source={images.providerIcon}
                  style={{
                    tintColor:
                      provider === true ? colors.blueBackground : colors.black2,
                  }}
                />
                <Text
                  style={{
                    color:
                      provider === true ? colors.blueBackground : colors.black2,
                    fontSize: hp(1.9),
                  }}>
                  {'Providers'}
                </Text>
              </View>
            </TouchableOpacity>
          )}
          <TouchableOpacity
            onPress={() => {
              setLab(false);
              setPharmacy(true);
              setProvider(false);
              setcCreCoordinator(false);
            }}>
            <View
              style={{
                flexDirection: 'column',
                height: hp(20),
                alignItems: 'center',
              }}>
              <Image
                source={images.pharmacyIcon}
                style={{
                  tintColor:
                    pharmacy === true ? colors.blueBackground : colors.black2,
                }}
              />
              <Text
                style={{
                  color:
                    pharmacy === true ? colors.blueBackground : colors.black2,
                  fontSize: hp(1.9),
                }}>
                {'Pharmacies'}
              </Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              setLab(true);
              setPharmacy(false);
              setProvider(false);
              setcCreCoordinator(false);
            }}>
            <View
              style={{
                flexDirection: 'column',
                height: hp(20),
                alignItems: 'center',
              }}>
              <Image
                source={images.labIcon}
                past-1707
                style={{
                  tintColor:
                    lab === true ? colors.blueBackground : colors.black2,
                }}
              />
              <Text
                style={{
                  color: lab === true ? colors.blueBackground : colors.black2,
                  fontSize: hp(1.9),
                }}>
                {'Labs'}
              </Text>
            </View>
          </TouchableOpacity>

          {/* {userProfileData?.source === 1 && (
            <TouchableOpacity
              onPress={() => {
                setLab(false);
                setPharmacy(false);
                setProvider(false);
                setcCreCoordinator(true);
              }}>
              <View
                style={{
                  flexDirection: 'column',
                  height: hp(20),
                  alignItems: 'center',
                }}>
                <Image
                  source={images.careCoordinatorIcon}
                  style={{
                    tintColor:
                      careCoordinator === true
                        ? colors.blueBackground
                        : colors.black2,
                  }}
                />
                <Text
                  style={{
                    paddingTop: hp(1.3),
                    color:
                      careCoordinator === true
                        ? colors.blueBackground
                        : colors.black2,
                    fontSize: hp(1.9),
                  }}>
                  {'Care Coordinator'}
                </Text>
              </View>
            </TouchableOpacity>
          )} */}
        </View>
        <View style={{backgroundColor: Colors.BgColor, height: '90%'}}>
          <View
            style={{
              backgroundColor: Colors.white,
              height: '90%',
              borderTopLeftRadius: 20,
              borderTopRightRadius: 20,
              shadowOffset: {width: 0.5, height: 0.5},
              shadowOpacity: 0.1,
              shadowRadius: 8,
              paddingTop: hp(2),
            }}>
            <FlatList
              contentContainerStyle={{backgroundColor: Colors.white}}
              contentInset={{bottom: 25}} // Add some bottom inset
              contentOffset={{x: 0, y: -25}}
              ItemSeparatorComponent={renderSeparator}
              data={
                pharmacy
                  ? pharmaciesContactList
                  : lab
                  ? labsContactList
                  : providerContactList
              }
              renderItem={({item}) => {
                return (
                  <TouchableOpacity
                    disabled={userProfileData?.isEMR ? true : false}
                    onPress={() => {
                      {
                      }
                      console.log('data rander item is : ', item);
                    }}
                    style={{
                      flex: 1,
                      height: hp(9),
                      justifyContent: 'space-evenly',
                      marginHorizontal: hp(2),
                      borderColor: 'red',
                      borderWidth: 0,
                    }}>
                    {provider ? (
                      <ProvidersContactCard
                        iconimage={require('../../../../../assets/images/avatar_contacts.png')}
                        name={item.physicianName}
                        physicianSpeciality={item.physicianSpeciality}
                        phoneNumber={item.phoneNo}
                        data={item}
                        navigation={navigation}
                        care={careCoordinator}
                        // chatFeatureEnabled={
                        //   homeApiData?.common?.chatFeatureEnabled
                        // }
                        chatFeatureEnabled={
                          userProfileData?.isEMR ? false : true
                        }
                      />
                    ) : (
                      <PharmacyContactCard
                        item={item}
                        type={pharmacy ? 'ph' : 'lab'}
                      />
                    )}
                  </TouchableOpacity>
                );
              }}
            />
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
};
const mapStateToProps = ({newMessage}) => ({
  newMessage,
});
export default connect(mapStateToProps)(Contacts);
