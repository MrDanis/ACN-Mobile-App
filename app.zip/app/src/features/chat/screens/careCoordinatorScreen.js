import React, {useEffect, useState, useMemo} from 'react';
import {
  FlatList,
  Image,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {useSelector} from 'react-redux';
import images from '../../../../../app/config/Images';
import {Colors, Images, Svgs} from '../../../../config';
import colors from '../../../../config/Colors';
import Spinner from 'react-native-loading-spinner-overlay';

import {messageEmitter} from '../../../helpers/signalR/SignalRService';
import ChatService from '../../../api/chat';

import CareCoordinationContactCard from '../components/CareCoordinationContactCard';
import {
  getUserRecentChats,
  updateUserChatStatus,
} from '../../../helpers/signalR/SignalRService';
import {connect} from 'react-redux';
import PushNotification from 'react-native-push-notification';
import MainHeader from '../../mycare/components/MainHeader';

import {SvgCss} from 'react-native-svg';
import {Fonts} from '../../../../config/AppConfig';
import {showMessage} from 'react-native-flash-message';

const careCoordinatorScreen = ({navigation, route, newMessage}) => {
  const homeApiData = useSelector(state => state.homeApiData);
  const patientId = useSelector(state => state.getUserSiganture);
  const unreadChatCount = useSelector(state => state?.unReadMessageData);

  const userProfileData = useSelector(state => state.userProfileData);
  const [loader, setLoader] = useState(false);

  const [careCoordinator, setcCreCoordinator] = useState(false);
  const [careCoordinatorConatctList, setCareCoordinatorConatctList] = useState(
    [],
  );

  console.log('====================================');
  console.log(newMessage, 'userProfileData', userProfileData);
  console.log('====================================');
  useEffect(() => {
    setLoader(true);
    console.log('rouets form the push is :', route.params);
    if (route?.params?.isVedioCalling) {
      navigation.navigate('Video');
    }

    ChatService.getCareCoordinationContacts()
      .then(response => {
        console.log('====================================');
        console.log('getCareCoordinationContacts', response);
        console.log('====================================');
        const updatedContacts = reorderArray(newMessage, response?.data);
        console.log('this is the sorted array of corns ', updatedContacts);

        setCareCoordinatorConatctList(updatedContacts);
        setLoader(false);
      })
      .catch(error => {
        setLoader(false);

        console.log('get care coordinator  Error', error);
        console.log(error);
        showMessage({
          message: 'Info',
          description: 'Internal Server Error',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });

    // getUserRecentChats(patientId, userProfileData.phone, 0);
  }, []);
  useEffect(() => {
    if (newMessage.message) {
      // Call the function to update unread message count
      updateUnreadCount(newMessage.message);
    }
  }, [newMessage.message]);
  const resetCounter = recievedName => {
    console.log(
      'for resetting  message counter',
      careCoordinatorConatctList,
      recievedName,
    );
    const updatedContacts = careCoordinatorConatctList.map(contact => {
      if (contact.name === recievedName) {
        // If contact matches, increment the unread message count by 1
        console.log('resetting the unread count');
        setBadgeCount(0);
        return {...contact, unreadCount: 0};
      }
      return contact; // Otherwise, return the contact as is
    });

    // Update the state with the modified contacts list
    setCareCoordinatorConatctList(updatedContacts);
  };
  const setBadgeCount = count => {
    PushNotification.setApplicationIconBadgeNumber(count);
  };
  const updateUnreadCount = newMessage => {
    // Find the contact whose unread count needs to be updated
    const updatedContacts = careCoordinatorConatctList.map(contact => {
      if (contact.name === newMessage.senderName) {
        // If contact matches, increment the unread message count by 1
        console.log('updating the unread count');
        setBadgeCount(contact.unreadCount + 1);
        return {...contact, unreadCount: contact.unreadCount + 1};
      }
      return contact; // Otherwise, return the contact as is
    });
    setCareCoordinatorConatctList(updatedContacts);
    ChatService.getCareCoordinationContacts().then(response => {
      console.log('====================================');
      console.log('getCareCoordinationContacts', response);
      console.log('====================================');
      const sortedContacts = reorderArray(newMessage, response.data);
      console.log('this is the sorted array of corns ', sortedContacts);

      setCareCoordinatorConatctList(sortedContacts);
    });
    console.log('new message arrieved in update read count', updatedContacts);
  };

  const reorderArray = (message, array) => {
    // Return a new array without mutating the original one
    if (message && message.senderName) {
      const matchedIndex = array.findIndex(
        contact => contact.name === message.senderName,
      );

      // If a match is found, create a new array with the matched object at the start
      if (matchedIndex !== -1) {
        const [matchedObject] = array.splice(matchedIndex, 1); // Remove the matched object
        return [matchedObject, ...array]; // Add it to the start of a new array
      }
    }

    // If no match, return the original array unchanged
    return array;
  };
  const renderSeparator = () => {
    return (
      <View
        style={{
          height: 1,
          width: '75%',
          backgroundColor: Colors.lightGrey,
          // marginLeft: hp(8),
          alignSelf: 'flex-end',
          marginVertical: hp(1),
        }}
      />
    );
  };
  return (
    <SafeAreaView style={{backgroundColor: Colors.BgColor, flex: 1}}>
      <MainHeader navigation={navigation} name={'Care Coordinator'}>
        <Spinner
          visible={loader}
          textContent={'Loading...'}
          textStyle={{color: '#FFF'}}
        />
        <View
          style={{
            backgroundColor: Colors.BgColor,

            marginTop: hp(2.5),
          }}>
          <View style={{backgroundColor: Colors.BgColor, height: '94%'}}>
            <View
              style={{
                backgroundColor: Colors.white,
                height: hp(79),
                borderTopLeftRadius: 20,
                borderTopRightRadius: 20,
                shadowOffset: {width: 0.5, height: 0.5},
                shadowOpacity: 0.1,
                shadowRadius: 8,
                paddingTop: hp(2),
              }}>
              <FlatList
                contentContainerStyle={{backgroundColor: Colors.white}}
                contentInset={{bottom: 25}} // Add some bottom inset
                contentOffset={{x: 0, y: -25}}
                ItemSeparatorComponent={renderSeparator}
                data={careCoordinatorConatctList}
                renderItem={({item}) => {
                  return (
                    <TouchableOpacity
                      onPress={() => {
                        {
                          navigation.navigate('Chat', {
                            data: item,
                            care: careCoordinator,
                            selectedCareManagerID: item?.userId,
                            resetCounter: recievedName =>
                              resetCounter(recievedName),
                          });
                        }
                        console.log('data rander item is : ', item);
                      }}
                      style={{
                        flex: 1,
                        height: hp(9),
                        justifyContent: 'space-evenly',
                        marginHorizontal: hp(2),
                        borderColor: 'red',
                        borderWidth: 0,
                      }}>
                      <CareCoordinationContactCard
                        name={item.name}
                        roleName={item.roleName}
                        iconimage={require('../../../../../assets/images/avatar_contacts.png')}
                        phoneNumber={item.phone}
                        unreadMessage={item.unreadCount}
                      />
                    </TouchableOpacity>
                  );
                }}
              />
            </View>
          </View>
        </View>
      </MainHeader>
      {/* <View
        style={{
          borderWidth: 1,
          display: 'flex',
          flexDirection: 'row',
          justifyContent: 'space-evenly',
        }}>
        <View style={{}}>
          <SvgCss
            xml={Svgs.arrowHeadLeft}
            width={hp(5)}
            height={hp(5)}
            fill={Colors.black}
            onPress={() => {
              // props?.resetCount(props?.nameToReset);
              props.navigation.pop();
            }}
            style={{marginHorizontal: hp(1)}}
          />
        </View>
        <View>
          <Text>Care Coordinator</Text>
        </View>
        <View style={{}}>
          <TouchableOpacity
            onPress={() => navigation.navigate('NotificationStack')}>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'flex-start',
                marginRight: hp(2),
              }}>
              <Image
                style={{
                  width: hp(2),
                  height: hp(2.5),
                }}
                source={Images.notification_dashboard}
              />
            </View>
          </TouchableOpacity>
        </View>
      </View> */}

      {/* <View
        style={{
          flex: 1,
          backgroundColor: 'red',
          height: '100%',
          width: '100%',
        }}></View> */}
    </SafeAreaView>
  );
};
const mapStateToProps = ({newMessage}) => ({
  newMessage,
});
const styles = StyleSheet.create({
  container: {
    // justifyContent: 'center',
    flex: 1,
    backgroundColor: Colors.BgColor,
    borderColor: 'red',
  },
});
export default connect(mapStateToProps)(careCoordinatorScreen);
