import React from 'react';
import {Text, View} from 'react-native';
import colors from '../../../../config/Colors';

const EMRchatScreen = () => {
  return (
    <View
      style={{
        flex: 1,
        borderColor: 'red',
        borderWidth: 2,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}>
      <Text style={{color: colors.black}}>EMRchatScreen</Text>
    </View>
  );
};

export default EMRchatScreen;
