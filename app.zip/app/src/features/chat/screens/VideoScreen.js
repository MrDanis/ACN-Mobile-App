import React, {useState} from 'react';
import {
  Button,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import RNAzureCommunicationUICalling from '../../../../../native/RNAzureCommunicationUI';
const VideoScreen = ({navigation}) => {
  const [tokenInput, onChangeTokenInput] = useState(
    'eyJhbGciOiJSUzI1NiIsImtpZCI6IjYwNUVCMzFEMzBBMjBEQkRBNTMxODU2MkM4QTM2RDFCMzIyMkE2MTkiLCJ4NXQiOiJZRjZ6SFRDaURiMmxNWVZpeUtOdEd6SWlwaGsiLCJ0eXAiOiJKV1QifQ.eyJza3lwZWlkIjoiYWNzOmU0N2U3YTI4LTNhODYtNDQyMS1iMmNhLWIzNGMyMzQwMGQ5ZV8wMDAwMDAyMS02NGQ1LTY3YmUtYTYxMC0yNDQ4MjIwMGE3YmEiLCJzY3AiOjE3OTIsImNzaSI6IjE3MjEyOTEyMjkiLCJleHAiOjE3MjEzNzc2MjksInJnbiI6ImFtZXIiLCJhY3NTY29wZSI6InZvaXAiLCJyZXNvdXJjZUlkIjoiZTQ3ZTdhMjgtM2E4Ni00NDIxLWIyY2EtYjM0YzIzNDAwZDllIiwicmVzb3VyY2VMb2NhdGlvbiI6InVuaXRlZHN0YXRlcyIsImlhdCI6MTcyMTI5MTIyOX0.Jg8nXS5EUVymBxcnXS39VdnzciWu8eHhYCz1CUIAAehgFi2qmgo8VHrSeDEw27MNcUANQuJNXegZnGRDTNP-JNP5GzJ-UPLMhzMjE9_K2iLcYngDuN5TAegPv1r6G1dZ_2ED0D74NRV_VbQ3XP4dzsJhAY74VkdLIf2SmGDT9493wJXv4UL0X_sJlPMmAUfzAkcMyjZbVZuA95bqIiFbIkuKZ813fph-H8c8tRvX3Q3ztSNrrzu8Xm7vVA7A18OgIRrNteQ7Ho8Yb91nw42AGNOOppvy-N0lTcs3Bi5c4pMXIjSgSCDUDQzE7QQqIeki3j33qa9-l_3Qdo99BwoPpA',
  );
  const [displayName, onChangeDisplayName] = useState('');
  const [title, onChangeTitle] = useState('');
  const [subtitle, onChangeSubtitle] = useState('');
  const [meetingInput, onChangeMeetingInput] = useState('99487375464064702');
  const [isRightToLeft, onChangeIsRightToLeft] = useState(false);
  const [disableLeaveCallConfirmation, onChangeDisableLeaveCallConfirmation] =
    useState(false);
  const [localAvatar, onLocalAvatarSet] = useState('');
  const [remoteAvatar, onRemoteAvatarSet] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState('en');

  const [isRoomsCall, setIsRoomsCall] = useState(true);
  const [localesArray, setLocalesArray] = useState([]);
  const toggleIsRightToLeftSwitch = () => onChangeIsRightToLeft(!isRightToLeft);
  const disableLeaveCallConfirmationSwitch = () =>
    onChangeDisableLeaveCallConfirmation(!disableLeaveCallConfirmation);

  React.useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <Button
          onPress={() => setModalVisible(!modalVisible)}
          title="Settings"
          color="#0078D4"
        />
      ),
    });
  }, [navigation, setModalVisible]);

  const setLocalAvatar = avatar => {
    if (avatar !== localAvatar) {
      onLocalAvatarSet(avatar);
    } else {
      onLocalAvatarSet('');
    }
  };

  const setRemoteAvatar = avatar => {
    if (avatar !== remoteAvatar) {
      onRemoteAvatarSet(avatar);
    } else {
      onRemoteAvatarSet('');
    }
  };

  const resolveAssetSource = require('react-native/Libraries/Image/resolveAssetSource');

  const getsupportedLocales = async () => {
    try {
      const locals = await RNAzureCommunicationUICalling?.getSupportedLocales();
      setLocalesArray(locals);
    } catch (e) {
      console.log('Error is : ', e.message);
    }
  };

  getsupportedLocales();

  const resolveAvatarSource = avatar => {
    let source = '';
    if (avatar === 'cat') {
      source = require('../../../../../assets/images/cat.png');
    } else if (avatar === 'fox') {
      source = require('../../../../../assets/images/fox.png');
    } else if (avatar === 'koala') {
      source = require('../../../../../assets/images/koala.png');
    } else if (avatar === 'monkey') {
      source = require('../../../../../assets/images/monkey.png');
    } else if (avatar === 'mouse') {
      source = require('../../../../../assets/images/mouse.png');
    } else if (avatar === 'octopus') {
      source = require('../../../../../assets/images/octopus.png');
    }
    return resolveAssetSource(source);
  };

  const startCallComposite = async () => {
    console.log('Display Name :  ', displayName);
    console.log('Title : ', title);
    console.log('Subtitile : ', subtitle);
    console.log('Meeting Input : ', meetingInput);
    console.log('Token Input : ', tokenInput);
    try {
      const localAvatarImageResource = resolveAvatarSource(localAvatar);
      const remoteAvatarImageResource = resolveAvatarSource(remoteAvatar);
      let callCompositeRequest =
        await RNAzureCommunicationUICalling.startCallComposite(
          // local options
          {
            displayName: `{"appSource": "3", "userId": "SMOKE26@GMAIL.COM"}`,
            title: title,
            subtitle: subtitle,
            disableLeaveCallConfirmation: disableLeaveCallConfirmation,
          },
          localAvatarImageResource,
          // remote options
          {token: tokenInput, meeting: meetingInput},
          remoteAvatarImageResource,
          // localization options
          {locale: selectedLanguage, layout: isRightToLeft},
          {setupOrientation: 'PORTRAIT', callOrientation: 'PORTRAIT'},
        );
    } catch (e) {
      console.log('Error Message is : ', e.message);
    }
  };
  return (
    <ScrollView contentInsetAdjustmentBehavior="automatic">
      {isRoomsCall && (
        <View>
          <Text style={styles.inputTitle}>Rooms Call</Text>
          <TextInput
            style={styles.textInput}
            onChangeText={onChangeMeetingInput}
            value={meetingInput}
            placeholderTextColor={'#6E6E6E'}
            placeholder="Enter Rooms ID"
          />
          <Text style={styles.inputDescription}>
            Get Room ID created by admin to join rooms call.
          </Text>
        </View>
      )}
      <Text style={styles.inputTitle}>ACS Token</Text>
      <TextInput
        style={styles.textInput}
        onChangeText={onChangeTokenInput}
        value={tokenInput}
        placeholderTextColor={'#6E6E6E'}
        placeholder="Token Function URL or ACS Token"
      />
      <Text style={styles.inputDescription}>
        Identify token used for authentication.
      </Text>
      <Text style={styles.inputTitle}>Your display name</Text>
      <View style={styles.inputContainer}>
        <Image
          style={styles.icon}
          source={require('../../../../../assets/images/user.png')}
        />

        <TextInput
          style={styles.textInput}
          onChangeText={onChangeDisplayName}
          value={displayName}
          placeholderTextColor={'#6E6E6E'}
          placeholder="Enter a name"
        />
      </View>

      <Text style={styles.inputDescription}>
        Name shown to the others on the call.
      </Text>

      <Pressable
        style={[
          styles.button,
          !tokenInput || !meetingInput
            ? styles.buttonDisabled
            : styles.buttonOpen,
        ]}
        disabled={!tokenInput || !meetingInput}
        onPress={startCallComposite}>
        <Text
          style={
            !tokenInput || !meetingInput
              ? styles.textCloseStyle
              : styles.textStyle
          }>
          Launch
        </Text>
      </Pressable>
    </ScrollView>
  );
};
const styles = StyleSheet.create({
  title: {
    textAlign: 'center',
    padding: 10,
    marginTop: 10,
    fontSize: 17,
  },
  textInput: {
    height: 48,
    backgroundColor: 'white',
    color: '#212121',
    fontSize: 17,
    paddingStart: 16,
    paddingEnd: 16,
    paddingTop: 13,
    paddingBottom: 13,
  },
  inputContainer: {
    flex: 1,
    backgroundColor: 'white',
    flexDirection: 'row',
    justifyContent: 'flex-start',
  },
  modalView: {
    margin: 10,
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  icon: {
    width: 16,
    marginStart: 20,
    alignSelf: 'center',
    height: 20,
  },
  tabButton: {
    flex: 1,
    borderRadius: 50,
    padding: 10,
    elevation: 2,
  },
  button: {
    marginTop: 64,
    borderRadius: 8,
    padding: 10,
    elevation: 2,
    margin: 10,
  },
  buttonOpen: {
    backgroundColor: '#0078D4',
  },
  buttonDisabled: {
    backgroundColor: '#F1F1F1',
  },
  buttonClose: {
    width: 24,
    height: 24,
    padding: 4,
    borderRadius: 12,
    textAlign: 'center',
  },
  inputTitle: {
    paddingStart: 16,
    paddingEnd: 16,
    paddingBottom: 8,
    paddingTop: 24,
    fontSize: 13,
    color: '#6E6E6E',
  },
  inputDescription: {
    paddingStart: 16,
    paddingEnd: 16,
    fontSize: 12,
    color: '#6E6E6E',
  },
  textStyle: {
    color: 'white',
    fontWeight: 'normal',
    textAlign: 'center',
    fontSize: 15,
  },
  textCloseStyle: {
    color: '#6E6E6E',
    fontSize: 15,
    textAlign: 'center',
  },
  modalTitleText: {
    marginVertical: 15,
    textAlign: 'center',
    fontSize: 17,
  },
  settingsSectionContainerView: {
    backgroundColor: '#F8F8F8',
    flexDirection: 'column',
    padding: 10,
    borderRadius: 4,
    marginVertical: 8,
  },
  settingsHeaderText: {
    color: 'grey',
  },
  settingsSwitchToggleContainer: {
    flexDirection: 'row',
    height: 40,
    marginVertical: 10,
    padding: 10,
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  closeContainerView: {
    alignItems: 'flex-end',
  },
});

const pickerSelectStyles = StyleSheet.create({
  inputIOS: {
    height: 40,
    fontSize: 16,
    paddingVertical: 12,
    paddingHorizontal: 10,
    marginVertical: 8,
    borderWidth: 1,
    borderColor: 'black',
    borderRadius: 4,
    color: 'black',
    paddingRight: 30, // to ensure the text is never behind the icon
  },
  inputAndroid: {
    height: 40,
    fontSize: 16,
    paddingHorizontal: 10,
    paddingVertical: 8,
    marginVertical: 8,
    borderWidth: 1,
    borderColor: 'black',
    borderRadius: 4,
    color: 'black',
    paddingRight: 30, // to ensure the text is never behind the icon
  },
});
export default VideoScreen;
