import React from 'react';
import {Image, Linking, Pressable, Text, View} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {Colors} from '../../../../config';
import {Fonts} from '../../../../config/AppConfig';
import colors from '../../../../config/Colors';

const ProvidersContactCard = props => {
  console.log('Data for the provider is : ', props);
  function dialCall(number) {
    console.log('CareManager Phone Number', number);
    let phoneNumber = '';
    if (Platform.OS === 'android') {
      phoneNumber = `tel:${number}`;
    } else {
      phoneNumber = `telprompt:${number}`;
    }
    Linking.openURL(phoneNumber);
  }
  return (
    <>
      <Pressable
        disabled={props.chatFeatureEnabled === false ? true : false}
        // onPress={() => {
        //   props?.navigation.navigate('Chat', {
        //     data: props?.data,
        //     care: props?.care,
        //     selectedCareManagerID: props?.data?.physicianId, //this name is temperory will change it when we refactor
        //     physicianInitials: props.name.substring(0, 2),
        //   });
        // }}
        style={{
          backgroundColor: colors.white,
          flexDirection: 'row',
          alignItems: 'center',
          flex: 1,
        }}>
        <View
          style={{
            width: hp(7),
            height: hp(7),
            backgroundColor: Colors.bleLayer4,
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: 8,
          }}>
          <Image
            style={{
              width: hp(4.5),
              height: hp(4.5),
              resizeMode: 'contain',
            }}
            source={props.iconimage}
          />
        </View>
        <View style={{flex: 1}}>
          <Text
            numberOfLines={1}
            style={{
              marginLeft: hp(2),
              fontFamily: Fonts.SourceSansSemibold,
              color: Colors.black,
              fontSize: hp(2),
            }}>
            {props?.name}
          </Text>
          <Text
            numberOfLines={1}
            style={{
              marginHorizontal: hp(2),
              fontFamily: Fonts.SourceSansRegular,
              color: Colors.noRecordFound,
              fontSize: hp(1.7),
            }}>
            {props?.physicianSpeciality}
          </Text>
        </View>
      </Pressable>
    </>
  );
};
export default ProvidersContactCard;
