import React, {useEffect, useState} from 'react';
import {Platform, StyleSheet, Text, View} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {SvgCss} from 'react-native-svg';
import {connect, useSelector} from 'react-redux';
import {Colors, Svgs} from '../../../../config';
import {Fonts} from '../../../../config/AppConfig';

// create a component
const Header = props => {
  const cmReduxDat = useSelector(state => state?.cmStatusData);
  const [isCmOnline, setisCmOnline] = useState(
    cmReduxDat?.argOne === props.careData?.data?.userId && cmReduxDat?.argOne
      ? true
      : false,
  );
  console.log('this is from header rest count', props);
  useEffect(() => {
    if (
      props?.activeCmID === cmReduxDat?.argOne &&
      cmReduxDat.argTwo === true
    ) {
      // console.log('Here in if...');
      setisCmOnline(true);
    }
    if (
      props?.activeCmID === cmReduxDat?.argOne &&
      cmReduxDat.argTwo === false
    ) {
      // console.log('Here in else...');
      setisCmOnline(false);
    }
  }, [cmReduxDat.argOne]);

  return (
    <>
      <View style={styles.container}>
        <View style={styles.headerLeft}>
          <SvgCss
            xml={Svgs.arrowHeadLeft}
            width={hp(5)}
            height={hp(5)}
            fill={Colors.black}
            onPress={() => {
              props?.resetCount(props?.nameToReset);
              props.navigation.pop();
            }}
            style={{marginHorizontal: hp(1)}}
          />

          <View style={{marginHorizontal: hp(1)}}>
            <Text
              style={{
                color: Colors.black4,
                fontSize: hp(2),
                fontFamily: Fonts.SourceSansSemibold,
              }}>
              {/* {props.careData?.care
                ? props.careData?.data?.name
                : props?.careData?.data?.physicianName} */}
              {props.nameToReset}
            </Text>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <View
                style={{
                  width: 6,
                  height: 6,
                  backgroundColor: isCmOnline ? '#56F000' : '#FF3838',
                  borderRadius: 6 / 2,
                  marginRight: hp(0.5),
                }}
              />
              <Text
                style={{
                  color: Colors.noRecordFound,
                  fontSize: hp(1.5),
                  fontFamily: Fonts.SourceSansSemibold,
                }}>
                {isCmOnline ? 'Online' : 'Offline'}
              </Text>
            </View>
          </View>
        </View>
      </View>
      {props.children}
    </>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.BgColor,
    height: Platform.OS === 'ios' ? hp(10) : hp(10),
    borderBottomWidth: 1,
    borderBottomColor: Colors.transparent,
    justifyContent: 'center',
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: Platform.OS === 'ios' ? hp(6) : 0,
  },
});

const mapStateToProps = ({cmStatusData}) => ({
  cmStatusData,
});
//make this component available to the app
export default connect(mapStateToProps)(Header);
