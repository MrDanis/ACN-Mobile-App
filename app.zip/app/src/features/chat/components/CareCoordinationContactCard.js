import React from 'react';
import {Image, Linking, Text, View} from 'react-native';
import {Colors} from '../../../../config';
import {Fonts} from '../../../../config/AppConfig';

import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import colors from '../../../../config/Colors';
import images from '../../../../config/Images';
const CareCoordinationContactCard = props => {
  function dialCall(number) {
    console.log('CareManager Phone Number', number);
    let phoneNumber = '';
    if (Platform.OS === 'android') {
      phoneNumber = `tel:${number}`;
    } else {
      phoneNumber = `telprompt:${number}`;
    }
    Linking.openURL(phoneNumber);
  }
  console.log('these are the porosp ', props);
  return (
    <>
      <View
        style={{
          backgroundColor: colors.white,
          flexDirection: 'row',
          alignItems: 'center',
          flex: 1,
          borderColor: 'red',
          // borderWidth: 1,
        }}>
        <View
          style={{
            width: hp(7),
            height: hp(7),
            backgroundColor: Colors.bleLayer4,
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: 8,
          }}>
          <Image
            style={{
              width: hp(4.5),
              height: hp(4.5),
              resizeMode: 'contain',
              borderWidth: 0,
              borderColor: 'green',
            }}
            source={props.iconimage}
          />
        </View>
        <View
          style={{
            flex: 1,
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}>
          <View>
            <Text
              numberOfLines={1}
              style={{
                marginLeft: hp(2),
                fontFamily: Fonts.SourceSansRegular,
                color: Colors.black,
                fontSize: hp(2),
              }}>
              {props.name}
            </Text>
            <Text
              numberOfLines={1}
              style={{
                marginHorizontal: hp(2),
                fontFamily: Fonts.SourceSansRegular,
                color: Colors.blueGrayDisableText,
                fontSize: hp(1.7),
              }}>
              {props.roleName.split(/(?=[A-Z])/).join(' ')}
            </Text>
          </View>
          {props?.unreadMessage > 0 && (
            <View
              style={{
                backgroundColor: 'red',
                borderRadius: 12, // Makes it rounded
                height: 24,
                minWidth: 24,
                paddingHorizontal: 6,
                alignItems: 'center',
                justifyContent: 'center',
                marginRight: hp(3),
              }}>
              <Text
                style={{
                  color: 'white',
                  fontSize: 14,
                  fontWeight: 'bold',
                }}>
                {props.unreadMessage}
              </Text>
            </View>
          )}
        </View>
        <Image
          style={{
            width: hp(3),
            height: hp(3),
            marginTop: hp(0.5),
            marginRight: hp(2),
          }}
          source={images.msgIconBlue}
        />
      </View>
    </>
  );
};

export default CareCoordinationContactCard;
