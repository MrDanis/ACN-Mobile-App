import React from 'react';
import {Image, Linking, Text, TouchableOpacity, View} from 'react-native';
import {Colors} from '../../../../config';
import {Fonts} from '../../../../config/AppConfig';
import Images from '../../../../config/Images';


import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import colors from '../../../../config/Colors';
const PharmacyContactCard = props => {
  function dialCall(number) {
    console.log('CareManager Phone Number', number);
    let phoneNumber = '';
    if (Platform.OS === 'android') {
      phoneNumber = `tel:${number}`;
    } else {
      phoneNumber = `telprompt:${number}`;
    }
    Linking.openURL(phoneNumber);
  }

  const openLocationOnMap = (latitude, longitude) => {
    const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=AIzaSyCgz4YIw1sMSPhgJ4p9DKVm8o9zKHiJGvs`;
    let address = null;
    let formattedAddress = [];
    let addressurl = null;
    fetch(url)
      .then(response => response.json())
      .then(data => {
        if (data.status === 'OK' && data.results.length > 0) {
          address = data.results[0];
          formattedAddress = address;
          console.log('Address:', address);
          addressurl = `https://www.google.com/maps/search/?api=1&query=${address.formatted_address}`;

          console.log('====================================');
          console.log('addressurl', addressurl);
          console.log('====================================');
          Linking.openURL(addressurl);
        } else {
          console.error('No address found for the given coordinates.');
        }
      })
      .catch(error => {
        console.error('Error fetching address:', error);
      });
  };
  return (
    <>
      <View
        style={{
          backgroundColor: colors.white,
          flexDirection: 'row',
          alignItems: 'center',
          flex: 1,
        }}>
        <View
          style={{
            width: hp(7),
            height: hp(7),
            backgroundColor: Colors.bleLayer4,
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: 8,
          }}>
          <Image
            style={{
              width: hp(4.5),
              height: hp(4.5),
              resizeMode: 'contain',
            }}
            source={
              props.type === 'ph' ? Images.Icon_Medication_gray : Images.labIcon
            }
          />
        </View>
        <View style={{flex: 1}}>
          <Text
            numberOfLines={1}
            style={{
              marginLeft: hp(2),
              fontFamily: Fonts.SourceSansSemibold,
              color: Colors.black,
              fontSize: hp(2),
            }}>
            {props?.type === 'ph'
              ? props.item?.pharmacyName
              : props.item?.labName}
          </Text>
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'center',
            }}>
            <Image
              style={{
                width: hp(1.7),
                height: hp(1.7),

                marginLeft: hp(2),

                resizeMode: 'contain',
              }}
              source={Images.clockSm}
            />
            <Text
              numberOfLines={1}
              style={{
                fontFamily: Fonts.SourceSansRegular,
                color: Colors.noRecordFound,
                fontSize: hp(1.7),
                marginLeft: hp(0.5),
              }}>
              {props?.type === 'ph'
                ? props.item?.pharmacyTiming
                : props.item?.labTiming}
            </Text>
          </View>
        </View>
        <View
          style={{
            flex: 0.3,
            flexDirection: 'row',
            justifyContent: 'space-between',
          }}>
          <TouchableOpacity onPress={() => dialCall(props.item?.phoneNo)}>
            <Image
              source={Images.call_Icon_Black}
              style={{width: 25, height: 25}}
            />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() =>
              openLocationOnMap(props.item?.latitude, props.item?.longitude)
            }>
            <Image
              source={Images.locationCon}
              style={{width: 25, height: 25}}
            />
          </TouchableOpacity>
        </View>
      </View>
    </>
  );
};

export default PharmacyContactCard;
