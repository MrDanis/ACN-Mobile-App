/* istanbul ignore file */
export const getCMCallStatus = status => ({
  type: 'UPDATE_CALL_END_STATUS',
  status,
});
export const getCMStatus = status => ({
  type: 'UPDATE_STATUS',
  status,
});
export const sendMessage = message => ({
  type: 'SEND_MESSAGE',
  message,
});
export const newMsg = message => ({
  type: 'NEW_MESSAGE',
  data: message,
});
export const getHistoryData = data => ({
  type: 'HISTORY_DATA',
  data,
});
export const getUnreadMessagesData = data => ({
  type: 'Unread_Messages_Data',
  data,
});
export const clearData = data => ({
  type: 'CLEAR_DATA',
  data,
});
export const getSignalRStatus = status => ({
  type: 'SIGNALR_CONNECTION',
  status,
});
export const getSplashSignalRStatus = status => ({
  type: 'SPLASH_SIGNALR_CONNECTION',
  status,
});
export const getCareCoordinationContactList = data => ({
  type: 'CARECOORDINATION_CONTACT_LIST',
  data,
});
export const getPhysicianContactList = data => ({
  type: 'PHYSICIAN_CONTACT_LIST',
  data,
});
