import {
  Image,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';
import MainHeader from '../mycare/components/MainHeader';
import colors from '../../../config/Colors';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import {Colors} from '../../../config';
import {Fonts} from '../../../config/AppConfig';
import {TouchableOpacity} from 'react-native-gesture-handler';
import images from '../../../config/Images';

const Interventions = ({navigation}) => {
  const [itemId, setItemId] = useState(0);
  const items = [
    {id: 1, text: 'Not Met'},
    {id: 2, text: 'Met'},
    {id: 3, text: 'Discontinued'},
    {id: 4, text: 'Partially Met'},
  ];

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: colors.BgColor}}>
      <MainHeader navigation={navigation} name={'Intervention'}>
        <View style={{borderWidth: 0, backgroundColor: colors.BgColor}}>
          {/* magin div */}
          <View
            style={{
              //   borderWidth: 1,
              //   borderColor: 'purple',
              marginHorizontal: wp(2.5),
              paddingBottom: hp(1.8),
            }}>
            <Text
              style={{
                // borderWidth: 1,
                fontSize: hp(2),
                fontFamily: Fonts.SourceSansSemibold,
                color: colors.black,
                marginVertical: hp(2),
                width: '90%',
              }}>
              Identifying if goal is short- term or long-term
            </Text>
            {/* container for options */}
            <View>
              {/* option */}
              {items.map(item => {
                return (
                  <TouchableOpacity
                    onPress={() => setItemId(item.id)}
                    style={{
                      padding: hp(2),
                      backgroundColor:
                        itemId === item.id ? Colors.TextColor : Colors.white,
                      marginTop: hp(3),
                      borderRadius: hp(0.4),
                      marginHorizontal: Platform.OS === 'ios' ? 0 : hp(0.5), //this should be coppied to next div to get the same marginh
                      borderColor: Colors.line,
                      borderWidth: 0.1,
                      elevation: Platform.OS === 'ios' ? 20 : 2,
                      display: 'flex',
                      flexDirection: 'row',
                    }}>
                    <Image
                      source={
                        itemId === item.id ? images.checked : images.unchecked
                      }
                      style={{
                        alignSelf: 'center',
                        height: hp(2.5),
                        width: hp(2.5),
                        marginLeft: wp(2),
                      }}
                    />
                    <Text
                      style={{
                        fontSize: hp(1.8),
                        fontFamily: Fonts.SourceSansRegular,
                        color: itemId === item.id ? Colors.white : colors.black,
                        marginLeft: wp(7),
                        paddingVertical: hp(0.5),
                      }}>
                      {item.text}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
            <TouchableOpacity
              style={{
                // borderWidth: 1,
                marginTop: hp(3.9),
                paddingVertical: hp(1.9),
                borderRadius: hp(0.9),
                backgroundColor: Colors.TextColor,
                display: 'flex',
                justifyContent: 'center',
                flexDirection: 'row',
              }}>
              <Text
                style={{
                  fontSize: hp(2),
                  fontFamily: Fonts.SourceSansSemibold,
                  color: colors.white,
                  //   padding: hp(0.4),
                  //   marginVertical: hp(0.5),
                }}>
                Mark Status
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </MainHeader>
    </SafeAreaView>
  );
};

export default Interventions;

const styles = StyleSheet.create({});
