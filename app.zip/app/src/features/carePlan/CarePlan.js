import {
  Image,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';
import MainHeader from '../mycare/components/MainHeader';
import colors from '../../../config/Colors';
import {AnimatedCircularProgress} from 'react-native-circular-progress';
import LinearGradient from 'react-native-linear-gradient';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import {Colors} from '../../../config';
import {Fonts} from '../../../config/AppConfig';
import {TouchableOpacity} from 'react-native-gesture-handler';
import images from '../../../config/Images';

const CarePlan = ({navigation}) => {
  const fill = 55;
  const [mainOutcomes, setMainOutcomes] = useState(false);
  const ProgressBar = ({progress, colorBg, colorLinear, rgba}) => {
    return (
      <View style={styles.container}>
        <View
          style={{
            flex: 1,
            height: hp(3),
            borderRadius: 5,
            backgroundColor: colorBg, // Base color of the entire bar
            position: 'relative',
            overflow: 'hidden',
          }}>
          {/* Solid gradient for the filled section */}
          <LinearGradient
            colors={[colorLinear, rgba]}
            start={{x: 0.8, y: 0}}
            end={{x: 0, y: 0}}
            style={[styles.progressFill, {width: `${progress}%`}]}
          />
        </View>
        <Text style={styles.progressText}>{`${progress}%`}</Text>
      </View>
    );
  };
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: colors.BgColor}}>
      <MainHeader navigation={navigation} name={'Care Plans'}>
        <ScrollView style={{borderWidth: 0, backgroundColor: colors.BgColor}}>
          {/* magin div */}
          <View
            style={{
              // borderWidth: 1,
              borderColor: 'purple',
              marginHorizontal: wp(2.4),
              paddingBottom: hp(1.8),
            }}>
            <View
              style={{
                padding: hp(2),
                backgroundColor: Colors.white,
                marginTop: hp(3),
                borderRadius: hp(1),
                marginHorizontal: Platform.OS === 'ios' ? 0 : hp(0.5), //this should be coppied to next div to get the same marginh
                borderColor: Colors.line,
                borderWidth: 0.1,
                elevation: Platform.OS === 'ios' ? 20 : 2,
              }}>
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}>
                <View>
                  <Text
                    style={{
                      fontSize: hp(2),
                      fontWeight: '400',
                      fontFamily: Fonts.SourceSansRegular,
                      color: colors.black4,
                    }}>
                    Problems
                  </Text>
                  <Text
                    style={{
                      fontSize: hp(1.8),
                      fontWeight: '400',
                      fontFamily: Fonts.SourceSansRegular,
                      color: colors.darkgrey,
                    }}>
                    3 out of 10 resolved
                  </Text>
                </View>
                <AnimatedCircularProgress
                  size={50}
                  width={5}
                  fill={fill}
                  rotation={0}
                  style={{marginRight: hp(1)}}
                  tintColor={Colors.badgeGreen}
                  backgroundColor={Colors.blueGrayDisableBG}>
                  {fill => (
                    <Text
                      style={{color: Colors.noRecordFound, fontSize: hp(1.5)}}>
                      {fill + '%'}
                    </Text>
                  )}
                </AnimatedCircularProgress>
              </View>

              {/*  progress bars 2nd */}
              <View style={{}}>
                <Text
                  style={{
                    fontSize: hp(1.6),
                    fontWeight: '600',
                    fontFamily: Fonts.SourceSansSemibold,
                    color: colors.black,
                    marginTop: hp(2.2),
                  }}>
                  Type 2 Diabetes
                </Text>
                <ProgressBar
                  progress={80}
                  colorBg={'#F8D3C1'}
                  colorLinear={'#F44336'}
                  rgba={'rgba(244, 67, 54, 0.15)'}
                />
              </View>
              {/*  progress bars 1st */}
              <View style={{}}>
                <Text
                  style={{
                    fontSize: hp(1.6),
                    fontWeight: '600',
                    fontFamily: Fonts.SourceSansSemibold,
                    color: colors.black,
                    marginTop: hp(2.2),
                  }}>
                  Diabetes
                </Text>
                <ProgressBar
                  progress={33}
                  colorBg={'#E3F2FD'}
                  colorLinear={'#2196F3'}
                  rgba={'rgba(33, 150, 243, 0.15)'}
                />
              </View>
              {/*  progress bars 3rd */}
              <View style={{}}>
                <Text
                  style={{
                    fontSize: hp(1.6),
                    fontWeight: '600',
                    fontFamily: Fonts.SourceSansSemibold,
                    color: colors.black,
                    marginTop: hp(2.2),
                  }}>
                  Asthama
                </Text>
                <ProgressBar
                  progress={90}
                  colorBg={'rgba(78, 203, 194, 0.15)'}
                  colorLinear={'#00BCD4'}
                  rgba={'rgba(0, 188, 212, 0.15)'}
                />
              </View>
              {/* button div container */}
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'center',
                }}>
                <View
                  style={{
                    width: '75%',
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginTop: hp(3.6),
                  }}>
                  <TouchableOpacity>
                    <Text
                      style={{
                        fontSize: hp(1.7),
                        fontFamily: Fonts.SourceSansRegular,
                        fontWeight: '400',
                        color: colors.TextColor,
                      }}>
                      ViewAll
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity>
                    <Text
                      style={{
                        fontSize: hp(1.7),
                        fontFamily: Fonts.SourceSansRegular,
                        fontWeight: '400',
                        color: colors.TextColor,
                      }}>
                      Download
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
            <View
              style={{
                // borderWidth: 1,
                marginTop: hp(2),
                marginHorizontal: Platform.OS === 'ios' ? 0 : hp(0.5), //this should be coppied to next div to get the same marginh
                display: 'flex',
                justifyContent: 'space-between',
                flexDirection: 'row',
              }}>
              <Text
                style={{
                  fontSize: hp(1.9),
                  fontFamily: Fonts.SourceSansRegular,
                  fontWeight: '400',
                  color: colors.black4,
                }}>
                Outcomes
              </Text>
              <Text
                style={{
                  fontSize: hp(1.5),
                  fontFamily: Fonts.SourceSansRegular,
                  fontWeight: '400',
                  color: colors.darkgrey,
                }}>
                1 out of 3 resolved
              </Text>
            </View>
            <View
              style={{
                padding: hp(2),
                backgroundColor: Colors.white,
                marginTop: hp(3),
                borderRadius: hp(1),
                marginHorizontal: Platform.OS === 'ios' ? 0 : hp(0.5), //this should be coppied to next div to get the same marginh
                borderColor: Colors.line,
                borderWidth: 0.33,
                elevation: Platform.OS === 'ios' ? 20 : 2,
              }}>
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                <Text
                  style={{
                    fontSize: hp(1.7),
                    fontFamily: Fonts.SourceSansRegular,
                    fontWeight: '400',
                    color: colors.black4,
                  }}>
                  P1: Cognitive impairment present
                </Text>
                <Pressable
                  onPress={() => setMainOutcomes(!mainOutcomes)}
                  style={{
                    // borderWidth: 1,
                    justifyContent: 'center',
                  }}>
                  <Image
                    source={images.arrowUpIcon}
                    style={{
                      alignSelf: 'center',
                      height: hp(0.6),
                      width: hp(1.3),
                      borderWidth: 1,
                      transform: mainOutcomes
                        ? [{rotate: '180deg'}]
                        : [{rotate: '0deg'}],
                    }}
                  />
                </Pressable>
              </View>
              {/* dot first */}
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  marginTop: hp(1.5),
                  alignItems: 'center',
                }}>
                <Text
                  style={{
                    fontSize: hp(1.5),
                    fontFamily: Fonts.SourceSansRegular,
                    fontWeight: '400',
                    color: colors.darkgrey,
                  }}>
                  3/4/2024 - 4:04:32 PM
                </Text>
                {/* dot */}
                <View
                  style={{
                    padding: hp(0.3),
                    backgroundColor: colors.textFieldGrey,
                    borderRadius: hp(10),
                    marginHorizontal: wp(3),
                  }}
                />
                <Text
                  style={{
                    fontSize: hp(1.5),
                    fontFamily: Fonts.SourceSansRegular,
                    fontWeight: '400',
                    color: '#607D8B',
                  }}>
                  John Smith
                </Text>
                {/* second dot */}
                <View
                  style={{
                    padding: hp(0.3),
                    backgroundColor: colors.textFieldGrey,
                    borderRadius: hp(10),
                    marginHorizontal: wp(3),
                  }}
                />
                <Text
                  style={{
                    fontSize: hp(1.5),
                    fontFamily: Fonts.SourceSansRegular,
                    fontWeight: '400',
                    color: colors.darkgrey,
                  }}>
                  No Status
                </Text>
              </View>
              {/* img and drop */}
              <View
                style={{
                  padding: hp(1.5),
                  backgroundColor: Colors.bgblue,
                  marginTop: hp(3),
                  borderRadius: hp(1.1),
                }}>
                <View
                  style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'flex-start',
                    // alignItems: 'center',
                  }}>
                  <Image
                    source={images.careplanTick}
                    style={{
                      alignSelf: 'center',
                      height: hp(5),
                      width: hp(5),
                    }}
                  />
                  <Text
                    style={{
                      fontSize: hp(1.7),
                      fontFamily: Fonts.SourceSansRegular,
                      fontWeight: '400',
                      color: colors.black4,
                      marginLeft: wp(4),
                      width: '70%',
                    }}
                    numberOfLines={2}>
                    G1: Patient reported cognitive and behavioral symptoms...
                  </Text>
                  <Pressable style={{}}>
                    <Image
                      source={images.arrowUpIcon}
                      style={{
                        height: hp(0.6),
                        width: hp(1.3),
                        marginLeft: wp(3),
                        marginTop: hp(0.7),

                        transform: mainOutcomes
                          ? [{rotate: '180deg'}]
                          : [{rotate: '0deg'}],
                      }}
                    />
                  </Pressable>
                </View>
                {/* dot second after img */}
                <View
                  style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'flex-end',
                    marginTop: hp(1.5),
                    alignItems: 'center',
                    width: '93%',
                  }}>
                  <Text
                    style={{
                      fontSize: hp(1.5),
                      fontFamily: Fonts.SourceSansRegular,
                      fontWeight: '400',
                      color: colors.darkgrey,
                    }}>
                    12/03/2024
                  </Text>
                  {/* dot */}
                  <View
                    style={{
                      padding: hp(0.3),
                      backgroundColor: colors.textFieldGrey,
                      borderRadius: hp(10),
                      marginHorizontal: wp(3),
                    }}
                  />
                  <Text
                    style={{
                      fontSize: hp(1.5),
                      fontFamily: Fonts.SourceSansRegular,
                      fontWeight: '400',
                      color: colors.darkgrey,
                    }}>
                    Not Met
                  </Text>
                  {/* second dot */}
                  <View
                    style={{
                      padding: hp(0.3),
                      backgroundColor: colors.textFieldGrey,
                      borderRadius: hp(10),
                      marginHorizontal: wp(3.5),
                    }}
                  />
                  <Text
                    style={{
                      fontSize: hp(1.5),
                      fontFamily: Fonts.SourceSansRegular,
                      fontWeight: '400',
                      color: colors.darkgrey,
                      marginRight: hp(0.5),
                    }}>
                    No barrier 
                  </Text>
                </View>
                {/* second last div  */}
                <TouchableOpacity
                  style={{
                    padding: wp(2),
                    backgroundColor: colors.white,
                    borderRadius: hp(1.1),
                    marginTop: hp(1.5),
                  }}>
                  <View
                    style={{
                      display: 'flex',
                      flexDirection: 'row',
                      justifyContent: 'flex-start',
                    }}>
                    <Image
                      source={images.careplanTick}
                      style={{
                        alignSelf: 'center',
                        height: hp(5),
                        width: hp(5),
                      }}
                    />
                    <Text
                      style={{
                        fontSize: hp(1.7),
                        fontFamily: Fonts.SourceSansRegular,
                        fontWeight: '400',
                        color: colors.black4,
                        marginLeft: wp(4),
                        width: '65%',
                      }}
                      numberOfLines={2}>
                      Identifying if goal is a priority for patient and...
                    </Text>
                    <Pressable
                      style={{
                        display: 'flex',
                        flexDirection: 'row',
                        flex: 1,
                        justifyContent: 'flex-end',
                        alignItems: 'center',
                      }}>
                      <Image
                        source={images.TakenIcon}
                        style={{
                          height: hp(2.6),
                          width: hp(2.6),
                          marginRight: wp(0.4),
                        }}
                      />
                    </Pressable>
                  </View>
                </TouchableOpacity>
                {/*  last div  */}
                <TouchableOpacity
                  onPress={() => navigation.navigate('interventions')}
                  style={{
                    padding: wp(2),
                    backgroundColor: colors.white,
                    borderRadius: hp(1.1),
                    marginTop: hp(1.5),
                  }}>
                  <View
                    style={{
                      display: 'flex',
                      flexDirection: 'row',
                      justifyContent: 'flex-start',
                    }}>
                    <Image
                      source={images.careplanTick}
                      style={{
                        alignSelf: 'center',
                        height: hp(5),
                        width: hp(5),
                      }}
                    />

                    <Text
                      style={{
                        fontSize: hp(1.7),
                        fontFamily: Fonts.SourceSansRegular,
                        fontWeight: '400',
                        color: colors.black4,
                        marginLeft: wp(4),
                        width: '65%',
                      }}
                      numberOfLines={2}>
                      Identifying if goal is a priority for patient and...
                    </Text>
                    <View
                      style={{
                        display: 'flex',
                        flexDirection: 'row',
                        flex: 1,
                        justifyContent: 'flex-end',
                        alignItems: 'center',
                      }}>
                      <Image
                        source={images.arrowUpIcon}
                        style={{
                          height: hp(0.6),
                          width: hp(1.3),
                          marginRight: wp(0.7),
                          transform: [{rotate: '90deg'}],
                        }}
                      />
                    </View>
                  </View>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </ScrollView>
      </MainHeader>
    </SafeAreaView>
  );
};

export default CarePlan;

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: hp(1),
  },

  progressFill: {
    position: 'absolute',
    height: '100%',
    borderRadius: 5,
    // borderWidth: 1,
  },
  unfilledSection: {
    position: 'absolute',
    height: '100%',
    borderRadius: 5,
  },
  progressText: {
    marginLeft: 8,
    fontSize: 14,
    color: '#707070',
  },
});
