import {
  Image,
  ImageBackground,
  Platform,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import React, {useEffect, useState} from 'react';

import Spinner from 'react-native-loading-spinner-overlay';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import {connect, useDispatch, useSelector} from 'react-redux';
import {Colors, Images} from '../../../../config';
import {Fonts} from '../../../../config/AppConfig';
import colors from '../../../../config/Colors';
import HomeService from '../../../api/home';
import ProfileService from '../../../api/profile';
import {
  getDayTime,
  requestUserPermission,
  saveTokens,
} from '../../../helpers/Common';
import {
  getBloodPressureHK,
  getHeartRateHK,
  getWeightHK,
} from '../../../helpers/HealthKit/HealthKitHandler';
import {retrieveItem} from '../../../helpers/LocalStorage';
import {NavigationHelper} from '../../../helpers/NavigationHelper';
import {messageListener} from '../../../helpers/NotificationHelper';
import {
  startSignalR,
  updateUserChatStatus,
} from '../../../helpers/signalR/SignalRService';
import {
  getAllergiesHistory,
  getAppLogoutTime,
  getMedicationHistory,
} from '../../bluebutton/action';
import {getUserProfile} from '../../profile/action';
import {getHomeApiData} from '../action';

import startPushKit from '../../../helpers/PushKit/PushKitHelper';

import {CallStatus, TwilioHelper} from '../../../helpers/Twilio/TwilioHelper';

import {useFocusEffect} from '@react-navigation/native';

import images from '../../../../config/Images';

import AsyncStorage from '@react-native-async-storage/async-storage';
import moment from 'moment';
import LinearGradient from 'react-native-linear-gradient';
import {Avatar} from 'react-native-paper';
import Swiper from 'react-native-swiper';
import {
  getBloodPressureFromGoogleFit,
  getHeartRateFromGoogleFit,
  getWeightFromGoogleFit,
} from '../../../helpers/GoogleFit/GoogleFitHandler';
import {DayTime} from '../../medication/constants';
import {getSignature} from '../../profile/action';
import AppIntro from '../../welcome/screens/AppIntro';
import VitalsCard from './components/VitalsCard';
import AllergiesCard from './components/allergiesCard';
import HealthMaintenanceCard from './components/healthMaintenanceCard';
import LabsCard from './components/labsCard';
import MedicationCard from './components/medicationCard';
import ScreeningCard from './components/screeningCard';
import WellnessCard from './components/wellnessCard';
import {jwtDecode} from 'jwt-decode';
import {showMessage} from 'react-native-flash-message';
import {modalHanlder} from '../../medication/actions';
import MedicalHistoryCardNew from './components/MedicalHistoryCardNew';
import CareCordinatorCard from './components/careCordinatorCard';
import { SvgCss } from 'react-native-svg';
import { Svgs } from '../../../../config';
import svgs from '../../../../config/Svgs';
// import CarePlanCard from './components/carePlanCard';

const HomeScreen = props => {
  navigationHelper: NavigationHelper;
  twilioHelper: TwilioHelper;
  NavigationHelper.sharedInstance().navigation = props.navigation;
  messageListener();
  const twilio = TwilioHelper.sharedInstance();
  const dispatch = useDispatch();
  const [isAco, setAco] = useState(false);
  const [loader, setLoader] = useState(false);
  const [time, setTime] = useState(null);
  const [heartRateHealthKit, setHeartRateHealthKit] = useState(0);

  const userProfileData = useSelector(state => state.userProfileData);
  const homaApiData = useSelector(state => state.homeApiData);
  const [bloodPressure, setBloodPressure] = useState();
  const [heartRate, setHeartRate] = useState();
  const [bodyWeight, setBodyWeight] = useState();
  const [bloodPressureGoogleFit, setBloodPressureGoogleFit] = useState();
  const [heartRateGoogleFit, setHeartRateGoogleFit] = useState();
  const [bodyWeightGoogleFit, setBodyWeightGoogleFit] = useState();
  const [dashboardListData, setDashboardListData] = useState(null);
  const [healthList, setHealthList] = useState([]);
  const [labsList, setLabsList] = useState([]);
  const [allergiesList, setAllergiesList] = useState([]);
  const [medicationList, setMedicationList] = useState([]);
  const [greetingText, setGreetingText] = useState('Morning');
  const [vitalsList, setVitalsList] = useState([]);
  const [vitalsStatus, setVitalsStatus] = useState(false);
  const [careCoordinatorStatus, setCareCoordinatorStatus] = useState(false);
  const [medicationStatus, setMedicationStatus] = useState(false);
  const [wellnessStatus, setwellnessStatus] = useState(false);
  const [healthStatus, setHealthStatus] = useState(false);
  const [medicalHistoryStatus, setmedicalHistoryStatus] = useState(false);
  const [allergiesStatus, setAllergiesStatus] = useState(false);
  const [labsStatus, setLabsStatus] = useState(false);
  const [screeningStatus, setScreeningStatus] = useState(false);
  const [assessmentList, setAssessmentList] = useState([]);
  const [carePlanStatus, setCarePlanStatus] = useState(false);
  const [isCm, setIsCm] = useState(false);
  const [appointmentStatus, setappointmentStatus] = useState(false);
  const [widgetData, setWidgetData] = useState(false);
  const stepsLiveRD = useSelector(state => state?.liveStepsData);
  const distanceLiveRD = useSelector(state => state?.liveDistanceData);
  const speedLiveRD = useSelector(state => state?.liveSpeedData);
  const isAuthorizeFromFit = useSelector(state => state?.authFromFit);
  const heartLiveRD = useSelector(state => state?.liveHeartData?.value);
  const heartLiveRDtest = useSelector(state => state?.liveHeartData);
  const [showIntro, setShowIntro] = useState(true);
  const [isSkipped, setIsSkipped] = useState(false);
  // const patientId = useSelector(state => state?.getUserSiganture);
  const [patientId, setPatientId] = useState(0);
  const [userSign, setUserSign] = useState(0);
  const [browseMode,setbrowseMode] = useState(0)//0:For card view 1:For list view
  var plusIcon = {
    icon: images.addIcon_dashboard,
    isActive: true,
    name: 'Add More',
    tileColor: colors.blueGrayDisableBG,
    value: null,
  };

  const handleUserSignature = async () => {
    let allKeys = await AsyncStorage.getAllKeys();
    retrieveItem('authToken').then(res => {
      console.log('UTS : ', res);
      let devtoken = jwtDecode(res);
      const {AcoKey, PatientId} = devtoken;
      let userSignature = `PAT_${PatientId}_${AcoKey}`;
      setPatientId(userSignature);
      dispatch(getSignature(userSignature));
      console.log('Signature is : ', userSignature);
    });
  };

  useEffect(() => {
    handleUserSignature();
    requestUserPermission();
    setHeartRateHealthKit(heartLiveRD);
    if (Platform.OS === 'ios') {
      startPushKit();
    }
    // uncomment below line to active intro
    // Moving it here to call the save device token only once it comes to dashboard
    //===============================================================================
    ProfileService.getUserProfile()
      .then(response => {
        if (response && response.statusCode === 200) {
          setLoader(false);
          setAco(response.data.isAcoPatient);
          console.log('Here in saving the token', response);
          saveTokens(response.data);
          dispatch(getUserProfile(response.data));
        }
      })
      .catch(error => {
        setLoader(false);
        console.log(error);
      });
    //=================================================================================
    HomeService.getHomeApi()
      .then(response => {
        if (response) {
          console.log('====================================');
          console.log('getHomeApi', response);
          console.log('====================================');
          setShowIntro(response.data.common.intro);
          global.isPatientTouch = response.data.common?.isPatientTouchEnabled;
          props.dispatch(getHomeApiData(response.data));
          let userSignature = `PAT_${response.data?.common?.patientId}_${response.data?.common?.acoKey}`;
          updateUserChatStatus(userSignature, 1);

          setPatientId(userSignature);
          dispatch(getSignature(userSignature));
          console.log('Signature is : ', userSignature);
          startSignalR(response.data, userProfileData, userSignature, props);
          const timer = 60000 * response.data.appLogoutTime;
          props.dispatch(getAppLogoutTime(timer));
        }
        setLoader(false);
      })
      .catch(err => {
        setLoader(false);
        console.log('getHomeApi Error');
        console.log(err);
      });
  }, []);
  useFocusEffect(
    React.useCallback(() => {
      setScreeningStatus(false);
      setVitalsStatus(false);
      setMedicationStatus(false);
      setwellnessStatus(false);
      setAllergiesStatus(false);
      setHealthStatus(false);
      setLabsStatus(false);
      setappointmentStatus(false);

      HomeService.getWidget()
        .then(response => {
          if (response) {
            setLoader(false);
            setWidgetData(response.data);
            console.log('====================================');
            console.log('getWidget', response.data);
            console.log('====================================');
            response.data.map(data => {
              console.log('====================================');
              console.log('screening', screeningStatus);
              console.log('====================================');
              if (data.id === 1) {
                console.log('====================================');
                console.log('in screening');
                console.log('====================================');
                if (data.status === true) {
                  setScreeningStatus(true);
                } else {
                  setScreeningStatus(false);
                }
              }
              if (data.id === 2) {
                if (data.status === true) {
                  setVitalsStatus(true);
                } else {
                  setVitalsStatus(false);
                }
              }
              if (data.id === 3) {
                if (data.status === true) {
                  setMedicationStatus(true);
                } else {
                  setMedicationStatus(false);
                }
              }
              if (data.id === 4) {
                if (data.status === true) {
                  setwellnessStatus(true);
                } else {
                  setwellnessStatus(false);
                }
              }
              if (data.id === 5) {
                if (data.status === true) {
                  setHealthStatus(true);
                } else {
                  setHealthStatus(false);
                }
              }
              if (data.id === 6) {
                if (data.status === true) {
                  setAllergiesStatus(true);
                } else {
                  setAllergiesStatus(false);
                }
              }
              if (data.id === 7) {
                if (data.status === true) {
                  setLabsStatus(true);
                } else {
                  setLabsStatus(false);
                }
              }
              if (data.id === 8) {
                if (data.status === true) {
                  setappointmentStatus(true);
                } else {
                  setappointmentStatus(false);
                }
              }
              if (data.id === 9) {
                if (data.status === true) {
                  setCarePlanStatus(true);
                } else {
                  setCarePlanStatus(false);
                }
              }
              if (data.id === 10) {
                if (data.status === true) {
                  setmedicalHistoryStatus(true);
                } else {
                  setmedicalHistoryStatus(false);
                }
              }
              if (data.id === 11) {
                if (data.status === true) {
                  setCareCoordinatorStatus(true);
                } else {
                  setCareCoordinatorStatus(false);
                }
              }
            });
          }
        })
        .catch(err => {
          console.log('getWidget Error');
          console.log(err);
        });

      if (Platform.OS === 'ios') {
        getBloodPressureHK()
          .then(results => {
            // Handle the resolved results here
            // dispatch(setStepsLive(results.value));
            setBloodPressure(results);

            // Do something with the results in your homeScreen component
          })
          .catch(error => {
            // Handle any errors that occurred during the execution of x() here
            console.error('Error calling x:', error);
          });
        getHeartRateHK()
          .then(results => {
            // Handle the resolved results here

            // dispatch(setStepsLive(results.value));
            setHeartRate(results);

            // Do something with the results in your homeScreen component
          })
          .catch(error => {
            // Handle any errors that occurred during the execution of x() here
            console.error('Error calling x:', error);
          });
        getWeightHK()
          .then(results => {
            // Handle the resolved results here
            // dispatch(setStepsLive(results.value));
            setBodyWeight(results);

            // Do something with the results in your homeScreen component
          })
          .catch(error => {
            // Handle any errors that occurred during the execution of x() here
            console.error('Error calling x:', error);
          });
      } else {
      }
    }, []),
  );

  useFocusEffect(
    React.useCallback(() => {
      setLoader(true);

      ProfileService.getUserProfile()
        .then(response => {
          if (response && response.statusCode === 200) {
            console.log('User profile', response.data.isCM);
            setIsCm(response.data?.isCM);
            setLoader(false);
            setAco(response.data.isAcoPatient);
            saveTokens(response.data);
            dispatch(getUserProfile(response.data));
          }
        })
        .catch(error => {
          setLoader(false);
          console.log(error);
        });
      HomeService.getDashboardDataApi()
        .then(response => {
          if (response) {
            setLoader(false);
            console.log('====================================');
            console.log('getDashboardDataApi', response.data);
            console.log('====================================');
            setVitalsList(response.data?.vitalsList);
            setDashboardListData(response.data);
            getDayTimeFun(response.data.medicationList);
            setMedicationList(response.data.medicationList);
            setLabsList(response.data.labsList);
            setAllergiesList(response.data.allergiesList);
            setHealthList(response.data.immunizationList);
            setAssessmentList(response.data.assessments);
          }
        })
        .catch(error => {
          setLoader(false);
          console.log('getDashboardDataApi error', error);
        });
      HomeService.getHomeApi()
        .then(response => {
          if (response) {
            console.log('====================================');
            console.log('getHomeApi', response);
            console.log('====================================');
            setShowIntro(response.data.common.intro);
            global.isPatientTouch = response.data.common?.isPatientTouchEnabled;
            props.dispatch(getHomeApiData(response.data));
            // startSignalR(response.data, props);
            const timer = 60000 * response.data.appLogoutTime;
            props.dispatch(getAppLogoutTime(timer));
          }
          setLoader(false);
        })
        .catch(err => {
          setLoader(false);
          console.log('getHomeApi Error');
          console.log(err);
        });
      checkIfFirstLaunch();
      setLoader(true);
    }, []),
  );

  const getDayTimeFun = medicationlistData => {
    const currentTime = moment(new Date()).format('hh:mm A');
    console.log('====================================');
    console.log('medicationlistData', medicationlistData);
    console.log('====================================');
    let medicationTopData = medicationlistData;
    let medicationTopData1 = medicationlistData;
    if (getDayTime(currentTime) === DayTime.MORNING) {
      setTime('0');
      setGreetingText('Morning');
    } else if (getDayTime(currentTime) === DayTime.NOON) {
      setTime('1');
      setGreetingText('Afternoon');
    } else if (getDayTime(currentTime) === DayTime.EVENING) {
      setTime('2');
      setGreetingText('Evening');
    } else if (getDayTime(currentTime) === DayTime.NIGHT) {
      setTime('3');
      console.log('====================================');
      console.log('getDayTime(currentTime)', getDayTime(currentTime));
      console.log('====================================');
    }
  };

  const isTodayYesterday = date => {
    let today = moment().format('YYYY-MM-DD');
    let yesterday = moment().subtract(1, 'day').format('YYYY-MM-DD');

    const formattedDate = moment(date).format('YYYY-MM-DD');

    if (moment(formattedDate).isSame(today, 'day')) {
      return `${moment().format('[Today,] MMMM D, YYYY')}`;
    } else {
      return moment(new Date(formattedDate)).format('dddd-MM/DD/YYYY');
    }
  };

  function convertTo12HourFormat(time24, apiTime) {
    //Below code is commented by Danish to resolve the appointment time bug(START)
    // UTC time string
    const utcTime = time24;

    // Convert UTC time to local time
    const localTime = moment.utc(utcTime, 'HH:mm:ss').local();

    // Format local time in 12-hour format
    const localTime12hr = localTime.format('hh:mm A');

    //Below code is commented by Danish to resolve the appointment time bug(END)

    // // Split the time string into hours and minutes
    // const [hours, minutes] = time24.split(':');

    // // Parse the hours and minutes into integers

    return localTime12hr;
  }
  const checkIfFirstLaunch = async () => {
    const skipIntro = await AsyncStorage.getItem('skipIntro');
    if (skipIntro === null || skipIntro === undefined || skipIntro === false) {
      setIsSkipped(false);
    } else {
      setIsSkipped(true);
    }
  };
  const handleDone = async () => {
    //call api to set introcomplete to true
    ProfileService.SkipIntro(true)
      .then(response => {
        console.log('response ', response);
        if (response.statusCode === 200) {
          setShowIntro(true);

          props.dispatch(modalHanlder(true));
        } else {
          showMessage({
            message: 'Something went wrong',
            description: 'Something went wrong in handle done',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        }
      })
      .catch(err => {
        console.log('error in api call ', err);
      });
  };
  const handleSkip = async () => {
    console.log('handle skip ');
    await AsyncStorage.setItem('skipIntro', 'true')
      .then(res => console.log('status of handle skip', res))
      .catch(err => console.log('err from handle skip', err));
    setIsSkipped(true);

    props.dispatch(modalHanlder(true));
  };

  const clearStoreData = () => {
    props.dispatch(getMedicationHistory([]));
    props.dispatch(getProviderHistory([]));
    props.dispatch(getHospitalVisitHistory([]));
    props.dispatch(getDiseasesHistory([]));
    props.dispatch(getCoverageHistory([]));
    props.dispatch(getAllergiesHistory([]));
    props.dispatch(getProceduresHistory([]));
    props.dispatch(getHomeApiData({}));
  };
  // uncomment below line to active intro
  console.log('this id the condition status:', showIntro, isSkipped);

  return (
    <>
      {showIntro === false && isSkipped === false ? (
        <AppIntro onDone={handleDone} onSkip={handleSkip} />
      ) : (
        <>
          <View
            style={{
              flexDirection: 'column',
              paddingTop: Platform.OS === 'ios' ? hp(6) : 0,
              backgroundColor: Colors.BgColor,
            }}>
            {twilio.currentCallStatus === CallStatus.CONNECTED ? (
              <TouchableOpacity
                onPress={() => {
                  props.navigation.navigate('CallUI');
                }}
                style={{
                  width: '100%',
                }}>
                <View
                  style={{
                    height: hp(5),

                    backgroundColor: Colors.greenCallHandler,

                    display: 'flex',

                    flexDirection: 'row',

                    alignItems: 'center',

                    justifyContent: 'center',
                  }}>
                  <Text
                    style={{
                      color: Colors.white,

                      fontFamily: Fonts.SourceSansSemibold,

                      fontSize: hp(2),
                    }}>
                    Tap To Return To Call
                  </Text>
                </View>
              </TouchableOpacity>
            ) : null}
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                // borderWidth: 1,
              }}>
              <View
                style={{
                  flex: 1,
                  alignItems: 'center',
                  alignItems: 'flex-start',
                  // borderWidth: 1,
                }}>
                {/* <Image
                  source={Images.splashForegroundLogo}
                  style={{
                    height: hp(9),
                    width: hp(15),
                    resizeMode: 'contain',
                  }}
                /> */}
                {/* logo before the current changes */}
                {userProfileData.imagePath !== null &&
                userProfileData.imagePath !== '' ? (
                  <TouchableOpacity
                    onPress={() => props.navigation.navigate('Profile')}>
                    <Image
                      style={{
                        width: hp(5),
                        height: hp(5),
                        marginLeft: hp(1),
                        borderRadius: 10,
                      }}
                      source={{
                        uri: userProfileData.imagePath,
                        // //priority: Image.priority.high,
                      }}
                    />
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity
                    onPress={() => props.navigation.navigate('Profile')}>
                    <Image
                      style={{
                        width: hp(5),
                        height: hp(5),
                        borderRadius: 10,
                        marginLeft: hp(1),
                      }}
                      resizeMode="contain"
                      source={require('../../../../../assets/images/user_logo.png')}
                    />
                  </TouchableOpacity>
                )}
              </View>
              <View style={{alignItems: 'flex-end', flex: 0.5}}>
                <TouchableOpacity
                  onPress={() =>
                    props.navigation.navigate('NotificationStack')
                  }>
                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'flex-start',
                    }}>
                    <Image
                      style={{
                        width: hp(2),
                        height: hp(2.5),
                      }}
                      source={Images.notification_dashboard}
                    />
                    <TouchableOpacity
                      onPress={() => {
                        props.navigation.navigate('SettingScreen');
                      }}>
                      <Image
                        style={{
                          width: hp(2.5),
                          height: hp(2.5),
                          marginHorizontal: hp(1.5),
                        }}
                        source={Images.settingsIcon_dashboard_dark}
                      />
                    </TouchableOpacity>
                  </View>
                </TouchableOpacity>
              </View>
            </View>
          </View>
          <ScrollView
            style={{
              flex: 1,
              height: '100%',
              backgroundColor: Colors.BgColor,
            }}>
            <StatusBar
              backgroundColor={Colors.BgColor}
              barStyle="dark-content"
              hidden={false}
            />
            <Spinner
              visible={loader}
              textContent={'Loading...'}
              textStyle={{color: '#FFF'}}
            />
            <View
              style={{
                flexDirection: 'row',
                alignSelf: 'center',
                marginTop: hp(1),
                width: '90%',
                alignItems: 'center',
              }}>
              <View>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansSemibold,
                    fontSize: hp(2.6),
                    color: Colors.black,
                  }}>
                  Hi, {userProfileData.firstName}
                </Text>
                <View
                  style={{
                    flexDirection: 'row',
                    marginTop: hp(0.5),
                    // borderWidth: 1,
                    alignItems: 'center',
                  }}>
                  {time === '0' && (
                    <Image
                      style={{
                        width: hp(2.5),
                        height: hp(2.5),
                      }}
                      source={Images.icon_sun}
                    />
                  )}
                  {time === '1' && (
                    <Image
                      style={{
                        width: hp(2.7),
                        height: hp(2.7),
                      }}
                      resizeMode="contain"
                      source={Images.afternoon_icon}
                    />
                  )}
                  {time === '2' && (
                    <Image
                      style={{
                        width: hp(2.5),
                        height: hp(2.5),
                      }}
                      resizeMode="contain"
                      source={Images.evening_icon_dashboard}
                    />
                  )}

                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansRegular,
                      fontSize: hp(1.8),
                      marginLeft: hp(1.5),
                      color: Colors.black,
                      marginTop: hp(0.4),
                    }}>
                    Good {greetingText}
                  </Text>
                </View>
              </View>
              {/* <View style={{alignItems: 'flex-end', flex: 1}}>
                {userProfileData.imagePath !== null &&
                userProfileData.imagePath !== '' ? (
                  <TouchableOpacity
                    onPress={() => props.navigation.navigate('Profile')}>
                    <Image
                      style={{
                        width: hp(5),
                        height: hp(5),
                        marginLeft: hp(1),
                        borderRadius: 10,
                      }}
                      source={{
                        uri: userProfileData.imagePath,
                        //priority: Image.priority.high,
                      }}
                    />
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity
                    onPress={() => props.navigation.navigate('Profile')}>
                    <Image
                      style={{
                        width: hp(5),
                        height: hp(5),
                        borderRadius: 10,
                        marginLeft: hp(1),
                      }}
                      resizeMode="contain"
                      source={require('../../../../../assets/images/user_logo.png')}
                    />
                  </TouchableOpacity>
                )}
              </View> */}
            </View>

            {/* Appointment Card */}

            {appointmentStatus && (
              <View
                style={{
                  width: '90%',
                  alignSelf: 'center',
                  marginTop: hp(2),
                  shadowOffset: {width: 0.5, height: 0.5},
                  shadowOpacity: 0.1,
                  shadowRadius: 8,
                  elevation: 3,
                  borderColor: 'red',
                  // borderWidth: 1,
                }}>
                <View
                  style={{
                    flex: 1,
                    padding: hp(2),
                    backgroundColor: '#006AD4', 
                    borderRadius: hp(1.4),
                  }}>
                  {dashboardListData?.appointmentsList !== null &&
                  dashboardListData?.appointmentsList.length > 0 ? (
                    <Pressable
                    style={{borderColor:'red',borderWidth:0,gap:hp(2)}}
                      onPress={() => {
                        props.navigation.navigate('AppointmentScreen');
                      }}>
                      <View
                        style={{
                          flexDirection: 'row',
                          alignItems: 'center',
                          width: '100%',
                        }}>
                        <View style={{flex: 1}}>
                          <Text
                            style={{
                              fontFamily: Fonts.SourceSansRegular,
                              fontSize: hp(1.7),
                              color: Colors.white,
                              
                            }}>
                             
                            {isTodayYesterday(
                              moment(
                                new Date(
                                  dashboardListData?.appointmentsList[0]?.startDate,
                                ),
                              ).format('YYYY-MM-DD'),
                            )}
                          </Text>
                        </View>
                      </View>
                      <View
                        style={{
                          flexDirection: 'row',
                          alignItems: 'center',
                          borderColor:'red',
                          // borderWidth:1,
                          backgroundColor:'#5E83FF',
                          padding:hp(1),
                          borderRadius:6
                        }}>
                        <Avatar.Text
                          label={
                            dashboardListData?.appointmentsList[0]?.initialName
                          }
                          size={30}
                        />
                        <View style={{marginLeft: hp(1),borderColor:'red',borderWidth:0}}>
                          <Text
                            style={{
                              fontFamily: Fonts.SourceSansSemibold,
                              fontSize: hp(1.3),
                              color: Colors.white,
                            }}>
                            {
                              dashboardListData?.appointmentsList[0]
                                ?.providerName
                            }
                          </Text>
                          <Text
                            style={{
                              fontFamily: Fonts.SourceSansRegular,
                              fontSize: hp(1.3),
                              color: Colors.white,
                            }}>
                            {convertTo12HourFormat(
                              dashboardListData?.appointmentsList[0]?.appointmentTime.split(
                                '-',
                              )[0],
                              dashboardListData?.appointmentsList[0]
                                ?.appointmentTime,
                            )}{' '}
                            -{' '}
                            {convertTo12HourFormat(
                              dashboardListData?.appointmentsList[0]?.appointmentTime.split(
                                '-',
                              )[1],
                              dashboardListData?.appointmentsList[0]
                                ?.appointmentTime,
                            )}
                          </Text>
                        </View>
                        <View style={{flex:1,borderColor:'red',borderWidth:0,display:'flex',alignItems:'flex-end',justifyContent:'flex-end'}}>
                         <Image source={images.appointmentCalenderIcon} resizeMode='center' style={{width:hp(2.5),height:hp(2.5)}} />
                        </View>
                      </View>
                    </Pressable>
                  ) : (
                    <Pressable
                      onPress={() => {
                        props.navigation.navigate('AppointmentScreen');
                      }}>
                      <View
                        style={{
                          flexDirection: 'row',
                          alignItems: 'center',
                          width: '100%',
                          paddingLeft: hp(3),
                        }}>
                        <View style={{flex: 1}}></View>
                        <View
                          style={{
                            // backgroundColor: Colors.card_arrow_appointment,
                            alignItems: 'flex-end',
                            borderBottomLeftRadius: 8,
                            borderTopRightRadius: 8,
                          }}>
                          <Image
                            style={{
                              width: hp(1.5),
                              height: hp(1.5),
                              margin: hp(1.5),
                            }}
                            resizeMode="contain"
                            source={Images.card_arrow}
                          />
                        </View>
                      </View>
                      <View >
                        <Text
                          style={{
                            fontFamily: Fonts.SourceSansSemibold,
                            fontSize: hp(2.5),
                            color: Colors.white,
                            width: '90%',
                          }}>
                          You have no upcoming appointment
                        </Text>
                      </View>
                      <View
                        style={{
                          paddingLeft: hp(3),
                          marginTop: hp(1),
                        }}>
                        <Pressable
                          onPress={() => {
                            props.navigation.navigate('ScheduleAppointment');
                          }}
                          style={{
                            backgroundColor: Colors.appointment_create,
                            width: hp(17),
                            borderRadius: 8,
                            alignItems: 'center',
                          }}>
                          <Text
                            style={{
                              fontFamily: Fonts.SourceSansSemibold,
                              fontSize: hp(1.4),
                              color: Colors.white,
                              margin: hp(1),
                            }}>
                            Schedule Appointment
                          </Text>
                        </Pressable>
                      </View>
                    </Pressable>
                  )}
                </View>
              </View>
            )}

            <View
              style={{
                width: '90%',
                alignSelf: 'center',
                marginTop: hp(1),
                marginBottom: hp(1),
                flexDirection: 'column',
                justifyContent: 'space-between',
                borderColor:'red',
                borderWidth:0
              }}>
                <View style={{
                  borderColor:'blue',
                  borderWidth:0,
                  flexDirection: 'row',
                  justifyContent: 'space-between'
                  
                }}>
                <Text style={{fontSize:hp(2),fontWeight:'600',color:colors.black}}>
                  Browse
                </Text>
                <View style={{flex:1,borderColor:'red',borderWidth:0,display:'flex',alignItems:'flex-end',justifyContent:'flex-end',flexDirection:'row'}}>
                <SvgCss
                  style={{marginLeft:hp(2)}}
                  xml={Svgs.browseMode(browseMode===0?"#1F1F20":"#ACACAC")}
                  width={hp(2)}
                  height={hp(2)}
                  fill={Colors.black}
                  onPress={() => {
                    setbrowseMode(0)
                    console.log('This is the test for changing the mode')
                    // this.props.navigation.goBack();
                  }}
                />
                <SvgCss
                  style={{marginLeft:hp(2)}}
                  xml={Svgs.listMode(browseMode===1?"#1F1F20":"#ACACAC")}
                  width={hp(2)}
                  height={hp(2)}
                  fill={Colors.black}
                  onPress={() => {
                    setbrowseMode(1)
                    console.log('This is the test for changing the mode')
                    // this.props.navigation.goBack();
                  }}
                />

                </View>
                </View>
                {
                  (browseMode === 2)&&(
                  <View style={{
                  borderColor:'green',
                  borderWidth:0,
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  flexWrap:'wrap'
                  }}>
  
              {/* new contact card */}
              {careCoordinatorStatus && (
                <CareCordinatorCard navigation={props.navigation} />
              )}

              {/* {isCm &&(<NewC)} */}
              {/* Vital Card */}

              {vitalsStatus && (
                <VitalsCard
                  navigation={props.navigation}
                  vitalsList={vitalsList}
                  bpReadingsHealthKit={bloodPressure}
                  heartRateHealthkit={heartRate}
                  bodyWeightHealthKit={bodyWeight}
                  bpReadingsGoogleFit={bloodPressureGoogleFit}
                  heartRateGoogleFit={heartRateGoogleFit}
                  bodyWeightGoogleFit={bodyWeightGoogleFit}
                />
              )}

              {/* Medication Card */}

              {medicationStatus && (
                <MedicationCard
                  navigation={props.navigation}
                  medicationData={medicationList}
                />
              )}

              {/* Wellness Card */}

              {wellnessStatus && <WellnessCard navigation={props.navigation} />}

              {/* Health Maintenance */}

              {healthStatus && (
                <HealthMaintenanceCard
                  navigation={props.navigation}
                  healthData={healthList}
                />
              )}

              {/* Allergies card */}

              {allergiesStatus && (
                <AllergiesCard
                  navigation={props.navigation}
                  allergiesData={allergiesList}
                />
              )}

              {/* Labs Card */}

              {labsStatus && (
                <LabsCard navigation={props.navigation} labsData={labsList} />
              )}

              {/* {assesment} */}
              {screeningStatus && (
                <ScreeningCard
                  navigation={props.navigation}
                  assesmentData={assessmentList}
                />
              )}
              {medicalHistoryStatus && (
                <MedicalHistoryCardNew
                  navigation={props.navigation}
                  isCm={isCm}
                />
              )}

              {/* care Plan */}
              {/* {carePlanStatus && <CarePlanCard navigation={props.navigation} />} */}
                  </View>
                  )
                }
                {
                  (browseMode === 0 || browseMode === 1)&&(
                  <View style={{
                    width:'100%',
                    borderColor:'red',
                    borderWidth:0,
                    paddingTop:hp(2),
                    display:'flex',
                    justifyContent:'space-between',
                    flexDirection:browseMode===0?'row':'column',
                    flexWrap:browseMode===0?'wrap':'nowrap',
                    gap:browseMode===0?hp(1):0
                  }}>
                    {/* new contact card */}
                    {/* {careCoordinatorStatus && (
                      <CareCordinatorCard navigation={props.navigation} />
                    )} */}
                    {
                      [
                      {
                        icon:svgs.listVitalIcon,
                        moduleName:'Vital',
                        description:'Track Blood Pressure, heart rate, temperature...',
                        isVisible:vitalsStatus,
                        navigationRoute:'VitalsStack',
                        filColor:'#486CE054'
                      },
                      // {
                      //   icon:svgs.listAppointmentIcon,
                      //   moduleName:'Appointments',
                      //   description:'Schedule and view upcoming doctor visits.',
                      //   isVisible:appointmentStatus,
                      //   navigationRoute:'ScheduleAppointment',
                      //   filColor:'#C108B554'
                      // },
                      {
                        icon:svgs.listLabsIcon,
                        moduleName:'Labs',
                        description:'Access and monitor your diagnostic test results.',
                        isVisible:labsStatus,
                        navigationRoute:'Lab',
                        filColor:'#7992FF54'
                      },
                      {
                        icon:svgs.listMedicationIcon,
                        moduleName:'Medications',
                        description:'Manage prescriptions, dosages & reminders.',
                        isVisible:medicationStatus,
                        navigationRoute:'MedicationStack',
                        filColor:'#16B36454'
                      },
                      {
                        icon:svgs.listMedicationIcon,
                        moduleName:'Medical History',
                        description:'Manage prescriptions, dosages & reminders.',
                        isVisible:medicalHistoryStatus,
                        navigationRoute:'MedHistoryStackScreen',
                        filColor:'#16B36454'
                      },
                      {
                        icon:svgs.listMedicationIcon,
                        moduleName:'Health Maintainess',
                        description:'Manage prescriptions, dosages & reminders.',
                        isVisible:healthStatus,
                        navigationRoute:'ImmunizationScreen',
                        filColor:'#16B36454'
                      },
                      {
                        icon:svgs.dashboardCardAllergy,
                        moduleName:'Allergies',
                        description:'Keep a record of your known allergies.',
                        isVisible:allergiesStatus,
                        navigationRoute:'AllergiesScreen',
                        filColor:'#F4433654'
                      },
                      {
                        icon:svgs.dashboardAssesmentCard,
                        moduleName:'Assessments',
                        description:'Access provider-completed assessments.',
                        isVisible:screeningStatus,
                        navigationRoute:'AssessmentStack',
                        filColor:'#44A64954'
                      },
                    
                    
                    
                    ].map((item,index)=>{
                        return(
                      <TouchableOpacity 
                        onPress={()=>{console.log('Navigation Route is :',item.navigationRoute);
                          if(item.navigationRoute.includes('MedHistoryStackScreen') && isCm)
                          {
                            props.navigation.navigate('MedHistoryStackScreen', {
                              screen: 'MainDashboard',
                              params: {
                                params: 0,
                              },
                            })
                          }
                          else
                          {
                            props.navigation.navigate(item.navigationRoute)}} 
                          }
                        style={{width:browseMode===0?'48%':'100%',marginBottom:browseMode===0?hp(1):hp(2),gap:hp(1),borderColor:'#CFD8DC',backgroundColor:colors.white,borderWidth:.75,padding:hp(1.5),paddingHorizontal:hp(1),borderRadius:10,display:item.isVisible?'flex':'none',flexDirection:browseMode===0?'column':'row',alignItems:'center'}}>
                      {
                        browseMode===0?
                        <View style={{width:'100%',borderColor:'red',borderWidth:0,display:'flex',alignItems:'center',justifyContent:'space-between',flexDirection:'row'}}>
                           <SvgCss
                            xml={item.icon}
                            width={browseMode===0?hp(4):hp(5)}
                            height={browseMode===0?hp(4):hp(5)}
                            fill={item.filColor}/>
                            <SvgCss
                            xml={svgs.navigationCardIcon}
                            width={browseMode===0?hp(2):hp(4)}
                            height={browseMode===0?hp(2):hp(4)}
                            fill={"000000"}/>
                        </View>:
                      <SvgCss
                       xml={item.icon}
                       width={browseMode===0?hp(3):hp(5)}
                       height={browseMode===0?hp(3):hp(5)}
                       fill={item.filColor}/>
                      }
                       <View style={{flex:1,display:'flex',flexDirection:'row',borderWidth:0,height:'100%',borderColor:'green'}}>
                          <View style={{flex:.85,borderColor:'blue',borderWidth:0,display:'flex'}}>
                             <Text style={{fontSize:hp(1.5),color:colors.black,fontWeight:600}}>
                                 {item.moduleName}
                             </Text>
                             <Text style={{fontSize:hp(1.25),fontWeight:400,color:colors.black}}>
                                 {item.description}
                             </Text>
                          </View>
                          <View style={{flex:.15,borderColor:'green',borderWidth:0,display:'flex'}}> 
                            </View>  
                       </View>
                      </TouchableOpacity>

                        )
                      })
                    }

              {/* Vital Card */}

              {/* {vitalsStatus && (
                <VitalsCard
                  navigation={props.navigation}
                  vitalsList={vitalsList}
                  bpReadingsHealthKit={bloodPressure}
                  heartRateHealthkit={heartRate}
                  bodyWeightHealthKit={bodyWeight}
                  bpReadingsGoogleFit={bloodPressureGoogleFit}
                  heartRateGoogleFit={heartRateGoogleFit}
                  bodyWeightGoogleFit={bodyWeightGoogleFit}
                />
              )} */}

              {/* Medication Card */}

              {/* {medicationStatus && (
                <MedicationCard
                  navigation={props.navigation}
                  medicationData={medicationList}
                />
              )} */}

              {/* Wellness Card */}
{/* 
              {wellnessStatus && <WellnessCard navigation={props.navigation} />} */}

              {/* Health Maintenance */}

              {/* {healthStatus && (
                <HealthMaintenanceCard
                  navigation={props.navigation}
                  healthData={healthList}
                />
              )} */}

              {/* Allergies card */}

              {/* {allergiesStatus && (
                <AllergiesCard
                  navigation={props.navigation}
                  allergiesData={allergiesList}
                />
              )} */}

              {/* Labs Card */}

              {/* {labsStatus && (
                <LabsCard navigation={props.navigation} labsData={labsList} />
              )} */}

              {/* {assesment} */}
              {/* {screeningStatus && (
                <ScreeningCard
                  navigation={props.navigation}
                  assesmentData={assessmentList}
                />
              )} */}
              {/* {medicalHistoryStatus && (
                <MedicalHistoryCardNew
                  navigation={props.navigation}
                  isCm={isCm}
                />
              )} */}

              {/* care Plan */}
              {/* {carePlanStatus && <CarePlanCard navigation={props.navigation} />} */}
                  </View>
                  )
                }
            </View>
          </ScrollView>
        </>
      )}
    </>
  );
};

export default connect()(HomeScreen);

const styles = StyleSheet.create({
  isIosActivityBox: {
    marginTop: hp(1),
    borderColor: colors.line,
    borderRadius: hp(1),
    borderBottomWidth: 1,
    borderWidth: 0.3,
    elevation: 2,
    backgroundColor: colors.white,
    shadowOffset: {width: 0.5, height: 0.5},
    shadowOpacity: 0.1,
    shadowRadius: 8,
    width: '94%',
    alignSelf: 'center',
  },
  isAndroidActivityBox: {
    marginLeft: hp(1.7),
    marginRight: hp(1.7),
    marginTop: hp(3),
    borderColor: colors.line,
    borderRadius: hp(1),
    borderBottomWidth: 1,
    borderWidth: 0.3,
    elevation: 2,
    backgroundColor: colors.white,
  },
  isIosShortCut: {
    marginTop: hp(2.5),
    borderColor: colors.line,
    borderRadius: hp(1),
    paddingVertical: hp(1.5),
    borderWidth: 0.3,
    elevation: 5,
    borderBottomWidth: 1,
    backgroundColor: colors.white,
    shadowOffset: {width: 0.5, height: 0.5},
    shadowOpacity: 0.1,
    shadowRadius: 8,
    width: '94%',
    alignSelf: 'center',
  },
  isAndroidShortCut: {
    marginLeft: hp(1.7),
    marginRight: hp(1.7),
    marginTop: hp(2.5),
    borderColor: colors.line,
    borderRadius: hp(1),
    paddingVertical: hp(1),
    paddingLeft: hp(3.0),
    borderWidth: 0.3,
    elevation: 2,
    borderBottomWidth: 0.5,
    backgroundColor: colors.white,
  },
  imageStyle: {
    width: 27,
    height: 27,
  },
  textStyle: {
    color: Colors.noRecordFound,
    alignItems: 'center',
    alignContent: 'center',
    fontFamily: Fonts.SourceSansRegular,
    fontSize: hp(1.7),
  },
});
