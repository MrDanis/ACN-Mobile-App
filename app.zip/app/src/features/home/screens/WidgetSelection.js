import React, {useEffect, useState} from 'react';
import {
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Image
} from 'react-native';

import {showMessage} from 'react-native-flash-message';
import Spinner from 'react-native-loading-spinner-overlay';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {SafeAreaView} from 'react-native-safe-area-context';
import {SvgCss} from 'react-native-svg';
import ToggleSwitch from 'toggle-switch-react-native';
import {Colors, Svgs} from '../../../../config';
import {CONVERT_PIXELS, Fonts} from '../../../../config/AppConfig';
import HomeService from '../../../api/home';

const WidgetSelection = ({navigation, route}) => {
  const [isActive, setIsActive] = useState(false);
  const [loader, setLoader] = useState(false);
  const [data, setData] = useState([]);
  const [selectAll, setSelectAll] = useState(false);
  useEffect(() => {
    setLoader(true);
    HomeService.getWidgetNew()
      .then(response => {
        console.log('getwidgetApi');
        console.log(response);
        if (response) {
          console.log('response of homw api data', response.data);
          setData(response.data);
          handleSwitchSelect(response.data);
          setLoader(false);
        }
      })
      .catch(err => {
        console.log('getHomeApi Error');
        console.log(err);
        setLoader(false);

        showMessage({
          message: 'Info',
          description: 'Internal Server Error',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  }, []);
  const updateStatusById = (data, targetId) => {
    return data.map(item => {
      if (item.id === targetId) {
        return {...item, status: !item.status};
      }
      return item;
    });
  };
  const checkAllStatusTrue = data => {
    return data.every(item => item.status === true);
  };
  const handleSwitch = id => {
    const updatedArray = updateStatusById(data, id);
    setData(updatedArray);
    handleSwitchSelect(updatedArray);
  };
  const handleSwitchSelect = updatedArray => {
    const currentAllStatus = checkAllStatusTrue(updatedArray);
    setSelectAll(currentAllStatus);
  };

  const updateStatusToTrue = (data, newStatus) => {
    return data.map(item => {
      return {...item, status: newStatus};
    });
  };
  const handleSwitchAll = newStatus => {
    const updatedArray = updateStatusToTrue(data, newStatus);
    console.log('this is the updated select all array', updatedArray);
    setData(updatedArray);
  };

  function getIdsWithTrueStatus(data) {
    return data.filter(item => item.status).map(item => item.id);
  }
  const handleSubmit = () => {
    const idsWithTrueStatus = getIdsWithTrueStatus(data);
    HomeService.UpdateWidgetsSelected(idsWithTrueStatus)
      .then(response => {
        console.log('====================================');
        console.log('response', response);
        console.log('====================================');
        setLoader(false);
        if (response && response.statusCode === 200) {
          navigation.popToTop();
          console.log('response of update widget api data', response);
        }
      })
      .catch(err => {
        setLoader(false);
        console.log('getHomeApi Error');
        console.log(err);
        showMessage({
          message: 'Internal Server Error',
          description: 'Internal Server Error',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
    console.log('selected ids for api', JSON.stringify(idsWithTrueStatus));
  };
  return (
    <SafeAreaView
      style={{
        backgroundColor: Colors.BgColor,
        flex: 1,
      }}>
      <Spinner
        visible={loader}
        textContent={'Loading...'}
        textStyle={{color: '#FFF'}}
      />
      <View
        style={{
          backgroundColor: Colors.BgColor,
        }}>
        {/* header */}
        <View
          style={{
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            paddingRight: hp(2.2),
            paddingLeft: hp(1),
            marginTop: hp(0.4),
          }}>
          <View style={{}}>
            <SvgCss
              xml={Svgs.arrowHeadLeft}
              width={hp(4)}
              height={hp(4)}
              fill={
                route.params.flagforback === true
                  ? Colors.black
                  : Colors.BgColor
              }
              onPress={() => {
                if (route.params.flagforback === true) {
                  navigation.pop();
                }
              }}
            />
          </View>
          <TouchableOpacity
            onPress={() => {
              setLoader(true);
              handleSubmit();
            }}>
            <Text
              style={{
                color: Colors.TextColor,
                fontSize: hp(1.8),
                fontFamily: Fonts.SourceSansRegular,
                fontWeight: '400',
              }}>
              Done
            </Text>
          </TouchableOpacity>
        </View>
        {/* heading */}
        <View
          style={{
            marginTop: hp(2.5),
            paddingLeft: hp(1.9),
            paddingBottom: hp(0.5),
            display: 'flex',
            flexDirection: 'row',
          }}>
          <Text
            style={{
              fontFamily: Fonts.SourceSansBold,
              fontStyle: 'normal',
              fontSize: hp(4.2),
              color: Colors.black,
              fontWeight: '600',
            }}>
            Select landing page widgets
          </Text>
          <View
            style={{
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'flex-end',
            }}>
            <TouchableOpacity
              onPress={() => {
                setSelectAll(!selectAll);
                handleSwitchAll(!selectAll);
              }}
              style={{
                position: 'relative',
                right: selectAll ? hp(4.8) : hp(2.2),
              }}>
              <Text
                style={{
                  color: Colors.TextColor,
                  fontSize: hp(1.8),
                  fontFamily: Fonts.SourceSansRegular,
                  fontWeight: '400',
                }}>
                {selectAll ? 'Un select All' : 'Select All'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
        {/* widgets */}

        <ScrollView
          style={{
            marginBottom: Platform.OS === 'android' ? hp(20) : hp(14),
          }}>
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              justifyContent: 'space-between',
              flexWrap: 'wrap',
              borderWidth: 0,
              borderColor: 'Red',

              marginLeft: hp(1.9),
            }}>
            {/* single widget */}
            {data.map(star => {
              console.log('this is the map star', star);
              return (
                <View
                  key={star.id}
                  style={{
                    minWidth: '46%',
                    maxWidth: '46%',

                    padding: hp(1.5),
                    backgroundColor: star.color,
                    borderRadius: hp(1.5),
                    marginTop: hp(2.5),
                    paddingBottom: hp(2),
                  }}>
                  <View
                    style={{
                      display: 'flex',
                      flexDirection: 'row',
                      justifyContent: 'flex-end',
                    }}>
                    <ToggleSwitch
                      isOn={star.status}
                      onColor={Colors.knobGreen}
                      offColor={Colors.knobBAckground}
                      onToggle={newValue => {
                        console.log('here comes new values ', newValue);
                        handleSwitch(star.id);
                        setIsActive(!isActive);
                      }}
                      size="small"
                    />
                  </View>
                  <View
                    style={{
                      display: 'flex',
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      marginTop: hp(0.5),
                    }}>
                    <View
                      style={{
                        display: 'flex',
                        flexDirection: 'column',
                        marginRight: hp(0.5),
                      }}>
                      <Image
                        resizeMode="contain"
                        style={{
                          width: hp(3.7),
                          height: hp(3.7),
                          marginTop: hp(0.5),
                        }}
                        source={{
                          uri: star.imagePath,
                          //priority: Image.priority.high,
                        }}
                      />
                    </View>
                    <View
                      style={{
                        display: 'flex',
                        flexDirection: 'column',
                        justifyContent: 'flex-start',
                        maxWidth: '72%',
                      }}>
                      <Text
                        numberOfLines={1}
                        ellipsizeMode="tail"
                        style={{
                          fontSize: hp(CONVERT_PIXELS(16)),
                          color: Colors.TextColor,
                          fontFamily: Fonts.SourceSansRegular,
                          fontWeight: '400',
                          maxWidth: '95%',
                          minWidth: '95%',
                          // borderWidth: 1,
                        }}>
                        {star.name}
                      </Text>
                      <Text
                        numberOfLines={2}
                        ellipsizeMode="tail"
                        style={{
                          fontSize: hp(CONVERT_PIXELS(11)),
                          color: Colors.black,
                          fontFamily: Fonts.SourceSansRegular,
                          fontWeight: '400',
                          marginTop: hp(0.8),
                        }}>
                        {star.description}
                      </Text>
                    </View>
                  </View>
                </View>
              );
            })}
          </View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
};

export default WidgetSelection;
const styles = StyleSheet.create({});
