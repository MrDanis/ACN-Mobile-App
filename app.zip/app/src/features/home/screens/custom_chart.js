import {BarChart} from 'react-native-gifted-charts';
import React, {useState} from 'react';
import {Platform, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import colors from '../../../../config/Colors';
const renderTitle = (
  setDateType,
  getVitalHistory,
  date,
  setisSelectedDay,
  isSelectedDay,
  handleChartScroll,
) => {
  const [showBottomColor, setshowBottomColor] = useState(true);

  return (
    <View
      style={{
        marginHorizontal: hp(6.5),
        marginTop: hp(2),
        borderColor: 'blue',
        borderWidth: 0,
      }}>
      <View
        style={{
          flexDirection: 'row',
          borderColor: 'red',
          borderWidth: 0,
        }}>
        <TouchableOpacity
          style={{}}
          onPress={() => {
            console.log('Pressed Day');
            setisSelectedDay('Day');
            setDateType(0);
            handleChartScroll(0);
            getVitalHistory(date);
          }}>
          <View
            style={{
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              alignSelf: 'center',
              paddingLeft: 0,
              paddingRight: 20,
              borderColor: 'red',
              borderWidth: 0,
            }}>
            {isSelectedDay === 'Day' ? (
              <Text
                style={{
                  borderColor: 'red',
                  borderWidth: 0,
                  width: 60,
                  // height: 16,
                  color: 'black',
                  marginBottom: 5,
                  height: Platform.OS === 'ios' ? hp(2) : hp(2.95),
                }}>
                Day
              </Text>
            ) : (
              <Text
                style={{
                  width: 60,
                  height: 16,
                  color: 'black',
                  marginBottom: 5,
                  // height: Platform.OS === 'ios' ? hp(2) : hp(2.95),
                }}>
                Day
              </Text>
            )}
            {showBottomColor === true && isSelectedDay === 'Day' ? (
              <View
                style={{
                  height: 12,
                  width: 12,
                  borderRadius: 6,
                  backgroundColor: 'blue',
                  marginHorizontal: hp(0.8),
                }}
              />
            ) : (
              <View />
            )}
          </View>
        </TouchableOpacity>
        <View padding={10}></View>
        <TouchableOpacity
          style={{}}
          onPress={() => {
            console.log('Pressed Week');
            setisSelectedDay('Week');
            setDateType(1);
            handleChartScroll(1);
            getVitalHistory(date);
          }}>
          <View style={{alignSelf: 'center'}}>
            {isSelectedDay === 'Week' ? (
              <Text
                style={{
                  width: 60,
                  height: 16,
                  color: 'black',
                  marginBottom: 5,
                  // height: Platform.OS === 'ios' ? hp(2) : hp(2.95),
                }}>
                Week
              </Text>
            ) : (
              <Text
                style={{
                  width: 60,
                  height: 16,
                  color: 'black',
                  marginBottom: 5,
                  // height: Platform.OS === 'ios' ? hp(2) : hp(2.95),
                }}>
                Week
              </Text>
            )}
            {showBottomColor === true && isSelectedDay === 'Week' ? (
              <View
                style={{
                  height: 12,
                  width: 12,
                  borderRadius: 6,
                  backgroundColor: 'blue',
                  marginHorizontal: hp(1.6),
                }}
              />
            ) : (
              <View />
            )}
          </View>
        </TouchableOpacity>
        <View padding={20}></View>
        <TouchableOpacity
          style={{}}
          onPress={() => {
            console.log('Pressed Month');
            setisSelectedDay('Month');
            setDateType(2);
            handleChartScroll(2);
            getVitalHistory(date);
          }}>
          <View style={{alignItems: 'center'}}>
            {isSelectedDay === 'Month' ? (
              <Text
                style={{
                  width: 60,
                  height: 16,
                  color: 'black',
                  marginBottom: 5,
                  // height: Platform.OS === 'ios' ? hp(2) : hp(2.95),
                }}>
                Month
              </Text>
            ) : (
              <Text
                style={{
                  width: 60,
                  height: 16,
                  color: 'black',
                  marginBottom: 5,
                  // height: Platform.OS === 'ios' ? hp(2) : hp(2.95),
                }}>
                Month
              </Text>
            )}
            {showBottomColor === true && isSelectedDay === 'Month' ? (
              <View
                style={{
                  height: 12,
                  width: 12,
                  borderRadius: 6,
                  backgroundColor: 'blue',
                  marginRight: hp(1.2),
                }}
              />
            ) : (
              <View />
            )}
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
};
const CustomTestChart = ({
  barDataRetrived,
  setDateType,
  getVitalHistory,
  date,
  setisSelectedDay,
  isSelectedDay,
  maxValue,
  isstackData,
}) => {
  const [chartScrollType, setchartScrollType] = useState(0);

  const handleChartScroll = num => {
    console.log('Number to reset the scroll is : ', num);
    setchartScrollType(num);
  };
  console.log(
    'Retrived bar chart data is : ',
    barDataRetrived,
    'Max value is  ',maxValue,
    'and Stack check is : ',
    isstackData,
  );
  return (
    <View
      style={{
        backgroundColor: 'white',
        borderRadius: 10,
        margin: hp(2),
        borderRadius: hp(1),
        elevation: hp(5),
        shadowOffset: {width: 0.5, height: 0.5},
        shadowOpacity: 0.1,
        shadowRadius: 8,
        borderWidth: 0,
        borderColor: 'red',
      }}>
      {renderTitle(
        setDateType,
        getVitalHistory,
        date,
        setisSelectedDay,
        isSelectedDay,
        handleChartScroll,
      )}
      <View
        style={{
          backgroundColor: '#333340',
          backgroundColor: 'white',
          paddingBottom: hp(6),
          borderRadius: 10,
          padding: 10,
          marginTop: hp(3),
          borderColor: 'green',
          borderWidth: 0,
        }}>
          {console.log('Max : ',maxValue)}
        {isstackData ? (
          <View>
            <BarChart
              width={285}
              leftShiftForLastIndexTooltip={hp(3)}
              leftShiftForTooltip={hp(3)}
              renderTooltip={(data, index) => (
                <View
                  style={{
                    marginLeft: index === barDataRetrived?.length - 1 ? -45 : 0,
                    display: 'flex',
                    flexDirection: 'column',
                    marginBottom: hp(1),
                    borderWidth: 0,
                    shadowOffset: {width: 0.5, height: 0.5},
                    shadowOpacity: 0.1,
                    borderWidth: 1,
                    borderRadius: hp(1),
                    borderColor: 'silver',
                    alignItems: 'flex-start',
                    shadowRadius: 8,
                    shadowOffset: {width: 0.5, height: 0.5},
                    backgroundColor: 'white',
                    paddingVertical: hp(1),
                    display: 'flex',
                    flexWrap: 'wrap',
                  }}>
                  <View
                    style={{
                      display: 'flex',
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderColor: 'blue',
                      borderWidth: 0,
                    }}>
                    <View
                      style={{
                        marginHorizontal: hp(1),
                        borderColor: 'orange',
                        borderWidth: 0,
                        height: hp(1),
                        width: hp(1),
                        backgroundColor: '#2962FF',
                        borderRadius: 50,
                      }}></View>
                    <Text style={{marginRight: hp(0.6), color: colors.black}}>
                      {parseInt(data?.stacks[1]?.value) +
                        parseInt(data?.stacks[0]?.value)}
                    </Text>
                    <Text style={{marginRight: hp(0.6), color: colors.black}}>
                      Sys
                    </Text>
                    {console.log(
                      'data of the stack is : ',
                      data,
                      'and index is : ',
                      index,
                    )}
                  </View>
                  <View
                    style={{
                      display: 'flex',
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderColor: 'blue',
                      borderWidth: 0,
                    }}>
                    <View
                      style={{
                        marginHorizontal: hp(1),
                        borderColor: 'orange',
                        borderWidth: 0,
                        height: hp(1),
                        width: hp(1),
                        backgroundColor: '#F44336',
                        borderRadius: 50,
                      }}></View>
                    <Text style={{color: colors.black}}>
                      {data?.stacks[0]?.value}
                    </Text>
                    <Text style={{color: colors.black}}> Dia</Text>
                  </View>
                </View>
              )}
              stackData={barDataRetrived}
              barWidth={17}
              spacing={20}
              initialSpacing={hp(3)}
              height={270}
              roundedTop
              hideRules
              yAxisLabelTexts={['0', '40', '80', '120', '160', '200']}
              //  stepValue={0}
              xAxisColor={colors.line}
              yAxisThickness={0}
              yAxisTextStyle={{color: 'gray'}}
              xAxisLabelTextStyle={{color: 'gray'}}
              noOfSections={6}
              yAxisSide="right"
              scrollToEnd={
                chartScrollType && chartScrollType === 0 ? false : true
              }
              isAnimated={Platform.OS === 'android' ? false : true}
              rulesLength={hp(35)}
              maxValue={maxValue}
              xAxisLength={hp(35)}
              referenceLine1Position={260}
              referenceLine1Config={{
                color: 'blue',
                dashGap: 2,
              }}
              referenceLine2Config={{
                color: 'red',
                dashWidth: 2,
                dashGap: 2,
              }}
              referenceLine2Position={260}
            />
          </View>
        ) : (
          <BarChart
            width={285}
            data={barDataRetrived}
            barWidth={17}
            spacing={hp(5)}
            initialSpacing={hp(3)}
            height={250}
            roundedTop
            hideRules
            // stepValue={0}
            xAxisColor={colors.line}
            yAxisThickness={0}
            yAxisTextStyle={{color: 'gray'}}
            xAxisLabelTextStyle={{color: 'gray'}}
            noOfSections={7}
            yAxisSide="right"
            scrollToEnd={
              chartScrollType && chartScrollType === 0 ? false : true
            }
            isAnimated={Platform.OS === 'android' ? false : true}
            rulesLength={hp(35)}
            maxValue={maxValue}
            xAxisLength={hp(35)}
            referenceLine1Position={260}
            referenceLine1Config={{
              color: 'blue',
              dashGap: 2,
            }}
            referenceLine2Config={{
              color: 'red',
              dashWidth: 2,
              dashGap: 2,
            }}
            referenceLine2Position={260}
          />
        )}
      </View>
    </View>
  );
};

export default CustomTestChart;

const styles = StyleSheet.create({});
