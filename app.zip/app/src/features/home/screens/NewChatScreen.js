import { View, Text, SafeAreaView, TextInput, FlatList, Image } from 'react-native'
import React, { useState } from 'react'
import { heightPercentageToDP as hp, widthPercentageToDP as wp } from 'react-native-responsive-screen'
import { TouchableOpacity } from 'react-native';
const NewChatScreen = ({ navigation }) => {
    const [currentMessage, setcurrentMessage] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    const [results, setResults] = useState([]);
    let typingTimeout = null;
    const fetchResults = async (query) => {
        if (!query) return;

        try {
            console.log('Searching for:', query);

            const response = await fetch(`https://randomuser.me/api/?results=10&name=${query}`);
            const data = await response.json();

            setResults(data.items); // Assuming the API returns { items: [...] }
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };
    const handleSearch = (text) => {
        setSearchTerm(text);

        // Clear the previous timeout if typing continues
        clearTimeout(typingTimeout);

        // Set a new timeout to delay the API call
        typingTimeout = setTimeout(() => {
            fetchResults(text);
        }, 500);  // Delay of 500ms before calling the API
    };
    const renderItem = ({ item }) => (
        <View >
            <Text>{item.name}</Text> {/* Assuming 'name' is a field in the API response */}
        </View>
    );
    return (
        <SafeAreaView style={{ flex: 1 }}>
            <TouchableOpacity style={{ backgroundColor: '#E2E2E2', width: '50%', borderRadius:hp(1),  padding:hp(1)}}>
                <Image source={{ uri: 'https://picsum.photos/id/1/200/300' }} style={{ height: hp(14), width: '100%', resizeMode: 'cover', borderRadius: 5}} />
                <Text style={{ textAlign: 'left', marginVertical:hp(1), color:'#797979'}}>Microsoft . 5 min read</Text>
                <Text style={{fontSize:hp(2.2), fontWeight:'bold'}}>Meet Microsoft office's new default font:Aptos</Text>
                <View style={{width:'100%', flexDirection:'row', justifyContent:'space-between', marginTop:hp(2)}}>
                    <Text style={{color:'#797979'}}>April 14, 2025</Text>
                    <Text>🔖</Text>
                </View>
            </TouchableOpacity>
        </SafeAreaView>
    )
}
export default NewChatScreen