//import liraries
import React from 'react';
import {Pressable, StyleSheet, Text, View,Image} from 'react-native';

import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Swiper from 'react-native-swiper';
import {Colors, Images} from '../../../../../config';
import {Fonts} from '../../../../../config/AppConfig';

// create a component
const VitalsCard = ({
  // name,
  navigation,
  vitalsList,
  bpReadingsHealthKit,
  heartRateHealthkit,
  bodyWeightHealthKit,
  bpReadingsGoogleFit,
  heartRateGoogleFit,
  bodyWeightGoogleFit,
}) => {
  console.log('====================================');
  console.log('vitalsList in card', vitalsList);
  console.log('====================================');
  return (
    <View
      style={{
        borderRadius: 8,
        height: hp(22),
        backgroundColor: Colors.bleLayer4,
        width: '47%',
        shadowOffset: {width: 0.5, height: 0.5},
        shadowOpacity: 0.3,
        shadowRadius: 8,
        marginTop: hp(2),
        shadowOpacity: 0.1,
        shadowRadius: 8,
        elevation: 3,
      }}>
      <Pressable
        style={{padding: hp(1)}}
        onPress={() => {
          navigation.navigate('VitalsStack');
        }}>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'start',
            justifyContent: 'space-between',
            borderColor: '#000000',
            borderWidth: 0,
            width: '100%',
            // paddingLeft: hp(3),
          }}>
          <View
            style={{
              borderColor: 'red',
              alignItems: 'center',
              justifyContent: 'center',
              padding: hp(0.5),
              backgroundColor: '#FCB73E',
              borderRadius: 8,
              height:hp(4)
            }}>
            <Image
              style={{
                width: hp(3),
                height: hp(3),
                // marginTop: hp(1.5),
                borderColor: 'red',
                // borderWidth: 1,
                backgroundColor: '#FCB73E',
              }}
              // tintColor={'#FFFFFF'}
              resizeMode="contain"
              source={Images.pulse_dashboard_white}
            />
          </View>
          <Pressable
            style={{height: hp(6)}}
            onPress={() => {
              navigation.navigate('VitalsStack');
            }}>
            <Image
              style={{
                width: hp(1.5),
                height: hp(1.5),
                // margin: hp(1.5),
                // borderWidth: 1,
              }}
              resizeMode="contain"
              source={Images.newDashboardArrow}
            />
          </Pressable>
        </View>
        <Text
          style={{
             fontFamily: Fonts.SourceSansSemibold,
              fontWeight: '600',
              fontSize: hp(1.8),
              color: Colors.black,
              marginVertical:hp(1)
          }}>
          Vitals
        </Text>
        <View style={{borderColor: 'red', borderWidth: 0}}>
          {vitalsList.length <= 0 ? (
            <View
              style={{
                paddingLeft: hp(3),
                width: '90%',
                marginTop: hp(2),
              }}>
              <Text
                style={{
                  fontFamily: Fonts.SourceSansRegular,
                  fontSize: hp(2.2),
                  color: Colors.TextColor,
                }}>
                No Record
              </Text>
            </View>
          ) : (
            <View
              style={{
                // paddingLeft: hp(3),
                // marginVertical: hp(1.5),
                marginTop: hp(1.5),
                display: 'flex',
                flexDirection: 'column',
                borderColor: 'red',
                borderWidth: 0,
                gap: 5,
              }}>
              <View
                style={{
                  // paddingLeft: hp(3),

                  alignItems: 'center',
                  flexDirection: 'row',
                }}>
                {/* <Image
              style={{
                width: hp(2.5),
                height: hp(2.5),
                marginRight: hp(0.5),
              }}
              resizeMode="contain"
              source={Images.pulse_rate_watch}
            /> */}
                <View
                  style={{
                    display: 'flex',
                    flexDirection: 'row',
                    gap: 10,
                    alignItems: 'center',
                  }}>
                  {vitalsList[0]?.value !== null ? (
                    <>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansSemibold,
                          fontSize: hp(2.5),
                          color: Colors.TextColor,
                          fontWeight: '600',
                        }}>
                        {vitalsList[0]?.value}
                      </Text>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansSemibold,
                          fontSize: hp(1.5),
                          color: Colors.TextColor,
                          marginTop: hp(-0.5),
                        }}>
                        {vitalsList[0]?.unit}
                      </Text>
                    </>
                  ) : (
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansSemibold,
                        fontSize: hp(1.5),
                        color: Colors.TextColor,
                        marginTop: hp(-0.5),
                      }}>
                      Add {vitalsList[0]?.name}
                    </Text>
                  )}
                </View>
              </View>
              <Text
                style={{
                  fontFamily: Fonts.SourceSansSemibold,
                  fontSize: hp(1.8),
                  color: Colors.TextColor,
                }}>
                {vitalsList[0]?.name}
              </Text>
            </View>
          )}
        </View>
      </Pressable>
      {/* <Pressable
          onPress={() => {
            if (vitalsList[1].value !== null) {
              navigation.navigate('VitalsStack');
            } else {
              if (vitalsList[1].id === 1) {
                navigation.navigate('VitalsStack', {
                  screen: 'VitalBloodPressure',
                  params: {
                    vitalsData: vitalsList[1],
                    bloodFromHealth: bpReadingsHealthKit,
                    bloodFromGoogleFit: bpReadingsGoogleFit,
                  },
                });
              } else if (vitalsList[1].id === 6) {
                navigation.navigate('VitalsStack', {
                  screen: 'VitalPulseRate',
                  params: {
                    vitalsData: vitalsList[1],
                    heartRateFromHealth: heartRateHealthkit,
                    heartRateFromGoogleFit: heartRateGoogleFit,
                  },
                });
              } else if (vitalsList[1].id === 10) {
                navigation.navigate('VitalsStack', {
                  screen: 'VitalWeight',
                  params: {
                    vitalsData: vitalsList[1],
                    bodyWeightFromHealthKit: bodyWeightHealthKit,
                    bodyWeightFromGoogleFit: bodyWeightGoogleFit,
                  },
                });
              } else if (vitalsList[1].id === 4) {
                navigation.navigate('VitalsStack', {
                  screen: 'VitalTemperature',
                  params: {
                    vitalsData: vitalsList[1],
                  },
                });
              } else if (vitalsList[1].id === 9) {
                navigation.navigate('VitalsStack', {
                  screen: 'VitalHeight',
                  params: {
                    vitalsData: vitalsList[1],
                  },
                });
              }
            }
          }}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              width: '100%',
              paddingLeft: hp(3),
            }}>
            <View style={{flex: 1, height: hp(6)}}>
              <Image
                style={{
                  width: hp(4),
                  height: hp(4),
                  marginTop: hp(1.5),
                  // marginTop: hp(1.5),
                }}
                resizeMode="contain"
                source={Images.pulse_dashboard_white}
              />
            </View>
            <Pressable
              style={{height: hp(6)}}
              onPress={() => {
                navigation.navigate('VitalsStack');
              }}>
              <View
                style={{
                  backgroundColor: Colors.card_arrow_vitals,
                  alignItems: 'flex-end',
                  borderBottomLeftRadius: 8,
                  borderTopRightRadius: 8,
                  justifyContent: 'flex-start',
                }}>
                <Image
                  style={{
                    width: hp(1.5),
                    height: hp(1.5),
                    margin: hp(1.5),
                  }}
                  resizeMode="contain"
                  source={Images.card_arrow}
                />
              </View>
            </Pressable>
          </View>
          <View
            style={{
              paddingLeft: hp(3),
              marginVertical: hp(1.5),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansSemibold,
                fontSize: hp(1.8),
                color: Colors.black,
              }}>
              {vitalsList[1]?.name}
            </Text>
          </View>
          <View
            style={{
              paddingLeft: hp(3),
              alignItems: 'center',
              flexDirection: 'row',
            }}>
            <Image
              style={{
                width: hp(2.5),
                height: hp(2.5),
                marginRight: hp(0.5),
              }}
              resizeMode="contain"
              source={Images.measure_bp_white}
            />
            <View>
              {vitalsList[1]?.value !== null ? (
                <>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansSemibold,
                      fontSize: hp(2.5),
                      color: Colors.white,
                    }}>
                    {vitalsList[1]?.value}
                  </Text>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansSemibold,
                      fontSize: hp(1.5),
                      color: Colors.white,
                      marginTop: hp(-0.5),
                    }}>
                    {vitalsList[1]?.unit}
                  </Text>
                </>
              ) : (
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansSemibold,
                    fontSize: hp(1.5),
                    color: Colors.black,
                    marginTop: hp(-0.5),
                  }}>
                  Add {vitalsList[1]?.name}
                </Text>
              )}
            </View>
          </View>
        </Pressable>
        <Pressable
          onPress={() => {
            if (vitalsList[2].value !== null) {
              navigation.navigate('VitalsStack');
            } else {
              if (vitalsList[2].id === 1) {
                navigation.navigate('VitalsStack', {
                  screen: 'VitalBloodPressure',
                  params: {
                    vitalsData: vitalsList[2],
                    bloodFromHealth: bpReadingsHealthKit,
                    bloodFromGoogleFit: bpReadingsGoogleFit,
                  },
                });
              } else if (vitalsList[2].id === 6) {
                navigation.navigate('VitalsStack', {
                  screen: 'VitalPulseRate',
                  params: {
                    vitalsData: vitalsList[2],
                    heartRateFromHealth: heartRateHealthkit,
                    heartRateFromGoogleFit: heartRateGoogleFit,
                  },
                });
              } else if (vitalsList[2].id === 10) {
                navigation.navigate('VitalsStack', {
                  screen: 'VitalWeight',
                  params: {
                    vitalsData: vitalsList[2],
                    bodyWeightFromHealthKit: bodyWeightHealthKit,
                    bodyWeightFromGoogleFit: bodyWeightGoogleFit,
                  },
                });
              } else if (vitalsList[2].id === 4) {
                navigation.navigate('VitalsStack', {
                  screen: 'VitalTemperature',
                  params: {
                    vitalsData: vitalsList[2],
                  },
                });
              } else if (vitalsList[2].id === 9) {
                navigation.navigate('VitalsStack', {
                  screen: 'VitalHeight',
                  params: {
                    vitalsData: vitalsList[2],
                  },
                });
              }
            }
          }}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              width: '100%',
              paddingLeft: hp(3),
            }}>
            <View style={{flex: 1, height: hp(6)}}>
              <Image
                style={{
                  width: hp(4),
                  height: hp(4),
                  marginTop: hp(1.5),
                }}
                resizeMode="contain"
                source={Images.pulse_dashboard_white}
              />
            </View>
            <Pressable
              style={{height: hp(6)}}
              onPress={() => {
                navigation.navigate('VitalsStack');
              }}>
              <View
                style={{
                  backgroundColor: Colors.card_arrow_vitals,
                  alignItems: 'flex-end',
                  borderBottomLeftRadius: 8,
                  borderTopRightRadius: 8,
                  justifyContent: 'flex-start',
                }}>
                <Image
                  style={{
                    width: hp(1.5),
                    height: hp(1.5),
                    margin: hp(1.5),
                  }}
                  resizeMode="contain"
                  source={Images.card_arrow}
                />
              </View>
            </Pressable>
          </View>
          <View
            style={{
              paddingLeft: hp(3),
              marginVertical: hp(1.5),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansSemibold,
                fontSize: hp(1.8),
                color: Colors.black,
              }}>
              {vitalsList[2]?.name}
            </Text>
          </View>
          <View
            style={{
              paddingLeft: hp(3),

              alignItems: 'center',
              flexDirection: 'row',
            }}>
            <Image
              style={{
                width: hp(2.5),
                height: hp(2.5),
                marginRight: hp(0.5),
              }}
              resizeMode="contain"
              source={Images.pulse_rate_watch}
            />
            <View style={{alignItems: 'center'}}>
              {vitalsList[2]?.value !== null ? (
                <>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansSemibold,
                      fontSize: hp(2.5),
                      color: Colors.white,
                    }}>
                    {vitalsList[2]?.value}
                  </Text>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansSemibold,
                      fontSize: hp(1.5),
                      color: Colors.white,
                      marginTop: hp(-0.5),
                    }}>
                    {vitalsList[2]?.unit}
                  </Text>
                </>
              ) : (
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansSemibold,
                    fontSize: hp(1.5),
                    color: Colors.black,
                  }}>
                  Add {vitalsList[2]?.name}
                </Text>
              )}
            </View>
          </View>
        </Pressable>
        <Pressable
          onPress={() => {
            if (vitalsList[3].value !== null) {
              navigation.navigate('VitalsStack');
            } else {
              if (vitalsList[3].id === 1) {
                navigation.navigate('VitalsStack', {
                  screen: 'VitalBloodPressure',
                  params: {
                    vitalsData: vitalsList[3],
                    bloodFromHealth: bpReadingsHealthKit,
                    bloodFromGoogleFit: bpReadingsGoogleFit,
                  },
                });
              } else if (vitalsList[3].id === 6) {
                navigation.navigate('VitalsStack', {
                  screen: 'VitalPulseRate',
                  params: {
                    vitalsData: vitalsList[3],
                    heartRateFromHealth: heartRateHealthkit,
                    heartRateFromGoogleFit: heartRateGoogleFit,
                  },
                });
              } else if (vitalsList[3].id === 10) {
                navigation.navigate('VitalsStack', {
                  screen: 'VitalWeight',
                  params: {
                    vitalsData: vitalsList[3],
                    bodyWeightFromHealthKit: bodyWeightHealthKit,
                    bodyWeightFromGoogleFit: bodyWeightGoogleFit,
                  },
                });
              } else if (vitalsList[3].id === 4) {
                navigation.navigate('VitalsStack', {
                  screen: 'VitalTemperature',
                  params: {
                    vitalsData: vitalsList[3],
                  },
                });
              } else if (vitalsList[3].id === 9) {
                navigation.navigate('VitalsStack', {
                  screen: 'VitalHeight',
                  params: {
                    vitalsData: vitalsList[3],
                  },
                });
              }
            }
          }}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              width: '100%',
              paddingLeft: hp(3),
            }}>
            <View style={{flex: 1, height: hp(6)}}>
              <Image
                style={{
                  width: hp(4),
                  height: hp(4),
                  marginTop: hp(1.5),
                }}
                resizeMode="contain"
                source={Images.pulse_dashboard_white}
              />
            </View>
            <Pressable
              style={{height: hp(6)}}
              onPress={() => {
                navigation.navigate('VitalsStack');
              }}>
              <View
                style={{
                  backgroundColor: Colors.card_arrow_vitals,
                  alignItems: 'flex-end',
                  borderBottomLeftRadius: 8,
                  borderTopRightRadius: 8,
                  justifyContent: 'flex-start',
                }}>
                <Image
                  style={{
                    width: hp(1.5),
                    height: hp(1.5),
                    margin: hp(1.5),
                  }}
                  resizeMode="contain"
                  source={Images.card_arrow}
                />
              </View>
            </Pressable>
          </View>
          <View
            style={{
              paddingLeft: hp(3),
              marginVertical: hp(1.5),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansSemibold,
                fontSize: hp(1.8),
                color: Colors.black,
              }}>
              {vitalsList[3]?.name}
            </Text>
          </View>
          <View
            style={{
              paddingLeft: hp(3),

              alignItems: 'center',
              flexDirection: 'row',
            }}>
            <Image
              style={{
                width: hp(2.5),
                height: hp(2.5),
                marginRight: hp(0.5),
              }}
              resizeMode="contain"
              source={Images.pulse_rate_watch}
            />
            <View style={{alignItems: 'center'}}>
              {vitalsList[3]?.value !== null ? (
                <>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansSemibold,
                      fontSize: hp(2.5),
                      color: Colors.white,
                    }}>
                    {vitalsList[3]?.value}
                  </Text>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansSemibold,
                      fontSize: hp(1.5),
                      color: Colors.white,
                      marginTop: hp(-0.5),
                    }}>
                    {vitalsList[3]?.unit}
                  </Text>
                </>
              ) : (
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansSemibold,
                    fontSize: hp(1.5),
                    color: Colors.black,
                  }}>
                  Add {vitalsList[3]?.name}
                </Text>
              )}
            </View>
          </View>
        </Pressable>
        <Pressable
          onPress={() => {
            if (vitalsList[4].value !== null) {
              navigation.navigate('VitalsStack');
            } else {
              if (vitalsList[4].id === 1) {
                navigation.navigate('VitalsStack', {
                  screen: 'VitalBloodPressure',
                  params: {
                    vitalsData: vitalsList[4],
                    bloodFromHealth: bpReadingsHealthKit,
                    bloodFromGoogleFit: bpReadingsGoogleFit,
                  },
                });
              } else if (vitalsList[4].id === 6) {
                navigation.navigate('VitalsStack', {
                  screen: 'VitalPulseRate',
                  params: {
                    vitalsData: vitalsList[4],
                    heartRateFromHealth: heartRateHealthkit,
                    heartRateFromGoogleFit: heartRateGoogleFit,
                  },
                });
              } else if (vitalsList[4].id === 10) {
                navigation.navigate('VitalsStack', {
                  screen: 'VitalWeight',
                  params: {
                    vitalsData: vitalsList[4],
                    bodyWeightFromHealthKit: bodyWeightHealthKit,
                    bodyWeightFromGoogleFit: bodyWeightGoogleFit,
                  },
                });
              } else if (vitalsList[4].id === 4) {
                navigation.navigate('VitalsStack', {
                  screen: 'VitalTemperature',
                  params: {
                    vitalsData: vitalsList[4],
                  },
                });
              } else if (vitalsList[4].id === 9) {
                navigation.navigate('VitalsStack', {
                  screen: 'VitalHeight',
                  params: {
                    vitalsData: vitalsList[4],
                  },
                });
              }
            }
          }}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              width: '100%',
              paddingLeft: hp(3),
            }}>
            <View style={{flex: 1, height: hp(6)}}>
              <Image
                style={{
                  width: hp(4),
                  height: hp(4),
                  marginTop: hp(1.5),
                }}
                resizeMode="contain"
                source={Images.pulse_dashboard_white}
              />
            </View>
            <Pressable
              style={{height: hp(6)}}
              onPress={() => {
                navigation.navigate('VitalsStack');
              }}>
              <View
                style={{
                  backgroundColor: Colors.card_arrow_vitals,
                  alignItems: 'flex-end',
                  borderBottomLeftRadius: 8,
                  borderTopRightRadius: 8,
                  justifyContent: 'flex-start',
                }}>
                <Image
                  style={{
                    width: hp(1.5),
                    height: hp(1.5),
                    margin: hp(1.5),
                  }}
                  resizeMode="contain"
                  source={Images.card_arrow}
                />
              </View>
            </Pressable>
          </View>
          <View
            style={{
              paddingLeft: hp(3),
              marginVertical: hp(1.5),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansSemibold,
                fontSize: hp(1.8),
                color: Colors.black,
              }}>
              {vitalsList[4]?.name}
            </Text>
          </View>
          <View
            style={{
              paddingLeft: hp(3),

              alignItems: 'center',
              flexDirection: 'row',
            }}>
            <Image
              style={{
                width: hp(2.5),
                height: hp(2.5),
                marginRight: hp(0.5),
              }}
              resizeMode="contain"
              source={Images.pulse_rate_watch}
            />
            <View style={{alignItems: 'center'}}>
              {vitalsList[4]?.value !== null ? (
                <>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansSemibold,
                      fontSize: hp(2.5),
                      color: Colors.white,
                    }}>
                    {vitalsList[4]?.value}
                  </Text>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansSemibold,
                      fontSize: hp(1.5),
                      color: Colors.white,
                      marginTop: hp(-0.5),
                    }}>
                    {vitalsList[4]?.unit}
                  </Text>
                </>
              ) : (
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansSemibold,
                    fontSize: hp(1.5),
                    color: Colors.black,
                  }}>
                  Add {vitalsList[4]?.name}
                </Text>
              )}
            </View>
          </View>
        </Pressable> */}
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#2c3e50',
  },
});

//make this component available to the app
export default VitalsCard;
