import React from 'react';
import {Platform, Pressable, StyleSheet, Text, View,Image} from 'react-native';

import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {Colors, Images} from '../../../../../config';
import {Fonts} from '../../../../../config/AppConfig';

const MedicalHistoryCardNew = ({navigation, isCm}) => {
  return (
    <View
      style={{
        borderRadius: 8,
        height: hp(22),
        backgroundColor: Colors.bleLayer4,
        width: '47%',
        marginTop: hp(2),
        shadowOffset: {width: 0.5, height: 0.5},
        shadowOpacity: 0.1,
        shadowRadius: 8,
        elevation: 3,
      }}>
      <Pressable
        onPress={() => {
          if (isCm) {
            navigation.navigate('MedHistoryStackScreen');
          } else {
            navigation.navigate('MedHistoryStackScreen', {
              screen: 'MainDashboard',
              params: {
                params: 0,
              },
            });
          }
        }}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            width: '100%',
            paddingLeft: hp(1),
          }}>
          <View
            style={{
              // flex: 1,
              // height: hp(6),
              // borderWidth: 1,
              padding: hp(2),
              borderColor: 'red',
              alignItems: 'center',
              justifyContent: 'center',
              padding: hp(0.6),
              backgroundColor: Colors.medHistoryBadge,
              borderRadius: 8,
              // maxHeight: 'streach',
            }}>
            <Image
              style={{
                width: hp(2.8),
                height: hp(2.8),
                // marginTop: hp(1.5),
                borderColor: 'red',
                // borderWidth: 1,
                backgroundColor: Colors.medHistoryBadge,
                // padding: hp(),
              }}
              // tintColor={'#FFFFFF'}
              resizeMode="contain"
              source={Images.medicationBadge_dashboard}
            />
          </View>

          <Pressable
            style={{height: hp(6)}}
            onPress={() => {
              if (isCm) {
                navigation.navigate('MedHistoryStackScreen');
              } else {
                navigation.navigate('MedHistoryStackScreen', {
                  screen: 'MainDashboard',
                  params: {
                    params: 0,
                  },
                });
              }
            }}>
            <Image
              style={{
                width: hp(1.5),
                height: hp(1.5),
                margin: hp(1.5),
                // borderWidth: 1,
              }}
              resizeMode="contain"
              source={Images.newDashboardArrow}
            />
          </Pressable>
        </View>

        <View
          style={{
            paddingLeft: hp(0.5),
            marginVertical: hp(1.5),
            flexDirection: 'row',
            alignItems: 'center',
            gap: 5,
          }}>
          <Text
            style={{
              fontFamily: Fonts.SourceSansSemibold,
              fontWeight: '600',
              fontSize: hp(1.8),
              color: Colors.black,
              marginLeft: hp(1),
            }}>
            Medical History
          </Text>
        </View>

        <View
          style={{
            marginTop: hp(1.5),
            paddingLeft: hp(1),
            borderColor: 'red',
            borderWidth: 0,
          }}>
          <Text
            style={{
              fontFamily: Fonts.SourceSansSemibold,
              fontSize: Platform.OS === 'ios' ? hp(2.2) : hp(1.8),
              color: Colors.TextColor,
              fontWeight: '600',
              // borderWidth: 1,
            }}
            numberOfLines={3}>
            Disease, Coverage Allergies
          </Text>
        </View>
      </Pressable>
    </View>
  );
};

export default MedicalHistoryCardNew;

const styles = StyleSheet.create({});
