import React from 'react';
import {Platform, Pressable, StyleSheet, Text, View,Image} from 'react-native';


import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {SvgCssUri} from 'react-native-svg';
import {Images} from '../../../../../config';
import {Fonts} from '../../../../../config/AppConfig';
import colors from '../../../../../config/Colors';

const ActivityIcon = ({
  id,
  backgroundColor,
  imageSource,
  text,
  navigation,
  healthKitData,
  distanceWalked,
  activityData,
  calculatedSpeed,
  stepHealth,
  heartHealth,
  sleepHealth,
  healthKitFormatedSleepTime,
}) => {
  console.log('Api Data is : ', activityData);
  console.log('====================================');
  console.log('activityData ', activityData);
  console.log('====================================');
  console.log('hear rate comming from the homeScreen is ', heartHealth);
  console.log('This is the id and name' + id + text);
  console.log('Steps from the health kit are : ', healthKitData);
  console.log('Health kit formated time is : ', healthKitFormatedSleepTime);
  return text === 'Add More' ? (
    <Pressable
      style={{marginBottom: hp(1)}}
      onPress={() => {
        navigation.navigate('DiscoverScreen');
      }}>
      <View
        style={{
          alignItems: 'center',
          alignContent: 'center',
          alignItems: 'center',
          alignSelf: 'center',
          paddingRight: hp(2),
          height: hp(8.2),
        }}>
        <View
          style={{
            alignContent: 'center',
            alignItems: 'center',
            height: hp(8.2),
            backgroundColor: backgroundColor,
            width: hp(8.2),
            borderRadius: hp(2),
            borderColor: colors.darkgrey,
            borderWidth: 1.2,
            borderStyle: 'dashed',
            justifyContent: 'center',
          }}>
          <Image
            resizeMode="contain"
            style={{
              width: 30,
              height: 45,
            }}
            source={Images.addIcon_dashboard}
          />
        </View>
        <Text
          style={{
            fontFamily: Fonts.SourceSansRegular,
            fontSize: hp(1.6),
            color: colors.black4,
            marginTop: hp(2.2),
            marginBottom: hp(1.1),
          }}>
          {text}
        </Text>
      </View>
    </Pressable>
  ) : text === 'Heart' ? (
    <Pressable
      onPress={() => {
        console.log('');
        navigation.navigate('HeartCounter', {
          navigation: navigation,
          id: id,
          item: activityData,
          heartRate: heartHealth?.value,
        });
      }}>
      <View
        style={{
          alignItems: 'center',
          alignContent: 'center',
          alignItems: 'center',
          alignSelf: 'center',
          paddingRight: hp(2),
        }}>
        <View
          style={{
            alignContent: 'center',
            alignItems: 'center',
            height: hp(8.2),
            backgroundColor: backgroundColor,
            width: hp(8.2),
            borderRadius: hp(2),
            justifyContent: 'center',
          }}>
          {console.log(
            'Value of the heart before sending to the next ',
            heartHealth,
          )}
          <SvgCssUri
            width={40}
            height={45}
            uri={imageSource + '?' + new Date()}
            fill={backgroundColor}
          />
        </View>
        <Text
          style={{
            fontFamily: Fonts.SourceSansRegular,
            fontSize: hp(1.6),
            color: colors.black4,
            marginTop: hp(2.2),
            marginBottom: hp(1.1),
          }}>
          {text}
        </Text>
      </View>
    </Pressable>
  ) : text === 'Sleep Monitor' ? (
    <Pressable
      onPress={() => {
        // Medications
        console.log('Inside Sleep Monitor');

        navigation.navigate('SleepCounter', {
          navigation: navigation,
          id: id,
          sleepGoal: activityData?.patientGoal,
          sleepValue: activityData.value,
          sleepDuration: sleepHealth,
          healthkitTimeFormat: healthKitFormatedSleepTime,
        });
      }}>
      <View
        style={{
          alignItems: 'center',
          alignContent: 'center',
          alignItems: 'center',
          alignSelf: 'center',
          paddingRight: hp(2),
        }}>
        <View
          style={{
            alignContent: 'center',
            alignItems: 'center',
            height: hp(8.2),
            backgroundColor: backgroundColor,
            width: hp(8.2),
            borderRadius: hp(2),

            justifyContent: 'center',
          }}>
          <SvgCssUri
            width={40}
            height={45}
            uri={imageSource + '?' + new Date()}
            fill={backgroundColor}
          />
        </View>
        <Text
          style={{
            fontFamily: Fonts.SourceSansRegular,
            fontSize: hp(1.6),
            color: colors.black4,
            marginTop: hp(2.2),
            marginBottom: hp(1.1),
          }}>
          {text}
        </Text>
      </View>
    </Pressable>
  ) : text === 'Symptoms' ? (
    <Pressable
      onPress={() => {
        // Medications
        console.log('Inside Sleep Monitor');

        navigation.navigate('SymptomsStack', {navigation: navigation});
      }}>
      <View
        style={{
          alignItems: 'center',
          alignContent: 'center',
          alignItems: 'center',
          alignSelf: 'center',
          paddingRight: hp(2),
        }}>
        <View
          style={{
            alignContent: 'center',
            alignItems: 'center',
            height: hp(8.2),
            backgroundColor: backgroundColor,
            width: hp(8.2),
            borderRadius: hp(2),

            justifyContent: 'center',
          }}>
          <SvgCssUri
            width={40}
            height={45}
            uri={imageSource + '?' + new Date()}
            fill={backgroundColor}
          />
        </View>
        <Text
          style={{
            fontFamily: Fonts.SourceSansRegular,
            fontSize: hp(1.6),
            color: colors.black4,
            marginTop: hp(2.2),
            marginBottom: hp(1.1),
          }}>
          {text}
        </Text>
      </View>
    </Pressable>
  ) : (
    <Pressable
      style={{
        marginBottom: hp(1),
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: hp(1),
      }}
      onPress={() => {
        console.log(
          navigation,
          id,
          healthKitData,
          activityData,
          distanceWalked,
        );
        navigation.navigate('StepCounter', {
          navigation: navigation,
          id: id,
          stepsTakenToday: healthKitData,
          item: activityData,
          dsstanceCoverd: Math.ceil(distanceWalked),
          speed: calculatedSpeed,
          stepCount: Platform.OS === 'android' ? healthKitData : stepHealth, //when there is no value comming from the googleFit then will send the last value comming from the api otherwise we will send the steps recieve from the google fit
        });
      }}>
      <View
        style={{
          alignContent: 'center',
          alignItems: 'center',
          height: hp(8.2),
          backgroundColor: backgroundColor,
          width: hp(8.2),
          borderRadius: hp(2),
          justifyContent: 'center',
        }}>
        <SvgCssUri
          width={40}
          height={45}
          uri={imageSource + '?' + new Date()}
          fill={backgroundColor}
        />
      </View>
      <View
        style={{
          alignItems: 'center',
          justifyContent: 'center',
          width: hp(11),
        }}>
        <Text
          style={{
            fontFamily: Fonts.SourceSansRegular,
            fontSize: hp(1.6),
            color: colors.black4,
            marginTop: hp(2.2),
          }}
          numberOfLines={1}>
          {text}
          {console.log('Steps from the health kit are : ', healthKitData)}
        </Text>
      </View>
    </Pressable>
  );
};

export default ActivityIcon;

const styles = StyleSheet.create({});
