// import {View, Text} from 'react-native';
import {Fragment, useEffect, useState} from 'react';

import MultiSlider from '@ptomasroos/react-native-multi-slider';
import {default as Moment, default as moment} from 'moment';
import React from 'react';
import {StyleSheet, Text, TouchableOpacity, View,Image} from 'react-native';

import LinearGradient from 'react-native-linear-gradient';
// import {
//   Easing,
//   useAnimatedStyle,
//   useSharedValue,
//   withSpring,
//   withTiming,
// } from 'react-native-reanimated';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {SvgCss} from 'react-native-svg';
import {Colors, Images, Svgs} from '../../../../../../config';
import {Fonts} from '../../../../../../config/AppConfig';
import VitalsService from '../../../../../api/vitals';

const SymptomSliderScreen = ({navigation, route}) => {
  const buttonName = route.params.buttonName;

  const [sliderText, setSliderText] = useState('Low');

//   const [isModalVisible, setModalVisible] = useState(false);
//   const gradientColors = ['#DE445D', '#2962FF'];
//   const [date, setDate] = useState(
//     moment(new Date()).format('yyyy-MM-DDThh:mm:ss'),
//   );

  const [loader, setloader] = useState(false);
  useEffect(() => {
    const defaultValueFromApi = 0;
    setDefaultValue(defaultValueFromApi);
    setSliderValue(defaultValueFromApi);

    getChartData();
  }, []);

  function getChartData(date) {
    setloader(true);
    VitalsService.getVitalCategoryHistory(
      10,
      Moment(new Date(date)).format('YYYY-MM-DD'),
    )
      .then(response => {
        setloader(false);
        console.log('getVitalCategoryHistory');
        console.log(JSON.stringify(response));

        if (response && response.statusCode === 200) {
          getvitalDataForChart(response.data);
        } else {
          showMessage({
            message: 'Information',
            description:
              'Authentication Failed. Provided information is not verified.',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        }
      })
      .catch(err => {
        setloader(false);
        console.log('error');
        console.log(err);
        showMessage({
          message: 'Info',
          description: 'Internal Server Error',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  }
  function getvitalDataForChart(listData) {
    let newStepList = [
      {
        value: 40,
        label: 'Jan',
        // spacing: 30,
        labelWidth: 20,
        labelTextStyle: {color: 'gray'},
        frontColor: '#177AD5',
        topLabelComponent: () => (
          <Text style={{color: 'black', fontSize: 10}}>50</Text>
        ),
      },
    ];
    console.debug('Just Inside');
    Object.keys(listData).map(valAtIndex => {
      newStepList.push({
        value: listData[valAtIndex].vitalData[0].value,
        label: listData[valAtIndex].vitalData[0].name.slice(0, 6),
        labelWidth: 40,
      });
    });
    console.log('The new StepList is');
    console.log(newStepList);
    setbarData(newStepList);
    console.log('The new StepList');
    console.log(barData);
  }
  enableScroll = () => this.setState({scrollEnabled: true});
  disableScroll = () => this.setState({scrollEnabled: false});
  // const translateY = useSharedValue(0);
  // const opacity = useSharedValue(1);

//   const animateTextChange = newText => {
//     const shouldSlideDown = sliderValue < 50; // Check if slider is moving down

//     translateY.value = withTiming(shouldSlideDown ? -30 : 30, {
//       duration: 300,
//       easing: Easing.linear,
//     });
//     opacity.value = withTiming(0, {
//       duration: 300,
//       easing: Easing.linear,
//     });

//     setTimeout(() => {
//       translateY.value = withSpring(0, {damping: 10, stiffness: 80});
//       opacity.value = withTiming(1, {
//         duration: 300,
//         easing: Easing.linear,
//       });

//       setSliderText(newText); // Update the new text
//     }, 300);
//   };

//   // Animated style for the text
//   const textAnimatedStyle = useAnimatedStyle(() => {
//     return {
//       transform: [{translateY: translateY.value}],
//       opacity: opacity.value,
//     };
//   });
//   const multiSliderValuesChange = values => {
//     console.log('====================================');
//     console.log('here i will set that state ', values);
//     console.log('====================================');
//     const newVal = values[0];
//     setSliderValue(newVal);
//     let newSliderText = 'Low';
//     if (newVal > 25 && newVal <= 50) {
//       newSliderText = 'Moderate';
//     } else if (newVal > 50 && newVal <= 75) {
//       newSliderText = 'Somewhat Low';
//     } else if (newVal > 75 && newVal <= 99) {
//       newSliderText = 'Moderately High';
//     } else if (newVal > 99) {
//       newSliderText = 'High';
//     }
//     animateTextChange(newSliderText);
//     if (newVal !== defaultValue) {
//       console.log('Slider value is over 50%');
//       setshowSave('yes');
//       // add your logic here to update the text below the slider
//     } else {
//       console.log('Slider value is the same as API');
//       setshowSave('no');
//     }
//   };

//   const [showSave, setshowSave] = useState('no');

//   const [defaultValue, setDefaultValue] = useState(0);
//   const [sliderValue, setSliderValue] = useState(defaultValue);
//   const renderMarker = ({currentValue}) => {
//     const markerColor =
//       currentValue > 50 ? Colors.sliderBlueColor : Colors.sliderRedColor;
//     const markerStyle = {
//       backgroundColor: markerColor,
//       borderRadius: 20,
//       width: 40,
//       height: 40,
//       alignItems: 'center',
//       justifyContent: 'center',
//     };
//     return (
//       <View style={markerStyle}>
//         <View style={styles.markerText}></View>
//       </View>
//     );
//   };

  return (
    <Fragment>
      <View
        style={{
          flex: 1,
          backgroundColor: Colors.backgroundMainLogin,
        }}>
        <View style={styles.container}>
          <View
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              flexDirection: 'row',
              marginTop: hp(6.5),
            }}>
            <View style={{flex: 0.25, paddingLeft: hp(1)}}>
              <SvgCss
                xml={Svgs.arrowHeadLeft}
                width={hp(4)}
                height={hp(4)}
                fill={Colors.black}
                onPress={() => {
                  navigation.pop();
                }}
              />
            </View>
            <View style={{flex: 0.6, alignItems: 'center'}}>
              <Text
                style={{
                  color: Colors.black,
                  fontSize: hp(2.5),
                  fontFamily: Fonts.SourceSansSemibold,
                }}>
                Symptom Tracker
              </Text>
            </View>
            <View style={{flex: 0.25, alignItems: 'flex-end'}}>
              <TouchableOpacity
                onPress={() => navigation.navigate('NotificationStack')}>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'flex-start',
                    marginRight: hp(2),
                  }}>
                  <Image
                    style={{
                      width: hp(2),
                      height: hp(2.5),
                    }}
                    source={Images.notification_dashboard}
                  />
                </View>
              </TouchableOpacity>
            </View>
          </View>
        </View>
        {/* header end */}
        <View
          style={{
            flex: 1,
            backgroundColor: Colors.backgroundMainLogin,
            shadowOffset: {width: 0.5, height: 0.5},
            shadowOpacity: 0.5,
            shadowRadius: 1.5,
            elevation: 1,
            borderTopColor: Colors.darkGrey1,
            borderTopRightRadius: 24,
            borderTopLeftRadius: 24,
            marginTop: hp(2),
          }}>
          <View
            style={{
              borderTopRightRadius: 24,
              borderTopLeftRadius: 24,
              backgroundColor: Colors.white,
              width: '100%',
              paddingLeft: hp(0.5),
              paddingRight: hp(0.5),
              alignSelf: 'center',
            }}>
            <View
              style={{
                width: '100%',

                height: '100%',
                borderTopRightRadius: 24,
                borderTopLeftRadius: 24,
                backgroundColor: Colors.white,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
              }}>
              <View>
                <View>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansPro,
                      fontSize: hp(2.6),
                      fontWeight: '700',
                      marginTop: hp(4),
                      color: Colors.TextColor,
                      alignSelf: 'center',
                    }}>
                    Depressive
                  </Text>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansPro,
                      fontSize: hp(3.6),
                      fontWeight: '700',
                      marginTop: hp(4),
                      color: Colors.black,
                      alignSelf: 'center',
                    }}>
                    {'Measure your'}
                  </Text>
                  <Text
                    style={{
                      fontFamily: Fonts.SourceSansPro,
                      fontSize: hp(3.6),
                      fontWeight: '700',
                      color: Colors.black,
                      marginTop: hp(-4),
                      alignSelf: 'center',
                    }}>
                    {'\nselected Symptom'}
                  </Text>
                </View>
                <View
                  style={{
                    paddingBottom: hp(2),
                  }}></View>

                <Text
                  style={{
                    fontFamily: Fonts.SourceSansPro,
                    fontSize: hp(2.6),
                    fontWeight: '700',
                    marginTop: hp(4),
                    color: Colors.greenTextColor,
                    alignSelf: 'center',
                  }}>
                  {buttonName}
                </Text>

                <View style={styles.sliderContainer}>
                  <LinearGradient
                    colors={gradientColors}
                    start={{x: 0, y: 0}}
                    end={{x: 1, y: 0}}
                    style={styles.gradientOverlay}
                  />
                  <MultiSlider
                    customMarker={renderMarker}
                    onValuesChange={multiSliderValuesChange}
                    sliderLength={hp(39.5)}
                    values={[sliderValue]}
                    min={0}
                    max={100}
                    containerStyle={{
                      height: 100,
                      marginLeft: hp(4),
                      marginRight: hp(4),
                      maxWidth: '90%',
                      alignSelf: 'center',
                    }}
                    trackStyle={{
                      height: hp(1),
                      backgroundColor: 'transparent',
                      maxWidth: '90%',
                    }}
                    unselectedStyle={{
                      containerColor: 'red',
                    }}
                    selectedStyle={{
                      backgroundColor: 'transparent',
                    }}
                  />
                </View>
                <Text style={styles.sliderText}>{sliderText}</Text>
              </View>
              <View
                style={{
                  marginBottom: hp(1),
                  width: '90%',
                  alignSelf: 'center',
                }}>
                {showSave === 'yes' ? (
                  <TouchableOpacity
                    onPress={() => navigation.navigate('Symptoms')}
                    style={{
                      paddingTop: hp(8),
                    }}>
                    <View
                      style={{
                        alignItems: 'center',
                        padding: 20,
                        borderRadius: hp(1),
                        backgroundColor: Colors.blueBackground,
                      }}>
                      <Text
                        style={{
                          color: Colors.white,
                          fontFamily: Fonts.SourceSansPro,
                          fontWeight: '600',
                          fontSize: hp(2),
                        }}>
                        Save
                      </Text>
                    </View>
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity
                    style={{
                      paddingTop: hp(8),
                    }}>
                    <View
                      style={{
                        alignItems: 'center',
                        padding: 20,
                        borderRadius: hp(1),
                        backgroundColor: Colors.bgGrey,
                      }}>
                      <Text
                        style={{
                          color: Colors.darkgrey,
                          fontFamily: Fonts.SourceSansPro,
                          fontWeight: '600',
                          fontSize: hp(2),
                        }}>
                        Save
                      </Text>
                    </View>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          </View>
        </View>
      </View>
    </Fragment>
  );
};
// Styles
const styles = StyleSheet.create({
  markerText: {
    borderWidth: 1,
    borderColor: Colors.white,
    padding: hp(1),
    borderRadius: 12,
    backgroundColor: Colors.white,
  },
  item: {
    flex: 1,
    maxWidth: '50%', // 100% devided by the number of rows you want
    alignItems: 'center',
    padding: 20,
    backgroundColor: 'rgba(249, 180, 45, 0.25)',
    borderWidth: 1,

    backgroundColor: Colors.blueBackground,
  },
  sliderContainer: {
    position: 'relative',
    overflow: 'hidden',
  },
  gradientOverlay: {
    position: 'absolute',
    top: '42%',
    height: hp(1),
    left: 0,
    right: 0,
    borderRadius: 10,
    marginLeft: hp(1.5),
    marginRight: hp(1.5),
  },
  sliderText: {
    fontFamily: Fonts.SourceSansPro,
    fontSize: hp(3.6),
    fontWeight: '700',
    color: Colors.black,
    alignSelf: 'center',
  },
  container: {
    backgroundColor: Colors.BgColor,
    marginTop: hp(1),
  },
});

// export default SymptomSliderScreen;
