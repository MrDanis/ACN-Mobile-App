//import liraries
import React from 'react';
import {Pressable, StyleSheet, Text, View,Image} from 'react-native';

import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Swiper from 'react-native-swiper';
import {Colors, Images} from '../../../../../config';
import {Fonts} from '../../../../../config/AppConfig';

// create a component
const HealthMaintenanceCard = ({navigation, healthData}) => {
  return (
    <View
      style={{
        borderRadius: 8,
        height: hp(22),
        backgroundColor: Colors.bleLayer4,
        width: '47%',
        marginTop: hp(2),
        shadowOffset: {width: 0.5, height: 0.5},
        shadowOpacity: 0.1,
        shadowRadius: 8,
        elevation: 3,
      }}>
      {healthData !== null && healthData.length > 0 && (
        <Pressable
          onPress={() => {
            navigation.navigate('ImmunizationScreen');
          }}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              width: '100%',
              paddingLeft: hp(1),
            }}>
            <View
              style={{
                // flex: 1,
                // height: hp(6),
                // borderWidth: 1,
                padding: hp(2),
                borderColor: 'red',
                alignItems: 'center',
                justifyContent: 'center',
                padding: hp(0.5),
                backgroundColor: '#40CECF',
                borderRadius: 8,
                // maxHeight: 'streach',
              }}>
              <Image
                style={{
                  width: hp(3),
                  height: hp(3),
                  // marginTop: hp(1.5),
                  borderColor: 'red',
                  // borderWidth: 1,
                  backgroundColor: '#40CECF',
                }}
                resizeMode="contain"
                source={Images.health_care_dashboard}
              />
            </View>
            <Pressable
              style={{height: hp(6)}}
              onPress={() => {
                navigation.navigate('ImmunizationScreen');
              }}>
              <Image
                style={{
                  width: hp(1.5),
                  height: hp(1.5),
                  margin: hp(1.5),
                }}
                resizeMode="contain"
                source={Images.newDashboardArrow}
              />
            </Pressable>
          </View>
          <View
            style={{
              paddingLeft: hp(1),
              flexDirection: 'row',
              alignItems: 'center',
              marginVertical: hp(1),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansSemibold,
                fontSize: hp(1.8),
                color: Colors.black,
                fontWeight: '600',
              }}>
              Health Maintenance
            </Text>
          </View>

          <View
            style={{
              paddingLeft: hp(3),
              width: '90%',
              marginTop: hp(2),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansSemibold,
                fontSize: Platform.OS === 'ios' ? hp(2.2) : hp(2),
                color: Colors.TextColor,
                fontWeight: '600',
              }}
              numberOfLines={2}>
              {healthData[0].vaccineName}
            </Text>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: Platform.OS === 'ios' ? hp(1.8) : hp(1.6),
                color: Colors.TextColor,
              }}
              numberOfLines={2}>
              {healthData[0].unitText}
            </Text>
          </View>
        </Pressable>
      )}
      {healthData !== null && healthData.length === 0 && (
        <Pressable
          style={{flex: 1}}
          onPress={() => {
            navigation.navigate('ImmunizationScreen');
          }}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              width: '100%',
              paddingLeft: hp(1),
            }}>
            <View
              style={{
                // flex: 1,
                // height: hp(6),
                // borderWidth: 1,
                padding: hp(2),
                borderColor: 'red',
                alignItems: 'center',
                justifyContent: 'center',
                padding: hp(0.5),
                backgroundColor: '#40CECF',
                borderRadius: 8,
                marginTop: hp(0.5),
                // maxHeight: 'streach',
              }}>
              <Image
                style={{
                  width: hp(3),
                  height: hp(3),
                  // marginTop: hp(1.5),
                  borderColor: 'red',
                  // borderWidth: 1,
                  backgroundColor: '#40CECF',
                }}
                resizeMode="contain"
                source={Images.health_care_dashboard}
              />
            </View>
            <Pressable
              style={{height: hp(6)}}
              onPress={() => {
                navigation.navigate('ImmunizationScreen');
              }}>
              <Image
                style={{
                  width: hp(1.5),
                  height: hp(1.5),
                  margin: hp(1.5),
                }}
                resizeMode="contain"
                source={Images.newDashboardArrow}
              />
            </Pressable>
          </View>
          <View
            style={{
              paddingLeft: hp(1),
              flexDirection: 'row',
              alignItems: 'center',
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansSemibold,
                fontSize: hp(1.8),
                color: Colors.black,
                fontWeight: '600',
                marginTop: hp(1.9),
              }}>
              Health Maintenance
            </Text>
          </View>

          <View
            style={{
              paddingLeft: hp(3),
              width: '90%',
              marginTop: hp(1.5),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2.2),
                color: Colors.TextColor,
              }}>
              No Record
            </Text>
          </View>
        </Pressable>
      )}
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#2c3e50',
  },
});

//make this component available to the app
export default HealthMaintenanceCard;
