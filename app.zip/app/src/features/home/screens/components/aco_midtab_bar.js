import React from 'react';
import {Platform, Pressable, StyleSheet, View,Image} from 'react-native';

import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {Images} from '../../../../../config';
import MiddleTabIcon from './middle_tab_icon';

const AcoMidTabBar = ({navigation}) => {
  return Platform.OS === 'ios' ? (
    <View style={{alignItems: 'center'}}>
      <View
        style={{
          flexDirection: 'column',
        }}>
        <View
          style={{
            marginTop: hp(6),
            flexDirection: 'row',
          }}>
          <Pressable
            onPress={() => {
              navigation.navigate('VitalsStack');
            }}>
            <MiddleTabIcon
              imageSource={Images.heart_dashboard}
              text={'Vitals'}
            />
          </Pressable>

          <Image
            style={{
              width: hp(0.12),
              height: hp(25),
            }}
            source={Images.straightLine_dashboard}
          />
          <Pressable
            onPress={() => {
              // Assessment
              navigation.navigate('MedicationStack');
            }}>
            <MiddleTabIcon
              imageSource={Images.medicine_dashboard}
              text={'Medications'}
            />
          </Pressable>
          <Image
            style={{
              width: 0.7,
              height: hp(27),
            }}
            source={Images.straightLine_dashboard}
          />

          <Pressable onPress={() => navigation.navigate('AppointmentScreen')}>
            <MiddleTabIcon
              imageSource={Images.appointment_dashboard}
              text={'Appointments'}
            />
          </Pressable>
        </View>
        <View style={{marginTop: hp(-14), marginLeft: hp(1.7)}}>
          <Image
            style={{
              width: '94%',
              height: hp(0.2),
            }}
            source={Images.horizontalLine_dashboard}
          />
        </View>
      </View>

      <View
        style={{
          marginTop: hp(-2),
          flexDirection: 'column',
        }}>
        <View
          style={{
            marginTop: hp(5),
            flexDirection: 'row',
          }}>
          <Pressable
            onPress={() => {
              // Lab
              navigation.navigate('Lab');
            }}>
            <MiddleTabIcon imageSource={Images.lab_dashboard} text={'Labs'} />
          </Pressable>

          <Pressable
            onPress={() => {
              navigation.navigate('ScheduleAppointment');
            }}>
            <MiddleTabIcon imageSource={Images.findADoc} text={'Find Doc'} />
          </Pressable>
          <Pressable
            onPress={() => navigation.navigate('Imaging')}
            style={{
              marginLeft: hp(1.7),
            }}>
            <MiddleTabIcon
              imageSource={Images.body_scan_dashboard}
              text={'Imaging'}
            />
          </Pressable>
        </View>
      </View>
    </View>
  ) : (
    <View style={{borderColor: 'red', borderWidth: 0}}>
      <View
        style={{
          flexDirection: 'column',
          borderColor: 'red',
          borderWidth: 0,
        }}>
        <View
          style={{
            marginTop: hp(6),
            flexDirection: 'row',
          }}>
          <Pressable
            onPress={() => {
              navigation.navigate('VitalsStack');
            }}>
            <MiddleTabIcon
              imageSource={Images.heart_dashboard}
              text={'Vitals'}
            />
          </Pressable>

          <Image
            style={{
              width: 1.09,
              height: hp(27),
            }}
            source={Images.straightLine_dashboard}
          />
          <Pressable
            onPress={() => {
              navigation.navigate('MedicationStack');
            }}>
            <MiddleTabIcon
              imageSource={Images.medicine_dashboard}
              text={'Medications'}
            />
          </Pressable>
          <Image
            style={{
              width: 0.7,
              height: hp(25),
              borderColor: 'blue',
              borderWidth: 0,
            }}
            source={Images.straightLine_dashboard}
          />

          <Pressable
            style={{borderColor: 'pink', borderWidth: 0}}
            onPress={() => navigation.navigate('AppointmentScreen')}>
            <MiddleTabIcon
              imageSource={Images.appointment_dashboard}
              text={'Appointments'}
            />
          </Pressable>
        </View>
        <View
          style={{
            marginTop: hp(-13),
            marginLeft: hp(0.5),
            marginRight: hp(1),
          }}>
          <Image
            style={{
              width: hp(50),
              height: hp(0.2),
            }}
            source={Images.horizontalLine_dashboard}
          />
        </View>
      </View>

      <View
        style={{
          marginTop: hp(-2),
          flexDirection: 'column',
        }}>
        <View
          style={{
            marginTop: hp(5),
            flexDirection: 'row',
          }}>
          <Pressable
            onPress={() => {
              // Lab
              navigation.navigate('Lab');
            }}>
            <MiddleTabIcon imageSource={Images.lab_dashboard} text={'Labs'} />
          </Pressable>
          <Pressable
            onPress={() => {
              navigation.navigate('ScheduleAppointment');
            }}>
            <MiddleTabIcon imageSource={Images.findADoc} text={'Find Doc'} />
          </Pressable>

          <Pressable
            onPress={() => navigation.navigate('Imaging')}
            style={{
              marginLeft: hp(1.7),
            }}>
            <MiddleTabIcon
              imageSource={Images.body_scan_dashboard}
              text={'Imaging'}
            />
          </Pressable>
        </View>
      </View>
    </View>
  );
};

export default AcoMidTabBar;

const styles = StyleSheet.create({});
