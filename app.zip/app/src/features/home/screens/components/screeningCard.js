//import liraries
import React from 'react';
import {Pressable, StyleSheet, Text, View,Image} from 'react-native';

import * as Progress from 'react-native-progress';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Swiper from 'react-native-swiper';
import {Colors, Images} from '../../../../../config';
import {Fonts} from '../../../../../config/AppConfig';

// create a component
const ScreeningCard = ({navigation, assesmentData}) => {
  return (
    <View
      style={{
        marginTop: hp(2),
        borderRadius: 8,
        height: hp(22),
        backgroundColor: Colors.bleLayer4,
        width: '47%',
        marginTop: hp(2),

        shadowOffset: {width: 0.5, height: 0.5},
        shadowOpacity: 0.1,
        shadowRadius: 8,
        elevation: 3,
      }}>
      <Pressable
        onPress={() => {
          navigation.navigate('AssessmentStack');
        }}>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            width: '100%',
            paddingLeft: hp(3),
          }}>
          <View style={{flex: 1, height: hp(6)}}>
            <Image
              style={{
                width: hp(4),
                height: hp(4),
                marginTop: hp(1.5),
              }}
              resizeMode="contain"
              source={Images.new_assesmentIcon}
            />
          </View>
          <View style={{height: hp(6)}}>
            <View
              style={{
                // backgroundColor: '#4F6BE9',
                alignItems: 'flex-end',
                borderBottomLeftRadius: 8,
                borderTopRightRadius: 8,
                justifyContent: 'flex-start',
              }}>
              <Image
                style={{
                  width: hp(1.5),
                  height: hp(1.5),
                  margin: hp(1.5),
                }}
                resizeMode="contain"
                source={Images.newDashboardArrow}
              />
            </View>
          </View>
        </View>
        <View style={{paddingLeft: hp(3), paddingTop: hp(2)}}>
          <Text
            style={{
              fontFamily: Fonts.SourceSansSemibold,
              fontSize: hp(1.8),
              color: Colors.black,
              fontWeight: '600',
            }}>
            Assessment
          </Text>
        </View>
        {assesmentData !== null && assesmentData?.length === 0 ? (
          <View
            style={{
              paddingLeft: hp(3),
              width: '90%',
              marginTop: hp(2),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2.2),
                color: Colors.TextColor,
              }}>
              No Record
            </Text>
          </View>
        ) : (
          <View
            style={{
              paddingLeft: hp(3),
              marginTop: hp(1.5),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansSemibold,
                fontSize: Platform.OS === 'ios' ? hp(2.2) : hp(2),
                color: Colors.TextColor,
                fontWeight: '600',
              }}
              numberOfLines={1}>
              {assesmentData[0].title}
            </Text>
          </View>
        )}
      </Pressable>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#2c3e50',
  },
});

//make this component available to the app
export default ScreeningCard;
