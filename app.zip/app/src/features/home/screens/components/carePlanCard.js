//import liraries
import React from 'react';
import {Pressable, StyleSheet, Text, View,Image} from 'react-native';

import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Swiper from 'react-native-swiper';
import {Colors, Images} from '../../../../../config';
import {Fonts} from '../../../../../config/AppConfig';

// create a component
const CarePlanCard = ({navigation, labsData}) => {
  return (
    <View
      style={{
        borderRadius: 8,
        height: hp(22),
        backgroundColor: Colors.carePlanCardColor,
        width: '47%',
        marginTop: hp(2),
        shadowOffset: {width: 0.5, height: 0.5},
        shadowOpacity: 0.1,
        shadowRadius: 8,
        elevation: 3,
      }}>
      <Swiper
        style={{}}
        autoplay
        horizontal
        dot={
          <View
            style={{
              backgroundColor: Colors.white,
              width: 7,
              height: 7,
              borderRadius: 4,
              marginLeft: 3,
              marginRight: 3,
              marginTop: 3,
              marginBottom: hp(-2),
              opacity: 0.5,
            }}
          />
        }
        activeDot={
          <View
            style={{
              backgroundColor: Colors.white,
              width: 8,
              height: 8,
              borderRadius: 4,
              marginLeft: 3,
              marginRight: 3,
              marginTop: 3,
              marginBottom: hp(-2),
            }}
          />
        }
        activeDotColor={Colors.white}
        autoplayTimeout={4}>
        <Pressable
          onPress={() => {
            navigation.navigate('CarePlans');
          }}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              width: '100%',
              paddingLeft: hp(3),
            }}>
            <View style={{flex: 1, height: hp(6)}}>
              <Image
                style={{
                  width: hp(3.5),
                  height: hp(3.5),
                  marginTop: hp(1.5),
                }}
                resizeMode="contain"
                source={Images.careplan_dashboard}
              />
            </View>
            <Pressable style={{height: hp(6)}}>
              <View
                style={{
                  backgroundColor: Colors.card_Arrow_careplan,
                  alignItems: 'flex-end',
                  borderBottomLeftRadius: 8,
                  borderTopRightRadius: 8,
                  justifyContent: 'flex-start',
                }}>
                <Image
                  style={{
                    width: hp(1.5),
                    height: hp(1.5),
                    margin: hp(1.5),
                  }}
                  resizeMode="contain"
                  source={Images.card_arrow}
                />
              </View>
            </Pressable>
          </View>
          <View style={{paddingLeft: hp(3), paddingTop: hp(2)}}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansSemibold,
                fontSize: hp(1.8),
                color: Colors.white,
              }}>
              Care Plans
            </Text>
          </View>
          <View
            style={{
              paddingLeft: hp(3),
              marginTop: hp(1.5),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansSemibold,
                fontSize: hp(2.3),
                color: Colors.white,
              }}
              numberOfLines={2}>
              3 Activities Pending
            </Text>
          </View>
        </Pressable>
      </Swiper>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#2c3e50',
  },
});

//make this component available to the app
export default CarePlanCard;
