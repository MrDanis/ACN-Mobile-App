import React from 'react';
import {Pressable, StyleSheet, Text,Image} from 'react-native';

import {Fonts} from '../../../../../config/AppConfig';
import colors from '../../../../../config/Colors';
import {modalHanlder} from '../../../medication/actions';
const ShortcutCards = ({
  imageSource,
  text,
  id,
  navigation,
  setIsCamera,
  isCamera,
  dispatch,
}) => {
  function dialCall(number) {
    // According to the new flow we have to add the navigation in this function so that a new screen will be shown
    // Placing the route in the home stack to have the bottom tab at the end other wise it will cause issue
    console.log('Navigations are : ', navigation);
    console.log('CareManager Phone Number', number);
    navigation.navigate('urgentCare');
  }
  const handleIosPress = () => {
    switch (id) {
      case 0: //code block for navigating to prescription screen of the Medication Stack
        navigation.navigate('AllergiesScreen');
        break;
      case 1: //code block for navigating to Assesment stack
        navigation.navigate('ImmunizationScreen');

        break;
      case 2: //code block for navigating to camera module
        dispatch(modalHanlder(false));
        console.log('====================================');
        console.log('herer');
        console.log('====================================');
        setIsCamera(!isCamera);
        break;
      case 3:
        dialCall('911');
        break;

      default:
        break;
    }
  };

  // Function responsible for navigating through shortcuts on android by Danish (Start)
  const handleAndroidPress = () => {
    switch (id) {
      case 0: //code block for navigating to prescription screen of the Medication Stack
        navigation.navigate('AllergiesScreen');
        break;
      case 1: //code block for navigating to Assesment stack
        navigation.navigate('ImmunizationScreen');
      case 2:
        dispatch(modalHanlder(false));
        console.log('====================================');
        console.log('herer');
        console.log('====================================');
        setIsCamera(!isCamera);
        console.log('Navigate to Take Pic from android');
        break;
      case 3:
        dialCall('911');
        console.log('Navigate to Urgent call from android');
        break;
      default:
        break;
    }
  };
  // Function responsible for navigating through shortcuts on android by Danish (End)
  return (
    <>
      <Pressable
        onPress={handleIosPress}
        style={{
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
        }}>
        <Image
          resizeMode="contain"
          style={{
            width: 25,
            height: 35,
          }}
          source={imageSource}
        />
        <Text
          style={{
            fontFamily: Fonts.SourceSansRegular,
            fontSize: 13.5,
            color: colors.black4,
          }}>
          {text}
        </Text>
      </Pressable>
    </>
  );
};

export default ShortcutCards;

const styles = StyleSheet.create({});
