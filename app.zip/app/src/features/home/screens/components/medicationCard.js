//import liraries
import React from 'react';
import {Platform, Pressable, StyleSheet, Text, View,Image} from 'react-native';

import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Swiper from 'react-native-swiper';
import {Colors, Images} from '../../../../../config';
import {Fonts} from '../../../../../config/AppConfig';

// create a component
const MedicationCard = ({navigation, medicationData}) => {
  console.log('====================================');
  console.log('medicationData', medicationData);
  console.log('====================================');
  const medicationImageSelector = index => {
    if (medicationData[index]?.medicationSlot[0] === 0) {
      return Images.sunIcon_dashboard_yellow;
    } else if (medicationData[index]?.medicationSlot[0] === 1) {
      return Images.noon_icon_white;
    } else if (medicationData[index]?.medicationSlot[0] === 2) {
      return Images.evening_icon_white;
    }
  };
  const medicationSlotSelector = index => {
    if (medicationData[index]?.medicationSlot[0] === 0) {
      return 'Morning';
    } else if (medicationData[index]?.medicationSlot[0] === 1) {
      return 'Noon';
    } else if (medicationData[index]?.medicationSlot[0] === 2) {
      return 'Evening';
    }
  };
  return (
    <View
      style={{
        borderRadius: 8,
        height: hp(22),
        backgroundColor: Colors.bleLayer4,
        width: '47%',
        marginTop: hp(2),
        shadowOffset: {width: 0.5, height: 0.5},
        shadowOpacity: 0.1,
        shadowRadius: 8,
        elevation: 3,
      }}>
      <Pressable
        onPress={() => {
          navigation.navigate('MedicationStack');
        }}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            width: '100%',
            paddingLeft: hp(1),
          }}>
          <View
            style={{
              // flex: 1,
              // height: hp(6),
              // borderWidth: 1,
              padding: hp(2),
              borderColor: 'red',
              alignItems: 'center',
              justifyContent: 'center',
              padding: hp(0.5),
              backgroundColor: '#00D685',
              borderRadius: 8,
              // maxHeight: 'streach',
            }}>
            <Image
              style={{
                width: hp(3),
                height: hp(3),
                // marginTop: hp(1.5),
                borderColor: 'red',
                // borderWidth: 1,
                backgroundColor: '#00D685',
                // padding: hp(),
              }}
              // tintColor={'#FFFFFF'}
              resizeMode="contain"
              source={Images.medication_dashboard}
            />
          </View>

          <Pressable
            style={{height: hp(6)}}
            onPress={() => {
              navigation.navigate('MedicationStack');
            }}>
            <Image
              style={{
                width: hp(1.5),
                height: hp(1.5),
                margin: hp(1.5),
                // borderWidth: 1,
              }}
              resizeMode="contain"
              source={Images.newDashboardArrow}
            />
          </Pressable>
        </View>

        <View
          style={{
            paddingLeft: hp(0.5),
            marginVertical: hp(1.5),
            flexDirection: 'row',
            alignItems: 'center',
            gap: 5,
          }}>
          <Text
            style={{
              fontFamily: Fonts.SourceSansSemibold,
              fontWeight: '600',
              fontSize: hp(1.8),
              color: Colors.black,
              marginLeft: hp(1),
            }}>
            Medications
          </Text>
          <Image
            style={{
              width: hp(2.5),
              height: hp(2.5),
              // backgroundColor: '#FCB73E',
            }}
            // tintColor="#FCB73E"
            resizeMode="contain"
            source={medicationImageSelector(0)}
          />
        </View>
        {medicationData !== null && medicationData?.length > 0 ? (
          <View
            style={{
              marginTop: hp(1.5),
              paddingLeft: hp(1),
              borderColor: 'red',
              borderWidth: 0,
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansSemibold,
                fontSize: Platform.OS === 'ios' ? hp(2.2) : hp(1.8),
                color: Colors.TextColor,
                fontWeight: '600',
              }}
              numberOfLines={1}>
              {medicationData[0]?.proprietaryName}
            </Text>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: Platform.OS === 'ios' ? hp(1.7) : hp(1.5),
                color: Colors.TextColor,
                marginTop: hp(1),
              }}>
              {medicationData[0]?.mealStatus === false
                ? 'Before Meal'
                : 'After Meal'}
            </Text>
          </View>
        ) : (
          <View
            style={{
              paddingLeft: hp(3),
              width: '90%',
              marginTop: hp(2),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2.2),
                color: Colors.TextColor,
              }}>
              No Record
            </Text>
          </View>
        )}
      </Pressable>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#2c3e50',
  },
});

//make this component available to the app
export default MedicationCard;
