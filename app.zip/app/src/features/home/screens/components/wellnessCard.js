//import liraries
import React from 'react';
import {Pressable, StyleSheet, Text, View,Image} from 'react-native';

import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Swiper from 'react-native-swiper';
import {Colors, Images} from '../../../../../config';
import {Fonts} from '../../../../../config/AppConfig';

// create a component
const WellnessCard = ({navigation}) => {
  return (
    <View
      style={{
        borderRadius: 8,
        height: hp(22),
        backgroundColor: Colors.bleLayer4,
        width: '47%',
        marginTop: hp(2),
        shadowOffset: {width: 0.5, height: 0.5},
        shadowOpacity: 0.1,
        shadowRadius: 8,
        elevation: 3,
      }}>
      <Pressable
        onPress={() => {
          navigation.navigate('Wellnesss');
        }}>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            width: '100%',
            paddingLeft: hp(1),
            justifyContent: 'space-between',
          }}>
          <View
            style={{
              borderColor: 'red',
              alignItems: 'center',
              justifyContent: 'center',
              padding: hp(0.5),
              borderRadius: 8,
              backgroundColor: '#24ACAD',
            }}>
            <Image
              style={{
                width: hp(3),
                height: hp(3),
                // marginTop: hp(1.5),
              }}
              resizeMode="contain"
              source={Images.wellness_dashboard}
            />
          </View>
          <Pressable
            onPress={() => navigation.navigate('Wellnesss')}
            style={{height: hp(6)}}>
            <View
              style={{
                backgroundColor: Colors.bleLayer4,
                alignItems: 'flex-end',
                borderBottomLeftRadius: 8,
                borderTopRightRadius: 8,
                justifyContent: 'flex-start',
              }}>
              <Image
                style={{
                  width: hp(1.5),
                  height: hp(1.5),
                  margin: hp(1.5),
                }}
                resizeMode="contain"
                source={Images.newDashboardArrow}
              />
            </View>
          </Pressable>
        </View>
        <View
          style={{
            paddingLeft: hp(1),
            flexDirection: 'row',
            alignItems: 'center',
          }}>
          <Text
            style={{
              fontFamily: Fonts.SourceSansSemibold,
              fontSize: hp(1.8),
              color: Colors.black,
              marginTop: hp(1.5),
              fontWeight: '600',
            }}>
            Wellness
          </Text>
        </View>
        <View
          style={{
            paddingLeft: hp(1),
            marginVertical: Platform.OS === 'ios' ? hp(1.5) : hp(1),
          }}>
          <Text
            style={{
              fontFamily: Fonts.SourceSansRegular,
              fontSize: hp(2.2),
              color: Colors.black,
            }}>
            Mental Health
          </Text>
        </View>
        <View
          style={{
            paddingLeft: hp(1),
            width: '90%',
          }}>
          <Text
            style={{
              fontFamily: Fonts.SourceSansRegular,
              fontSize: hp(1.8),
              color: Colors.TextColor,
            }}>
            Health education is a profession of...
          </Text>
        </View>
      </Pressable>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#2c3e50',
  },
});

//make this component available to the app
export default WellnessCard;
