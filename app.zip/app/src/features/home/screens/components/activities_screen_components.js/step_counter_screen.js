// import {View, Text} from 'react-native';
import moment from 'moment';
import React, {useEffect, useState} from 'react';
import {Platform, ScrollView, StyleSheet, Text, View,Image} from 'react-native';
import CalendarStrip from 'react-native-calendar-strip';
import {AnimatedCircularProgress} from 'react-native-circular-progress';

import {TouchableOpacity} from 'react-native-gesture-handler';
import Spinner from 'react-native-loading-spinner-overlay';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {SafeAreaView} from 'react-native-safe-area-context';
import {Colors, Images} from '../../../../../../config';
import {Fonts} from '../../../../../../config/AppConfig';
import images from '../../../../../../config/Images';
import {source} from '../../../../../api/constants';
import DiscoverService from '../../../../../api/discover';
import MainHeader from '../../../../mycare/components/MainHeader';
import CustomTestChart from '../../custom_chart';
const StepCounterScreen = ({navigation, route}) => {
  console.log('Route step is : ', route?.params);
  //================================================= Declaring the all the states (START) =================================================
  let dateType = 0;
  const [date, setDate] = useState(
    moment(new Date()).format('yyyy-MM-DDThh:mm:ss'),
  );
  const [isSelectedDay, setisSelectedDay] = useState('Day');
  const [goalCount, setgoalCount] = useState(route?.params?.item?.patientGoal);

  const [loader, setloader] = useState(false);
  const [barData, setbarData] = useState([]);
  const [barYaxisLabels, setbarYaxisLabels] = useState([]);
  const [maxChartRange, setmaxChartRange] = useState(0);
  // Creating a new state to resolve the data issue (START)
  const [golaStats, setgolaStats] = useState({
    goal: route?.params?.item?.patientGoal,
    avgGoal: route?.params?.stepCount,
    activeIndex: 0,
  });
  // Creating a new state to resolve the data issue (END)
  console.log('====================================');
  console.log('step data for api', parseInt(route?.params?.item?.value));
  console.log('====================================');
  //================================================= Declaring the all the states (END) =================================================
  const handleEditGoalCount = (val, type) => {
    if (type === 0) {
      setgoalCount(val);
      switch (golaStats.activeIndex) {
        case 0:
          setgolaStats({...golaStats, goal: parseInt(val)});
          break;
        case 1:
          setgolaStats({...golaStats, goal: parseInt(val * 7)});
          break;
        case 2:
          setgolaStats({...golaStats, goal: parseInt(val * 30)});
          break;
        default:
          break;
      }
      console.log('Date type is : ', dateType);
    } else {
    }
  };
  // function responsible to calculate the totall steps and the average steps
  // ========================Declaring all the function to preform the required functionality (START) ===============================
  // update the chart data base on the date on calendarStrip
  const handleDateChangeAndUpdateChart = date => {
    getChartData(date, 0);
    setDate(date);
  };
  async function getChartData(date, type) {
    // set the generic data for the screen also set the data for the chart

    setloader(true);
    console.log('Params comming from the parent are : ', route?.params);

    try {
      const dataRequest = await DiscoverService.getHealthCategoryById(
        route?.params?.id,
        date.split('T')[0],
        type,
      );
      const dataResponse = await dataRequest;
      console.log('data response is : ', dataResponse);
      if (dataResponse && dataResponse.statusCode === 200) {
        let tempData = [];
        if (dataResponse?.data?.length > 0) {
          switch (dateType) {
            case 0:
              setgolaStats({
                goal: goalCount,
                avgGoal: route?.params?.stepCount,
                activeIndex: 0,
              });
              let dayFormatSample = [
                '12:00 AM',
                '01:00 AM',
                '02:00 AM',
                '03:00 AM',
                '04:00 AM',
                '05:00 AM',
                '06:00 AM',
                '07:00 AM',
                '08:00 AM',
                '09:00 AM',
                '10:00 AM',
                '11:00 AM',
                '12:00 PM',
                '01:00 PM',
                '02:00 PM',
                '03:00 PM',
                '04:00 PM',
                '05:00 PM',
                '06:00 PM',
                '07:00 PM',
                '08:00 PM',
                '09:00 PM',
                '10:00 PM',
                '11:00 PM',
                '12:00 AM',
              ];
              let stackData = [];
              for (let j = 0; j < dayFormatSample.length; j++) {
                let groupedDayData = [];
                console.log(
                  'data of the day from the api is : ',
                  dataResponse?.data,
                );
                for (let k = 0; k < dataResponse?.data?.length; k++) {
                  let recordSubmitTime = moment(
                    dataResponse?.data[k]?.createdDate.split('T')[1],
                    'HH:mm:ss.SS',
                  ).format('hh:mm A');
                  let currentTime = moment(recordSubmitTime, 'hh:mm A');
                  let afterTime = moment(dayFormatSample[j], 'hh:mm A');
                  let beforeTime = moment(dayFormatSample[j + 1], 'hh:mm A');
                  if (
                    (currentTime.isBetween(afterTime, beforeTime) ||
                      parseInt(afterTime.format('HH:mm').split(':')[0]) ===
                        parseInt(currentTime.format('HH:mm').split(':')[0])) &&
                    dataResponse?.data[k]?.value !== null
                  ) {
                    groupedDayData.push({
                      value: dataResponse?.data[k]?.value,
                      label:
                        j === 0
                          ? '12A'
                          : j === 12
                          ? '12P'
                          : j === 24
                          ? '12A'
                          : j % 2 !== 0
                          ? ''
                          : dayFormatSample[j].split(':')[0],
                      labelWidth: 20,
                      spacing: 18,
                      labelTextStyle: {color: 'gray', fontSize: 10},
                      frontColor: Colors.blueTextColor,
                      topLabelComponent: () => (
                        <Text style={{color: 'black', fontSize: 8}}>
                          {dataResponse?.data[k]?.value > 999
                            ? (dataResponse?.data[k]?.value / 1000).toFixed(1) +
                              ' K'
                            : dataResponse?.data[k]?.value}
                        </Text>
                      ),
                    });
                  }
                }
                if (groupedDayData.length === 0) {
                  stackData.push({
                    value: '',
                    label:
                      j === 0
                        ? '12A'
                        : j === 12
                        ? '12P'
                        : j === 24
                        ? '12A'
                        : j % 2 !== 0
                        ? ''
                        : dayFormatSample[j].split(':')[0],
                    spacing: 18,
                    labelWidth: 20,
                    labelTextStyle: {color: 'gray', fontSize: 10},
                    frontColor: Colors.blueTextColor,
                  });
                } else {
                  stackData.push(groupedDayData[0]);
                }
              }
              console.log('=========================================');
              console.log('Stack data is : ', stackData);
              console.log('=========================================');
              let maxValue = [...stackData];
              maxValue = maxValue.sort((a, b) => b.value - a.value);
              let maxRangeValue = parseInt(maxValue[0]?.value);
              setmaxChartRange(maxRangeValue + 10);
              setTimeout(() => {
                console.log('Maximum Range Value is : ', maxChartRange);
                setbarData(stackData);
              }, 500);
              break;
            case 1:
              let dataForMaxRage = [...dataResponse?.data].sort(
                (a, b) => b.value - a.value,
              );
              let weekMaxValue = parseInt(dataForMaxRage[0]?.value);
              setmaxChartRange(weekMaxValue + 10);
              let averageWeeklySteps = 0;
              for (let j = 0; j < dataResponse?.data?.length; j++) {
                console.log(parseInt(dataResponse?.data[j]?.value));
                averageWeeklySteps += parseInt(dataResponse?.data[j]?.value);
                tempData.push({
                  value: dataResponse?.data[j]?.value,
                  label: moment(dataResponse?.data[j]?.createdDate).format(
                    'ddd',
                  ),
                  spacing: 23,
                  labelWidth: 20,
                  labelTextStyle: {color: 'gray', fontSize: 10},
                  frontColor: Colors.blueTextColor,
                  topLabelComponent: () => (
                    <Text style={{color: 'black', fontSize: 8}}>
                      {dataResponse?.data[j].value === '0'
                        ? ''
                        : dataResponse?.data[j]?.value > 999
                        ? (dataResponse?.data[j]?.value / 1000).toFixed(1) +
                          ' K'
                        : dataResponse?.data[j]?.value}
                    </Text>
                  ),
                });
              }
              //
              getYaxisLabelFormated(weekMaxValue + 10);
              setgolaStats({
                goal: parseInt(goalCount * 7),
                avgGoal: parseInt(averageWeeklySteps / 7),
                activeIndex: 1,
              });
              setbarData([...tempData].reverse());
              break;
            case 2:
              let MonthdataForMaxRage = [...dataResponse?.data].sort(
                (a, b) => b.value - a.value,
              );
              let monthMaxValue = parseInt(MonthdataForMaxRage[0]?.value);
              let averageMonthlySteps = 0;
              setmaxChartRange(monthMaxValue + 10);
              for (let j = 0; j < dataResponse.data.length; j++) {
                averageMonthlySteps += parseInt(dataResponse?.data[j]?.value);
                tempData.push({
                  value: dataResponse?.data[j]?.value,
                  label: dataResponse?.data[j]?.createdDate
                    .split('T')[0]
                    .split('-')[2],
                  spacing: 18,
                  labelWidth: 20,
                  labelTextStyle: {color: 'gray', fontSize: 10},
                  frontColor: Colors.blueTextColor,
                  topLabelComponent: () => (
                    <Text style={{color: 'black', fontSize: 8}}>
                      {dataResponse?.data[j].value === '0'
                        ? ''
                        : dataResponse?.data[j]?.value > 999
                        ? (dataResponse?.data[j]?.value / 1000).toFixed(1) +
                          ' K'
                        : dataResponse?.data[j]?.value}
                    </Text>
                  ),
                });
              }
              console.log('goalStats are ', golaStats);
              getYaxisLabelFormated(monthMaxValue + 10);
              setgolaStats({
                goal: goalCount * 30,
                avgGoal: parseInt(averageMonthlySteps / 30),
                activeIndex: 2,
              });
              setbarData([...tempData].reverse());
              break;
            default:
              break;
          }
        } else {
          console.log('Comes to else ..........');
          setgolaStats({
            goal: route?.params?.item?.patientGoal,
            avgGoal: route?.params?.stepCount,
            activeIndex: 0,
          });
          let dummyData = [
            '12:00 AM',
            '01:00 AM',
            '02:00 AM',
            '03:00 AM',
            '04:00 AM',
            '05:00 AM',
            '06:00 AM',
            '07:00 AM',
            '08:00 AM',
            '09:00 AM',
            '10:00 AM',
            '11:00 AM',
            '12:00 PM',
            '01:00 PM',
            '02:00 PM',
            '03:00 PM',
            '04:00 PM',
            '05:00 PM',
            '06:00 PM',
            '07:00 PM',
            '08:00 PM',
            '09:00 PM',
            '10:00 PM',
            '11:00 PM',
            '12:00 AM',
          ];
          let dayData = [];
          for (let i = 0; i < dummyData?.length; i++) {
            let dayValue = {
              value: 0,
              label:
                i === 0
                  ? '12A'
                  : i === 12
                  ? '12P'
                  : i === 24
                  ? '12A'
                  : i % 2 !== 0
                  ? ''
                  : dummyData[i].split(':')[0],
              spacing: 20,
              labelWidth: 20,
              labelTextStyle: {color: 'gray', fontSize: 10},
              frontColor: Colors.purpleBar,
              topLabelComponent: () => (
                <Text style={{color: 'black', fontSize: 10}}></Text>
              ),
            };
            dayData.push(dayValue);
          }
          console.log('Data before reverse is : ', dayData);
          tempData.push(...dayData);
          setbarData(tempData);
        }
        setloader(false);
      }
    } catch (error) {
      setloader(false);
      console.log('Server is busy now', error);
    }
  }
  const getYaxisLabelFormated = maxVal => {
    let parts = parseInt(maxVal / 7);
    let result = parts;
    let yAxisLabels = [];
    for (let i = 0; i < 7; i++) {
      if (i == 0) {
        yAxisLabels.push((parts / 1000).toFixed(2) + 'k');
      } else {
        result = result + parts;
        yAxisLabels.push((result / 1000).toFixed(2) + 'k');
      }
    }
    setbarYaxisLabels(yAxisLabels);
    console.log('yAxisLabels list is : ', yAxisLabels);
  };
  const setDateTypeFunction = d => {
    dateType = d;
  };
  const getStepsHistory = () => {
    console.log('Calling the api data from the chart : ', dateType);
    getChartData(date, dateType);
  };
  // ========================Declaring all the function to preform the required functionality (END) ===============================
  useEffect(() => {
    if (
      parseInt(route?.params?.item?.value) !==
      parseInt(route?.params?.stepCount)
    ) {
      console.log('update the data and call the chart api');
      handleUpdateAndFillChart();
    }
    // this will work only when the the main dashboard api is updated with the latest value of health kit
    // this check is added because there is no flow if the above condition work but api case error
    if (
      parseInt(route?.params?.item?.value) ===
      parseInt(route?.params?.stepCount)
    ) {
      console.log(
        'calling it because of the the Value and steps taken which are comming from the healthkit are same',
      );
      getChartData(date, 0);
    }
  }, []);

  const handleUpdateAndFillChart = () => {
    let payload = {
      categoryId: route?.params?.id,
      value: `${route?.params?.stepCount}`,
      source: source,
      device: 1,
    };
    console.log('Payload is : ', JSON.stringify(payload));
    if (parseInt(route?.params?.stepCount) > 0) {
      DiscoverService.postHealthCategoryById(payload)
        .then(res => {
          console.log('Response of the step api is  lolololo: ', res.data);
          if (res.data) {
            getChartData(date, 0);
          }
        })
        .catch(err => {
          console.log(
            'Error in saving steps that are comming from the health kit and still call the chart populate data : ',
            err,
          );
          getChartData(date, 0);
        });
    } else {
      getChartData(date, 0);
    }

    console.log('current date type is ', dateType);
  };

  return (
    <SafeAreaView
      style={{flex: 1, backgroundColor: Colors.backgroundMainLogin}}>
      <MainHeader navigation={navigation} name={'Step Counter'}>
        <ScrollView
          style={{
            backgroundColor: Colors.backgroundMainLogin,
            width: '100%',
            height: '100%',
          }}>
          <Spinner
            visible={loader}
            textContent={'Loading...'}
            textStyle={{color: '#FFF'}}
          />
          {/* Calender View */}
          <View
            style={{
              backgroundColor: Colors.backgroundMainLogin,
              width: '100%',
            }}>
            <CalendarStrip
              scrollable
              calendarAnimation={{type: 'sequence', duration: 2}}
              daySelectionAnimation={{
                type: 'background',
                duration: 200,
                borderWidth: 1,
                highlightColor: Colors.blueHeadingColor,
                borderHighlightColor: Colors.bleLayer4,
              }}
              style={{
                height: hp(10),
                width: '95%',
                marginLeft: hp(1),
                padding: hp(1),
                justifyContent: 'center',
              }}
              innerStyle={{
                flex: 1,
              }}
              calendarHeaderStyle={{color: Colors.transparent}}
              calendarColor={Colors.BgColor}
              dateNumberStyle={{
                color: Colors.black,
                fontSize: hp(1.5),
              }}
              disabledDateNameStyle={{color: 'black'}}
              disabledDateNumberStyle={{color: Colors.black, fontSize: hp(1.3)}}
              dateNameStyle={{color: Colors.black, fontSize: hp(1.3)}}
              highlightDateNumberStyle={{
                color: Colors.white,
                fontSize: hp(1.5),
              }}
              highlightDateContainerStyle={{
                backgroundColor: Colors.blueTextColor,
                borderRadius: 30,
                width: Platform.OS === 'ios' ? hp(5.2) : hp(5.5),
                height: Platform.OS === 'ios' ? hp(5.2) : hp(5.6),
                alignItems: 'center',
                justifyContent: 'center',
              }}
              highlightDateNameStyle={{
                color: Colors.white,
                fontSize: hp(1.3),
              }}
              maxDate={moment(new Date()).add(7, 'days')}
              datesBlacklist={[
                moment(new Date()).add(1, 'days'),
                moment(new Date()).add(2, 'days'),
                moment(new Date()).add(3, 'days'),
                moment(new Date()).add(4, 'days'),
                moment(new Date()).add(5, 'days'),
                moment(new Date()).add(6, 'days'),
                moment(new Date()).add(7, 'days'),
              ]}
              iconContainer={{flex: 0.02}}
              selectedDate={date}
              onDateSelected={date => {
                handleDateChangeAndUpdateChart(
                  moment(date).format('YYYY-MM-DDTHH:mm:ss'),
                );
              }}
            />
          </View>
          {/* Main Card Daily Steps, Circular Bar And Distance Speed Time, Custom Chart*/}
          <View style={{width: '100%', alignSelf: 'center'}}>
            {/* Daily Steps Row */}
            <View
              style={{
                backgroundColor: 'white',
                width: '90%',
                alignSelf: 'center',
                marginVertical: hp(2),
                paddingVertical: hp(2),
                alignItems: 'center',
                borderRadius: hp(1),
                elevation: hp(5),
                shadowOffset: {width: 0.5, height: 0.5},
                shadowOpacity: 0.1,
                shadowRadius: 8,
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  alignContent: 'center',
                  alignItems: 'center',
                  alignSelf: 'flex-end',
                }}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansPro,
                    fontSize: hp(1.8),
                    fontWeight: '400',
                    marginLeft: hp(2),
                    marginVertical: hp(1.1),
                    color: Colors.blueTextColor,
                    letterSpacing: 2.5,
                    alignSelf: 'center',
                  }}>
                  {'DAILY STEPS'}
                </Text>
                <View
                  style={{
                    paddingRight: hp(10),
                  }}
                />
                <TouchableOpacity
                  onPress={() => {
                    navigation.navigate('HealthCategoriesEditValuesScreen', {
                      heading: 'Edit Goal',
                      changeTextTitle: 'Steps',
                      unit: 'steps',
                      updateGoal: handleEditGoalCount,
                      id: route?.params?.id,
                      userSteps: route?.params?.stepsTakenToday,
                    });
                  }}>
                  <Image
                    style={{
                      width: 20,
                      height: 20,
                      marginRight: hp(1),
                      alignSelf: 'center',
                    }}
                    source={images.settings_activities}
                  />
                </TouchableOpacity>
              </View>
              {/* Main Text for You have walked % */}
              <Text
                style={{
                  fontFamily: Fonts.SourceSansPro,
                  fontSize: hp(1.8),
                  fontWeight: '600',
                  marginTop: hp(1.8),
                  marginBottom: hp(3.1),
                  color: Colors.black,
                }}>
                {'You have walked '}
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansPro,
                    fontSize: hp(1.8),
                    fontWeight: '600',
                    color: Colors.blueTextColor,
                  }}>
                  {`${
                    parseInt((route?.params?.stepCount / goalCount) * 100) > 100
                      ? 100
                      : parseInt((route?.params?.stepCount / goalCount) * 100)
                  }% `}
                </Text>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansPro,
                    fontSize: hp(1.8),
                    fontWeight: '600',
                    color: Colors.black,
                  }}>
                  {'of your goal'}
                </Text>
              </Text>

              {/* settings_activities */}
              {/* Circular Progress Bar */}
              <AnimatedCircularProgress
                size={hp(24)}
                width={7.5}
                fill={(route?.params?.stepCount / goalCount) * 100}
                rotation={360}
                tintColor={Colors.blueTextColor}
                backgroundColor={Colors.bleLayer4}>
                {fill => (
                  <View>
                    <Image
                      source={Images.steps_icon_step_activities}
                      style={{
                        height: hp(4),
                        width: hp(2.4),
                        resizeMode: 'contain',
                        alignSelf: 'center',
                      }}
                    />
                    <Text
                      style={{
                        alignSelf: 'center',
                        fontSize: hp(1.4),
                        color: Colors.darkgrey,
                        paddingBottom: hp(0.5),
                      }}>
                      Steps
                    </Text>
                    <Text
                      style={{
                        alignSelf: 'center',
                        fontSize: hp(2.5),
                        fontWeight: '600',
                        fontFamily: Fonts.SourceSansRegular,
                        paddingBottom: hp(0.5),
                        color: 'black',
                      }}>
                      {route?.params?.stepCount}
                      {console.log(
                        'Steps comming from the parent screen is : ',
                        route?.params?.stepCount,
                      )}
                    </Text>
                    <View
                      style={{
                        flexDirection: 'row',
                      }}>
                      <Text
                        style={{
                          color: Colors.blueTextColor,
                        }}>
                        Goal{' '}
                      </Text>
                      <Text
                        style={{
                          color: Colors.blueTextColor,
                        }}>
                        {goalCount}
                      </Text>
                    </View>
                  </View>
                )}
              </AnimatedCircularProgress>
              <View
                style={{
                  display: 'none',
                  backgroundColor: 'white',
                  width: '90%',
                  alignSelf: 'center',
                }}>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    paddingHorizontal: hp(2.5),
                    display: 'none',
                  }}>
                  {/* Distance Box View */}
                  <View
                    style={{
                      flexDirection: 'column',
                      alignContent: 'center',
                      alignItems: 'center',
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansPro,
                        fontSize: hp(2.6),
                        fontWeight: '600',
                        marginTop: hp(4),
                        marginBottom: hp(0.4),
                        color: Colors.black,
                      }}>
                      {route?.params?.dsstanceCoverd / 1000}
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansPro,
                          fontSize: hp(1.6),
                          fontWeight: '400',

                          color: Colors.darkGrey,
                        }}>
                        {' km'}
                      </Text>
                    </Text>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansPro,
                        fontSize: hp(1.6),
                        fontWeight: '400',

                        color: Colors.darkGrey,
                      }}>
                      {'Distance'}
                    </Text>
                  </View>
                  {/* Speed Box View */}
                  <View
                    style={{
                      flexDirection: 'column',
                      alignContent: 'center',
                      alignItems: 'center',
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansPro,
                        fontSize: hp(2.6),
                        fontWeight: '600',
                        marginTop: hp(4),
                        marginBottom: hp(0.4),
                        color: Colors.black,
                      }}>
                      {/* {5} */}
                      {route?.params?.speed}
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansPro,
                          fontSize: hp(1.6),
                          fontWeight: '400',
                          color: Colors.darkGrey,
                        }}>
                        {' km/h'}
                      </Text>
                    </Text>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansPro,
                        fontSize: hp(1.6),
                        fontWeight: '400',
                        color: Colors.darkGrey,
                      }}>
                      {'Speed'}
                    </Text>
                  </View>
                  {/* Time Box View */}
                  <View
                    style={{
                      display: 'none',
                      flexDirection: 'column',
                      alignContent: 'center',
                      alignItems: 'center',
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansPro,
                        fontSize: hp(2.6),
                        fontWeight: '600',
                        marginTop: hp(4),
                        marginBottom: hp(0.4),
                        color: Colors.black,
                      }}>
                      {route?.params?.dsstanceCoverd === 0 &&
                      route?.params?.speed === 0
                        ? '0:0'
                        : moment
                            .utc(
                              moment
                                .duration(
                                  route?.params?.dsstanceCoverd /
                                    1000 /
                                    route?.params?.speed,
                                  'hours',
                                )
                                .asMilliseconds(),
                            )
                            .format('H:m')}
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansPro,
                          fontSize: hp(1.6),
                          fontWeight: '400',
                          color: Colors.darkGrey,
                        }}>
                        {' h/m'}
                      </Text>
                    </Text>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansPro,
                        fontSize: hp(1.6),
                        fontWeight: '400',
                        color: Colors.darkGrey,
                      }}>
                      {'Time'}
                    </Text>
                  </View>
                </View>
              </View>
            </View>

            <CustomTestChart
              date={date} //date on the base of which we retrive the chart data
              getVitalHistory={getStepsHistory}
              setDateType={setDateTypeFunction}
              isSelectedDay={isSelectedDay}
              setisSelectedDay={setisSelectedDay}
              barDataRetrived={barData}
              maxValue={maxChartRange}
            />
          </View>
          {/* Total Steps Card */}
          <View>
            <View style={{width: '100%', alignSelf: 'center'}}>
              {/* Daily Steps Row */}
              <View
                style={{
                  backgroundColor: 'white',
                  width: '90%',
                  alignSelf: 'center',
                  marginVertical: hp(2),
                  paddingVertical: hp(2),
                  alignItems: 'center',
                  borderRadius: hp(1),
                  elevation: hp(5),
                  shadowOffset: {width: 0.5, height: 0.5},
                  shadowOpacity: 0.1,
                  shadowRadius: 8,
                }}>
                {/* Main Text for You have walked % */}
                {console.log('yAxisLabels are : ', barYaxisLabels)}
                <Text
                  style={{
                    alignSelf: 'flex-start',
                    marginLeft: hp(2),
                    fontFamily: Fonts.SourceSansPro,
                    fontSize: hp(2.1),
                    fontWeight: '400',
                    color: Colors.black,
                  }}>
                  {'Total Steps'}
                </Text>

                <View
                  style={{
                    backgroundColor: 'white',
                    width: '90%',
                    alignSelf: 'center',
                  }}>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                    }}>
                    {/* Distance Box View */}
                    <View
                      style={{
                        flexDirection: 'column',
                        alignContent: 'center',
                        alignItems: 'center',
                      }}>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansPro,
                          fontSize: hp(2.6),
                          fontWeight: '600',
                          marginTop: hp(4),
                          marginBottom: hp(0.4),
                          color: Colors.black,
                        }}>
                        {golaStats?.goal}
                      </Text>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansPro,
                          fontSize: hp(1.6),
                          fontWeight: '400',

                          color: Colors.darkGrey,
                        }}>
                        {'Goal'}
                      </Text>
                    </View>

                    {/* Time Box View */}
                    <View
                      style={{
                        flexDirection: 'column',
                        alignContent: 'center',
                        alignItems: 'center',
                      }}>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansPro,
                          fontSize: hp(2.6),
                          fontWeight: '600',
                          marginTop: hp(4),
                          marginBottom: hp(0.4),
                          color: Colors.black,
                        }}>
                        {golaStats?.avgGoal}
                      </Text>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansPro,
                          fontSize: hp(1.6),
                          fontWeight: '400',

                          color: Colors.darkGrey,
                        }}>
                        {'Avg Goal'}
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
            </View>
          </View>
        </ScrollView>
      </MainHeader>
    </SafeAreaView>
  );
};

export default StepCounterScreen;

const styles = StyleSheet.create({});
