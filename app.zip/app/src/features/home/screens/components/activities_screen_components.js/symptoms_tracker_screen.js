// import {View, Text} from 'react-native';
import {Fragment, useEffect, useState} from 'react';

import moment from 'moment';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';

import Moment from 'moment';
import React from 'react';
import {
  Dimensions,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  Image,
  View,
} from 'react-native';

import {SvgCss} from 'react-native-svg';
import {Colors, Images, Svgs} from '../../../../../../config';
import {Fonts} from '../../../../../../config/AppConfig';
import VitalsService from '../../../../../api/vitals';

const SymptomTrackerScreen = ({navigation}) => {
  const [isModalVisible, setModalVisible] = useState(false);
  const [stepNo, setstepNo] = useState('first');

  const toggleModal = () => {
    setModalVisible(!isModalVisible);
  };
  const [date, setDate] = useState(
    moment(new Date()).format('yyyy-MM-DDThh:mm:ss'),
  );
  const [barData, setbarData] = useState([
    {
      value: 40,
      label: 'Jan',
      labelWidth: 20,
      labelTextStyle: {color: 'gray'},
      frontColor: Colors.purpleBar,
      topLabelComponent: () => (
        <Text style={{color: 'black', fontSize: 10}}>50</Text>
      ),
    },
    {
      value: 60,
      label: 'Feb',
      labelWidth: 20,
      labelTextStyle: {color: 'gray'},
      frontColor: Colors.purpleBar,
      topLabelComponent: () => (
        <Text style={{color: 'black', fontSize: 10}}>60</Text>
      ),
    },
    {
      value: 80,
      label: 'Mar',
      labelWidth: 20,
      labelTextStyle: {color: 'gray'},
      frontColor: Colors.purpleBar,
      topLabelComponent: () => (
        <Text style={{color: 'black', fontSize: 10}}>80</Text>
      ),
    },
    {
      value: 100,
      label: 'Apr',
      labelWidth: 20,
      labelTextStyle: {color: 'gray'},
      frontColor: Colors.purpleBar,
      topLabelComponent: () => (
        <Text style={{color: 'black', fontSize: 7.0}}>100</Text>
      ),
    },
  ]);
  const [loader, setloader] = useState(false);

  useEffect(() => {
    getChartData();
  }, []);

  function getChartData(date) {
    setloader(true);
    VitalsService.getVitalCategoryHistory(
      10,
      Moment(new Date(date)).format('YYYY-MM-DD'),
    )
      .then(response => {
        setloader(false);
        console.log('getVitalCategoryHistory');
        console.log(JSON.stringify(response));

        if (response && response.statusCode === 200) {
          getvitalDataForChart(response.data);
        } else {
          showMessage({
            message: 'Information',
            description:
              'Authentication Failed. Provided information is not verified.',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        }
      })
      .catch(err => {
        setloader(false);
        console.log('error');
        console.log(err);
        showMessage({
          message: 'Info',
          description: 'Internal Server Error',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  }
  function getvitalDataForChart(listData) {
    let newStepList = [
      {
        value: 40,
        label: 'Jan',
        labelWidth: 20,
        labelTextStyle: {color: 'gray'},
        frontColor: '#177AD5',
        topLabelComponent: () => (
          <Text style={{color: 'black', fontSize: 10}}>50</Text>
        ),
      },
    ];
    console.debug('Just Inside');
    console.debug('Hitting the api inside heart screen');
    Object.keys(listData).map(valAtIndex => {
      newStepList.push({
        value: listData[valAtIndex].vitalData[0].value,
        label: listData[valAtIndex].vitalData[0].name.slice(0, 6),
        labelWidth: 40,
      });
    });
    console.log('The new StepList is');
    console.log(newStepList);
    setbarData(newStepList);
    console.log('The new StepList');
    console.log(barData);
  }

  return (
    <Fragment>
      {/* header */}
      <View
        style={{
          backgroundColor: Colors.backgroundMainLogin,
          flex: 1,
        }}>
        <View style={styles.container}>
          <View
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              flexDirection: 'row',
              marginTop: hp(6.5),
            }}>
            <View style={{flex: 0.25, paddingLeft: hp(1)}}>
              <SvgCss
                xml={Svgs.arrowHeadLeft}
                width={hp(4)}
                height={hp(4)}
                fill={Colors.black}
                onPress={() => {
                  navigation.pop();
                }}
              />
            </View>
            <View style={{flex: 0.6, alignItems: 'center'}}>
              <Text
                style={{
                  color: Colors.black,
                  fontSize: hp(2.5),
                  fontFamily: Fonts.SourceSansSemibold,
                }}>
                Symptom Tracker
              </Text>
            </View>
            <View style={{flex: 0.25, alignItems: 'flex-end'}}>
              <TouchableOpacity
                onPress={() => navigation.navigate('NotificationStack')}>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'flex-start',
                    marginRight: hp(2),
                  }}>
                  <Image
                    style={{
                      width: hp(2),
                      height: hp(2.5),
                    }}
                    source={Images.notification_dashboard}
                  />
                </View>
              </TouchableOpacity>
            </View>
          </View>
        </View>
        {/* header end */}
        <View
          style={{
            flex: 1,
            backgroundColor: Colors.backgroundMainLogin,
            shadowOffset: {width: 0.5, height: 0.5},
            shadowOpacity: 0.5,
            shadowRadius: 1.5,
            elevation: 1,
            borderTopColor: Colors.darkGrey1,
            borderTopRightRadius: 24,
            borderTopLeftRadius: 24,
            marginTop: hp(2),
          }}>
          <ScrollView
            style={{
              borderTopRightRadius: 24,
              borderTopLeftRadius: 24,
              backgroundColor: Colors.white,
            }}
            contentContainerStyle={{
              width: '90%',
              alignSelf: 'center',
            }}>
            <View
              style={{
                width: '100%',
                height: '100%',
                borderTopRightRadius: 24,
                borderTopLeftRadius: 24,
                backgroundColor: Colors.white,
              }}>
              <View>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansPro,
                    fontSize: hp(2.6),
                    fontWeight: '700',
                    marginTop: hp(4),
                    marginBottom: hp(0.4),
                    color: Colors.black,
                  }}>
                  Which type of {'\n'}Symptom do you have ?
                </Text>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansPro,
                    fontSize: hp(1.7),
                    fontWeight: '400',
                    marginTop: hp(2),
                    marginBottom: hp(0.4),
                    color: Colors.black,
                  }}>
                  Select the option and click on the severity of {'\n'}your
                  feelings.
                </Text>
              </View>
              <View
                style={{
                  paddingBottom: hp(2),
                }}></View>
              <View
                style={{
                  flexDirection: 'column',
                }}>
                <View
                  style={{
                    flexDirection: 'row',
                    alignContent: 'center',
                  }}>
                  <TouchableOpacity
                    style={{
                      height: Dimensions.get('window').width * 0.45,
                      width: Dimensions.get('window').width * 0.45,
                      borderRadius: Math.round(
                        (Dimensions.get('window').height +
                          Dimensions.get('window').width) /
                          2,
                      ),
                      backgroundColor: Colors.symtomsColorOrange,
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}
                    underlayColor="#ccc"
                    onPress={() => {
                      console.log('Symtom Tracker Screen');
                      navigation.navigate('DepressiveScreen', {
                        navigation: navigation,
                        symptomHeading: 'Depressive',
                      });
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansPro,
                        fontWeight: '600',
                        fontSize: hp(2),
                      }}>
                      {' '}
                      Depressive{' '}
                    </Text>
                  </TouchableOpacity>
                  <View
                    style={{
                      paddingLeft: hp(1.5),
                      paddingTop: hp(4.7),
                    }}>
                    <TouchableOpacity
                      style={{
                        height: Dimensions.get('window').width * 0.4,
                        width: Dimensions.get('window').width * 0.4,
                        borderRadius: Math.round(
                          (Dimensions.get('window').height +
                            Dimensions.get('window').width) /
                            2,
                        ),
                        backgroundColor: Colors.symtomsColorGreen,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}
                      underlayColor="#ccc"
                      onPress={() => {
                        console.log('Symtom Tracker Screen');
                        navigation.navigate('DepressiveScreen', {
                          navigation: navigation,
                          symptomHeading: 'Anxiety',
                        });
                      }}>
                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansPro,
                          fontWeight: '600',
                          fontSize: hp(2),
                        }}>
                        {' '}
                        Anxiety{' '}
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
                <View
                  style={{
                    paddingLeft: hp(7),
                    marginTop: hp(-1.5),
                  }}>
                  <TouchableOpacity
                    style={{
                      height: Dimensions.get('window').width * 0.42,
                      width: Dimensions.get('window').width * 0.42,
                      borderRadius: Math.round(
                        (Dimensions.get('window').height +
                          Dimensions.get('window').width) /
                          2,
                      ),
                      backgroundColor: Colors.symtomsColorBlue,
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}
                    underlayColor="#ccc"
                    onPress={() => {
                      console.log('Symtom Tracker Screen');
                      navigation.navigate('DepressiveScreen', {
                        navigation: navigation,
                        symptomHeading: 'Manic',
                      });
                    }}>
                    <Text
                      style={{
                        fontFamily: Fonts.SourceSansPro,
                        fontWeight: '600',
                        fontSize: hp(2),
                      }}>
                      {' '}
                      Manic{' '}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </ScrollView>
        </View>
      </View>
    </Fragment>
  );
};

export default SymptomTrackerScreen;

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.BgColor,
    marginTop: hp(1),
  },
});
