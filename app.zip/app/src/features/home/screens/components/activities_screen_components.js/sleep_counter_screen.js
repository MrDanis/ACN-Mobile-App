// import {View, Text} from 'react-native';
import moment from 'moment';
import React, {Fragment, useEffect, useState} from 'react';
import {
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  Image,

  View,
} from 'react-native';
import CalendarStrip from 'react-native-calendar-strip';
import {AnimatedCircularProgress} from 'react-native-circular-progress';

import Spinner from 'react-native-loading-spinner-overlay';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {SafeAreaView} from 'react-native-safe-area-context';
import {SvgCss} from 'react-native-svg';
import {Colors, Svgs} from '../../../../../../config';
import {Fonts} from '../../../../../../config/AppConfig';
import images from '../../../../../../config/Images';
import MainHeader from '../../../../mycare/components/MainHeader';
import CustomTestChart from '../../custom_chart';

import DiscoverService from '../../../../../api/discover';
import {source} from '../../../../../api/constants';
let dateType = 0;
const SleepCounterScreen = ({navigation, route}) => {
  const [circularProgressFill, setcircularProgressFill] = useState(0);
  const [angleOfRotation, setangleOfRotation] = useState(0);
  const [sleepRoutine, setsleepRoutine] = useState(null); //used to open the timer on the time which user set by himself
  const [isModalVisible, setModalVisible] = useState(false);
  const [loader, setloader] = useState(false);
  const [mySleepDuration, setMySleepDuration] = useState(
    route?.params?.sleepDuration.length > 0
      ? route?.params?.sleepDuration
      : route?.params?.sleepValue,
  ); //if the data comming from the health kit is empty the we will display the value comming from the api
  const [patientGoal, setpatientGoal] = useState(route?.params?.sleepGoal); // Creating the state for the goal when user update the goal we must update this state as well
  const [isSelectedDay, setisSelectedDay] = useState('Day');
  const [date, setDate] = useState(
    moment(new Date()).format('yyyy-MM-DDThh:mm:ss'),
  );
  const [barData, setbarData] = useState([]);
  const [activeIndex, setactiveIndex] = useState(0);
  console.log('Sleep duration is : ', mySleepDuration);
  useEffect(() => {
    if (route?.params?.sleepDuration.length <= 0) {
      console.log('Call it if the difference is empty');
      convertTime(mySleepDuration);
    }
    handleGoal(patientGoal); // this function will be responsible for showing the fill of circular progressbar and will represent the patient goal(Coded by Danish)
    // check weather the healthkitTimeFormat is equall to sleepValue the just papulate the chart otherwise update the chart first then papulate
    if (route?.params?.healthkitTimeFormat === route?.params?.sleepValue) {
      getChartData(0, date); // this function is responsible for handling the chart data for Day,Month,Week
    }
    if (route?.params?.healthkitTimeFormat !== route?.params?.sleepValue) {
      let payload = {
        categoryId: route?.params?.id,
        value: `${route?.params?.healthkitTimeFormat}`,
        source: source,
        device: 1,
      };
      if (
        payload?.value !== 'undefined' &&
        route?.params?.healthkitTimeFormat?.length > 0
      ) {
        DiscoverService.postHealthCategoryById(payload)
          .then(res => {
            console.log('Response of the updating the sleep chart: ', res.data);
            if (res.data) {
              getChartData(0, date);
            }
          })
          .catch(err => {
            console.log(
              'Error in saving the sleep routine comming from the health app : ',
              err,
            );
            console.log('will popup error message here ....', err);
            getChartData(0, date);
          });
      } else {
        console.log('====================================');
        console.log('Undefined heartrate cannot be entered....');
        console.log('====================================');
        getChartData(0, date);
      }
      console.log('Must update the chart first then papulate ', payload);
    }
  }, []);
  // UseEffect (End)
  const handleGoal = goal => {
    // Setting up the goal
    setpatientGoal(goal);
    // Step(1) : Find that which time is greater between Start and end
    const [startTime, endTime] = goal.split('-');

    // Parse the times using Moment.js
    const startMoment = moment(startTime, 'hh:mm A').format('HH');
    const endMoment = moment(endTime, 'hh:mm A').format('HH');
    let circularFill = 0;
    let rotationAngle = 0;
    console.log('Start time in 24 hour : ', parseInt(startMoment));
    console.log('End time in 24 hour : ', parseInt(endMoment));

    // Check if the start time is greater then end time (indicating a time span across midnight)
    if (parseInt(startMoment) > parseInt(endMoment)) {
      // Step(1) Add 1 day to the end time to account for the next day
      // Step(2) : Find the difference between the time in hours based on step one result
      // Step(3) : Find the angle of rotation based on Step one result
      circularFill = parseInt(endMoment) + 24 - parseInt(startMoment);
      rotationAngle = parseInt(startMoment) * 15; // as 1degree is equall to 15 as a numaric constant
      setcircularProgressFill(circularFill);
      setangleOfRotation(rotationAngle);
      console.log(
        'Circular progressbar to be filled for ',
        circularFill,
        ' hours when start time is in PM',
      );
      console.log('Circular progressbar start angle : ', rotationAngle);
    } else {
      circularFill = parseInt(endMoment) - parseInt(startMoment);
      rotationAngle = parseInt(startMoment) * 15;
      setcircularProgressFill(circularFill);
      setangleOfRotation(rotationAngle);
      console.log(
        'Circular progressbar to be filled for ',
        circularFill,
        ' hours when start time is in AM',
      );
      console.log('Circular progressbar start angle : ', rotationAngle);
    }
    console.log('Goal of the patient is : ', goal);
  };
  const toggleModal = () => {
    setModalVisible(!isModalVisible);
  };
  // const [modalHeight, setmodalHeight] = useState(0.3);
  // Generic function to handle the chart data is
  const getChartData = async (dateType, date) => {
    console.log(
      'Bar chart data type is : ',
      dateType,
      ' and bar chart date is : ',
      date,
    );
    setloader(true);
    try {
      let dataRequest = await DiscoverService.getHealthCategoryById(
        route?.params?.id,
        date.split('T')[0],
        dateType,
      );
      let dataResponse = await dataRequest;
      console.log('Sleep Screen data request is : ', dataResponse);
      if (dataResponse && dataResponse?.statusCode === 200) {
        let tempData = [];
        if (dataResponse?.data?.length > 0) {
          switch (dateType) {
            case 0:
              //
              let dayFormatSample = [
                '12:00 AM',
                '01:00 AM',
                '02:00 AM',
                '03:00 AM',
                '04:00 AM',
                '05:00 AM',
                '06:00 AM',
                '07:00 AM',
                '08:00 AM',
                '09:00 AM',
                '10:00 AM',
                '11:00 AM',
                '12:00 PM',
                '01:00 PM',
                '02:00 PM',
                '03:00 PM',
                '04:00 PM',
                '05:00 PM',
                '06:00 PM',
                '07:00 PM',
                '08:00 PM',
                '09:00 PM',
                '10:00 PM',
                '11:00 PM',
                '12:00 AM',
              ];
              let stackData = [];
              for (let j = 0; j < dayFormatSample.length; j++) {
                let groupedDayData = [];
                for (let k = 0; k < dataResponse?.data?.length; k++) {
                  let recordSubmitTime = moment(
                    dataResponse?.data[k]?.createdDate.split('T')[1],
                    'HH:mm:ss.SS',
                  ).format('hh:mm A');
                  let currentTime = moment(recordSubmitTime, 'hh:mm A');
                  let afterTime = moment(dayFormatSample[j], 'hh:mm A');
                  let beforeTime = moment(dayFormatSample[j + 1], 'hh:mm A');
                  if (
                    currentTime.isBetween(afterTime, beforeTime) ||
                    parseInt(afterTime.format('HH:mm').split(':')[0]) ===
                      parseInt(currentTime.format('HH:mm').split(':')[0])
                  ) {
                    groupedDayData.push({
                      value: dataResponse?.data[k]?.value,
                      label:
                        j === 0
                          ? '12A'
                          : j === 12
                          ? '12P'
                          : j === 24
                          ? '12A'
                          : j % 2 !== 0
                          ? ''
                          : dayFormatSample[j].split(':')[0],
                      labelWidth: 20,
                      labelTextStyle: {color: 'gray', fontSize: 10},
                      frontColor: Colors.blueTextColor,
                      topLabelComponent: () => (
                        <View
                          style={{
                            display: 'flex',
                            borderColor: 'red',
                            borderWidth: 0,
                          }}>
                          <Text style={{color: 'black', fontSize: 4}}>
                            {dataResponse?.data[k]?.value}
                          </Text>
                        </View>
                      ),
                    });
                  }
                }
                if (groupedDayData.length === 0) {
                  stackData.push({
                    value: 0,
                    label:
                      j === 0
                        ? '12A'
                        : j === 12
                        ? '12P'
                        : j === 24
                        ? '12A'
                        : j % 2 !== 0
                        ? ''
                        : dayFormatSample[j].split(':')[0],
                    spacing: 15,
                    labelWidth: 20,
                    labelTextStyle: {color: 'gray', fontSize: 10},
                    frontColor: Colors.blueTextColor,
                  });
                } else {
                  // here before assign the list to the chart we will check that weather the value in the chart is not null or undefined
                  handleResetTimeOfChart(stackData, groupedDayData[0]); // passing array and its monkey in it and will get the filled array for the chart
                }
              }
              setbarData(stackData);
              console.log('Called for updating the day data : ', dataResponse);
              console.log('Group Day data is : ', stackData);
              break;
            case 1:
              //Code block to handle the week data
              console.log('============ Format the week data ==============');
              console.log(date);
              console.log(
                'This is the data of the week : ',
                dataResponse?.data,
              );
              for (let u = 0; u < dataResponse?.data?.length; u++) {
                console.log('Value of the response is : ', dataResponse?.data);
                let temObj = {
                  value: dataResponse?.data[u]?.value,
                  label: moment(dataResponse?.data[u]?.createdDate).format(
                    'ddd',
                  ),
                  labelWidth: 20,
                  spacing: 20,
                  labelTextStyle: {color: 'gray', fontSize: 10},
                  frontColor: Colors.purpleBar,

                  topLabelComponent: () => (
                    <View style={{borderColor: 'green', borderWidth: 0}}>
                      <Text
                        style={{
                          color: 'black',
                          fontSize: 8,
                          width: '100%',

                          marginBottom: 5,
                          height: 10,
                          borderColor: 'red',
                          borderWidth: 0,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}>
                        {parseInt(dataResponse?.data[u]?.value.split(' ')[0]) /
                          60 ===
                        0 ? null : (
                          <Text>
                            {`${
                              Math.ceil(
                                parseInt(
                                  dataResponse?.data[u]?.value.split(' ')[0],
                                ) / 60,
                              ) === 0
                                ? ''
                                : Math.ceil(
                                    parseInt(
                                      dataResponse?.data[u]?.value.split(
                                        ' ',
                                      )[0],
                                    ) / 60,
                                  )
                            }hr`}
                          </Text>
                        )}
                      </Text>
                    </View>
                  ),
                };
                handleResetTimeOfChart(tempData, temObj);
              }
              setbarData([...tempData].reverse());
              console.log('Week data results array is : ', dataResponse?.data);
              break;
            case 2:
              //code block to handle the monthly data
              for (let u = 0; u < dataResponse?.data?.length; u++) {
                let tempObj = {
                  value: dataResponse?.data[u]?.value,
                  label: dataResponse?.data[u]?.createdDate
                    .split('T')[0]
                    .split('-')[2],
                  labelWidth: 20,
                  labelTextStyle: {color: 'gray', fontSize: 10},
                  frontColor: Colors.purpleBar,
                  topLabelComponent: () => (
                    <View style={{borderColor: 'green', borderWidth: 0}}>
                      <Text
                        style={{
                          color: 'black',
                          fontSize: 8,
                          width: '100%',

                          marginBottom: 5,
                          height: 10,
                          borderColor: 'red',
                          borderWidth: 0,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}>
                        {parseInt(dataResponse?.data[u]?.value.split(' ')[0]) /
                          60 ===
                        0 ? null : (
                          <Text style={{fontSize: 6}}>
                            {`${Math.ceil(
                              parseInt(
                                dataResponse?.data[u]?.value.split(' ')[0],
                              ) / 60,
                            )}hr`}
                          </Text>
                        )}
                      </Text>
                    </View>
                  ),
                };
                handleResetTimeOfChart(tempData, tempObj);
              }
              setbarData([...tempData].reverse());
              console.log('Month results array is : ', dataResponse?.data);
              break;
            default:
              break;
          }
        } //This case will work when there is no data comming from the api
        else {
          let dummyData = [
            '12:00 AM',
            '01:00 AM',
            '02:00 AM',
            '03:00 AM',
            '04:00 AM',
            '05:00 AM',
            '06:00 AM',
            '07:00 AM',
            '08:00 AM',
            '09:00 AM',
            '10:00 AM',
            '11:00 AM',
            '12:00 PM',
            '01:00 PM',
            '02:00 PM',
            '03:00 PM',
            '04:00 PM',
            '05:00 PM',
            '06:00 PM',
            '07:00 PM',
            '08:00 PM',
            '09:00 PM',
            '10:00 PM',
            '11:00 PM',
            '12:00 AM',
          ];
          let dayData = [];
          for (let i = 0; i < dummyData?.length; i++) {
            let dayValue = {
              value: 0,
              label:
                i === 0
                  ? '12A'
                  : i === 12
                  ? '12P'
                  : i === 24
                  ? '12A'
                  : i % 2 !== 0
                  ? ''
                  : dummyData[i].split(':')[0],
              spacing: 15,
              labelWidth: 20,
              labelTextStyle: {color: 'gray', fontSize: 10},
              frontColor: Colors.purpleBar,
              topLabelComponent: () => (
                <Text style={{color: 'black', fontSize: 8}}></Text>
              ),
            };
            dayData.push(dayValue);
          }
          dayData = [...dayData];
          tempData.push(...dayData);
          setbarData(tempData);
        }
        setloader(false);
      }
    } catch (error) {
      setloader(false);
      console.log('Server is busy now', error);
    }
  };
  // below functions run when the date is change from the top calender (START)
  const handleSpecificDateSleepRoutine = date => {
    let userSelectedDate = moment(date).format('yyyy-MM-DDThh:mm:ss');
    setDate(userSelectedDate);
    console.log('User selected date is : ', userSelectedDate);
    getChartData(0, userSelectedDate);
  };
  //Function is responsible for selecting the type(day,month,year) of which data is required
  const setDateTypeFunction = d => {
    console.log('====================================');
    console.log('fetch date type', d);
    console.log('====================================');
    dateType = d;
    setactiveIndex(dateType);
  };
  const convertTime = timeRange => {
    console.log(
      'Here comes in the Covert time to set the shedule....',
      timeRange,
    );
    setsleepRoutine(timeRange);
    const [startTime, endTime] = timeRange.split('-');
    const sheduleHandler = {
      startTime: 0,
      endTime: 0,
      resultenTime: 0,
      sheduleTime: '',
    };
    // Implementing the new logic as above one is not working and that will be similar to goal logic but slightly difference START(Danish)
    const startHour = moment(startTime, 'hh:mm A').format('HH');
    const endHour = moment(endTime, 'hh:mm A').format('HH');
    if (startHour > endHour) {
      sheduleHandler.endTime =
        parseInt(moment(endTime, 'hh:mm A').format('HH:mm').split(':')[0]) *
          60 +
        parseInt(moment(endTime, 'hh:mm A').format('HH:mm').split(':')[1]); //equation of converting time in mints
      sheduleHandler.endTime = sheduleHandler.endTime + 24 * 60; //adding the mints of the day
      console.log('end');
      sheduleHandler.startTime =
        parseInt(moment(startTime, 'hh:mm A').format('HH:mm').split(':')[0]) *
          60 +
        parseInt(moment(startTime, 'hh:mm A').format('HH:mm').split(':')[1]);
      sheduleHandler.resultenTime =
        sheduleHandler.endTime - sheduleHandler.startTime;
      sheduleHandler.sheduleTime = `${parseInt(
        sheduleHandler.resultenTime / 60,
      )}hr ${parseInt(sheduleHandler.resultenTime % 60)}min`;
      setMySleepDuration(sheduleHandler.sheduleTime);
    } else {
      sheduleHandler.endTime =
        parseInt(moment(endTime, 'hh:mm A').format('HH:mm').split(':')[0]) *
          60 +
        parseInt(moment(endTime, 'hh:mm A').format('HH:mm').split(':')[1]); //equation of converting time in mints
      sheduleHandler.startTime =
        parseInt(moment(startTime, 'hh:mm A').format('HH:mm').split(':')[0]) *
          60 +
        parseInt(moment(startTime, 'hh:mm A').format('HH:mm').split(':')[1]);
      sheduleHandler.resultenTime =
        sheduleHandler.endTime - sheduleHandler.startTime;
      sheduleHandler.sheduleTime = `${parseInt(
        sheduleHandler.resultenTime / 60,
      )}hr  ${parseInt(sheduleHandler.resultenTime % 60)}min`;
      setMySleepDuration(sheduleHandler.sheduleTime);
    }
  };
  const handleUpdateSleepRoutine = (sleepRoutine, type) => {
    // 0)When user update the value(It represent the time duration that user Sleeps)
    // 1)When user update the goal
    switch (type) {
      case 0: //value case
        console.log('here comes in the updating value function :');
        convertTime(sleepRoutine);
        getChartData(activeIndex, date);
        break;
      default:
        break;
    }
  };
  const getVitalHistory = () => {
    console.log('Call the api from inside the chart : ');
    getChartData(dateType, date);
  };
  const handleResetTimeOfChart = (arr, monkey) => {
    console.log('Array is : ', arr);
    console.log('Monkey is : ', monkey);
    // Algo for finding time difference of hours
    // Check weather the Value of the monkey is not undefined,null,'0'
    // calculate the difference in hours from the value of the monkey
    // assign the difference hours to the value of the monkey
    // assign the monkey to the jungle
    if (
      monkey.value === '0' ||
      monkey.value === undefined ||
      monkey.value === null ||
      monkey.value.length < 5
    ) {
      arr.push({
        ...monkey,
        value: '',
        topLabelComponent: () => (
          <Text style={{color: 'black', fontSize: 8}}></Text>
        ),
      });
    } else {
      let differenceFinder = {
        startTime: parseInt(
          moment(monkey.value.split('-')[0], 'hh:mm A')
            .format('HH:mm')
            .split(':')[0],
        ),
        endTime: parseInt(
          moment(monkey.value.split('-')[1], 'hh:mm A')
            .format('HH:mm')
            .split(':')[0],
        ),
        resutenTime: 0,
      };
      if (differenceFinder.startTime > differenceFinder.endTime) {
        differenceFinder.endTime += 24;
        differenceFinder.resutenTime =
          differenceFinder.endTime - differenceFinder.startTime;
        monkey.value = differenceFinder.resutenTime;
        arr.push({
          ...monkey,
          value: monkey.value,
          topLabelComponent: () => (
            <Text style={{color: 'black', fontSize: 8}}>
              {monkey.value + 'hr'}
            </Text>
          ),
        });
      } else {
        differenceFinder.resutenTime =
          differenceFinder.endTime - differenceFinder.startTime;
        monkey.value = differenceFinder.resutenTime;
        monkey.topLabelComponent = arr.push({
          ...monkey,
          topLabelComponent: () => (
            <Text style={{color: 'black', fontSize: 8}}>
              {monkey.value + 'hr'}
            </Text>
          ),
        });
      }
      console.log('Difference Finder is : ', differenceFinder);
    }
    // handle the time difference logic here
  };
  return (
    <Fragment>
      <SafeAreaView
        style={{flex: 1, backgroundColor: Colors.backgroundMainLogin}}>
        <MainHeader navigation={navigation} name={'Sleep Monitor'}>
          <ScrollView
            style={{
              backgroundColor: Colors.backgroundMainLogin,
              width: '100%',
              height: '100%',
            }}>
            <Spinner
              visible={loader}
              textContent={'Loading...'}
              textStyle={{color: '#FFF'}}
            />

            {/* Calender View */}
            <View
              style={{
                backgroundColor: Colors.backgroundMainLogin,
                width: '100%',
              }}>
              <CalendarStrip
                scrollable
                calendarAnimation={{type: 'sequence', duration: 2}}
                daySelectionAnimation={{
                  type: 'background',
                  duration: 200,
                  borderWidth: 1,
                  highlightColor: Colors.blueHeadingColor,
                  borderHighlightColor: Colors.bleLayer4,
                }}
                style={{
                  height: hp(10),
                  width: '95%',
                  marginLeft: hp(1),
                  padding: hp(1),
                  justifyContent: 'center',
                }}
                innerStyle={{
                  flex: 1,
                }}
                calendarHeaderStyle={{color: Colors.transparent}}
                calendarColor={Colors.BgColor}
                dateNumberStyle={{
                  color: Colors.black,
                  fontSize: hp(1.5),
                }}
                disabledDateNameStyle={{color: 'black'}}
                disabledDateNumberStyle={{
                  color: Colors.black,
                  fontSize: hp(1.3),
                }}
                dateNameStyle={{color: Colors.black, fontSize: hp(1.3)}}
                highlightDateNumberStyle={{
                  color: Colors.white,
                  fontSize: hp(1.5),
                }}
                highlightDateContainerStyle={{
                  backgroundColor: Colors.blueTextColor,
                  borderRadius: 30,
                  width: Platform.OS === 'ios' ? hp(5.2) : hp(5.5),
                  height: Platform.OS === 'ios' ? hp(5.2) : hp(5.6),
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
                highlightDateNameStyle={{
                  color: Colors.white,
                  fontSize: hp(1.3),
                }}
                maxDate={moment(new Date()).add(7, 'days')}
                datesBlacklist={[
                  moment(new Date()).add(1, 'days'),
                  moment(new Date()).add(2, 'days'),
                  moment(new Date()).add(3, 'days'),
                  moment(new Date()).add(4, 'days'),
                  moment(new Date()).add(5, 'days'),
                  moment(new Date()).add(6, 'days'),
                  moment(new Date()).add(7, 'days'),
                ]}
                iconContainer={{flex: 0.02}}
                selectedDate={date}
                onDateSelected={date => {
                  setactiveIndex(0);
                  handleSpecificDateSleepRoutine(date);
                }}
              />
            </View>

            {/* Main Card Daily Steps, Circular Bar And Distance Speed Time, Custom Chart*/}
            <View style={{width: '100%', alignSelf: 'center'}}>
              {/* Daily Steps Row */}
              <View
                style={{
                  backgroundColor: 'white',
                  width: '90%',
                  alignSelf: 'center',
                  marginVertical: hp(2),
                  paddingVertical: hp(2),
                  alignItems: 'center',
                  borderRadius: hp(1),
                  elevation: hp(5),
                  shadowOffset: {width: 0.5, height: 0.5},
                  shadowOpacity: 0.1,
                  shadowRadius: 8,
                }}>
                <View
                  style={{
                    flexDirection: 'row',
                    alignContent: 'flex-end',
                  }}>
                  <View
                    style={{
                      paddingRight: hp(35),
                    }}
                  />
                  <TouchableOpacity
                    style={{
                      padding: hp(0.5),
                    }}
                    onPress={() => {
                      navigation.navigate('HealthCategoriesEditValuesScreen', {
                        heading: 'Edit Sleep Goal',
                        changeTextTitle: 'Sleep Time',
                        unit: '',
                        id: route.params.id,
                        updateSleepRoutine: handleGoal,
                        sleepTime: patientGoal?.split('-')[0],
                        wakeTime: patientGoal?.split('-')[1],
                      });
                    }}>
                    <Image
                      style={{
                        width: 20,
                        height: 20,
                      }}
                      source={images.settings_activities}
                    />
                  </TouchableOpacity>
                </View>
                {/* settings_activities */}
                {/* Circular Progress Bar */}
                <AnimatedCircularProgress
                  size={hp(24)}
                  width={7.5}
                  arcSweepAngle={360}
                  style={{borderColor: 'red', borderWidth: 0}}
                  rotation={angleOfRotation}
                  fill={(circularProgressFill / 24) * 100}
                  tintColor={Colors.purpleBar}
                  backgroundColor={Colors.bleLayer4}>
                  {fill => (
                    <View
                      style={{
                        borderColor: 'red',
                        borderWidth: 0,
                      }}>
                      <SvgCss
                        xml={Svgs.clock_sleep_counter}
                        width={hp(30.5)}
                        height={hp(21.5)}
                        fill={Colors.black}
                        // onPress={() => navigation.pop()}
                        style={{marginHorizontal: hp(1)}}
                      />
                    </View>
                  )}
                </AnimatedCircularProgress>
                <View
                  style={{
                    borderColor: 'green',
                    borderWidth: 0,
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                  <TouchableOpacity
                    onPress={() => {
                      navigation.navigate('HealthCategoriesEditValuesScreen', {
                        heading: 'Add Data',
                        changeTextTitle: 'Sleep Time',
                        unit: '',
                        id: route?.params?.id,
                        updateSleepRoutine: handleUpdateSleepRoutine,
                        sleepTime:
                          sleepRoutine === null
                            ? route?.params?.sleepValue.split('-')[0]
                            : sleepRoutine?.split('-')[0],
                        wakeTime:
                          sleepRoutine === null
                            ? route?.params?.sleepValue.split('-')[1]
                            : sleepRoutine?.split('-')[1],
                      });
                    }}>
                    <View>
                      <Text
                        style={{paddingVertical: hp(1), color: Colors.black}}>
                        Add Data
                        {console.log(
                          'Routine of the sleep is : ',
                          sleepRoutine,
                          'Value comming fromthe parent is : ',
                          route?.params?.sleepValue,
                          'User goal is : ',
                          route?.params?.sleepGoal,
                        )}
                      </Text>
                    </View>
                  </TouchableOpacity>
                </View>
                <View
                  style={{
                    backgroundColor: 'white',
                    width: '90%',
                    alignSelf: 'center',
                  }}>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'space-around',
                    }}>
                    {/* Distance Box View */}
                    <View
                      style={{
                        flexDirection: 'column',
                        alignContent: 'center',
                        alignItems: 'center',
                      }}>
                      {route?.params?.sleepDuration !== '' ? (
                        <Text
                          style={{
                            fontFamily: Fonts.SourceSansPro,
                            fontSize: hp(2.6),
                            fontWeight: '600',
                            marginTop: hp(4),
                            marginBottom: hp(0.4),
                            color: Colors.black,
                          }}>
                          {mySleepDuration}
                        </Text>
                      ) : (
                        <Text
                          style={{
                            fontFamily: Fonts.SourceSansPro,
                            fontSize: hp(2.6),
                            fontWeight: '600',
                            marginTop: hp(4),
                            marginBottom: hp(0.4),
                            color: Colors.black,
                          }}>
                          {mySleepDuration}
                          {console.log('Sleep duration is : ', mySleepDuration)}
                        </Text>
                      )}

                      <Text
                        style={{
                          fontFamily: Fonts.SourceSansPro,
                          fontSize: hp(1.8),
                          fontWeight: '600',

                          color: Colors.blueGrayDisableText,
                        }}>
                        Scheduled time To Meet Goal
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
              <CustomTestChart
                date={date}
                getVitalHistory={getVitalHistory}
                setDateType={setDateTypeFunction}
                isSelectedDay={isSelectedDay}
                setisSelectedDay={setisSelectedDay}
                barDataRetrived={barData}
                maxValue={24}
              />
            </View>
          </ScrollView>
        </MainHeader>
      </SafeAreaView>
    </Fragment>
  );
};

export default SleepCounterScreen;

const styles = StyleSheet.create({});
