import {
  Image,
  ImageBackground,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import React from 'react';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import {Colors, Images} from '../../../../../config';
import images from '../../../../../config/Images';

import {Fonts} from '../../../../../config/AppConfig';
const CareCordinatorCard = ({navigation}) => {
  return (
    <View
      style={{
        borderRadius: 8,
        height: hp(22),
        backgroundColor: Colors.bleLayer4,
        width: '100%',
        marginTop: hp(2),
        shadowOffset: {width: 0.5, height: 0.5},
        shadowOpacity: 0.1,
        shadowRadius: 8,
        elevation: 3,
      }}>
      <Pressable onPress={
        () => 
          //navigation.navigate('NewChatScreen')//
         navigation.navigate('CareCoordinatorScreen')
        }>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            width: '100%',
            paddingLeft: hp(1),
          }}>
          <View
            style={{
              // flex: 1,
              // height: hp(6),
              // borderWidth: 1,
              padding: hp(2),
              borderColor: 'red',
              alignItems: 'center',
              justifyContent: 'center',
              padding: hp(0.6),
              backgroundColor: Colors.wellnessCardColor,
              borderRadius: 8,
              // maxHeight: 'streach',
            }}>
            <Image
              style={{
                width: hp(2.8),
                height: hp(2.8),
                // marginTop: hp(1.5),
                borderColor: 'red',
                // borderWidth: 1,
                backgroundColor: Colors.wellnessCardColor,
                // padding: hp(),
              }}
              // tintColor={'#FFFFFF'}
              resizeMode="contain"
              source={Images.careCordinatorBadge}
            />
          </View>

          <Pressable
            style={{height: hp(6)}}
            onPress={() => navigation.navigate('CareCoordinatorScreen')}>
            <Image
              style={{
                width: hp(1.5),
                height: hp(1.5),
                margin: hp(1.5),
                // borderWidth: 1,
              }}
              resizeMode="contain"
              source={Images.newDashboardArrow}
            />
          </Pressable>
        </View>

        <View
          style={{
            paddingLeft: hp(0.5),
            marginVertical: hp(1.5),
            flexDirection: 'row',
            alignItems: 'center',
            gap: 5,
          }}>
          <Text
            style={{
              fontFamily: Fonts.SourceSansSemibold,
              fontWeight: '600',
              fontSize: hp(1.8),
              color: Colors.black,
              marginLeft: hp(1),
              marginTop: hp(0.4),
            }}>
            Care Coordination
          </Text>
        </View>

        <View
          style={{
            marginTop: hp(0.9),
            paddingLeft: hp(1),
            borderColor: 'red',
            // borderWidth: 1,
            display: 'flex',
            flexDirection: 'row',
            // alignItems: 'flex-start',
            gap: 9,
          }}>
          <Image
            style={{
              width: hp(3),
              height: hp(3),
              marginTop: hp(0.5),
            }}
            source={images.msgIconBlue}
          />
          <Text
            style={{
              fontFamily: Fonts.SourceSansSemibold,
              fontSize: Platform.OS === 'ios' ? hp(2.2) : hp(1.8),
              color: Colors.TextColor,
              fontWeight: '600',
              width: wp(77),
            }}
            numberOfLines={3}>
            Your health, always in sync. and care that’s always with you.
          </Text>
        </View>
      </Pressable>
    </View>
  );
};

export default CareCordinatorCard;

const styles = StyleSheet.create({});
//   return (
//     <View
//       style={{
//         borderRadius: 8,
//         height: hp(22),
//         backgroundColor: Colors.bleLayer4,
//         width: '48%',
//         shadowOffset: {width: 0.5, height: 0.5},
//         shadowOpacity: 0.3,
//         shadowRadius: 8,
//         marginTop: hp(2),
//         shadowOpacity: 0.1,
//         shadowRadius: 8,
//         elevation: 3,
//         display: 'flex',
//         flexDirection: 'column',
//         alignItems: 'center',
//         justifyContent: 'space-between',
//         // borderWidth: 1,
//         // overflow: 'hidden',
//       }}>
//       <ImageBackground
//         source={Images.maskGroup}
//         resizeMode="contain"
//         width="10%"
//         // borderRadius={15}
//         style={{
//           flex: 1,
//           padding: 10,
//           backgroundColor: '#006AD4',
//           // borderWidth: 1,
//           borderRadius: hp(1.4),
//           overflow: 'hidden',
//           // width: '47%',
//           shadowOffset: {width: 0.5, height: 0.5},
//           shadowOpacity: 0.3,
//           shadowRadius: 8,
//           // marginTop: hp(2),
//           shadowOpacity: 0.1,
//           shadowRadius: 8,
//           elevation: 3,
//           display: 'flex',
//           flexDirection: 'column',
//           alignItems: 'center',
//           justifyContent: 'space-between',
//         }}>
//         <Text
//           style={{
//             color: Colors.white,
//             fontWeight: '600',
//             fontSize: hp(2.125),
//           }}>
//           Your Care Manager, Just a Click Away.
//         </Text>
//         <View
//           style={{
//             borderColor: 'red',
//             // borderWidth: 2,
//             width: wp(37),
//             display: 'flex',
//             flexDirection: 'row',
//             gap: hp(1.5),
//           }}>
//           <View
//             style={{
//               backgroundColor: '#FEECBB',
//               height: hp(5.8),
//               width: hp(5.8),
//               borderRadius: hp(9),
//               display: 'flex',
//               flexDirection: 'row',
//               justifyContent: 'center',
//               alignItems: 'center',
//             }}>
//             <Pressable onPress={() => navigation.navigate('Contacts')}>
//               <Image
//                 style={{
//                   width: hp(3),
//                   height: hp(3),
//                 }}
//                 source={images.msgIcon}
//               />
//             </Pressable>
//           </View>
//           <View
//             style={{
//               backgroundColor: '#FEECBB',
//               height: hp(5.8),
//               width: hp(5.8),
//               borderRadius: hp(9),
//               display: 'flex',
//               flexDirection: 'row',
//               justifyContent: 'center',
//               alignItems: 'center',
//             }}>
//             <Pressable onPress={() => navigation.navigate('Contacts')}>
//               <Image
//                 style={{
//                   width: hp(3),
//                   height: hp(3),
//                 }}
//                 source={images.callIcon}
//               />
//             </Pressable>
//           </View>
//         </View>
//       </ImageBackground>
//     </View>
//   );
