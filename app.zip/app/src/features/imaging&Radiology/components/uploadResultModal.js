//import liraries
import moment from 'moment';
import React, {useRef, useState} from 'react';
import {
  PermissionsAndroid,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Image
} from 'react-native';
import DocumentPicker from 'react-native-document-picker';

import * as ImagePicker from 'react-native-image-picker';
import ImageResizer from 'react-native-image-resizer';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import {Modalize} from 'react-native-modalize';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {Colors, Images} from '../../../../config';
import {Fonts} from '../../../../config/AppConfig';
import ImagingService from '../../../api/imaging';
import LabService from '../../../api/lab';
import {
  checkCameraPermission,
  requestMicCameraPermission,
} from '../../../helpers/Common';
import {showMessage} from 'react-native-flash-message';
import {AuthToken, retrieveItem} from '../../../helpers/LocalStorage';

// create a component
const UploadResultModal = props => {
  const [isPdf, setisPdf] = useState(false);
  const modalizeRef = useRef();
  const onOpen = () => {
    modalizeRef.current?.open();
  };
  const onClose = () => {
    modalizeRef.current?.close();
  };
  console.log('image object is : ', props?.imageObject);
  console.log('All the props are : ', props);
  const singleFilePicker = async () => {
    let options = {
      mediaType: 'photo',
      includeBase64: false,
      cropping: false,
      mode: 'contain',
    };
    ImagePicker.launchImageLibrary(options)
      .then(fileData => {
        console.log('data received');
        console.log(fileData);
        console.log('size in mb', fileData.assets[0].fileSize / (1024 * 1024));
        if (fileData) {
          // image qulaity can be reduced for controling size from here
          ImageResizer.createResizedImage(
            fileData.assets[0].uri,
            fileData.assets[0].width,
            fileData.assets[0].height,
            'JPEG',
            100,
          )
            .then(({uri, size}) => {
              console.log('====================================');
              console.log('resize file uri', uri);
              console.log('====================================');
              fileData.assets[0].uri = uri;
              let imageData = {};
              const fileExtension = String(fileData.assets[0].type).substr(
                String(fileData.assets[0].type).indexOf('/') + 1,
              );
              imageData.uri = fileData.assets[0].uri;
              imageData.name = `Mobile_Upload_${moment().unix()}.${fileExtension}`;
              imageData.type = fileData.assets[0].type;
              imageData.size = size;
              console.log('====================================');
              console.log('ImageData after reszing', imageData);
              console.log(
                'this is the size in mb after resizing',
                imageData.size / (1024 * 1024),
              );
              console.log('====================================');
              props.setImageObject(imageData);
              setisPdf(false);
            })
            .catch(err => {
              console.log(err);
              return Alert.alert(
                'Unable to resize the photo',
                'Check the console for full the error message',
              );
            });
        }
      })
      .catch(error => {
        console.log('error');
        console.log(error);
      });
  };
  const openCamera = () => {
    if (Platform.OS === 'android') {
      PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.CAMERA).then(
        async response => {
          console.log('====================================');
          console.log('camera permission', response);
          console.log('====================================');
          if (response === true) {
            console.log('open camera');
            let options = {
              mediaType: 'photo',
              includeBase64: false,

              cropping: true,
              cameraType: 'back',
            };
            ImagePicker.launchCamera(options).then(result => {
              if (result && result.didCancel !== true) {
                console.log(' camera result');
                console.log(result);
                let image = result.assets[0];
                ImageResizer.createResizedImage(
                  image.uri,
                  image.width,
                  image.height,
                  'JPEG',
                  100,
                )
                  .then(({uri}) => {
                    image.uri = uri;
                    if (image) {
                      let imageData = {};
                      imageData.uri = image.uri;
                      imageData.name = image.fileName;
                      imageData.type = image.type;
                      imageData.size = image.fileSize;
                      console.log(imageData);
                      setisPdf(false);
                      props.setImageObject(imageData);
                    }
                  })
                  .catch(err => {
                    console.log(err);
                    return Alert.alert(
                      'Unable to resize the photo',
                      'Check the console for full the error message',
                    );
                  });
              }
            });
          } else {
            const granted = await PermissionsAndroid.request(
              PermissionsAndroid.PERMISSIONS.CAMERA,
              {
                title: '360PatientEngagement App Camera Permission',
                message:
                  '360PatientEngagement App needs access to your camera ' +
                  'so you can take awesome pictures.',
                buttonNeutral: 'Ask Me Later',
                buttonNegative: 'Cancel',
                buttonPositive: 'OK',
              },
            );
            console.log('====================================');
            console.log('granted', granted);
            console.log('====================================');
            if (granted === 'granted') {
              console.log('open camera');
              let options = {
                mediaType: 'photo',
                includeBase64: false,

                cropping: true,
                cameraType: 'back',
              };
              ImagePicker.launchCamera(options).then(result => {
                if (result && result.didCancel !== true) {
                  console.log(' camera result');
                  console.log(result);
                  let image = result.assets[0];
                  ImageResizer.createResizedImage(
                    image.uri,
                    image.width,
                    image.height,
                    'JPEG',
                    100,
                  )
                    .then(({uri}) => {
                      console.log('====================================');
                      console.log('uri of image', uri);
                      console.log('====================================');
                      image.uri = uri;
                      if (image) {
                        let imageData = {};
                        imageData.uri = image.uri;
                        imageData.name = image.fileName;
                        imageData.type = image.type;
                        imageData.size = image.fileSize;
                        console.log(imageData);
                        props.setImageObject(imageData);
                      }
                    })
                    .catch(err => {
                      console.log(err);
                      return Alert.alert(
                        'Unable to resize the photo',
                        'Check the console for full the error message',
                      );
                    });
                }
              });
            }
          }
        },
      );
    } else {
      requestMicCameraPermission().then(statuses => {
        console.log('====================================');
        console.log('statuses', statuses);
        console.log('====================================');
        if (statuses.cameraPermission !== 'granted') {
          checkCameraPermission();
        } else {
          console.log('open camera');
          let options = {
            mediaType: 'photo',
            includeBase64: false,

            cropping: true,
            cameraType: 'front',
          };
          ImagePicker.launchCamera(options).then(result => {
            if (result && result.didCancel !== true) {
              console.log(' camera result');
              console.log(result);
              let image = result.assets[0];
              console.log(
                'size in mb camera ios',
                image.fileSize / (1024 * 1024),
              );
              ImageResizer.createResizedImage(
                image.uri,
                image.width,
                image.height,
                'JPEG',
                100, //quality
                90, //rotaion
              )
                .then(({uri}) => {
                  console.log('====================================');
                  console.log('uri of image', uri);
                  console.log('====================================');
                  image.uri = uri;
                  if (image) {
                    let imageData = {};
                    imageData.uri = image.uri;
                    imageData.name = image.fileName;
                    imageData.type = image.type;
                    imageData.size = image.fileSize;
                    console.log(imageData);
                    props.setImageObject(imageData);
                  }
                })
                .catch(err => {
                  console.log(err);
                  return Alert.alert(
                    'Unable to resize the photo',
                    'Check the console for full the error message',
                  );
                });
            }
          });
        }
      });
    }
  };

  const pickDocument = async () => {
    try {
      const result = await DocumentPicker.pick({
        type: [DocumentPicker.types.images, DocumentPicker.types.pdf],
      });

      console.log('document data received');
      console.log(result);
      isPDF(result[0]);
      setisPdf(true);
      props.setImageObject(result[0]);

      // Handle the picked document
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
        // User cancelled the picker
      } else {
        throw err;
      }
    }
  };
  function isPDF(fileObject) {
    // Check if 'type' is present and contains 'pdf' or 'png'
    console.log(
      'passed to test in pdfpng is',
      fileObject,
      '\n',
      fileObject.type.includes('pdf'),
    );

    return fileObject && fileObject.type && fileObject.type.includes('pdf');
  }
  const onUploadResult = async () => {
    if (props?.isLab) {
      console.log('This is the test upload function ....');
      let data = {};
      data.TestName = props.testName;
      data.LabName = props.labName;
      data.Description = props.description;
      console.log(
        'Upload the result data is : ',
        data,
        ' Image object is : ',
        props?.imageObject,
        'lololo',
      );
      //====================================================================(Below portion is commented because of checking the uploading issue on android)================================================
      props.setLoader(true);
      // let authToken = null;
      // authToken = await retrieveItem(AuthToken);
      // const formdata = new FormData();
      // formdata.append('TestName', data.TestName);
      // formdata.append('LabName', data.LabName);
      // formdata.append('Description', data.Description);
      // console.log('====================================');
      // console.log('formdata', formdata);
      // console.log('====================================');
      // if (
      //   props.imageObject &&
      //   props.imageObject !== null &&
      //   props.imageObject.name &&
      //   props.imageObject.name !== null
      // ) {
      //   formdata.append('Files', {
      //     uri: props.imageObject.uri,
      //     name: props.imageObject.name,
      //     type: props.imageObject.type,
      //   });
      // }
      // console.log('====================================');
      // console.log('formdata', formdata);
      // console.log('====================================');
      // fetch(`${PRE_RELEASE}/api/Labs/AddLabs`, {
      //   method: 'POST',
      //   'Security-Key': 'lSWQ9NyZ1c2VyTmFtZT1TeWVkIFNoYWgmcGF0aWVudElkPTMwMD',
      //   headers: {
      //     Accept: 'application/json',
      //     'Content-Type': 'application/json, multipart/form-data',
      //     Authorization: 'Bearer '.concat(authToken === null ? '' : authToken),
      //   },
      //   body: formdata,
      // })
      //   .then(response => response.json())
      //   .then(json => {
      //     props.setLoader(true);
      //     console.log('====================================');
      //     console.log('data response', json);
      //     console.log('====================================');
      //   })
      //   .catch(err => {
      //     props.setLoader(false);
      //     console.log('====================================');
      //     console.log('error', err);
      //     console.log('====================================');
      //   });
      LabService.uploadLabData(data, props.imageObject)
        .then(res => {
          console.log('server response  :  ', res);
          if (res && res.statusCode === 200) {
            console.log('Data is submited to the backend');
            props.setLoader(false);
            showMessage({
              message: 'Succeeded',
              description: 'Your lab result is successfuly uploaded.',
              type: 'success',
            });
            props.onClose();
            if (props?.navigation) {
              props.navigation.navigate('Lab', {previousScreen: 'Home'});
            }
          }
        })
        .catch(error => {
          console.log(
            'Error in uploading the result by the picture taken from camera : ',
            error,
            error.isError,
          );
          props.setLoader(false);
          // props.onClose();
          if (error.isError) {
            showMessage({
              message: 'Info!',
              description: error?.detail,
              type: 'default',
              icon: {icon: 'info', position: 'top'},
              backgroundColor: Colors.red,
            });
          } else {
            showMessage({
              message: 'Something went wrong!',
              description: error?.response?.data?.detail,
              type: 'default',
              icon: {icon: 'info', position: 'left'},
              backgroundColor: Colors.red,
            });
          }
        });
      //====================================================================(Below portion is commented because of checking the uploading issue on android)================================================
    } else {
      let data = {};
      data.Name = props.testName;
      data.Description = props.description;
      props.setLoader(true);
      ImagingService.uploadimagingData(data, props?.imageObject)
        .then(res => {
          console.log('====================================');
          console.log('res', res);
          console.log('====================================');
          if (res && res.statusCode === 200) {
            props.setLoader(false);
            props.onClose();
            if (props?.navigation) {
              props.navigation.navigate('Imaging', {previousScreen: 'Home'});
            }
            props.imagingGetData();
          } else {
            props.setLoader(false);
          }
        })
        .catch(err => {
          props.setLoader(false);
        });
      // }
      console.log('Data comming from the lab is.... ', {
        data: data,
        img: props?.imageObject,
      });
    }
  };

  return (
    <>
      <Modalize
        ref={modalizeRef}
        adjustToContentHeight={true}
        modalStyle={{
          borderTopRightRadius: 25,
          borderTopLeftRadius: 25,
        }}>
        <View style={{padding: hp(3)}}>
          <TouchableOpacity
            onPress={() => {
              onClose();
              openCamera();
            }}
            style={{
              flexDirection: 'row',
              marginTop: hp(4),
              marginBottom: hp(2),
              marginLeft: hp(3),
              marginRight: hp(3),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2.2),
                flex: 1,
                color: Colors.black1,
              }}>
              Take Photo
            </Text>
          </TouchableOpacity>
          <View
            style={{
              height: 1,
              backgroundColor: Colors.line,
              width: '90%',
              alignSelf: 'center',
            }}
          />
          <TouchableOpacity
            onPress={() => {
              onClose();
              singleFilePicker();
            }}
            style={{
              flexDirection: 'row',
              marginTop: hp(2),
              marginBottom: hp(2),
              marginLeft: hp(3),
              marginRight: hp(3),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2.2),
                flex: 1,
                color: Colors.black1,
              }}>
              Choose Photo
            </Text>
          </TouchableOpacity>
          <View
            style={{
              height: 1,
              backgroundColor: Colors.line,
              width: '90%',
              alignSelf: 'center',
            }}
          />
          <TouchableOpacity
            onPress={() => {
              onClose();
              pickDocument();
            }}
            style={{
              flexDirection: 'row',
              marginTop: hp(2),
              marginBottom: hp(2),
              marginLeft: hp(3),
              marginRight: hp(3),
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2.2),
                flex: 1,
                color: Colors.black1,
              }}>
              Choose Document
            </Text>
          </TouchableOpacity>
        </View>
      </Modalize>
      <View style={{alignItems: 'center', flex: 1}}>
        <Text
          style={{
            color: Colors.black4,
            fontFamily: Fonts.SourceSansSemibold,
            fontSize: hp(2.2),
            marginVertical: hp(3),
          }}>
          Upload Result
        </Text>
      </View>
      <KeyboardAwareScrollView style={{flex: 1}}>
        <View style={{width: '90%', alignSelf: 'center'}}>
          <Text
            style={{
              color: Colors.noRecordFound,
              fontFamily: Fonts.SourceSansRegular,
              fontSize: hp(2.2),
            }}>
            Test Name
          </Text>
          <View
            style={{
              width: '100%',
              alignItems: 'center',
              justifyContent: 'center',
              borderWidth: 1,
              height: hp(7),
              borderColor: Colors.circleBackground,
              borderRadius: 5,
              marginTop: hp(0.5),
            }}>
            <TextInput
              style={{
                paddingTop: 10,
                paddingBottom: 10,
                color: '#424242',
                borderRadius: 8,
                borderColor: Colors.line,
                flexDirection: 'row',
                width: '90%',
                height: hp(10),
                alignSelf: 'center',
                fontSize: hp(2.2),
                fontFamily: Fonts.SourceSansRegular,
              }}
              maxLength={20}
              value={props.testName}
              onChangeText={text => {
                props.setTestName(text);
              }}
              placeholder={'Test Name'}
              placeholderTextColor={Colors.blueGrayDisableText}
            />
          </View>
        </View>
        {props.isLab ? (
          <View
            style={{
              width: '90%',
              alignSelf: 'center',
              marginVertical: hp(3),
            }}>
            <Text
              style={{
                color: Colors.noRecordFound,
                fontFamily: Fonts.SourceSansRegular,
                fontSize: hp(2.2),
              }}>
              Lab Name
            </Text>
            <View
              style={{
                width: '100%',
                alignItems: 'center',
                justifyContent: 'center',
                borderWidth: 1,
                height: hp(7),
                borderColor: Colors.circleBackground,
                borderRadius: 5,
                marginTop: hp(0.5),
              }}>
              <TextInput
                style={{
                  paddingTop: 10,
                  paddingBottom: 10,
                  color: '#424242',
                  borderRadius: 8,
                  borderColor: Colors.line,
                  flexDirection: 'row',
                  width: '90%',
                  height: hp(10),
                  alignSelf: 'center',
                  fontSize: hp(2.2),
                  fontFamily: Fonts.SourceSansRegular,
                }}
                value={props.labName}
                onChangeText={text => {
                  props.setLabName(text);
                }}
                maxLength={20}
                placeholder={'Lab Name'}
                placeholderTextColor={Colors.blueGrayDisableText}
              />
            </View>
          </View>
        ) : null}
        <View
          style={{
            width: '90%',
            alignSelf: 'center',
            marginBottom: hp(3),
            marginTop: !props.isLab ? hp(3) : 0,
          }}>
          <Text
            style={{
              color: Colors.noRecordFound,
              fontFamily: Fonts.SourceSansRegular,
              fontSize: hp(2.2),
            }}>
            Description
          </Text>
          {Platform.OS === 'ios' ? (
            <View
              style={{
                width: '100%',
                alignItems: 'center',
                justifyContent: 'center',
                borderWidth: 1,
                height: hp(10),
                borderColor: Colors.circleBackground,
                borderRadius: 5,
                marginTop: hp(0.5),
              }}>
              <TextInput
                style={{
                  paddingTop: 10,
                  color: '#424242',
                  borderRadius: 8,
                  borderColor: Colors.line,
                  flexDirection: 'row',
                  width: '90%',
                  height: hp(10),
                  alignSelf: 'center',
                  fontSize: hp(2.2),
                  fontFamily: Fonts.SourceSansRegular,
                }}
                value={props.description}
                maxLength={50}
                onChangeText={text => {
                  props.setDescription(text);
                }}
                enablesReturnKeyAutomatically={true}
                placeholder={'Test Description'}
                placeholderTextColor={Colors.blueGrayDisableText}
                multiline
                numberOfLines={5}
              />
            </View>
          ) : (
            <View
              style={{
                width: '100%',
                borderWidth: 1,
                height: hp(10),
                borderColor: Colors.circleBackground,
                borderRadius: 5,
                marginTop: hp(0.5),
              }}>
              <TextInput
                style={{
                  paddingLeft: 10,
                  color: '#424242',
                  borderRadius: 8,
                  borderColor: Colors.line,
                  minWidth: '100%',
                  fontSize: hp(2.2),
                  fontFamily: Fonts.SourceSansRegular,
                }}
                value={props.description}
                maxLength={50}
                onChangeText={text => {
                  props.setDescription(text);
                }}
                enablesReturnKeyAutomatically={true}
                placeholder={'Test Description'}
                placeholderTextColor={Colors.blueGrayDisableText}
                multiline={true}
              />
            </View>
          )}
        </View>
        <View style={{width: '90%', alignSelf: 'center', marginBottom: hp(3)}}>
          <Text
            style={{
              color: Colors.noRecordFound,
              fontFamily: Fonts.SourceSansRegular,
              fontSize: hp(2.2),
            }}>
            Upload Picture
          </Text>
          <Pressable
            onPress={() => {
              onOpen();
            }}
            style={{
              width: hp(15),
              alignItems: 'center',
              justifyContent: 'center',
              borderWidth: 1,
              height: hp(12),
              borderColor: Colors.circleBackground,
              borderRadius: 8,
              marginTop: hp(0.5),
            }}>
            {props.imageObject === null ? (
              <View style={{alignItems: 'center'}}>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansBold,
                    fontSize: hp(2.5),
                    color: Colors.noRecordFound,
                  }}>
                  +
                </Text>
                <Text
                  style={{
                    fontFamily: Fonts.SourceSansSemibold,
                    fontSize: hp(2),
                    color: Colors.noRecordFound,
                  }}>
                  Image
                </Text>
              </View>
            ) : (
              <Image
                source={
                  isPDF(props?.imageObject)
                    ? Images.PDF_file_icon // Set the source for PDF
                    : {uri: `file://${props?.imageObject?.uri}`} // Set the source for non-PDF
                }
                style={{
                  width: hp(15),
                  height: hp(12),
                  borderRadius: 8,
                  borderColor: 'red',
                  borderWidth: 0,
                }}
                resizeMode="contain"
              />
            )}
          </Pressable>
        </View>
        <View
          style={{
            width: '90%',
            alignSelf: 'center',
            marginBottom: hp(1),
            flexDirection: 'row',
            justifyContent: 'space-between',
          }}>
          <Pressable
            onPress={() => props.onClose()}
            style={{
              width: '47%',
              alignItems: 'center',
              justifyContent: 'center',
              height: hp(7),
              borderRadius: 8,
              backgroundColor: Colors.blueTextColorDisabled,
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansSemibold,
                color: Colors.blueTextColor,
                fontSize: hp(2),
              }}>
              Cancel
            </Text>
          </Pressable>

          <Pressable
            onPress={() => onUploadResult()}
            disabled={
              props.testName === '' ||
              props.labName === '' ||
              props.imageObject === null
                ? true
                : false
            }
            style={{
              width: '47%',
              alignItems: 'center',
              justifyContent: 'center',
              height: hp(7),
              borderRadius: 8,
              backgroundColor: Colors.blueTextColor,
              opacity:
                props.testName === '' ||
                props.labName === '' ||
                props.imageObject === null
                  ? 0.3
                  : 1,
            }}>
            <Text
              style={{
                fontFamily: Fonts.SourceSansSemibold,
                color: Colors.white,
                fontSize: hp(2),
              }}>
              Upload
            </Text>
          </Pressable>
        </View>
      </KeyboardAwareScrollView>
    </>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#2c3e50',
  },
});

//make this component available to the app
export default UploadResultModal;
