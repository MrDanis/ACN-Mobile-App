import React, {Fragment, useEffect, useState} from 'react';
import {SafeAreaView, StatusBar, Text, View,Image} from 'react-native';

import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {Colors, Images} from '../../../../config';
import FindDoctorListView from './components/FindDoctorListView';
import FindDoctorMapView from './components/FindDoctorMapView';
const FoundDoctor = ({navigation}) => {
  const [isDoctorFound, setisDoctorFound] = useState(null);
  const [viewType, setviewType] = useState('map');
  const handleViewChange = type => {
    switch (type) {
      case 0:
        setviewType('map');
        break;
      case 1:
        setviewType('list');
        break;
      default:
        break;
    }
  };
  useEffect(() => {
    setisDoctorFound(true);
    setTimeout(() => {
      setisDoctorFound(false);
    }, 5000);
  }, []);
  return (
    <Fragment>
      <StatusBar backgroundColor={Colors.BgColor} barStyle="dark-content" />
      <SafeAreaView
        style={{
          flex: 1,
          backgroundColor: Colors.BgColor,
        }}>
        {isDoctorFound ? (
          <View
            style={{
              flex: 1,
              alignItems: 'center',
              justifyContent: 'center',
              marginTop: hp(-3),
            }}>
            <View
              source={require('../../../../../assets/animations/findDocAnimation.json')}
              autoPlay
              loop
            />
            <View
              style={{
                borderColor: 'red',
                borderWidth: 0,
                alignItems: 'center',
                width: '90%',
                marginBottom: hp(-10),
              }}>
              <Image
                style={{
                  width: hp(18),
                  height: hp(18),
                }}
                source={Images.finDoc}
              />
            </View>
            <View
              style={{
                width: '85%',
                borderColor: 'red',
                borderWidth: 0,
                marginTop: hp(25),
              }}>
              <Text
                style={{
                  fontWeight: '700',
                  fontSize: hp(3.5),
                  textAlign: 'center',
                }}>
                Searching for nearby doctor....
              </Text>
            </View>
          </View>
        ) : !isDoctorFound && viewType === 'map' ? (
          <FindDoctorMapView
            changeView={handleViewChange}
            viewIs={viewType}
            navigation={navigation}
          />
        ) : (
          <FindDoctorListView
            changeView={handleViewChange}
            viewIs={viewType}
            navigation={navigation}
          />
        )}
      </SafeAreaView>
    </Fragment>
  );
};

export default FoundDoctor;
