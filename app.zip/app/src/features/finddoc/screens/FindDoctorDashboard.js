import React, {Fragment} from 'react';
import {
  SafeAreaView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Colors from '../../../../config/Colors';
import FindDocMainHeader from './components/findDocMainHeader';
const FindDoctorDashboard = ({navigation, route}) => {
  console.log('Data for the navigation is : ', route);
  const handleGoBack = () => {
    console.log('Handling go back navigation : ', navigation);
    navigation.navigate('FindDocSearch');
  };
  return (
    <Fragment>
      <StatusBar backgroundColor={Colors.BgColor} barStyle="dark-content" />
      <SafeAreaView
        style={{
          flex: 1,
          backgroundColor: Colors.BgColor,
        }}>
        <FindDocMainHeader name={'Find a Doctor'} navigation={navigation}>
          <View style={styles.container}>
            <View style={styles.content}></View>
            <View style={styles.buttonContainer}>
              <TouchableOpacity
                style={styles.buttonContainerButton}
                onPress={handleGoBack}>
                <Text style={styles.buttonContainerButtonText}>
                  Submit Assesment
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </FindDocMainHeader>
      </SafeAreaView>
    </Fragment>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-between',
    padding: 16,
  },
  content: {
    flex: 1,
  },
  buttonContainer: {
    borderColor: 'red',
    borderWidth: 0,
  },
  buttonContainerButton: {
    padding: hp(2),
    borderRadius: hp(1),
    backgroundColor: Colors.blueTextColor,

    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonContainerButtonText: {
    color: 'white', // Text color
    fontSize: 18,
    fontWeight: 'normal',
  },
});

export default FindDoctorDashboard;
