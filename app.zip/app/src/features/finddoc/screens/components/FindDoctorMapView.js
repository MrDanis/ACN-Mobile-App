import React, {Fragment, useState} from 'react';
import {
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import MapView, {Marker, PROVIDER_GOOGLE} from 'react-native-maps';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Carousel from 'react-native-snap-carousel';
import Colors from '../../../../../config/Colors';
import {docData} from '../../dummyData/doctorData';
import DoctorDataCard from './DoctorDataCard';
import FindDocMainHeader from './findDocMainHeader';
const FindDoctorMapView = ({changeView, viewIs, navigation}) => {
  console.log('CB : ', changeView, 'View type is : ', viewIs);
  const [activeFiler, setactiveFiler] = useState({
    index: 0,
    finterName: 'Most Reviewed',
  });
  const [mapMarkerLocation, setmapMarkerLocation] = useState({
    lat: 37.78825,
    lon: -122.4324,
    markersList: [
      {
        id: 1,
        coordinate: {
          latitude: 37.78825,
          longitude: -122.4324,
        },
        title: 'Marker 1',
        description: 'This is Marker 1',
      },
      {
        id: 2,
        coordinate: {
          latitude: 37.75825,
          longitude: -122.4624,
        },
        title: 'Marker 2',
        description: 'This is Marker 2',
      },
    ],
  });
  return (
    <Fragment>
      <SafeAreaView style={{flex: 1, borderColor: 'red', borderWidth: 0}}>
        <View
          style={{
            flex: 1,
            borderColor: 'red',
            borderWidth: 0,
            position: 'relative',
          }}
          collapsable={false}>
          <View
            style={{
              width: '100%',
              position: 'absolute',
              borderColor: 'green',
              borderWidth: 0,
              zIndex: 1,
            }}>
            <FindDocMainHeader name={'Doctor'} navigation={navigation} />
          </View>
          <MapView
            initialCamera={{
              center: {
                latitude: parseFloat(mapMarkerLocation.lat),
                longitude: parseFloat(mapMarkerLocation.lon),
              },
              pitch: 45,
              heading: 90,
              altitude: 1000,
              zoom: 17,
            }}
            provider={PROVIDER_GOOGLE}
            style={{flex: 1}}>
            {mapMarkerLocation.markersList.map((item, index) => {
              return (
                <Marker
                  key={item?.id}
                  coordinate={item?.coordinate}
                  title={item?.title}
                  description={item?.description}
                />
              );
            })}
          </MapView>
          <View
            style={{
              borderColor: 'green',
              borderWidth: 0,
              width: '100%',
              marginTop: '20%',
              position: 'absolute',
              zIndex: 1,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            {/* Tabs switching view */}
            <View style={{width: '90%', borderColor: 'blue', borderWidth: 0}}>
              <View
                style={{
                  alignItems: 'center',
                }}>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'center',
                    backgroundColor: Colors.bleLayer4,
                    width: Platform.OS === 'ios' ? '90%' : hp(44),
                    borderRadius: hp(1),
                  }}>
                  <TouchableOpacity
                    style={{
                      minWidth: Platform.OS === 'ios' ? '50%' : hp('23%'),
                      height: Platform.OS === 'android' ? hp(4) : hp(5),
                      flexDirection: 'row',
                      justifyContent: 'center',
                      alignItems: 'center',
                      backgroundColor:
                        viewIs === 'map'
                          ? Colors.blueTextColor
                          : Colors.bleLayer4,
                      borderRadius: hp(1),
                    }}
                    onPress={() => {
                      changeView(0);
                      console.log('Change view type is ', 0);
                    }}>
                    <Text
                      style={{
                        color:
                          viewIs === 'map'
                            ? Colors.white
                            : Colors.noRecordFound,
                      }}>
                      Map View
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={{
                      minWidth: Platform.OS === 'ios' ? '50%' : hp('23%'),
                      height: Platform.OS === 'android' ? hp(4) : hp(5),
                      justifyContent: 'center',
                      alignItems: 'center',
                      backgroundColor:
                        viewIs === 'list'
                          ? Colors.blueTextColor
                          : Colors.bleLayer4,
                      borderRadius: hp(1),
                      shadowRadius: 5,
                      marginLeft: Platform.OS === 'ios' ? hp(0.1) : hp(0),
                    }}
                    onPress={() => {
                      changeView(1);
                      console.log('Change view type is ', 1);
                    }}>
                    <Text
                      style={{
                        color:
                          viewIs === 'list'
                            ? Colors.white
                            : Colors.noRecordFound,
                      }}>
                      List View
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
            {/* Filters View (START)*/}
            <View
              style={{
                borderColor: 'red',
                alignItems: 'center',
                borderWidth: 0,
                width: '100%',
                marginTop: hp(2.5),
              }}>
              <View
                style={{width: '100%', borderColor: 'green', borderWidth: 0}}>
                <ScrollView
                  scrollEnabled={true}
                  showsHorizontalScrollIndicator={false}
                  horizontal={true}>
                  {[
                    'Most Reviewed',
                    'Avilable Today',
                    'Discounts',
                    'Highest Rated',
                  ].map((item, index) => {
                    return (
                      <Pressable
                        style={{
                          borderColor: 'green',
                          borderWidth: 0,
                          paddingHorizontal: hp(0.5),
                        }}
                        onPress={() => {
                          console.log('Press for the filter is : ', index);
                          setactiveFiler({index: index, finterName: item});
                        }}>
                        <View
                          style={{
                            alignItems: 'center',
                            justifyContent: 'center',
                            borderColor: 'red',
                            borderWidth: 0,
                            backgroundColor:
                              activeFiler.index === index
                                ? Colors.blueTextColor
                                : Colors.bleLayer4,
                            borderRadius: hp(1),
                            shadowRadius: 5,
                          }}>
                          <View
                            style={{
                              borderColor: 'green',
                              borderWidth: 0,
                              width: '100%',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              borderRadius: hp(1),
                              shadowRadius: 5,
                            }}>
                            <Text
                              style={{
                                color:
                                  activeFiler.index === index
                                    ? Colors.white
                                    : Colors.noRecordFound,
                                paddingHorizontal: hp(1.2),
                                paddingVertical: hp(1),
                              }}>
                              {item}
                            </Text>
                          </View>
                        </View>
                      </Pressable>
                    );
                  })}
                </ScrollView>
              </View>
            </View>
            {/* Filters View (END)*/}
          </View>
          <View
            style={{
              borderColor: 'green',
              borderWidth: 0,
              width: '100%',
              marginBottom: '5%',
              bottom: 0,
              position: 'absolute',
              zIndex: 1,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            {/* Doctors List view */}
            <View style={{width: '100%', borderColor: 'blue', borderWidth: 0}}>
              <Carousel
                data={docData}
                renderItem={({item}) => {
                  return (
                    <View
                      style={{
                        borderRadius: 8,
                        shadowOffset: {width: 0.5, height: 0.5},
                        shadowOpacity: 0.1,
                        shadowRadius: 8,
                        borderWidth: 1,
                        borderColor: Colors.line,
                        shadowOffset: {width: 0.5, height: 0.5},
                        shadowOpacity: 0.05,
                        shadowRadius: 8,
                        elevation: 1,
                        backgroundColor: Colors.BgColor,
                        padding: hp(2),
                      }}>
                      <DoctorDataCard docData={item} navigation={navigation} />
                    </View>
                  );
                }}
                sliderWidth={400} // Width of your carousel container
                itemWidth={300} // Width of your carousel items
                loop={false} // Enable infinite loop
                autoplay={false}
                centerMode={false}
                containerCustomStyle={{
                  overflow: 'visible',
                  borderColor: 'red',
                  borderWidth: 0,
                }}
              />
            </View>
          </View>
        </View>
      </SafeAreaView>
    </Fragment>
  );
};

export default FindDoctorMapView;
