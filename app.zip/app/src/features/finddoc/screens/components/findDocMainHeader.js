import React from 'react';
import {StyleSheet, Text, TouchableOpacity, View,Image} from 'react-native';

import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {SvgCss} from 'react-native-svg';
import {Colors, Images, Svgs} from '../../../../../config';
import {Fonts} from '../../../../../config/AppConfig';
const findDocMainHeader = ({navigation, children, name}) => {
  return (
    <View
      style={{
        justifyContent: 'center',
        flex: 1,
        backgroundColor: name === 'Doctor' ? 'transparent' : Colors.BgColor,
        bordercolor: 'red',
        borderWidth: 0,
      }}>
      <View
        style={{
          alignItems: 'center',
          justifyContent: 'center',
          flexDirection: 'row',
          marginTop: hp(3),
        }}>
        <View style={{flex: 0.25, paddingLeft: hp(1)}}>
          <SvgCss
            xml={Svgs.arrowHeadLeft}
            width={hp(4)}
            height={hp(4)}
            fill={Colors.black}
            onPress={() => {
              navigation.pop();
            }}
          />
        </View>
        <View style={{flex: 0.6, alignItems: 'center'}}>
          <Text
            style={{
              color: Colors.black,
              fontSize: hp(2.5),
              fontFamily: Fonts.SourceSansSemibold,
            }}>
            {name}
          </Text>
        </View>
        <View style={{flex: 0.25, alignItems: 'flex-end'}}>
          <TouchableOpacity
            onPress={() => navigation.navigate('NotificationStack')}>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'flex-start',
                marginRight: hp(2),
              }}>
              <Image
                style={{
                  width: hp(2),
                  height: hp(2.5),
                }}
                source={Images.notification_dashboard}
              />
            </View>
          </TouchableOpacity>
        </View>
      </View>
      {children}
    </View>
  );
};
// Defining styles for the component
const styles = StyleSheet.create({
  container: {},
});
export default findDocMainHeader;
