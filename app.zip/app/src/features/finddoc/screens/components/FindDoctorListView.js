import React, {Fragment, useState} from 'react';
import {
  FlatList,
  Pressable,
  SafeAreaView,
  ScrollView,
  StatusBar,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {RefreshControl} from 'react-native-gesture-handler';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Colors from '../../../../../config/Colors';
import {docData} from '../../dummyData/doctorData';
import DoctorDataCard from './DoctorDataCard';
import FindDocMainHeader from './findDocMainHeader';

const FindDoctorListView = ({changeView, viewIs, navigation}) => {
  const [doctorsList, setdoctorsList] = useState(docData);
  const [isRefreshDoctorList, setisRefreshDoctorList] = useState(false);
  const [activeFiler, setactiveFiler] = useState({
    index: 0,
    finterName: 'Most Reviewed',
  });
  console.log('doctor list is : ', doctorsList);
  return (
    <Fragment>
      <StatusBar backgroundColor={Colors.BgColor} barStyle="dark-content" />
      <SafeAreaView
        style={{
          flex: 1,
          backgroundColor: Colors.BgColor,
        }}>
        {/* Header Row*/}
        <FindDocMainHeader name={'Doctors'} navigation={navigation}>
          <View
            style={{
              flex: 1,
              alignItems: 'center',
              width: '100%',
              borderColor: 'blue',
              borderWidth: 0,
            }}>
            {/* Tabs Switching (START) */}
            <View
              style={{
                marginTop: hp(2),
                alignItems: 'center',
                borderColor: 'red',
                borderWidth: 0,
                width: '90%',
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'center',
                  backgroundColor: Colors.bleLayer4,
                  width: Platform.OS === 'ios' ? '90%' : hp(44),
                  borderRadius: hp(1),
                }}>
                <TouchableOpacity
                  style={{
                    minWidth: Platform.OS === 'ios' ? '50%' : hp('23%'),
                    height: Platform.OS === 'android' ? hp(4) : hp(5),
                    flexDirection: 'row',
                    justifyContent: 'center',
                    alignItems: 'center',
                    backgroundColor:
                      viewIs === 'map'
                        ? Colors.blueTextColor
                        : Colors.bleLayer4,
                    borderRadius: hp(1),
                  }}
                  onPress={() => {
                    changeView(0);
                    console.log('Change view type is ', 0);
                  }}>
                  <Text
                    style={{
                      color:
                        viewIs === 'map' ? Colors.white : Colors.noRecordFound,
                    }}>
                    Map View
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={{
                    minWidth: Platform.OS === 'ios' ? '50%' : hp('23%'),
                    height: Platform.OS === 'android' ? hp(4) : hp(5),
                    justifyContent: 'center',
                    alignItems: 'center',
                    backgroundColor:
                      viewIs === 'list'
                        ? Colors.blueTextColor
                        : Colors.bleLayer4,
                    borderRadius: hp(1),
                    shadowRadius: 5,
                    marginLeft: Platform.OS === 'ios' ? hp(0.1) : hp(0),
                  }}
                  onPress={() => {
                    changeView(1);
                    console.log('Change view type is ', 1);
                  }}>
                  <Text
                    style={{
                      color:
                        viewIs === 'list' ? Colors.white : Colors.noRecordFound,
                    }}>
                    List View
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
            {/* Tabs Switching (END) */}
            <View
              style={{
                borderColor: 'red',
                alignItems: 'center',
                borderWidth: 0,
                width: '100%',
                marginTop: hp(2.5),
              }}>
              <View
                style={{width: '100%', borderColor: 'green', borderWidth: 0}}>
                <ScrollView
                  scrollEnabled={true}
                  showsHorizontalScrollIndicator={false}
                  horizontal={true}>
                  {[
                    'Most Reviewed',
                    'Avilable Today',
                    'Discounts',
                    'Highest Rated',
                  ].map((item, index) => {
                    return (
                      <Pressable
                        style={{
                          borderColor: 'green',
                          borderWidth: 0,
                          paddingHorizontal: hp(0.5),
                        }}
                        onPress={() => {
                          // Medications
                          console.log('Press for the filter is : ', index);
                          setactiveFiler({index: index, finterName: item});
                        }}>
                        <View
                          style={{
                            alignItems: 'center',
                            justifyContent: 'center',
                            borderColor: 'red',
                            borderWidth: 0,
                            backgroundColor:
                              activeFiler.index === index
                                ? Colors.blueTextColor
                                : Colors.bleLayer4,
                            borderRadius: hp(1),
                            shadowRadius: 5,
                          }}>
                          <View
                            style={{
                              borderColor: 'green',
                              borderWidth: 0,
                              width: '100%',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              borderRadius: hp(1),
                              shadowRadius: 5,
                            }}>
                            <Text
                              style={{
                                color:
                                  activeFiler.index === index
                                    ? Colors.white
                                    : Colors.noRecordFound,
                                paddingHorizontal: hp(1.2),
                                paddingVertical: hp(1),
                              }}>
                              {item}
                            </Text>
                          </View>
                        </View>
                      </Pressable>
                    );
                  })}
                </ScrollView>
              </View>
            </View>
            <View
              style={{
                flex: 1,
                borderColor: 'red',
                borderWidth: 0,
                width: '100%',
              }}>
              <View
                style={{
                  flex: 1,
                  borderColor: 'green',
                  borderWidth: 0,
                  marginVertical: hp(2.5),
                }}>
                <FlatList
                  style={{
                    borderColor: 'blue',
                    borderWidth: 0,
                    paddingHorizontal: hp(2),
                  }}
                  data={docData}
                  onEndReachedThreshold={0.05}
                  onEndReached={({distanceFromEnd}) => {
                    console.log(
                      'Distance found and reacr the end',
                      distanceFromEnd,
                    );
                  }}
                  keyExtractor={item => item?.id}
                  renderItem={({item}) => {
                    console.log('item', item);
                    return (
                      <View
                        style={{
                          borderRadius: 8,
                          shadowOffset: {width: 0.5, height: 0.5},
                          shadowOpacity: 0.1,
                          shadowRadius: 8,
                          borderWidth: 1,
                          borderColor: Colors.line,
                          width: '100%',
                          marginTop: hp(3),
                          shadowOffset: {width: 0.5, height: 0.5},
                          shadowOpacity: 0.05,
                          shadowRadius: 8,
                          elevation: 1,
                          backgroundColor: Colors.BgColor,
                          padding: hp(2),
                        }}>
                        <DoctorDataCard
                          docData={item}
                          navigation={navigation}
                        />
                      </View>
                    );
                  }}
                  refreshControl={
                    <RefreshControl
                      refreshing={isRefreshDoctorList}
                      onRefresh={() => {
                        console.log('Calling the refresh....');
                      }}
                    />
                  }
                />
              </View>
            </View>
          </View>
        </FindDocMainHeader>
      </SafeAreaView>
    </Fragment>
  );
};

export default FindDoctorListView;
