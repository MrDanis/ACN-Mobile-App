import React from 'react';
import {Pressable, Text, View,Image} from 'react-native';

import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import DocLocSvg from '../../../../../../assets/svg/locationIcon.svg';
import Colors from '../../../../../config/Colors';
import Images from '../../../../../config/Images';
const DoctorDataCard = ({docData, navigation}) => {
  return (
    <View
      style={{
        flex: 1,
        display: 'flex',
        flexDirection: 'row',
        borderColor: 'red',
        borderWidth: 0,
      }}>
      <View style={{flex: 1, borderColor: 'green', borderWidth: 0}}>
        {/* To show the Image of the doc (START) */}
        <Image
          style={{
            width: hp(4),
            height: hp(4.5),
          }}
          source={Images.docImg}
        />
        {/* To show the Image of the doc (END) */}
      </View>
      <View
        style={{
          flex: 5,
          display: 'flex',
          flexDirection: 'column',
          borderColor: 'blue',
          borderWidth: 0,
        }}>
        {/* name View (START)*/}
        <View style={{flex: 1, borderWidth: 0, borderColor: 'red'}}>
          <Text>{docData?.name}</Text>
        </View>
        {/* name View (END)*/}
        {/* Occupation and Workplace View (START)*/}
        <View
          style={{
            flex: 1,
            display: 'flex',
            marginTop: hp(0.5),
            flexDirection: 'row',
            borderWidth: 0,
            borderColor: 'red',
          }}>
          <Text style={{fontSize: hp(1.45), color: Colors.noRecordFound}}>
            {docData?.occupation + ' '}
          </Text>

          <Text
            style={{
              fontSize: hp(1.45),
              marginLeft: hp(0.5),
              color: Colors.noRecordFound,
            }}>
            {docData?.workPlace}
          </Text>
        </View>
        {/* Occupation and Workplace View (END)*/}
        {/* Rating and Shedule View (START)*/}
        <View
          style={{
            flex: 1,
            display: 'flex',
            marginTop: hp(2),
            flexDirection: 'row',
            borderWidth: 0,
            borderColor: 'red',
          }}>
          <Text style={{fontSize: hp(1.45), color: Colors.noRecordFound}}>
            IC
          </Text>
          <Text style={{fontSize: hp(1.45), color: Colors.noRecordFound}}>
            {docData?.rating}
          </Text>
          <Text style={{fontSize: hp(1.45), color: Colors.noRecordFound}}>
            IC
          </Text>
          <Text
            style={{
              fontSize: hp(1.45),
              marginLeft: hp(0.5),
              color: Colors.noRecordFound,
            }}>
            {docData?.sheduleTime}
          </Text>
        </View>
        {/* Rating and Shedule View (END)*/}
      </View>
      <View
        style={{
          flex: 1,
          display: 'flex',
          borderColor: 'yellow',
          borderWidth: 0,
          alignItems: 'flex-end',
        }}>
        <Pressable
          onPress={() => {
            console.log('I am pressed to navigate to Urgent Care...');
          }}>
          <DocLocSvg />
        </Pressable>
      </View>
    </View>
  );
};

export default DoctorDataCard;
