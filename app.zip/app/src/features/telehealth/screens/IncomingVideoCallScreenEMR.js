import React, {useEffect, useState, useCallback, Fragment} from 'react';
import {
  Vibration,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Platform,
  StatusBar,
  SafeAreaView,
  ActivityIndicator,
  Image
} from 'react-native';
import InCallManager from 'react-native-incall-manager';
import RingerMode from 'react-native-ringer-mode';
import {answerIncomingIOSCall} from '../../../helpers/CallKeep/CallKeepHelper';
import {connect} from 'react-redux';
import {setCallIncomming} from '../actions';

import Colors from '../../../../config/Colors';
import {Fonts} from '../../../../config/AppConfig';
import {CallActionType} from '../../../helpers/Constants';
import {CallAction} from '../../../helpers/signalR/SignalRService';
import {TwilioHelper} from '../../../helpers/Twilio/TwilioHelper';
import {requestMicCameraPermission} from '../../../helpers/Common';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';

import {CallCircularView} from '../components/CallCircularView';
import {useSelector, useDispatch} from 'react-redux';
import {getCMCallStatus} from '../../chat/actions';
import Spinner from 'react-native-loading-spinner-overlay';
import { Images } from '../../../../config';
import colors from '../../../../config/Colors';
const IncomingCallScreenEMR = props => {
  const cmCallEnd = useSelector(state => state?.cmCallEndStatus);
  const dispatch = useDispatch();
  console.log('Call end reducer is : ', cmCallEnd);
  console.log('Props are  at InComming screen : ', props);
  const [isAnswer, setisAnswer] = useState(false);
  const [timeoutId, setTimeoutId] = useState(null); // Store timeout ID
  const [isLoading,setisLoading] = useState(true);
  const _onRejectPress = useCallback(() => {
    setisAnswer(true);
    console.log('Call manually rejected');
    // CallAction(CallActionType.reject);
    global.isIncomingCall = false;
    InCallManager.stopRingtone();
    Vibration.cancel();
    props.navigation.goBack(); // Go back to the previous screen
  }, [props.navigation]);

  const _onAcceptPress = useCallback(() => {
    setisAnswer(true);
    console.log('Call accepted');
    // if (Platform.OS === 'ios') {
    //   const callUUID = TwilioHelper.sharedInstance().callUUID;
    //   answerIncomingIOSCall(callUUID);
    // }
    //console.log('props are : ',props);
    //CallAction(CallActionType.accept);
    InCallManager.stopRingtone();
    Vibration.cancel();
    props.navigation.goBack(); // Go back to the previous screen
    console.log('Props are : ', props);
    props.navigation.navigate('MeetingWithCM', {
      data: props?.route?.params?.data,
    });
  }, [props.navigation]);

  // Handle incoming call when the screen is mounted
  useEffect(() => {
    requestMicCameraPermission().then(statuses => {
      console.log(
        'Here in on accept press : ',
        statuses.microphonePermission,
        statuses.microphonePermission,
      );
      if (
        statuses.cameraPermission === 'granted' &&
        statuses.microphonePermission === 'granted'
      ) {
          _onAcceptPress();
      }
    });
    // const init = async () => {
    //   const PATTERN = [1000, 2000, 3000];
    //   console.log('Incoming call screen initialized');
    //   InCallManager.startRingtone('_DEFAULT_');
    //   const mode = await RingerMode.getRingerMode();
    //   if (mode === 'VIBRATE') {
    //     Vibration.vibrate(PATTERN, true);
    //   }
    // };
    // init();
  }, []);

  // Reset the timer when navigating to this screen
  useEffect(() => {
    if (isAnswer === false) {
      // Clear any existing timeout before setting a new one
      if (timeoutId) {
        clearTimeout(timeoutId);
      }

      const newTimeoutId = setTimeout(() => {
        console.log('Here in the set timeout: ', isAnswer);
        InCallManager.stopRingtone();
        const currentRouteName =
          props.navigation.getState()?.routes?.[
            props.navigation.getState().index
          ]?.name;
        console.log('Current Screen name is : ', currentRouteName);
        if (currentRouteName === 'IncomingCallScreen') {
          props.navigation.pop();
        } else {
          props.navigation.navigate(currentRouteName);
        }
      }, 30000);
      // Store the new timeout ID
      setTimeoutId(newTimeoutId);
      // Cleanup function to clear the timeout when component unmounts
      return () => clearTimeout(newTimeoutId);
    }
  }, [isAnswer, props.navigation]);
  useEffect(() => {
    console.log('call End staus from the sm side is : ', cmCallEnd);
    if (
      cmCallEnd.isCallEndedbeforeJoining &&
      cmCallEnd.roomId.roomId === props.route?.params?.data?.room
    ) {
      InCallManager.stopRingtone();
      const currentRouteName =
        props.navigation.getState()?.routes?.[props.navigation.getState().index]
          ?.name;
      let tempcamEndPaylod = {
        isCallEndedbeforeJoining: false,
        roomId: {roomId: '', userId: ''},
      };
      dispatch(getCMCallStatus(tempcamEndPaylod));
      if (currentRouteName === 'IncomingCallScreen') {
        props.navigation.pop();
      } else {
        props.navigation.navigate(currentRouteName);
      }
    }
  }, [cmCallEnd]);
  // const renderTopContainer = () => (
  //   <View style={styles.topBarContainer}>
  //     <View style={styles.callerInfo}>
  //       <Text style={styles.callerDetail}>
  //         {props?.route?.params?.data?.caller}
  //       </Text>
  //     </View>
  //   </View>
  // );

  // const renderBottomContainer = () => (
  //   <View style={styles.topBarContainer}>
  //     <View style={styles.actionButtonsContainer}>
  //       <TouchableOpacity
  //         style={styles.leftButton}
  //         onPress={() => {
  //           requestMicCameraPermission().then(statuses => {
  //             console.log(
  //               'Here in on accept press : ',
  //               statuses.microphonePermission,
  //               statuses.microphonePermission,
  //             );
  //             if (
  //               statuses.cameraPermission === 'granted' &&
  //               statuses.microphonePermission === 'granted'
  //             ) {
  //               _onAcceptPress();
  //             }
  //           });
  //         }}>
  //         <Imagestyle={styles.callIcon} source={images.callIcon} />
  //       </TouchableOpacity>
  //       <TouchableOpacity style={styles.centerButton} onPress={_onRejectPress}>
  //         <Image
  //           style={[styles.callIcon, {transform: [{scaleX: -1}]}]} // Flipped horizontally
  //           source={images.callIcon}
  //         />
  //       </TouchableOpacity>
  //     </View>
  //   </View>
  // );

  return (
    <Fragment>
      <SafeAreaView
       style={{
        flex: 1,
        backgroundColor: Colors.BgColor,
      }}
      >
        <View style={{flex:1,borderColor:'red',borderWidth:0,display:'flex',alignItems:'center',justifyContent:'center',gap:hp(2)}}>
           <ActivityIndicator  size="large" color="#000000" />
           <Text style={{color:colors.black}}>
              Please wait taking you back to app....
            </Text> 
        </View>
      </SafeAreaView>

    </Fragment>
  )
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.black1,
    flexDirection: 'column',
  },
  callContainer: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: Colors.black1,
  },
  topBarContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  actionButtonsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: hp(10),
    marginLeft: hp(5),
    marginRight: hp(5),
    justifyContent: 'space-between',
    flex: 1,
  },
  centerButton: {
    height: 90,
    width: 90,
    backgroundColor: 'rgba(212, 105, 96, 1.0)',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 100,
  },
  leftButton: {
    height: 95,
    width: 95,
    backgroundColor: Colors.green,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 100,
  },
  callIcon: {
    width: hp(2.5),
    height: hp(2.5),
  },
  callerInfo: {
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: hp(3),
    flex: 1,
  },
  callerDetail: {
    fontSize: 18,
    color: Colors.white,
    marginTop: hp(1),
    textAlign: 'center',
    fontFamily: Fonts.SourceSansRegular,
  },
});

const mapStateToProps = ({homeApiData, getCallIncomming, cmCallEndStatus}) => ({
  homeApiData,
  getCallIncomming,
  cmCallEndStatus,
});

export default connect(mapStateToProps)(IncomingCallScreenEMR);
