import Geolocation from '@react-native-community/geolocation';
import React, {Fragment, useEffect, useState} from 'react';
import {SafeAreaView, View} from 'react-native';
import Spinner from 'react-native-loading-spinner-overlay';
import MapView, {Marker, PROVIDER_GOOGLE} from 'react-native-maps';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {} from 'react-native-safe-area-context';
import Carousel from 'react-native-snap-carousel';
import Colors from '../../../../config/Colors';
import UrgentCareService from '../../../api/urgentCare';
import {docData} from '../../finddoc/dummyData/doctorData';
import DoctorDataCard from '../../finddoc/screens/components/DoctorDataCard';
import FindDocMainHeader from '../../finddoc/screens/components/findDocMainHeader';
const UrgrntCareMainScreen = ({navigation}) => {
  const [loading, setLoading] = useState(false);
  const [mapMarkerLocation, setmapMarkerLocation] = useState({
    lat: 37.78825,
    lon: -122.4324,
    markersList: [
      {
        id: 1,
        coordinate: {
          latitude: 37.78825,
          longitude: -122.4324,
        },
        title: 'Marker 1',
        description: 'This is Marker 1',
      },
      {
        id: 2,
        coordinate: {
          latitude: 37.75825,
          longitude: -122.4624,
        },
        title: 'Marker 2',
        description: 'This is Marker 2',
      },
    ],
  });
  const handleGoBack = () => {
    navigation.pop();
  };
  useEffect(() => {
    // Check and request location permission
    Geolocation.getCurrentPosition(info =>
      console.log('Location Info is : ', JSON.stringify(info)),
    );

    setLoading(true);
    UrgentCareService.getUrgentCareDoctorList('md')
      .then(res => {
        console.log('Response of Urgent Care Api is : ', res);
        let tempDataArry = [];
        for (let i = 0; i < res?.data?.length; i++) {
          let tempObj = {
            id: i,
            coordinate: {
              latitude: parseInt(res?.data[0]?.lat),
              longitude: parseInt(res?.data[0]?.long),
            },
            title: `Name : ${res?.data[i]?.name}`,
            description: `Address : ${res?.data[i]?.address}`,
          };
          tempDataArry.push(tempObj);
        }
        setmapMarkerLocation({
          ...mapMarkerLocation,
          lat: parseInt(res?.data[0]?.lat),
          lon: parseInt(res?.data[0]?.long),
          markersList: tempDataArry,
        });
        setLoading(false);
      })
      .catch(err => {
        console.log('Error in the api is : ', err);
        setLoading(false);
      });
  }, []);
  return (
    <Fragment>
      <SafeAreaView style={{flex: 1, borderColor: 'red', borderWidth: 0}}>
        <Spinner
          visible={loading}
          textContent={'Loading...'}
          textStyle={{color: '#FFF'}}
        />
        <View
          style={{
            flex: 1,
            borderColor: 'red',
            borderWidth: 0,
            position: 'relative',
          }}
          collapsable={false}>
          <View
            style={{
              width: '100%',
              position: 'absolute',
              borderColor: 'green',
              borderWidth: 0,
              zIndex: 1,
            }}>
            <FindDocMainHeader name={'Doctor'} navigation={navigation} />
          </View>
          <MapView
            initialCamera={{
              center: {
                latitude: parseFloat(mapMarkerLocation.lat),
                longitude: parseFloat(mapMarkerLocation.lon),
              },
              pitch: 45,
              heading: 90,
              altitude: 1000,
              zoom: 17,
            }}
            showsCompass={false}
            provider={PROVIDER_GOOGLE}
            style={{flex: 1}}>
            {mapMarkerLocation.markersList.map((item, index) => {
              return (
                <Marker
                  key={item?.id}
                  coordinate={item?.coordinate}
                  title={item?.title}
                  description={item?.description}
                />
              );
            })}
          </MapView>

          <View
            style={{
              borderColor: 'green',
              borderWidth: 0,
              width: '100%',
              marginBottom: '5%',
              bottom: 0,
              position: 'absolute',
              zIndex: 1,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              display: 'none',
            }}>
            {/* Doctors List view */}
            <View style={{width: '100%', borderColor: 'blue', borderWidth: 0}}>
              <Carousel
                data={docData}
                renderItem={({item}) => {
                  return (
                    <View
                      style={{
                        borderRadius: 8,
                        shadowOffset: {width: 0.5, height: 0.5},
                        shadowOpacity: 0.1,
                        shadowRadius: 8,
                        borderWidth: 1,
                        borderColor: Colors.line,
                        shadowOffset: {width: 0.5, height: 0.5},
                        shadowOpacity: 0.05,
                        shadowRadius: 8,
                        elevation: 1,
                        backgroundColor: Colors.BgColor,
                        padding: hp(2),
                      }}>
                      <DoctorDataCard docData={item} navigation={navigation} />
                    </View>
                  );
                }}
                sliderWidth={400}
                itemWidth={300}
                loop={false}
                autoplay={false}
                centerMode={false}
                containerCustomStyle={{
                  overflow: 'visible',
                  borderColor: 'red',
                  borderWidth: 0,
                }}
              />

              {/* Doctors data card start showing from here (END)*/}
            </View>
          </View>
        </View>
      </SafeAreaView>
    </Fragment>
  );
};

export default UrgrntCareMainScreen;
