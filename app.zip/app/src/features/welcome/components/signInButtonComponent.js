import React from 'react';
import {Image, Text, View} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {Fonts} from '../../../../config/AppConfig';
import Colors from '../../../../config/Colors';

const SignInButton = props => {
  return (
    <View
      style={{
        backgroundColor: Colors.white,
        flexDirection: 'column',
        alignItems: 'center',
        alignContent: 'center',
        borderColor: Colors.black,
        borderRadius: Platform.OS == 'ios' ? 20 : 10,
        marginTop: hp(2.5),
        elevation: 4,
        shadowOffset: {width: 0, height: 8},
        shadowOpacity: 0.08,
        shadowRadius: 10,
        paddingHorizontal: hp(1.8),
      }}>
      <View
        style={{
          marginVertical: hp(4),
          alignItems: 'center',
        }}>
        {props.text === 'Email Address' ? (
          <Image
            source={props.image}
            style={{
              height: hp(3.6),
              width: hp(3.5),
              resizeMode: 'contain',
            }}
          />
        ) : (
          <Image
            source={props.image}
            style={{
              height: hp(3.6),
              width: hp(3.5),
              resizeMode: 'contain',
            }}
          />
        )}

        {props.text === 'Email Address' ? (
          <Text
            style={{
              textAlign: 'center',
              fontFamily: Fonts.SourceSansSemibold,
              fontSize: hp(2.1),
              color: Colors.black,
            }}>
            {props.text}
          </Text>
        ) : (
          <Text
            style={{
              textAlign: 'center',
              fontFamily: Fonts.SourceSansSemibold,
              fontSize: hp(2.1),
              paddingHorizontal: 28,
              paddingTop: 10,
              color: Colors.black,
            }}>
            {props.text}
          </Text>
        )}
      </View>
    </View>
  );
};

export default SignInButton;
