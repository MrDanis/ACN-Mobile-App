/* istanbul ignore file */
import React, {Fragment, useState} from 'react';
import {
  Image,
  Keyboard,
  SafeAreaView,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import CountryPicker from 'react-native-country-picker-modal';
import {showMessage} from 'react-native-flash-message';
import Spinner from 'react-native-loading-spinner-overlay';
import {TextInputMask} from 'react-native-masked-text';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import {SvgCss} from 'react-native-svg';
import {useDispatch} from 'react-redux';
import {Fonts} from '../../../../config/AppConfig';
import Colors from '../../../../config/Colors';
import images from '../../../../config/Images';
import Svgs from '../../../../config/Svgs';
import AuthService from '../../../api/auth';
import {
  AuthCode,
  IsEmailORPhone,
  storeItem,
  storeValue,
  UserPhoneNumber,
} from '../../../helpers/LocalStorage';
import {getIsEmail} from '../action';

const InputPhoneScreen = ({navigation}) => {
  const dispatch = useDispatch();
  const defaultCountryCode = 'US';
  const [phoneNumber, setPhoneNumber] = useState('');
  const [phoneError, setPhoneError] = useState('');
  const [phoneValidation, setPhoneValidation] = useState(false);
  const [loader, showLoader] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState(defaultCountryCode);
  const [countryCode, setCountryCode] = useState('1');
  const customCountries = ['US', 'PK'];
  /* istanbul ignore next */
  function validatePhone(text) {
    var regex = /^\(\d{3}\) \d{3} \d{4}$/;
    if (regex.test(text) === false) {
      setPhoneValidation(false);
      setPhoneError('Enter valid phone number');
      return false;
    } else {
      setPhoneValidation(true);
      setPhoneError('');
      return true;
    }
  }
  function sendOTPOverPhone(phone, isEmail) {
    Keyboard.dismiss();
    showLoader(true);
    const phoneNumberDigits = phone.replace(/[\s()]/g, '');
    const finalFormattedNumber =  '+' + countryCode + phoneNumberDigits;

    AuthService.getAuthToken(finalFormattedNumber, isEmail)
      .then(async response => {
        showLoader(false);
        if (response && response.statusCode === 200) {
          console.log('Response of login with phone : ',response);
          dispatch(getIsEmail(false));
          storeValue('isEmail', 'false');
          storeItem(UserPhoneNumber, phone).then(phone => {});
          storeItem(IsEmailORPhone, false).then(email => {});
          storeItem(AuthCode, response.data.authCode).then(authCode => {
            navigation.navigate('OTP', {
              email: finalFormattedNumber,
              OtpCode: response?.data?.otp,
              type: 'Phone Number',
            });
          });

          // storeItem(RefreshToken, data.RefreshToken);
        } else {
          showMessage({
            message: 'Error',
            description: 'Invalid phone number. Please try again.',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        }
      })
      .catch(error => {
        if (error.status === 500) {
          showLoader(false);
          showMessage({
            message: 'Error',
            description: 'Invalid phone number. Please try again.',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        } else {
          console.log(error);
          showLoader(false);
          showMessage({
            message: 'Info',
            description: 'Internal Server Error',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        }
      });
  }

  return (
    <Fragment>
      <SafeAreaView style={{flex: 1, backgroundColor: Colors.BgColor}}>
        <View
          style={{
            flex: 1,
            backgroundColor: Colors.BgColor,
            alignItems: 'center',
          }}>
          <TouchableOpacity
            onPress={() => {
              navigation.goBack();
            }}
            style={{
              height: hp(9),
              width: hp(9),
              paddingVertical: hp(2),
              paddingHorizontal: hp(2),
              alignSelf: 'flex-start',
            }}>
            <SvgCss
              xml={Svgs.arrowHeadLeft}
              width={hp(5)}
              height={hp(5)}
              fill={Colors.black}
            />
          </TouchableOpacity>
          <View style={{width: '90%'}}>
            <Text
              style={{
                textAlign: 'left',
                fontFamily: Fonts.SourceSansBold,
                marginTop: hp(2),
                fontSize: hp(4.5),
                color: Colors.notificationGray,
              }}>
              Enter your
            </Text>
            <Text
              style={{
                textAlign: 'left',
                fontFamily: Fonts.SourceSansBold,
                marginTop: hp(0),
                fontSize: hp(4.5),
                color: Colors.notificationGray,
              }}>
              Phone Number
            </Text>
            <Text
              style={{
                textAlign: 'left',
                fontFamily: Fonts.SourceSansRegular,
                marginTop: hp(1),
                fontSize: hp(2),
                color: Colors.noRecordFound,
              }}>
              We will sent you a OTP code on your provided phone number to login
              in DataQ HealthSpot.
            </Text>
          </View>
          <View
            style={{
              backgroundColor: Colors.white,
              borderRadius: 8,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'flex-start',
              paddingHorizontal: hp(1.8),
              shadowOffset: {width: 0.5, height: 0.5},
              shadowOpacity: 0.05,
              shadowRadius: 8,
              elevation: 10,
              height: hp(6.5),
              width: '90%',
              marginVertical: hp(4.5),
            }}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'flex-start',
              }}>
              <CountryPicker
                withFlag
                withEmoji
                withCallingCode
                withAlphaFilter
                onSelect={country => {
                  console.log('yuuhuu', country.callingCode[0]);
                  setCountryCode(country.callingCode[0]);
                  setSelectedCountry(country.cca2);
                }}
                countryCode={selectedCountry}
                countryCodes={['US']}
              />
              <Image
                style={{
                  marginHorizontal: hp(0),
                  color: Colors.blueGrayDisableText,
                  borderColor: 'red',
                }}
                source={images.arrowDown}
              />
              <TextInputMask
                type={'custom'}
                options={{
                  mask: '(999) 999 9999',
                }}
                style={{
                  fontSize: hp(2.0),
                  width: '90%',
                  color: Colors.black4,
                  marginLeft: wp(1.8),
                }}
                value={phoneNumber}
                onChangeText={e => {
                  setPhoneNumber(e);
                  validatePhone(e);
                }}
                placeholderTextColor={Colors.noRecordFound}
                placeholder={'(999) 999-9999'}
                keyboardType="phone-pad"
                onSubmitEditing={() => {
                  Keyboard.dismiss();
                }}
              />
            </View>
          </View>
          <TouchableOpacity
            onPress={() =>
              phoneError === '' && sendOTPOverPhone(phoneNumber, false)
            }
            disabled={phoneValidation ? false : true}
            style={{
              backgroundColor: phoneValidation
                ? Colors.blueTextColor
                : Colors.blueTextColorDisabled,
              borderRadius: 8,
              justifyContent: 'center',
              height: hp(6.5),
              width: '90%',
              alignSelf: 'center',
            }}>
            {loader ? (
              <Spinner
                visible={loader}
                textContent={'Loading...'}
                textStyle={{color: '#FFF'}}
              />
            ) : (
              <Text
                style={{
                  textAlign: 'center',
                  fontFamily: Fonts.SourceSansSemibold,
                  fontSize: hp(2.5),
                  color: Colors.white,
                }}>
                Submit
              </Text>
            )}
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </Fragment>
  );
};

export default InputPhoneScreen;
