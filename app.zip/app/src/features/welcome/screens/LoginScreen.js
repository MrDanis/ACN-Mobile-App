import {appleAuth} from '@invertase/react-native-apple-authentication';
import React, {Fragment, useEffect, useState} from 'react';
import {
  Image,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  Text,
  View,
  Linking,
} from 'react-native';
import {showMessage} from 'react-native-flash-message';
import Spinner from 'react-native-loading-spinner-overlay';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {useDispatch} from 'react-redux';
import {Fonts} from '../../../../config/AppConfig';
import Colors from '../../../../config/Colors';
import Images from '../../../../config/Images';
import AuthService from '../../../api/auth';
import {
  AppleData,
  AuthCode,
  AuthToken,
  LoginMethod,
  RefreshToken,
  retrieveItem,
  storeItem,
} from '../../../helpers/LocalStorage';
import {loginWithGoogle} from '../../../helpers/SocailLoginHelper';
import {getUserProfile} from '../../profile/action';
import SignInButton from '../components/signInButtonComponent';
import {checkGoogleFitAppInstalled} from '../../../helpers/GoogleFit/GoogleFitHandler';
// import JailMonkey from 'jail-monkey';

let user = null;
let authCredentialListener = null;

const Login = ({navigation}) => {
  const dispatch = useDispatch();
  const [loader, setLoader] = useState(false);
  const [credentialStateForUser, setCredentialStateForUser] = useState(-1);

  useEffect(() => {
    // checkGoogleFitAppInstalled().then((res)=>{console.log('response of google fit is : ',res)});
    if (appleAuth.isSupported) {
      authCredentialListener = appleAuth.onCredentialRevoked(async () => {
        fetchAndUpdateCredentialState().catch(error =>
          setCredentialStateForUser(`Error: ${error.code}`),
        );
      });

      fetchAndUpdateCredentialState()
        .then(res => setCredentialStateForUser(res))
        .catch(error => setCredentialStateForUser(`Error: ${error.code}`));
    }
  }, []);

  const verifyGoogleToken = token => {
    setLoader(true);
    AuthService.verifyGoogleAccessToken(token)
      .then(response => {
        console.log('this is google profile data', response);
        setLoader(false);
        if (response.statusCode === 200) {
          dispatch(getUserProfile(response.data.profile));
          storeItem(AuthCode, response.data.accessToken).then(authCode => {});
          storeItem(AuthToken, response.data.accessToken).then(email => {});
          storeItem(RefreshToken, response.data.refreshToken);
          storeItem(LoginMethod, 'Google');
          if (
            response.data.profile.firstName !== '' &&
            response.data.profile.firstName !== null &&
            response.data.profile.lastName !== '' &&
            response.data.profile.lastName !== null &&
            response.data.profile.gender !== 0 &&
            response.data.profile.gender !== null &&
            response.data.profile.dateOfBirth !== '01/01/1900 00:00:00' &&
            response.data.profile.dateOfBirth !== null &&
            response.data.profile.email !== '' &&
            response.data.profile.email !== null &&
            response.data.profile.phone !== '' &&
            response.data.profile.phone !== null
          ) {
            navigation.navigate('HomeTab', {screen: 'Home'});
          } else {
            navigation.navigate('EditProfile', {
              profileDetails: response.data.profile,
              screenName: 'otp',
            });
          }
        } else {
          showMessage({
            message: 'Error',
            description: response.Error
              ? response.Error.Message
              : 'Invalid Email, Please try again!',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        }
      })
      .catch(error => {
        console.log(error);
        setLoader(false);
        showMessage({
          message: 'Error',
          description: 'Invalid email. Please try again.',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  };

  const appleSignIn = async () => {
    try {
      const appleAuthRequestResponse = await appleAuth.performRequest({
        requestedOperation: appleAuth.Operation.LOGIN,
        requestedScopes: [appleAuth.Scope.FULL_NAME, appleAuth.Scope.EMAIL],
      });

      const {
        user: newUser,
        email,
        nonce,
        identityToken,
        fullName,
        realUserStatus /* etc */,
      } = appleAuthRequestResponse;

      user = newUser;

      fetchAndUpdateCredentialState()
        .then(res => setCredentialStateForUser(res))
        .catch(error => setCredentialStateForUser(`Error: ${error.code}`));

      if (identityToken) {
        // e.g. sign in with Firebase Auth using `nonce` & `identityToken`
        if (email !== null) {
          let appleData = {};
          appleData.email = email;
          appleData.fullName = fullName.familyName + ' ' + fullName.givenName;
          appleData.firstName = fullName.givenName;
          appleData.lastName = fullName.familyName;
          appleData.appleID = user;
          verifyAppleToken(appleData);
          await storeItem(AppleData, JSON.stringify(appleData));
        } else {
          var appleData = await retrieveItem(AppleData);

          verifyAppleToken(JSON.parse(appleData));
        }
      } else {
        // no token - failed sign-in?
      }

      if (realUserStatus === appleAuth.UserStatus.LIKELY_REAL) {
      }
    } catch (error) {
      if (error.code === appleAuth.Error.CANCELED) {
        console.warn('User canceled Apple Sign in.');
      } else {
        console.error(error);
      }
    }
  };

  const fetchAndUpdateCredentialState = async () => {
    if (user === null) {
      setCredentialStateForUser('N/A');
    } else {
      const credentialState = await appleAuth.getCredentialStateForUser(
        this.user,
      );
      if (credentialState === appleAuth.State.AUTHORIZED) {
        setCredentialStateForUser('AUTHORIZED');
      } else {
        setCredentialStateForUser(credentialState);
      }
    }
  };

  const verifyAppleToken = data => {
    console.log('====================================');
    console.log('data', data);
    console.log('====================================');
    setLoader(true);
    AuthService.verifyAppleToken(data)
      .then(response => {
        setLoader(false);
        if (response.statusCode === 200) {
          dispatch(getUserProfile(response.data.profile));
          storeItem(AuthCode, response.data.accessToken).then(authCode => {});
          storeItem(AuthToken, response.data.accessToken).then(email => {});
          storeItem(RefreshToken, response.data.refreshToken);
          storeItem(LoginMethod, 'Apple');
          if (
            response.data.profile.firstName !== '' &&
            response.data.profile.firstName !== null &&
            response.data.profile.lastName !== '' &&
            response.data.profile.lastName !== null &&
            response.data.profile.gender !== 0 &&
            response.data.profile.gender !== null &&
            response.data.profile.dateOfBirth !== '01/01/1900 00:00:00' &&
            response.data.profile.dateOfBirth !== null
          ) {
            navigation.navigate('HomeTab', {screen: 'Home'});
          } else {
            navigation.navigate('EditProfile', {
              profileDetails: response.data.profile,
              screenName: 'otp',
            });
          }
        } else {
          showMessage({
            message: 'Error',
            description: response.Error
              ? response.Error.Message
              : 'Invalid Email, Please try again!',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        }
      })
      .catch(error => {
        console.log(error);
        setLoader(false);
        showMessage({
          message: 'Error',
          description: 'Invalid email. Please try again.',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  };

  /* istanbul ignore next */
  const verifyFBToken = token => {
    setLoader(true);
    AuthService.verifyFacebookAccessToken(token)
      .then(response => {
        setLoader(false);
        if (response.statusCode === 200) {
          dispatch(getUserProfile(response.data.profile));
          storeItem(AuthCode, response.data.accessToken).then(authCode => {});
          storeItem(AuthToken, response.data.accessToken).then(email => {});
          storeItem(RefreshToken, response.data.refreshToken);
          navigation.navigate('HomeTab', {screen: 'Home'});
        } else {
          showMessage({
            message: 'Error',
            description: response.error
              ? response.error
              : 'Invalid Email, Please try again!',
            type: 'default',
            icon: {icon: 'info', position: 'left'},
            backgroundColor: Colors.red,
          });
        }
      })
      .catch(error => {
        console.log(error);
        setLoader(false);
        showMessage({
          message: 'Error',
          description: 'Invalid email. Please try again.',
          type: 'default',
          icon: {icon: 'info', position: 'left'},
          backgroundColor: Colors.red,
        });
      });
  };
  const goTovideoCallingScreen = () => {
    navigation.navigate('MeetingWithCM');
  };
  return (
    <Fragment>
      <SafeAreaView
        style={{
          backgroundColor: Colors.BgColor,
        }}>
        <View
          style={{
            alignItems: 'center',
            alignSelf: 'center',
            alignContent: 'center',
          }}>
          <Spinner
            visible={loader}
            textContent={'Loading...'}
            textStyle={{color: '#FFF'}}
          />
          <View style={{alignItems: 'center', color: '#E5E5E5'}}>
            <Image
              source={Images.splashForegroundLogo}
              style={{
                marginTop: hp(5),
                height: hp(20),
                width: hp(22),
                resizeMode: 'contain',
              }}
            />

            <Text
              style={{
                fontFamily: Fonts.SourceSansSemibold,
                marginTop: hp(0.5),
                fontSize: hp(2.3),
                color: Colors.black,
              }}>
              Sign in with social Platforms
            </Text>
          </View>

          <View
            style={{
              marginTop: hp(2.6),

              marginBottom: hp(4),
              width: '100%',
              flexDirection: 'row',
              justifyContent: 'space-evenly',
              alignItems: 'center',
            }}>
            <Pressable
              onPress={() => {
                loginWithGoogle()
                  .then(data => {
                    verifyGoogleToken(data.user);
                  })
                  .catch(error => {
                    console.log('ERROR ' + error);
                  });
              }}
              style={{
                width: '22%',
                backgroundColor: Colors.white,
                borderRadius: 30,
                height: hp(5.5),
                shadowOffset: {width: 0.5, height: 0.5},
                shadowOpacity: 0.1,
                shadowRadius: 8,
                elevation: 5,
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Image
                source={Images.google_image}
                style={{
                  // height: hp(2.5),
                  height: hp(3),
                  width: hp(5),
                  resizeMode: 'contain',
                }}
              />
            </Pressable>

            {Platform.OS === 'ios' ? (
              <Pressable
                onPress={() => appleSignIn()}
                style={{
                  width: '22%',
                  backgroundColor: Colors.white,
                  borderRadius: 30,
                  height: hp(5.5),
                  shadowOffset: {width: 0.5, height: 0.5},
                  shadowOpacity: 0.1,
                  shadowRadius: 8,
                  elevation: 5,
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <Image
                  source={Images.apple_image}
                  style={{
                    height: hp(3),
                    width: hp(5),
                    resizeMode: 'contain',
                  }}
                />
              </Pressable>
            ) : null}
          </View>
        </View>
      </SafeAreaView>

      <View
        style={{
          backgroundColor: Colors.backgroundMainLogin,
        }}>
        <View
          style={{
            backgroundColor: Colors.backgroundMainLogin,
            shadowOffset: {width: 0.5, height: 0.5},
            shadowOpacity: 0.5,
            shadowRadius: 1.5,
            elevation: 1,
            borderTopColor: Colors.darkGrey1,
            borderTopRightRadius: 24,
            borderTopLeftRadius: 24,
          }}>
          <ScrollView
            style={{
              borderTopRightRadius: 24,
              borderTopLeftRadius: 24,
              backgroundColor: Colors.white,
            }}
            contentContainerStyle={{
              flexGrow: 1,
              alignItems: 'center',
              alignSelf: 'center',
              alignContent: 'center',
            }}>
            <Text
              style={{
                color: Colors.black,
                fontSize: hp(3),
                marginTop: hp(4),
                alignContent: 'center',
                justifyContent: 'center',
                fontFamily: Fonts.SourceSansBold,
              }}>
              {' '}
              Sign in Now
            </Text>
            <Text
              style={{
                color: Colors.darkGrey,
                fontSize: hp(2.1),
                paddingHorizontal: hp(6),
                marginTop: hp(2.2),
                fontFamily: Fonts.SourceSansRegular,
                textAlign: 'center',
              }}>
              Select an Option to Sign In. You can Sign in from Phone or Email
            </Text>

            <View
              style={{
                flexDirection: 'row',
                marginTop: hp(2),
                justifyContent: 'space-evenly',
                alignItems: 'center',
                alignSelf: 'center',
                width: '100%',
              }}>
              <Pressable onPress={() => navigation.navigate('EmailScreen')}>
                <SignInButton
                  image={Images.homeIconProfileSignUpEmailIcon}
                  text="Email"
                />
              </Pressable>

              <Pressable onPress={() => navigation.navigate('PhoneScreen')}>
                <SignInButton image={Images.phoneIcon} text="Phone" />
              </Pressable>
            </View>
            <View
              style={{
                flexDirection: 'row',
                backgroundColor: Colors.white,
                marginTop: Platform.OS == 'ios' ? hp(11) : hp(13.2),
                marginBottom: hp(10),
                width: '100%',
                // alignItems: 'flex-start',
                // justifyContent: 'center',
              }}>
              <Text
                style={{
                  fontFamily: Fonts.SourceSansRegular,
                  fontSize: hp(2.5),
                  color: Colors.black4,
                }}>
                Can't access your account?
              </Text>
              <Pressable
                onPress={() => {
                  Linking.openURL('mailto:helpdesk@wisemani.com');
                }}>
                <Text
                  style={{
                    textAlign: 'center',
                    fontFamily: Fonts.SourceSansSemibold,
                    fontSize: hp(2.5),
                    color: Colors.blueTextColor,
                    marginLeft: hp(1),
                  }}>
                  Contact Us
                </Text>
              </Pressable>
            </View>
          </ScrollView>
        </View>
      </View>
      {/* Sign In Part */}
    </Fragment>
  );
};
export default Login;
