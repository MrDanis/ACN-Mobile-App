import React, {useRef, useState} from 'react';
import {Image, SafeAreaView, StyleSheet, Text, View, TouchableOpacity} from 'react-native';
import AppIntroSlider from 'react-native-app-intro-slider';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import {useDispatch} from 'react-redux';
import colors from '../../../../config/Colors';
import {modalHanlder} from '../../medication/actions';
const slides = [
  {
    key: '1',
    title: 'Dashboard',
    text: 'Access your personalized dashboard to view all your health metrics and updates in one place.',
    image: require('../../../../../assets/images/dashboardIntro.png'),
    backgroundColor: '#febe29',
  },
  {
    key: '2',
    title: 'Widgets',
    text: 'Choose your preferred widgets and customize your dashboard for a personalized experience.',
    image: require('../../../../../assets/images/widgetsIntro.png'),
    backgroundColor: '#22bcb5',
  },
  {
    key: '3',
    title: 'Appointment',
    text: 'Schedule and manage your appointments with healthcare providers easily.',
    image: require('../../../../../assets/images/appointmentIntro.png'),
    backgroundColor: '#59b2ab',
  },
  {
    key: '4',
    title: 'Blood Pressure',
    text: 'Select the option and click on the severity of your feelings',
    image: require('../../../../../assets/images/BloodpressureIntro.png'),
    backgroundColor: '#59b2ab',
  },
  {
    key: '5',
    title: 'Pulse Rate',
    text: 'Select the option and click on the severity of your pulse rate to log your data.',
    image: require('../../../../../assets/images/pulseRateIntro.png'),
    backgroundColor: '#59b2ab',
  },
];
 
const AppIntro = ({onDone, onSkip}) => {
  const sliderRef = useRef(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const dispatch = useDispatch();
  dispatch(modalHanlder(false));
  const _renderItem = ({item}) => {
    return (
      <View
        style={{
          flex: 1,
          alignItems: 'center',
          borderColor: 'red',
          backgroundColor: 'white',
        }}>
        <Text
          style={{
            fontSize: 24,
            color: 'black',
            fontWeight: 'bold',
            textAlign: 'center',
            marginBottom: hp(2),
            marginTop: hp(2),
          }}>
          {item.title}
        </Text>
        <Text
          style={{
            fontSize: 16,
            color: 'black',
            textAlign: 'center',
            paddingHorizontal: 30,
            width: wp('82%'),
            marginBottom: hp(2),
          }}>
          {item.text}
        </Text>
        <Image
          source={item.image}
          style={{
            height: hp(68),
            marginBottom: 20,
          }}
          resizeMode="contain"
        />
      </View>
    );
  };
  const renderNextButton = () => {
    return (
      <View style={{marginRight: wp(3)}}>
        <Text
          style={{
            color: colors.garyLight,
            fontSize: 16,
            fontWeight: 'bold',
          }}>
          Next
        </Text>
      </View>
    );
  };
 
  const renderDoneButton = () => {
    return (
      <View style={{marginRight: wp(3)}}>
        <Text
          style={{color: colors.garyLight, fontSize: 16, fontWeight: 'bold'}}>
          Done
        </Text>
      </View>
    );
  };
  const renderBackButton = () => {
    return (
      <View style={{marginLeft: wp(3)}}>
        <Text
          style={{color: colors.garyLight, fontSize: 16, fontWeight: 'bold'}}>
          Back
        </Text>
      </View>
    );
  };
  const onSlideChange = index => {
    setCurrentIndex(index);
  };
  const renderPagination = activeIndex => {
    return (
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          paddingVertical: hp(1),
          borderColor: 'yellow',
        }}>
        <View
          style={{
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            flex: 0.3,
          }}>
          {currentIndex > 0 && (
            <TouchableOpacity
              onPress={() => {
                sliderRef.current.goToSlide(currentIndex - 1);
                setCurrentIndex(currentIndex - 1);
              }}>
              {renderBackButton()}
            </TouchableOpacity>
          )}
        </View>
 
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            flex: 0.3,
          }}>
          {slides.map((_, i) => (
            <View
              key={i}
              style={[
                styles.dot,
                i === activeIndex ? styles.activeDot : styles.inactiveDot,
              ]}
            />
          ))}
        </View>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'flex-end',
            flex: 0.3,
          }}>
          <TouchableOpacity
            onPress={() => {
              if (currentIndex === slides.length - 1) {
                onDone();
              } else {
                sliderRef.current.goToSlide(currentIndex + 1);
                setCurrentIndex(currentIndex + 1);
              }
            }}>
            {currentIndex === slides.length - 1
              ? renderDoneButton()
              : renderNextButton()}
          </TouchableOpacity>
        </View>
      </View>
    );
  };
 
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: 'white'}}>
      <TouchableOpacity onPress={() => onSkip()}>
        <Text
          style={{
            alignSelf: 'flex-end',
            marginRight: wp(3),
            marginTop: hp(1),
 
            color: colors.TextColor,
            fontSize: hp(1.9),
            fontWeight: '500',
          }}>
          Skip All
        </Text>
      </TouchableOpacity>
      <AppIntroSlider
        ref={sliderRef}
        renderItem={_renderItem}
        data={slides}
        renderPagination={renderPagination}
        onSlideChange={onSlideChange}
      />
    </SafeAreaView>
  );
};
 
const styles = StyleSheet.create({
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginHorizontal: 4,
  },
  activeDot: {
    backgroundColor: 'white',
  },
  inactiveDot: {
    backgroundColor: 'gray',
  },
});
export default AppIntro;