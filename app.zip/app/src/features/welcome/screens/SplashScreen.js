/* istanbul ignore file */
import moment from 'moment';
import React, {Fragment, useEffect, useState} from 'react';
import {
  Image,
  ImageBackground,
  Platform,
  Pressable,
  SafeAreaView,
  Text,
  View,
} from 'react-native';
import {TouchableOpacity} from 'react-native-gesture-handler';
// import LocalAuth from 'react-native-local-auth';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {useDispatch} from 'react-redux';
// import LocalAuthentication from 'rn-local-authentication';
import Colors from '../../../../config/Colors';
import Images from '../../../../config/Images';
import ProfileService from '../../../api/profile';
import {requestAndHandleBiometricPermission} from '../../../helpers/Common';
import {
  getBloodPressureHK,
  getDistanceWalkingFromHK,
  getHeartRateHK,
  getSleepSamplesHK,
  getStepCountFromHK,
  getWeightHK,
} from '../../../helpers/HealthKit/HealthKitHandler';
import {
  AuthCode,
  AuthToken,
  BlueButtonAccessToken,
  BlueButtonRefreshToken,
  removeItemValue,
  retrieveItem,
  retrieveValue,
  storeItem,
  storeValue,
} from '../../../helpers/LocalStorage';
import {signOut} from '../../../helpers/SocailLoginHelper';
import {
  getAllergiesHistory,
  getCoverageHistory,
  getDiseasesHistory,
  getHospitalVisitHistory,
  getMedicationHistory,
  getProceduresHistory,
  getProviderHistory,
} from '../../bluebutton/action';
import {getHomeApiData} from '../../home/action';
import {
  setDistanceLive,
  setHeartLive,
  setSpeedLive,
  setStepsLive,
  setWeightLive,
} from '../action';
import {
  startGoogleFit,
  checkGoogleFitAppInstalled,
  getTodaySteps,
} from '../../../helpers/GoogleFit/GoogleFitHandler';

function SplashScreen({navigation}) {
  const dispatch = useDispatch();
  const [authTypes, setAuthTypes] = useState('');
  const [isAuthEnabled, setIsAuthEnabled] = useState(false);
  const proceedToApiCalling = () => {
    retrieveItem(AuthCode).then(authCode => {
      if (authCode === undefined || authCode === null) {
        navigation.navigate('LoginScreen');
      } else {
        // get the auth token if the token is not undefine then preform the below code
        retrieveItem(AuthToken)
          .then(res => {
            if (res === undefined || res === null) {
              navigation.navigate('LoginScreen');
            } else {
              ProfileService.getUserProfile()
                .then(response => {
                  console.log('getUserProfile in splash', response);

                  if (
                    response &&
                    response.statusCode === 200 &&
                    response.data
                  ) {
                    console.log('FirstName', response.data.firstName);
                    console.log('LastName', response.data.lastName);
                    console.log('DOB', response.data.dateOfBirth);
                    console.log('Gender', response.data.gender);
                    if (
                      response.data.firstName !== '' &&
                      response.data.firstName !== null &&
                      response.data.lastName !== '' &&
                      response.data.lastName !== null &&
                      response.data.gender !== 0 &&
                      response.data.gender !== '0' &&
                      response.data.gender !== '' &&
                      response.data.gender !== null &&
                      response.data.dateOfBirth !== '01/01/1900 00:00:00' &&
                      response.data.dateOfBirth !== null
                    ) {
                      navigation.navigate('HomeTab');
                    } else {
                      navigation.navigate('EditProfile', {
                        profileDetails: response.data,
                        screenName: 'splash',
                      });
                    }
                  }
                })
                .catch(error => {
                  console.log('error in fetching token ', error);
                });
              navigation.navigate('HomeTab');
            }
            console.log('this is the testing code : ', res);
          })
          .catch(err => {
            console.log('Error in fetching code : ', err);
            navigation.navigate('LoginScreen');
          });
      }
    });
  };
  const clearStoreData = () => {
    dispatch(getMedicationHistory([]));
    dispatch(getProviderHistory([]));
    dispatch(getHospitalVisitHistory([]));
    dispatch(getDiseasesHistory([]));
    dispatch(getCoverageHistory([]));
    dispatch(getAllergiesHistory([]));
    dispatch(getProceduresHistory([]));
    dispatch(getHomeApiData({}));
  };
  const handleLogoutPress = () => {
    ProfileService.userLogout()
      .then(res => {
        clearStoreData();
      })
      .catch(err => {
        console.log('userLogoutError');
        console.log(err);
      });
    signOut();
    removeItemValue('isAcoUserLogin');
    removeItemValue('authCode');
    removeItemValue('authToken');
    removeItemValue('userEmail');
    removeItemValue('isEmailORPhone');
    removeItemValue('drawOverlay');
    removeItemValue('refreshToken');
    storeItem(BlueButtonAccessToken, '');
    storeItem(BlueButtonRefreshToken, '');
    storeValue('isAuthEnabled', 'false');
    navigation.navigate('LoginScreen');
  };
  const authenticate = () => {
    //change made
    console.log('inside authenticate fun');
    retrieveItem(AuthCode).then(authCode => {
      if (authCode === undefined || authCode === null) {
        navigation.navigate('LoginScreen');
      } else {
        // if (Platform.OS === 'ios') {
        //   FingerprintScanner.isSensorAvailable()
        //     .then(res => {
        //       LocalAuthentication.authenticateAsync({
        //         reason: 'Please, authenticate!',
        //         fallbackEnabled: true,
        //         fallbackTitle: 'Use PassCode',
        //         fallbackToPinCodeAction: true,
        //       }).then(response => {
        //         if (response.success) {
        //           proceedToApiCalling();
        //         }
        //       });
        //     })
        //     .catch(err => {
        //       console.log('Error checking biometric availability', err);
        //       err = String(err);
        //       const parts = err.split(':');
        //       if (parts[0].trim() === 'FingerprintScannerNotAvailable') {
        //         console.log('FingerprintScanner Permission Not Available');
        //         requestAndHandleBiometricPermission()
        //           .then(res => {
        //             console.log('res', res);
        //           })
        //           .catch(err => {
        //             console.log('err', err);
        //           });
        //       }
        //     });
        // } else if (Platform.OS === 'android') {
        //   FingerprintScanner.isSensorAvailable()
        //     .then(res => {
        //       LocalAuth.authenticate({
        //         reason: 'Please Authenticate yourself',
        //         fallbackToPasscode: true, // fallback to passcode on cancel
        //         suppressEnterPassword: true, // disallow Enter Password fallback
        //       })
        //         .then(success => {
        //           proceedToApiCalling();
        //         })
        //         .catch(error => {
        //           console.log('error', error);
        //         });
        //     })
        //     .catch(error => {
        //       console.log('Error checking biometric availability', error);
        //     });
        // }
      }
    });
  };

  useEffect(() => {
    setTimeout(() => {
      // FingerprintScanner.isSensorAvailable()
      //   .then(res => {
      //     setAuthTypes(res);
      //   })
      //   .catch(err => console.log('error getting type', err));
      // HealthKitPermissions();
      if (Platform.OS === 'ios') {
        getWeightHK()
          .then(res => {
            if (res && res.length > 0) {
              dispatch(setWeightLive(res[0]?.value)); //distance comes
            }
          })
          .catch(err => {
            console.log('err from hk weight', err);
          });
        getDistanceWalkingFromHK()
          .then(results => {
            // Handle the resolved results here

            let startTime = moment(results?.startDate);
            let endTime = moment(results?.endDate);
            let difference = Math.ceil(
              endTime.valueOf() / 1000 - startTime.valueOf() / 1000,
            ); //time in second
            let distanceCovered = Math.ceil(
              results.value / 1000 / (difference / 3600),
            );
            dispatch(setDistanceLive(results.value)); //distance comes
            dispatch(setSpeedLive(distanceCovered));
            // Do something with the results in your homeScreen component
          })
          .catch(error => {
            // Handle any errors that occurred during the execution of x() here
            console.error('Error calling x:', error);
          })
          .finally(() => {
            console.debug('came back');
          });
        getStepCountFromHK()
          .then(results => {
            // Handle the resolved results here

            dispatch(setStepsLive(results.value));

            // Do something with the results in your homeScreen component
          })
          .catch(error => {
            // Handle any errors that occurred during the execution of x() here
            console.error('Error calling x:', error);
          });
        getHeartRateHK()
          .then(results => {
            // Handle the resolved results here

            dispatch(
              setHeartLive({
                value: results[0]?.value,
                time: results[0]?.startDate,
              }),
            );

            // Do something with the results in your homeScreen component
          })
          .catch(error => {
            // Handle any errors that occurred during the execution of x() here
            console.error('Error calling x:', error);
          });
        getBloodPressureHK()
          .then(results => {})
          .catch(error => {
            // Handle any errors that occurred during the execution of x() here
            console.error('Error calling x:', error);
          });
      } else {
        try {
          getTodaySteps();
        } catch (error) {
          console.log('This is the test : ', error);
        }
      }
      retrieveValue('isAuthEnabled')
        .then(res => {
          if (res === undefined || res === null) {
            storeValue('isAuthEnabled', 'false');
            authenticate();
          } else if (JSON.parse(res) === true) {
            setIsAuthEnabled(true);
            authenticate();
          } else if (JSON.parse(res) === false) {
            proceedToApiCalling();
          }
        })
        .catch(err => {
          console.log('error', err);
        });
    }, 3000);
  });

  return (
    <Fragment>
      <Pressable
        style={{flex: 1}}
        onPress={() => {
          console.log('====================================');
          console.log('pressed');
          console.log('====================================');
          retrieveValue('isAuthEnabled')
            .then(res => {
              if (res === undefined || res === null) {
                storeValue('isAuthEnabled', 'false');
                authenticate();
              } else if (JSON.parse(res) === true) {
                setIsAuthEnabled(true);
                authenticate();
              } else if (JSON.parse(res) === false) {
                proceedToApiCalling();
              }
            })
            .catch(err => {
              console.log('error', err);
            });
        }}>
        <SafeAreaView onP style={{flex: 1}}>
          <View
            style={{
              flex: 1,
              backgroundColor: Colors.white,
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <View
              style={{
                height: hp('65%'),
                borderColor: 'yellow',
                justifyContent: 'center',
              }}>
              <ImageBackground
                source={Images.splashBackGroundImage}
                style={{
                  alignContent: 'center',
                  alignSelf: 'center',
                  // marginTop:hp(10),
                  // marginBottom: hp(10),
                  marginRight: hp(6),
                  height: hp(60),
                  width: hp(50),
                }}
                resizeMode="contain">
                <Image
                  source={Images.splashForegroundLogo}
                  style={{
                    marginLeft: hp(3),
                    height: hp(65),
                    width: hp(25),
                    resizeMode: 'contain',
                    alignSelf: 'center',
                  }}></Image>
              </ImageBackground>
            </View>
            {isAuthEnabled === true ? (
              <View
                style={{
                  minWidth: hp(25),
                  position: 'relative',
                  top: hp(8),
                }}>
                <TouchableOpacity
                  onPress={() => {
                    console.log('pressed');
                    authenticate();
                  }}
                  style={{
                    backgroundColor: Colors.regularLabel,
                    borderRadius: hp(1),
                  }}>
                  <Text
                    style={{
                      color: Colors.white,
                      alignSelf: 'center',
                      paddingVertical: hp(1.5),
                      paddingHorizontal: hp(9),
                      fontSize: hp(2.2),
                    }}>
                    Use {Platform.OS === 'ios' ? authTypes : 'FingerPrint'}
                  </Text>
                </TouchableOpacity>
                <View style={{paddingVertical: hp(1)}}>
                  <Text
                    onPress={handleLogoutPress}
                    style={{
                      textAlign: 'center',
                      marginBottom: hp(1),
                      textDecorationLine: 'underline',
                      color: Colors.blueTextColor,
                    }}>
                    Logout
                  </Text>
                </View>
              </View>
            ) : (
              <View></View>
            )}
          </View>
        </SafeAreaView>
      </Pressable>
    </Fragment>
  );
}

export default SplashScreen;
